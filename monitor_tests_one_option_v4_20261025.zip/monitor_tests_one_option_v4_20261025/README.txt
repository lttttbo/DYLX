Monitor v4：测试统一一个编译开关 / 2026-10-25

本包是 monitor_hv_tests_v4_20261025 的增量，只有一份 single_option.patch。
尚未合入上一份 Hypervisor 测试包时，先按上一包合入，再使用本包简化配置。
本包含修改后的完整文件、按函数/配置位置的手工合入说明和验证报告。

测试只保留 CONFIG_WBOXTEST_MONITOR=y。
删去 HOST、LIVE 两个子开关及子目录编译列表，统一由 monitor/objects.mk 构建。
已有 monitor 产品功能及 wboxtest 框架仍需启用；memory 和 wboxtest 命令由测试选项自动选择。

按当前“先做 Hypervisor 测试”的范围，monitor 组固定运行 9 项：
原 6 项隔离测试 + monitor_host_range、monitor_host_guest_guard、monitor_host_shmem。
Guest 现场用例源码保留，本阶段不编译、不注册，也不会作为跳过的 PASS。
无需 monitor_live target 或 Guest 用户态测试程序。日志人工检查。
Guest 写保护测试仍需已有符合检查条件的 Guest 映射；没有条件会明确失败。

运行：
monitor start
wboxtest run_groups 1 monitor

完整步骤见 guide.md；手工合入见 merge_locations.txt。
删除补丁列出的旧 objects.mk/openconf.cfg，避免递归扫描仍带入旧对象；不要删除其他私有文件。
重新生成配置，旧 HOST/LIVE 值不再生效；量产只需关闭 CONFIG_WBOXTEST_MONITOR 测试项。

已验证单开关开启/关闭的 11 次 ARM64 编译；开启时无重复全局定义，关闭时测试接口消失；
54 次原隔离执行、360 组命令行为对照、新三个用例模型及漏记/错误类型/采样异常反例通过。
补丁应用、反向还原和文件校验通过；未进行私有固件完整链接或板卡执行。
