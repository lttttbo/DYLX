/* SPDX-License-Identifier: GPL-2.0 */
/* Diagnostic only. Include ONCE per participating module/translation unit.
 * Independently included in CCM ioeventfd.c and vhost/net.c: NOT shared state.
 * No new module_init, no hot-path printk, no allocation inside hooks.
 * Counts every selected completed call; elapsed time sampled 1/(2^n4_shift).
 * Times are wall-clock elapsed time, including preemption; not CPU cycles.
 */
#ifndef _NOTIFY_ROUND4_PROBE_H
#define _NOTIFY_ROUND4_PROBE_H
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/percpu.h>
#include <linux/cpu.h>
#include <linux/smp.h>
#include <linux/spinlock.h>
#include <linux/mutex.h>
#include <linux/ktime.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/math64.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/log2.h>
#include <linux/string.h>

#define N4_PHASES 4 /* elapsed, begin->mark0, mark0->mark1, mark1->mark2 */
#define N4_BINS 20 /* <1us, [1,2)us, [2,4)us, ..., >=262144us */
struct n4_dist { u64 n, sum, max, bin[N4_BINS]; };
struct n4_data {
 u64 begins, ends, units, errors, migrated;
 u64 batch[6]; /* units == 0,1,2-4,5-16,17-64,>64 */
 u64 origin[2]; /* integration-defined: vhost kick or backend readiness */
 u64 state[4], state_changes;
 bool state_valid;
 struct n4_dist d[N4_PHASES];
};
struct n4_token {
 bool active, sample;
 u64 epoch, start, mark[3];
 unsigned int cpu;
 unsigned int marks;
 u64 state[4];
 bool state_valid;
 unsigned int origin; /* 0 unset; 1 kick; 2 backend readiness */
};
static DEFINE_PER_CPU(struct n4_data, n4_stats);
static DEFINE_PER_CPU(raw_spinlock_t, n4_locks) = __RAW_SPIN_LOCK_UNLOCKED(n4_locks);
static DEFINE_MUTEX(n4_ctl);
static bool n4_enabled;
static u64 n4_epoch, n4_start_ns, n4_stop_ns;
static unsigned int n4_shift = 10;
static int n4_tid; /* 0 = all; recommended to set current target TID before start */
static unsigned long long n4_addr; /* CCM only, 0 = no address filter */
module_param_named(n4_addr, n4_addr, ullong, 0600);
module_param_named(n4_tid, n4_tid, int, 0600);
module_param_named(n4_shift, n4_shift, uint, 0600);
MODULE_PARM_DESC(n4_tid, "Debug current-task filter; 0=all. Change only while stopped");
MODULE_PARM_DESC(n4_addr, "CCM actual MMIO address filter; 0=all. Change only while stopped");
MODULE_PARM_DESC(n4_shift, "Timing sample log2, 0..20; 21=count only. Change only while stopped");

static bool n4_selected(void)
{
 int tid = READ_ONCE(n4_tid);
 return smp_load_acquire(&n4_enabled) && !in_nmi() &&
        (tid == 0 || (tid > 0 && task_pid_nr(current) == tid));
}
static struct n4_token n4_begin(bool select)
{
 struct n4_token t = { 0 };
 struct n4_data *d;
 raw_spinlock_t *l;
 unsigned long flags;
 unsigned int shift;
 if (!select || !n4_selected()) return t;
 local_irq_save(flags);
 t.cpu = raw_smp_processor_id();
 l = this_cpu_ptr(&n4_locks);
 raw_spin_lock(l);
 if (!READ_ONCE(n4_enabled)) goto out;
 d = this_cpu_ptr(&n4_stats);
 t.active = true;
 t.epoch = READ_ONCE(n4_epoch);
 shift = READ_ONCE(n4_shift);
 t.sample = shift <= 20 && ((d->begins & ((1ULL << shift) - 1)) == 0);
 d->begins++;
out:
 raw_spin_unlock(l);
 local_irq_restore(flags);
 if (t.sample) t.start = ktime_get_ns();
 return t;
}
static __maybe_unused void n4_state(struct n4_token *t, u64 a, u64 b, u64 c, u64 d,
                                  unsigned int origin)
{
 if (!t->active) return;
 t->state[0]=a; t->state[1]=b; t->state[2]=c; t->state[3]=d;
 t->state_valid=true; t->origin=origin;
}
static __maybe_unused void n4_mark(struct n4_token *t, unsigned int i)
{
 if (t->sample && i < 3) {
   t->mark[i] = ktime_get_ns(); t->marks |= 1U << i;
 }
}
static void n4_add_dist(struct n4_dist *d, u64 ns)
{
 u64 us = div_u64(ns, 1000);
 unsigned int b = us ? min_t(unsigned int, fls64(us), N4_BINS-1) : 0;
 d->n++; d->sum += ns; d->max = max(d->max, ns); d->bin[b]++;
}
static void n4_end(struct n4_token *t, u64 units, int error)
{
 unsigned long flags;
 unsigned int cpu, b;
 struct n4_data *d;
 raw_spinlock_t *l;
 u64 end;
 if (!t->active || !READ_ONCE(n4_enabled)) return;
 end = t->sample ? ktime_get_ns() : 0;
 local_irq_save(flags);
 cpu = raw_smp_processor_id(); l = this_cpu_ptr(&n4_locks);
 raw_spin_lock(l);
 if (!READ_ONCE(n4_enabled) || t->epoch != READ_ONCE(n4_epoch)) goto out;
 d = this_cpu_ptr(&n4_stats);
 d->ends++; d->units += units; d->errors += error != 0;
 d->migrated += cpu != t->cpu;
 if (t->origin >= 1 && t->origin <= 2) d->origin[t->origin-1]++;
 if (t->state_valid) {
   if (!d->state_valid) {
     memcpy(d->state,t->state,sizeof(d->state)); d->state_valid=true;
   } else if (memcmp(d->state,t->state,sizeof(d->state))) d->state_changes++;
 }
 b = units == 0 ? 0 : units == 1 ? 1 : units <= 4 ? 2 :
     units <= 16 ? 3 : units <= 64 ? 4 : 5;
 d->batch[b]++;
 if (t->sample) {
   n4_add_dist(&d->d[0], end-t->start);
   if (t->marks & 1) n4_add_dist(&d->d[1], t->mark[0]-t->start);
   if ((t->marks & 3) == 3) n4_add_dist(&d->d[2], t->mark[1]-t->mark[0]);
   if ((t->marks & 6) == 6) n4_add_dist(&d->d[3], t->mark[2]-t->mark[1]);
 }
out:
 raw_spin_unlock(l); local_irq_restore(flags);
 t->active = false;
}
static void n4_drain(void)
{
 unsigned long flags;
 int cpu;
 WRITE_ONCE(n4_enabled, false);
 for_each_possible_cpu(cpu) {
   raw_spinlock_t *l=&per_cpu(n4_locks,cpu);
   raw_spin_lock_irqsave(l,flags);
   raw_spin_unlock_irqrestore(l,flags);
 }
}
static int n4_run_set(const char *s, const struct kernel_param *kp)
{
 bool on;
 int cpu, rc=kstrtobool(s,&on);
 unsigned long flags;
 if (rc) return rc;
 mutex_lock(&n4_ctl);
 if (on && (READ_ONCE(n4_tid) < 0 || READ_ONCE(n4_shift) > 21)) {
   mutex_unlock(&n4_ctl); return -EINVAL;
 }
 n4_drain();
 if (!on) { if (!n4_stop_ns) n4_stop_ns=ktime_get_ns(); }
 else {
   WRITE_ONCE(n4_epoch,n4_epoch+1);
   for_each_possible_cpu(cpu) {
     raw_spinlock_t *l=&per_cpu(n4_locks,cpu);
     raw_spin_lock_irqsave(l,flags);
     memset(&per_cpu(n4_stats,cpu),0,sizeof(struct n4_data));
     raw_spin_unlock_irqrestore(l,flags);
   }
   n4_start_ns=ktime_get_ns(); n4_stop_ns=0;
   smp_store_release(&n4_enabled,true);
 }
 mutex_unlock(&n4_ctl); return 0;
}
static int n4_run_get(char *buf, const struct kernel_param *kp)
{ return scnprintf(buf,PAGE_SIZE,"%u\n",READ_ONCE(n4_enabled)); }
static void n4_merge(struct n4_data *a, const struct n4_data *b)
{
 unsigned int i,j;
 a->begins+=b->begins; a->ends+=b->ends; a->units+=b->units;
 a->errors+=b->errors; a->migrated+=b->migrated;
 for(i=0;i<6;i++) a->batch[i]+=b->batch[i];
 for(i=0;i<2;i++) a->origin[i]+=b->origin[i];
 a->state_changes+=b->state_changes;
 if (b->state_valid) {
   if (!a->state_valid) { memcpy(a->state,b->state,sizeof(a->state)); a->state_valid=true; }
   else if (memcmp(a->state,b->state,sizeof(a->state))) a->state_changes++;
 }
 for(i=0;i<N4_PHASES;i++) {
  a->d[i].n+=b->d[i].n; a->d[i].sum+=b->d[i].sum;
  a->d[i].max=max(a->d[i].max,b->d[i].max);
  for(j=0;j<N4_BINS;j++) a->d[i].bin[j]+=b->d[i].bin[j];
 }
}
static int n4_report_get(char *buf, const struct kernel_param *kp)
{
 struct n4_data *a;
 int cpu,n=0;
 unsigned int i,j;
 static const char *const names[]={"elapsed","begin_to_mark0","mark0_to_mark1","mark1_to_mark2"};
 mutex_lock(&n4_ctl);
 if (READ_ONCE(n4_enabled)) { n=-EBUSY; goto unlock; }
 a=kzalloc(sizeof(*a),GFP_KERNEL);
 if(!a) { n=-ENOMEM; goto unlock; }
 for_each_possible_cpu(cpu) n4_merge(a,&per_cpu(n4_stats,cpu));
 n+=scnprintf(buf+n,PAGE_SIZE-n,"# n4 v1 start_ns=%llu stop_ns=%llu epoch=%llu tid=%d addr=0x%llx shift=%u\n",
 (unsigned long long)n4_start_ns,(unsigned long long)n4_stop_ns,
 (unsigned long long)n4_epoch,READ_ONCE(n4_tid),READ_ONCE(n4_addr),READ_ONCE(n4_shift));
 n+=scnprintf(buf+n,PAGE_SIZE-n,"COUNT,begins=%llu,ends=%llu,units=%llu,errors=%llu,migrated=%llu\n",
 (unsigned long long)a->begins,(unsigned long long)a->ends,(unsigned long long)a->units,
 (unsigned long long)a->errors,(unsigned long long)a->migrated);
 n+=scnprintf(buf+n,PAGE_SIZE-n,"BATCH,zero=%llu,one=%llu,two_to_four=%llu,five_to_16=%llu,17_to_64=%llu,gt64=%llu\n",
 (unsigned long long)a->batch[0],(unsigned long long)a->batch[1],(unsigned long long)a->batch[2],
 (unsigned long long)a->batch[3],(unsigned long long)a->batch[4],(unsigned long long)a->batch[5]);
 n+=scnprintf(buf+n,PAGE_SIZE-n,"# DIST,name,samples,avg_ns,max_ns; HIST has 20 exponential-us bins, final bin >=262144us\n");
 for(i=0;i<N4_PHASES;i++) {
  struct n4_dist *d=&a->d[i];
  if (PAGE_SIZE-n < 700) { n+=scnprintf(buf+n,PAGE_SIZE-n,"# TRUNCATED\n"); break; }
  n+=scnprintf(buf+n,PAGE_SIZE-n,"DIST,%s,%llu,%llu,%llu\n",names[i],
   (unsigned long long)d->n,(unsigned long long)(d->n ? div64_u64(d->sum,d->n):0),
   (unsigned long long)d->max);
  n+=scnprintf(buf+n,PAGE_SIZE-n,"HIST,%s",names[i]);
  for(j=0;j<N4_BINS;j++) n+=scnprintf(buf+n,PAGE_SIZE-n,",%llu",(unsigned long long)d->bin[j]);
  n+=scnprintf(buf+n,PAGE_SIZE-n,"\n");
 }
 if(a->state_valid) n+=scnprintf(buf+n,PAGE_SIZE-n,
  "CONFIG,event_idx=%llu,packed=%llu,busyloop_us=%llu,ring_size=%llu,changes=%llu\n",
  (unsigned long long)a->state[0],(unsigned long long)a->state[1],
  (unsigned long long)a->state[2],(unsigned long long)a->state[3],
  (unsigned long long)a->state_changes);
 n+=scnprintf(buf+n,PAGE_SIZE-n,"ORIGIN,kick=%llu,backend_ready=%llu\n",
  (unsigned long long)a->origin[0],(unsigned long long)a->origin[1]);
 for_each_possible_cpu(cpu) {
  struct n4_data *d=&per_cpu(n4_stats,cpu);
  if (!d->begins && !d->ends) continue;
  if (PAGE_SIZE-n<150) { n+=scnprintf(buf+n,PAGE_SIZE-n,"# CPU_ROWS_TRUNCATED\n"); break; }
  n+=scnprintf(buf+n,PAGE_SIZE-n,"CPU,%d,begins=%llu,ends=%llu,units=%llu\n",cpu,
   (unsigned long long)d->begins,(unsigned long long)d->ends,(unsigned long long)d->units);
 }
 kfree(a);
unlock:
 mutex_unlock(&n4_ctl); return n;
}
static const struct kernel_param_ops n4_run_ops={.set=n4_run_set,.get=n4_run_get};
static const struct kernel_param_ops n4_report_ops={.get=n4_report_get};
module_param_cb(n4_run,&n4_run_ops,NULL,0600);
module_param_cb(n4_report,&n4_report_ops,NULL,0400);
#endif
