#!/usr/bin/env python3
"""Pair filtered ftrace waking/wakeup/next-switch events, no guessed boundaries.
Wall elapsed times, not pure IPI service times. Records partial wakeup->run pairs
separately. Refuses to summarize when ring-buffer overruns/loss are detected.
"""
from __future__ import annotations
import argparse
import csv
import json
import re
import statistics
from decimal import Decimal
from pathlib import Path

EVENT = re.compile(r'\[(\d+)\].*?\s(\d+\.\d+):\s+(sched_waking|sched_wakeup|sched_switch):\s*(.*)$')
WAKE_PID = re.compile(r'\bpid=(\d+)\b')
NEXT_PID = re.compile(r'\bnext_pid=(\d+)\b')
LOSS = re.compile(r'^\s*(?:overrun|commit overrun|dropped events)\s*:\s*(\d+)', re.M)


def percentile(values: list[int], pct: float) -> float | None:
    if not values:
        return None
    xs = sorted(values)
    position = (len(xs) - 1) * pct / 100
    lower = int(position)
    upper = min(lower + 1, len(xs) - 1)
    return (xs[lower] + (xs[upper] - xs[lower]) * (position - lower)) / 1000


def pair_events(text: str, tids: set[int]) -> tuple[list[dict], dict]:
    pending: dict[int, dict] = {}
    result: list[dict] = []
    diag = dict(parsed_events=0, duplicate_waking=0, duplicate_wakeup=0,
                incomplete_end=0, switch_without_pending=0, negative_intervals=0)
    last_stamp = -1
    for line in text.splitlines():
        m = EVENT.search(line)
        if not m:
            continue
        cpu, stamp, event, body = m.groups()
        ns = int(Decimal(stamp) * 1_000_000_000)
        if ns < last_stamp:
            raise ValueError('Trace timestamp decreased; check clock/trace integrity')
        last_stamp = ns
        pid_match = (NEXT_PID if event == 'sched_switch' else WAKE_PID).search(body)
        if not pid_match:
            continue
        tid = int(pid_match.group(1))
        if tid not in tids:
            continue
        diag['parsed_events'] += 1
        if event == 'sched_waking':
            if tid in pending:
                diag['duplicate_waking'] += 1
            # A new waking supersedes an unfinished pairing; never reuse its old timestamp.
            pending[tid] = {'tid': tid, 'waking_ns': ns, 'wakeup_ns': None,
                            'source_cpu': int(cpu), 'wakeup_cpu': None}
        elif event == 'sched_wakeup':
            rec = pending.setdefault(tid, {'tid': tid, 'waking_ns': None,
                         'wakeup_ns': None, 'source_cpu': None, 'wakeup_cpu': None})
            if rec['wakeup_ns'] is not None:
                diag['duplicate_wakeup'] += 1
                # A second wakeup without switch makes this cycle ambiguous.
                rec['waking_ns'] = None
            rec['wakeup_ns'] = ns
            rec['wakeup_cpu'] = int(cpu)
        else:
            rec = pending.pop(tid, None)
            if rec is None:
                diag['switch_without_pending'] += 1
                continue
            if rec['wakeup_ns'] is None:
                # Possibly boundary/missing event: do not invent activation time.
                continue
            rec['switch_ns'] = ns
            rec['run_cpu'] = int(cpu)
            rec['runnable_to_run_ns'] = ns - rec['wakeup_ns']
            rec['waking_to_wakeup_ns'] = None if rec['waking_ns'] is None else rec['wakeup_ns'] - rec['waking_ns']
            rec['waking_to_run_ns'] = None if rec['waking_ns'] is None else ns - rec['waking_ns']
            if any(rec[k] is not None and rec[k] < 0 for k in
                   ('runnable_to_run_ns', 'waking_to_wakeup_ns', 'waking_to_run_ns')):
                diag['negative_intervals'] += 1
                continue
            result.append(rec)
    diag['incomplete_end'] = len(pending)
    return result, diag


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('directory', type=Path)
    ap.add_argument('tids', type=int, nargs='+')
    args = ap.parse_args()
    text = (args.directory / 'trace.txt').read_text(errors='replace')
    losses = {p.name: sum(int(x) for x in LOSS.findall(p.read_text(errors='replace')))
              for p in args.directory.glob('cpu*_stats.txt')}
    if any(losses.values()) or re.search(r'LOST\s+\d+\s+EVENTS', text, re.I):
        print(json.dumps({'status': 'INVALID_TRACE_LOSS', 'buffer_losses': losses}, indent=2))
        return 3
    if not losses:
        raise ValueError('Missing cpu*_stats.txt; capture buffer loss status is required')
    pairs, diagnostics = pair_events(text, set(args.tids))
    output = args.directory / 'wait_pairs.csv'
    fields = ['tid', 'source_cpu', 'wakeup_cpu', 'run_cpu', 'waking_ns', 'wakeup_ns',
              'switch_ns', 'waking_to_wakeup_ns', 'runnable_to_run_ns', 'waking_to_run_ns']
    with output.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(pairs)
    summary: dict = {'status': 'OK' if pairs else 'NO_VALID_PAIRS',
         'diagnostics': diagnostics, 'buffer_losses': losses, 'tasks': {},
         'note': 'microseconds; waking->wakeup is NOT pure IPI time; neither metric is I/O request latency'}
    for tid in args.tids:
        rows = [r for r in pairs if r['tid'] == tid]
        entry: dict = {'valid_pairs': len(rows), 'full_pairs': sum(r['waking_ns'] is not None for r in rows)}
        for name in ('waking_to_wakeup_ns', 'runnable_to_run_ns', 'waking_to_run_ns'):
            vals = [r[name] for r in rows if r[name] is not None]
            entry[name.replace('_ns', '_us')] = {'count': len(vals),
                  'mean': statistics.mean(vals) / 1000 if vals else None,
                  'p50': percentile(vals, 50), 'p95': percentile(vals, 95),
                  'p99': percentile(vals, 99), 'max': max(vals) / 1000 if vals else None}
        summary['tasks'][str(tid)] = entry
    formatted = json.dumps(summary, indent=2, ensure_ascii=False)
    (args.directory / 'wait_summary.json').write_text(formatted + '\n')
    print(formatted)
    return 0 if pairs else 2


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as exc:
        raise SystemExit(f'ERROR: {exc}')
