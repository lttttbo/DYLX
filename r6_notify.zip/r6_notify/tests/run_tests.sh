#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
D=$(mktemp -d);trap 'rm -rf "$D"' EXIT
cc -Wall -Wextra -Werror -O2 tests/test_math.c -o "$D/math"
"$D/math"
python3 tests/test_tools.py
sh -n capture_r6.sh
bash -n capture_r6.sh
if command -v busybox >/dev/null;then busybox ash -n capture_r6.sh;fi
python3 -m py_compile apply_r6.py analyze_r6.py
