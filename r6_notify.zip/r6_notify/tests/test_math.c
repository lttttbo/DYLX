/* Synthetic self-test; these numbers are NOT target-board measurements. */
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
typedef uint64_t u64;
#include "../src/r6_math.h"
int main(void) {
 u64 x[6];struct r6_dist d={0};unsigned i;
 assert(!r6_partition(100,200,500,600,1000,1,x));
 assert(x[0]==500 && x[1]==400 && x[2]==900);
 assert(x[3]+x[4]+x[5]==x[0]);
 assert(!r6_partition(100,0,0,300,400,0,x));
 assert(r6_partition(100,200,199,300,400,1,x));
 assert(r6_partition(100,200,0,300,400,1,x));
 assert(r6_partition(100,99,200,300,400,1,x));
 assert(r6_partition(100,200,301,300,400,1,x));
 assert(r6_partition(100,200,300,500,400,1,x));
 assert(r6_partition(0,200,300,500,600,1,x));
 assert(!r6_partition(100,100,100,100,100,1,x));
 assert(r6_bin(0)==0 && r6_bin(63)==0 && r6_bin(64)==1);
 assert(r6_bin(127)==1 && r6_bin(128)==2 && r6_bin(268435456ULL)==23);
 assert(r6_bin(UINT64_MAX)==23);
 for(i=0;i<1024;i++)r6_add(&d,i);
 assert(d.n==1024 && d.sum==1023ULL*1024/2 && d.min==0 && d.max==1023);
 puts("PASS: production timing partition, invalid ordering, histogram boundary/accumulation tests");
 return 0;
}
