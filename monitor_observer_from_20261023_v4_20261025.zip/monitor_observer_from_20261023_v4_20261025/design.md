# Monitor v4：只记录，不改变业务策略

日期：2026-10-25。升级基线明确为 `monitor_live_tests_v4_20261023`；私有 CCM 打点以本会话上传的原文件为基线。无需先合入 20261024 包。

## 1. 本次边界

monitor 的职责是采集已经发生的调度/退出信息，以及原代码或硬件已经识别的错误，形成事件并交给原日志接口。monitor 不参与决定请求是否允许、不修改错误返回、不增加 vCPU 重置、暂停、限流、恢复或系统 panic。

```mermaid
flowchart LR
    A[原业务代码或硬件异常] --> B[原有判断与处理]
    B --> C[原有返回值、映射、通知与状态]
    B -. 只追加记录 .-> D[monitor 固定缓存与聚合]
    D --> E[JSON 事件环]
    E --> F[vmm_lwarning / vmm_lprintf]
    F --> G[项目现有日志存储与串口回显]
    E --> H[monitor events 查询]
```

物理内存的归属、共享授权、读写执行权限由原工程维护。任何主 RAM 分区外的访问都不能直接定性为越权；serverVM 原本获准映射 Android RAM 的路径保持不变。

## 2. 相对你当前 23 日版的变化

| 范围 | 从 23 日版直接升级后的结果 |
|---|---|
| monitor 主体、调度与 Stage-2 打点 | 保留，补丁不重复修改这些文件 |
| 日志回执、只读测试接口 | 复用 23 日版已有实现 |
| monitor_live | 从专用测试 Guest/mailbox 改为选择现有 Guest 的全局 vCPU ID |
| CCM | 在上传原文件的既有失败分支追加记录；不增加调用者限制、容量限制或重复注册拒绝 |
| shmem | 清理早期 monitor 包自己引入的授权包装与额外拒绝；仅在原业务失败分支记录 |
| 隔离白盒与日志核对 | 配套更新；保留 vmm_shmem_reserve 的符号隔离修复 |
| Linux/Android 内核及 CCM 驱动 | 无修改，无新增测试 ioctl，也没有需要执行的 Linux 还原补丁 |

20261024 包中的策略性修改并不是本包的前置条件。你尚未合入它们，因此不需要先安装再撤回。

“保留原有行为”不是认定原行为没有缺陷。只清理旧 monitor 自己添加的判断；如果产品本来就有独立授权、边界或溢出检查，必须保留，不能用开源参考文件覆盖掉它。

## 3. 保留的记录位置

### 私有 HC_SET_SBUF

`cpu_hcall.c:hcall_set_sbuf()` 只增加两处记录：

1. 原代码发现 `res != sizeof(sp)`，仍然返回 `VMM_EIO`；返回前记录 CCM_READ_FAILED。
2. 原注册流程完成后，原 `ret != VMM_OK`，记录 CCM_REGISTER_FAILED，再原样返回 ret。

原 `if (hpa)`、映射查询长度、Host 映射、sbuf_setup_common 调用参数及顺序都保持。没有新的调用者身份判断，也没有额外读取 Guest 头部数据。

### 私有 sbuf 写入

`vmm_u_ioreq.c:sbuf_put()` 仅在原来设置 `ret = U32_MAX` 的分支记录 CCM_ELEMENT_REJECTED。原条件是当前流程走到 `ele_size > max_len` 的失败路径。原满队列、覆盖计数、head/tail 更新、barrier、返回值均不变。

该函数没有 Guest/vCPU 参数，记录时 actor=NULL，不能猜测当前 CPU 上的 vCPU 就是责任主体。事件 guest/vcpu 为无归属标记，不足以判断谁损坏了共享数据。

`init_asyncio`、`init_vm_event`、`insert_asyncio_request`、`sbuf_setup_common` 和私有头文件保持本次上传版本。

### 开源 shmem

`vmm_shmem_read/write/set()` 保留原表达式 `shm->size < (off + len)`；只在原 return 0 分支之前追加 SHMEM_BOUNDS 记录。不额外调用物理映射接口，不改变后端内存访问调用。

原表达式可能存在无符号加法回绕问题。本版对该原始行为只做模拟对照，不新增拒绝策略，也不在真实内存上主动触发它。若工程已有更完整的检查，在你的原检查分支加记录即可。

此前新增的 `vmm_shmem_guest_access/read/write` 是授权包装接口，不符合本次“仅记录”定位，本版不再提供。如果产品已接入这些新 API，先核对并恢复由旧方案调整的调用点，不能直接删除声明导致链接失败，也不能绕过工程本来就有的授权逻辑。

### Stage-2、调度与 exit

既有 Stage-2 的映射失败/Permission fault 记录保留；合法首次补建映射和正常 MMIO 模拟不被新判成错误。原错误返回、halt/panic 处理保持。

调度时间戳复用、ready/dispatch 统计、exit 计数、超限持续窗口与告警去重保留。exit 超限只形成事件，不自动 reset 或限流。monitor 线程优先级继续为 3。

## 4. 事件解释

保留 schema=3、type=3 及旧 code=1..4；新增 5..7 仅用于区分原 CCM 失败结果，避免误判为越权。

| code | 名称 | address | detail |
|---|---|---|---|
| 1 | SHMEM_BOUNDS | shmem 接口的 offset | 本次请求长度 |
| 2 | MAP_REJECT | Stage-2 映射失败的 IPA（按原打点） | 原映射错误码 |
| 3 | ACCESS_DENIED | 仅用于工程已有明确授权拒绝的打点 | 按原记录点定义；本次不新增授权判定 |
| 4 | PERMISSION | FAR_EL2，按原打点为虚拟地址 | ISS，需结合 FnV 等有效性信息 |
| 5 | CCM_READ_FAILED | 参数描述符的调用者 GPA | 原请求描述符长度 |
| 6 | CCM_REGISTER_FAILED | sp.gpa，即调用者缓冲区 GPA | 原 ret 转为 64 位补码保存 |
| 7 | CCM_ELEMENT_REJECTED | 0，表示此接口未提供定位地址 | 高 32 位 ele_size，低 32 位 max_len |

对 code=6，detail 转回有符号 64 位整数后才是原错误码。它不是硬件 ESR，也不等于“已经证明越权”。code=5/6 的 actor 是原调用 vCPU，不对其他 Guest 作归责。

当前 monitor 在采样窗口内聚合内存事件：value 是次数，time_ns/last_ns 是首末时间，code/address/detail 为最后一次代表信息；不是每次错误都有独立完整记录。保留既有容量与 lost 计数，缓存耗尽和严重异常后的日志排出仍有局限。

## 5. 记录与存储

热路径只调用 `vmm_monitor_mem_fault()` 写监控缓存。采样器形成事件，后台调用 `vmm_lwarning("monitor", "%s", json)`，沿用你项目已有的 `vmm_lprintf` 存储及串口回显。

未新增文件系统、磁盘驱动、独立通知或 Guest 上报 ioctl。monitor events 查询的是环形历史，不等同于从持久化存储读取。

`monitor stop` 停止新的监控采集，原业务分支照常执行；此前缓存的事件仍可能被排出。编译关闭 monitor 时记录宏为空操作，原判断仍然存在。日志函数返回不代表数据已可靠写入介质；需要用原工程方式刷新、导出日志核对。EL2 panic 等严重异常可能使异步排日志无法完成，本版不改变原异常策略来保证排出。

## 6. 从 23 日版手工合入

本包只有两份补丁：

1. `from_20261023.patch`：以 `monitor_live_tests_v4_20261023` 交付完成后的参考树为基线，更新事件枚举、shmem、现有 Guest 测试框架、日志核对工具和说明。完整包含 common.c/common.h/scheduler.c 的迁移差异，不依赖 24 日版。
2. `ccm_from_uploaded.patch`：以你上传的 cpu_hcall.c、vmm_u_ioreq.c 为基线，只追加既有失败分支的记录。与第一份补丁中的事件定义一起合入。

两份均以 Hypervisor 根目录为路径起点。私有工程按 `merge_locations.txt` 的函数和上下文合入，行号仅辅助定位。完整文件在 `full_files/upstream` 和 `full_files/private_hypervisor`，不要覆盖自己的其他改动。

无需应用先前记录包的 upstream_update.patch、ccm_from_20261024.patch 或 linux_restore_20261024.patch。本包没有 Linux 文件，也不重复修改 vmm_scheduler.c、cpu_interrupts.c、cpu_vcpu_excep.c、monitor_agent.c、monitor_test.inc 或 vmm_monitor_test.h。

`CONFIG_WBOXTEST_MONITOR` 和 `CONFIG_WBOXTEST_MONITOR_LIVE` 沿用。monitor_live/objects.mk 的四个编译对象与 23 日版一致，不需要修改。原 protocol.h 和 tests/monitor/live_guest 可以保留，但新版用例不再使用；不再按旧文档创建专用 Guest。旧 verify_live_logs.py 保留用于历史工具回归，新一轮现场日志使用 verify_existing_logs.py。

此包是 23 日版增量，并非从零安装包。若曾把旧 monitor 提供的 vmm_shmem_guest_access/read/write 接到私有路径，须核对这些调用并恢复原业务路径；不删除工程本来就有的安全策略。

## 7. 测试如何调整

### 隔离白盒

`CONFIG_WBOXTEST_MONITOR=y` 下的六类用例保留，`monitor_memory` 改为验证原 shmem 分支及记录：合法访问通过、原本的越界拒绝仍返回 0、三次拒绝聚合并调用日志、空指针原行为不变、stop 后业务结果不变。

原未拦截的回绕场景只交给测试私有的假后端，假后端不会解引用地址。它验证的是“没有偷偷改变原处理”，不是认可原边界安全性，更不能在业务 Guest 上照做。

```text
wboxtest run_tests 1 monitor_memory
```

### 现有 Guest 的 live 观察

`CONFIG_WBOXTEST_MONITOR_LIVE=y`、`monitor start` 后，先用 `monitor_live target <全局vCPU ID>` 选择现有 Guest。VM 生命周期和映射须保持稳定。

- monitor_live_schedule 保留已有受控竞争方式，目标 vCPU 单核绑定、优先级不高于 3，且不选择物理 CPU 0；需要 Guest 已有忙负载。它只用于测试配置，运行时会产生约 2ms 调度干扰。
- monitor_live_storm 保留只读窗口观察，要求既有可控负载形成“低负载—持续高负载—恢复—再次持续高负载”。没有外部负载不能保证用例完成。不要再使用旧 CCM 辅助程序的流程来满足它。
- monitor_live_memory 现在只等待指定 vCPU 的真实 type=3 事件，核对时间、类型及日志回执。没有错误事件时超时失败，不能凭空制造 PASS；通过只证明本次观察到的类别，并不证明所有越界/越权路径。
- 本包不引入 monitor_live_ccm、CONFIG_WBOXTEST_MONITOR_CCM 或 CCM 测试 ioctl。

本次没有加入修改 Stage-2 权限的注入功能，也没有给现有 Guest 安排故障恢复；真实 CPU 越权触发测试需要独立设计，不能与 monitor 本身的记录职责混合。更不会在原失败路径之外新增错误判断来让测试通过。

不需要 24 日版的 ccm_monitor_probe、CONFIG_CCM_MONITOR_TEST 或固定溢出描述符操作步骤。本版没有 Linux/Android 内核修改，也不要求创建新 Guest。

### 存储核对

三个 live 用例分别完成且导出独立存储日志后，使用更新的 verify_existing_logs.py。它匹配三条回执（两次 storm、一次实际内存事件），不再要求旧 ioctl 的固定地址或六条 CCM 测试事件。

```sh
python3 verify_existing_logs.py --console wboxtest.txt --stored-log stored.log
```

## 8. 已完成的验证与限制

- 对私有两个文件去掉新增记录后，与上传原文精确一致；Linux hsm 和私有头文件与上传版本相同；shmem 去掉记录及为记录增加的括号后，与开源原文相同。
- 编译开启和关闭各执行 212 组本机差分对照，覆盖原返回值、后端调用顺序与参数、缓冲区内容；开启版本又包含运行时关闭和开启两种状态。
- 删除记录、重新加上 serverVM 独占判断的两种变异均被测试拒绝。
- 32 次 ARM64 编译检查；原隔离白盒 54 次执行；monitor 主逻辑与禁用宏、Stage-2 模型、只读接口及日志核对回归通过。
- 本次重制核对 23 日版 24 个交付文件和 9 个依赖的 SHA-256；两份补丁应用、反向还原和结果哈希校验通过。
- 本次只调整升级基线和说明，交付源码与已完成上述测试的记录版逐文件一致；测试报告沿用该相同源码的结果。

这些是编译和本机 API 模型验证，不是完整私有工程链接、QEMU/板卡运行或实际存储持久化验证。监控开销不等于零；ROM 5KB、CPU <0.5% 的产品验收仍未完成。

观察范围以实际打点和现有判断为限：Guest 内部自行处理的异常、映射页内对象越界，以及原代码没有检查的非法元数据不会因安装本版而自动被发现。
