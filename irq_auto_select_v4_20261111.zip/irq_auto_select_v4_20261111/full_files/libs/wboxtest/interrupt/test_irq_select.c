/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "test_irq.h"

#define IRQ_SELECT_INVALID (~0U)
#define IRQ_SELECT_HW_STATE \
	(VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_MASKED)

u32 test_irq_spi_ids[TEST_IRQ_SPI_COUNT] = {
	IRQ_SELECT_INVALID, IRQ_SELECT_INVALID, IRQ_SELECT_INVALID,
	IRQ_SELECT_INVALID, IRQ_SELECT_INVALID, IRQ_SELECT_INVALID,
};

/* The wboxtest runner serializes .run() calls. This is not an IRQ reservation. */
enum irq_select_reason {
	IRQ_SELECT_OK,
	IRQ_SELECT_NOT_SPI,
	IRQ_SELECT_OWNER,
	IRQ_SELECT_STATE,
	IRQ_SELECT_API,
	IRQ_SELECT_LAYOUT,
	IRQ_SELECT_REASONS
};

static bool irq_select_has_actions(struct vmm_host_irq *irq)
{
	irq_flags_t flags;
	u32 cpu;
	bool found;

	for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
		vmm_read_lock_irqsave_lite(&irq->action_lock[cpu], flags);
		found = !list_empty(&irq->action_list[cpu]);
		vmm_read_unlock_irqrestore_lite(&irq->action_lock[cpu], flags);
		if (found) {
			return TRUE;
		}
	}
	return FALSE;
}

static enum irq_select_reason irq_select_check(u32 id)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(id);
	u32 hw = 0;
	u32 levels = 0;
	u32 pmr = 0;
	u8 priority = 0;

	/* Restrict this version to the HOS GICv3 ordinary SPI descriptors. */
	if (!irq || !irq->chip || !irq->chip->name || strcmp(irq->chip->name, "GICv3") ||
	    irq->hwirq < 32U || irq->hwirq >= 1020U || (irq->state & VMM_IRQ_STATE_EXTENDED) ||
	    vmm_host_irq_is_per_cpu(irq) || vmm_host_irq_is_ipi(irq) ||
	    vmm_host_irq_is_chained(irq)) {
		return IRQ_SELECT_NOT_SPI;
	}
	if (vmm_host_irq_is_routed(irq) || irq_select_has_actions(irq)) {
		return IRQ_SELECT_OWNER;
	}
	if (vmm_host_irq_get_routed_state(id, &hw, IRQ_SELECT_HW_STATE)) {
		return IRQ_SELECT_API;
	}
	/* A currently enabled line without an action is not used by this probe. */
	if (hw != VMM_ROUTED_IRQ_STATE_MASKED || !vmm_host_irq_is_masked(irq)) {
		return IRQ_SELECT_STATE;
	}
	if (vmm_host_irq_get_priority(id, &priority) ||
	    vmm_host_irq_priority_level(id, &levels, &pmr)) {
		return IRQ_SELECT_API;
	}
	if (levels < 2U || (u32)priority >= levels) {
		return IRQ_SELECT_API;
	}
	return IRQ_SELECT_OK;
}

static bool irq_select_used(u32 id, const u32 *chosen, u32 count)
{
	struct vmm_host_irq *candidate = vmm_host_irq_get(id);
	u32 i;

	for (i = 0; i < count; i++) {
		struct vmm_host_irq *previous = vmm_host_irq_get(chosen[i]);
		if (chosen[i] == id) {
			return TRUE;
		}
		/* Also avoid duplicate hardware identities in non-identity mappings. */
		if (candidate && previous && candidate->chip == previous->chip &&
		    candidate->chip_data == previous->chip_data &&
		    candidate->hwirq == previous->hwirq) {
			return TRUE;
		}
	}
	return FALSE;
}

static bool irq_select_pair_layout(u32 id)
{
	struct vmm_host_irq *first = vmm_host_irq_get(id);
	struct vmm_host_irq *second = vmm_host_irq_get(id + 1U);

	/* Check both the HOS wrapper's HIRQ boundary and the driver's HWIRQ bank. */
	if (!first || !second || ((id + 1U) % 32U) == 0U || first->chip != second->chip ||
	    first->chip_data != second->chip_data || second->hwirq != first->hwirq + 1U ||
	    first->hwirq / 32U != second->hwirq / 32U) {
		return FALSE;
	}
	return TRUE;
}

int test_irq_select_spis(struct vmm_chardev *cdev)
{
	u32 chosen[TEST_IRQ_SPI_COUNT] = {0};
	u32 rejected[IRQ_SELECT_REASONS] = {0};
	u32 irq_count = vmm_host_irq_count();
	u32 found = 0;
	u32 id;
	u32 i;
	enum irq_select_reason reason;

	/* On every failure leave invalid IDs, never yesterday's selection or SGI0. */
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		test_irq_spi_ids[i] = IRQ_SELECT_INVALID;
	}
	vmm_cprintf(cdev, "IRQSCAN: current registration/state only; board ownership unknown\n");
	if (irq_count < 2U) {
		return VMM_ENOTAVAIL;
	}
	for (id = 0; id < irq_count - 1U && found < TEST_IRQ_SPI_COUNT; id++) {
		if (irq_select_used(id, chosen, found) || irq_select_used(id + 1U, chosen, found)) {
			continue;
		}
		reason = irq_select_check(id);
		if (reason == IRQ_SELECT_OK) {
			reason = irq_select_check(id + 1U);
		}
		if (reason != IRQ_SELECT_OK) {
			rejected[reason]++;
			continue;
		}
		if (!irq_select_pair_layout(id)) {
			rejected[IRQ_SELECT_LAYOUT]++;
			continue;
		}
		chosen[found++] = id;
		chosen[found++] = id + 1U;
	}
	if (found != TEST_IRQ_SPI_COUNT) {
		vmm_cprintf(cdev, "IRQSCAN: need 3 pairs, found=%u; test aborted\n", found / 2U);
		vmm_cprintf(cdev,
			    "IRQSCAN: rejected not_spi=%u owner=%u state=%u api=%u layout=%u\n",
			    rejected[IRQ_SELECT_NOT_SPI], rejected[IRQ_SELECT_OWNER],
			    rejected[IRQ_SELECT_STATE], rejected[IRQ_SELECT_API],
			    rejected[IRQ_SELECT_LAYOUT]);
		return VMM_ENOTAVAIL;
	}
	/* Recheck before publishing, but do not claim this is an atomic reservation. */
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		reason = irq_select_check(chosen[i]);
		if (reason != IRQ_SELECT_OK) {
			vmm_cprintf(cdev, "IRQSCAN: irq=%u changed, reason=%u; test aborted\n",
				    chosen[i], (u32)reason);
			return VMM_EBUSY;
		}
	}
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		test_irq_spi_ids[i] = chosen[i];
	}
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i += 2U) {
		vmm_cprintf(cdev, "IRQSCAN: pair%u hirq=%u/%u hwirq=%u/%u\n", i / 2U + 1U,
			    chosen[i], chosen[i + 1U], vmm_host_irq_get(chosen[i])->hwirq,
			    vmm_host_irq_get(chosen[i + 1U])->hwirq);
	}
	return VMM_OK;
}
