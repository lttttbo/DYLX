# HOS monitor v4：命令模块初始化接入

日期：2026-11-10。

本版将 monitor 命令改为由标准模块框架注册。`vmm_main.c` 只负责监控本体初始化；`cmd_monitor.c` 通过 `VMM_DECLARE_MODULE` 声明命令初始化和退出函数。保持本体初始化失败时不注册命令，运行期间的 start/stop 与命令注册相互独立。

## 基线与交付内容

基线为 `monitor_lock_retry_v4_20261109` 完整树，并合入 `monitor_test_style_v4_20261109` 的八个在用测试文件。

包内有五个完整文件、`changes.patch`、`merge_locations.txt` 和校验清单。补丁仅包含本次改动；完整文件便于阅读或替换没有私有差异的文件。

| 文件 | 修改 |
| --- | --- |
| commands/cmd_monitor.c | 新增模块声明；命令 init/exit 改为文件内部静态函数；init 检查本体就绪后注册，exit 注销命令 |
| core/include/vmm_monitor.h | 删除 vmm_monitor_cmd_init 的声明和空桩；声明只读就绪接口 vmm_monitor_ready，关闭监控时提供 FALSE 空桩 |
| core/monitor/monitor_agent.c | 新增 vmm_monitor_ready 及符号导出，读取已有 initialized 原子量 |
| core/vmm_main.c | 删除对命令初始化的直接调用，保留监控本体初始化及非致命错误日志；本次修改块使用完整花括号 |
| libs/wboxtest/monitor/support.c | 就绪接口映射到测试副本；注册/注销均映射到测试空桩；包含命令源码时临时屏蔽模块声明 |

`storm_runtime.c`、其余测试用例、生产打点、CCM、Guest 内核、Kconfig 和 objects.mk 不变。此前的 ARM64 有界取锁重试与诊断保留；此次变更不修改采样和风暴判断。

## 初始化链路

```text
system_init_work()
  ├─ vmm_cmdmgr_init()             初始化命令管理器
  ├─ vmm_monitor_init()            初始化监控本体与执行器
  └─ vmm_modules_init()            遍历并按初始化优先级执行模块
       └─ cmd_monitor_init()      检查 ready，注册 monitor 命令
            └─ vmm_cmdmgr_register_cmd(&monitor_cmd)
```

不在 `vmm_cmdmgr_init()` 中硬编码 monitor 命令，也不从命令 init 再调用监控本体 init。这样不会重复创建监控工作队列、重新初始化数据或启动第二份定时器。

模块声明使用初始化优先级 **0**，与现有 host、vcpu 命令一致。它控制启动时模块初始化顺序，**不是线程调度优先级**。监控工作线程仍沿用原来的配置（通常为 3），不会调整 auth、mterm 或 IPI 的优先级。

`cmd_monitor_exit()` 只注销命令，不停止监控本体。当前布尔配置产生的是内置模块，现有模块框架不允许通过模块卸载命令卸载内置模块；exit 函数是按命令模块惯例提供的配对接口，不能把 `monitor stop` 理解为模块退出。

## 为什么新增 ready 接口

`vmm_monitor_ready()` 只读取已有 `initialized`，不修改 epoch、配置、enabled 或采样数据，不创建任何资源。

| 状态 | ready | 命令注册 |
| --- | --- | --- |
| 本体尚未初始化 | FALSE | init 返回 VMM_ENOTAVAIL，不进入命令注册接口 |
| 本体初始化失败 | FALSE | 同上；主启动流程继续 |
| 本体初始化成功，自启动关闭 | TRUE | 正常注册，可以输入 monitor start |
| monitor start 后 | TRUE | 命令仍然存在 |
| monitor stop 后 | TRUE | 命令仍然存在，可以查询已有记录或重新 start |

不能使用 enabled 来判断是否允许注册，否则自启动关闭时会失去 start 命令。

命令注册失败时，由模块框架报告初始化错误；不会销毁已经初始化的监控本体。若本体初始化失败，除了原来的 unavailable 提示，后续模块框架也可能报告 cmd_monitor 初始化失败。这不代表框架又启动了一次监控。

## 隔离测试副本如何处理

support.c 会直接包含生产的 monitor_agent.c 和 cmd_monitor.c，以测试私有实例。生产命令新增模块声明后，测试副本必须屏蔽这个声明，否则会多出一个真实命令模块。

处理方式：

1. `vmm_monitor_ready` 重命名为 `wb_agent_ready`，与私有的 initialized 对应。
2. 注册、注销接口都映射到 `mt_command_registry_stub`，不操作真实命令列表。
3. `push_macro` 保存 `VMM_DECLARE_MODULE`，包含 cmd_monitor.c 时临时替换为一个未使用的静态辅助函数，随后 `pop_macro` 恢复。
4. 辅助函数仅引用 init/exit，避免严格编译出现未使用函数告警，不被调用，也不生成模块描述符。编译对象检查已经验证 support.o 没有 `.modtbl` 对象。

这些宏只作用于 support.c 的编译单元；生产 cmd_monitor.c 正常生成且只生成一个命令模块描述符。没有新增测试开关或头文件。

## 手工合入

五个文件配套合入。重点是删除旧的直接注册调用，并同步修改 support.c。

- 以 `merge_locations.txt` 的函数/宏名称定位，行号仅作参考。
- **core/vmm_main.c 的完整文件只供对照。HOS 有大量私有修改，请仅替换 system_init_work 中 monitor 的小段初始化代码。**
- core/monitor/monitor_agent.c 只需增加一个函数和一条导出；不要用本包覆盖你的其他私有修改。
- support.c 以最新 style 版为基线。如果尚未合入测试 style 版，可按定位说明在现有 support.c 中修改对应的重命名、空桩及源码包含位置，不必覆盖其他测试内容。
- 合入后，生产代码中不应再有 `vmm_monitor_cmd_init()` 的调用或声明。
- `CONFIG_CMD_MONITOR=n` 时仍不编译命令；`CONFIG_MONITOR_AGENT=n` 时保留本体初始化空桩，且命令配置依赖监控本体。无须调整现有开关。

有 Git 的工程可先执行：

```sh
git apply --check /path/to/changes.patch
```

补丁与完整文件二选一，存在私有差异时手工合入。补丁已在提供的基线上完成正向应用、反向还原和字节一致性检查。

## 内存与体积变化

标准模块接入会增加模块元数据和框架启动时的管理对象。下面是当前参考 ARM64 编译配置的测量，目标 HOS 可能不同：

| 项目 | 变化 |
| --- | --- |
| 命令对象静态可写分配节 | 224 → 520 字节，新增模块描述符 296 字节 |
| 命令对象加载区 | 823 → 1151 字节，增加 328 字节，包含模块描述符和相关代码 |
| 生产监控本体静态 RAM | 不变，就绪查询复用原有 initialized |
| 模块框架启动时额外请求 | 一个 module_wrap，sizeof 为 360 字节，尚未计入分配器对齐或管理开销 |
| support.o 静态可写分配节（测试开启） | 14781 → 14557 字节，减少 224 字节，私有命令描述符被编译器消除 |

`.modtbl` 是可写的初始化数据，属于上面命令对象的 296 字节增量，不要重复统计。测试关闭时，以上静态增量为 296 字节；测试开启时，这两个对象的净静态增量为 72 字节。框架堆分配另算。

没有新增线程、线程栈、工作队列或定时器。上述数据不是最终镜像 ROM、整体 RAM 或 vapool 增量的测量；模块描述符可能位于最终链接的初始化区域，其保留/回收以目标链接脚本为准。此前产品已允许启动时框架分配内存，本次只沿用标准模块框架的启动分配，不引入运行期间采集分配。

## 验证

- ARM64 交叉编译 32 个对象：覆盖内部/外部执行、自启动开/关、测试开/关、关闭命令、关闭监控；包含基线尺寸对比和结构尺寸探针。主要使用 -Wall、-Wextra、-Werror，原有上游头文件和 vmm_main 中无关告警的例外见 report.json。
- 确认生产命令对象仅一个模块描述符，测试 support.o 中为零。
- 12 个模块回调模型场景通过：正常注册与退出、未初始化拒绝、重复注册拒绝、工作队列/绑核/定时器初始化失败、注册失败、start/stop 不影响 ready 和命令可用性。
- 六个隔离用例，在内部、外部、自启动三种模型下各运行三次，共 54 次通过；结果与上一版完全一致。
- 所有本次交付的 monitor 文件通过 style 检查。vmm_main 仅检查并整理本次改动块，不对上游其他代码进行无关重排。

这些是开发机平台模型和 ARM64 编译结果。未进行你的 HOS GCC 12 整机链接或单板启动验证；模块回调模型不等于真实固件模块加载测试。单板建议核对启动后 `help monitor`、`monitor start/stop/status`，并运行原 monitor 测试组。日志输出和存储仍沿用此前实现。
