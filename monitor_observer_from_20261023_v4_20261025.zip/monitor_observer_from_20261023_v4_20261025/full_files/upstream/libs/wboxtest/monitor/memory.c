/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Product-only symbols must remain private in this included test instance. */
#define vmm_shmem_reserve wb_shmem_reserve
#include "common.h"
#include <vmm_shmem.h>
#include <vmm_host_aspace.h>
#include <vmm_host_ram.h>
#include <vmm_heap.h>
#include <vmm_mutex.h>

#define TEST_HPA 0x100000ULL
static struct vmm_shmem object;
static u8 backing[32];
static u32 accesses;
static bool invalid_backend;
static bool backend_range(physical_addr_t address, u32 len)
{
    accesses++;
    if (address < TEST_HPA || !vmm_monitor_range_valid(sizeof(backing),address-TEST_HPA,len)) {
        invalid_backend=TRUE; return FALSE;
    }
    return TRUE;
}
static u32 read_memory(physical_addr_t addr, void *buf, u32 len, bool cacheable)
{
    (void)cacheable;
    if (!backend_range(addr,len)) return 0;
    memcpy(buf,backing+(addr-TEST_HPA),len); return len;
}
static u32 write_memory(physical_addr_t addr, void *buf, u32 len, bool cacheable)
{
    (void)cacheable;
    if (!backend_range(addr,len)) return 0;
    memcpy(backing+(addr-TEST_HPA),buf,len); return len;
}
static u32 set_memory(physical_addr_t addr, u8 byte, u32 len, bool cacheable)
{
    (void)cacheable;
    if (!backend_range(addr,len)) return 0;
    memset(backing+(addr-TEST_HPA),byte,len); return len;
}

/* Only this isolated copy calls fake backing APIs. No real Guest memory,
 * mappings, registry or production monitor instance is touched. */
#define vmm_shmem_read wb_shmem_read
#define vmm_shmem_write wb_shmem_write
#define vmm_shmem_set wb_shmem_set
#define vmm_shmem_iterate wb_shmem_iterate
#define vmm_shmem_count wb_shmem_count
#define vmm_shmem_find_byname wb_shmem_find_byname
#define vmm_shmem_ref wb_shmem_ref
#define vmm_shmem_dref wb_shmem_dref
#define vmm_shmem_create wb_shmem_create
#define vmm_shmem_init wb_shmem_init
void wb_shmem_ref(struct vmm_shmem *shm);
#define vmm_host_memory_read read_memory
#define vmm_host_memory_write write_memory
#define vmm_host_memory_set set_memory
#undef vmm_monitor_mem_fault
#define vmm_monitor_mem_fault(v,k,a,d) mt_fault(v,k,a,d)
#include "../../../core/vmm_shmem.c"

static int memory_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
    int rc=VMM_OK;
    u8 data[32],saved[32];
    u32 prior;
    struct mt_event e;
    (void)test; (void)cpu;
    mt_begin(); MT_CHECK(mt_enable(TRUE)==VMM_OK);
    memset(&object,0,sizeof(object)); object.addr=TEST_HPA; object.size=sizeof(backing);
    memset(backing,0,sizeof(backing)); memset(data,0x5a,sizeof(data));
    accesses=0; invalid_backend=FALSE;
    MT_CHECK(wb_shmem_write(&object,28,data,4,FALSE)==4);
    memset(data,0,sizeof(data));
    MT_CHECK(wb_shmem_read(&object,28,data,4,FALSE)==4 && data[0]==0x5a);
    MT_CHECK(wb_shmem_set(&object,0,0xa5,4,FALSE)==4 && backing[0]==0xa5);
    mt_sample(mt_now()+VMM_MONITOR_NS); MT_CHECK(!mt_event(1,&e));
    memcpy(saved,backing,sizeof(saved)); prior=accesses;
    MT_CHECK(!wb_shmem_write(&object,31,data,2,FALSE));
    MT_CHECK(!wb_shmem_read(&object,33,data,0,FALSE));
    MT_CHECK(!wb_shmem_set(&object,32,0,1,FALSE));
    MT_CHECK(accesses==prior && !invalid_backend && !memcmp(saved,backing,sizeof(saved)));
    mt_sample(mt_now()+VMM_MONITOR_NS);
    MT_CHECK(mt_event(1,&e) && e.type==3 && e.code==VMM_MONITOR_SHMEM_BOUNDS && e.value==3);
    MT_CHECK(e.guest==~0U && e.vcpu==~0U && e.address==32 && e.detail==1);
    mt_drain(); MT_CHECK(strstr(mt_log(),"\"type\":3"));
    MT_CHECK(!wb_shmem_read(NULL,0,data,4,FALSE));
    MT_CHECK(!wb_shmem_write(&object,0,NULL,4,FALSE));
    MT_CHECK(!wb_shmem_set(NULL,0,0,4,FALSE));
    mt_sample(mt_now()+VMM_MONITOR_NS); MT_CHECK(!mt_event(2,&e));
    /* Runtime disable must not change the original rejection or valid access. */
    MT_CHECK(!mt_enable(FALSE));
    prior=accesses;
    MT_CHECK(!wb_shmem_write(&object,31,data,2,FALSE) && accesses==prior);
    MT_CHECK(wb_shmem_write(&object,0,data,4,FALSE)==4 && accesses==prior+1);
    mt_sample(mt_now()+VMM_MONITOR_NS); MT_CHECK(!mt_event(2,&e));
    /* Legacy unsigned-wrap behavior is observed ONLY via this fake backend.
     * The old predicate permits the backend call; monitor must not silently
     * introduce a new rejection policy. Fake backing never dereferences it. */
    MT_CHECK(!mt_enable(TRUE)); prior=accesses;
    MT_CHECK(!wb_shmem_write(&object,~0ULL-1,data,4,FALSE));
    MT_CHECK(accesses==prior+1 && invalid_backend);
    mt_sample(mt_now()+VMM_MONITOR_NS); MT_CHECK(!mt_event(2,&e));
    MT_CHECK(!mt_overflow());
out:
    mt_end(); return rc;
}
MT_REGISTER(monitor_memory,memory_run);
