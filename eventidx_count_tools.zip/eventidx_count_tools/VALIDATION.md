# 验证范围

已完成：

- `sh -n`和`busybox sh -n`语法检查。
- Python模块编译检查；19项模拟测试全部通过。
- 覆盖：大于2^53的计数、负增量拒绝、CPU/时间布局、已解绑vhost不复活、最新绑定与多设备歧义、路由/特征不匹配、共享IRQ不强行拆TX、缺失IPI不补零、ethtool kick计数与不可用处理、独立OS时钟、OFF/ON目录误置。
- 使用临时模拟proc/sysfs运行BusyBox shell实际采集流程；检查MSI向量只选目标virtio设备，不误选virtio01；检查无流量超时退出。
- 可选C统计工具通过本容器x86_64编译器`-std=c11 -Wall -Wextra -Werror -O2`编译及无效参数/设备错误路径检查。未把该x86_64可执行文件放入交付包。

未完成：

- 用户ARM64板卡、Android和ServerVM上的真实运行。
- 目标Android工具链编译/部署可选C工具。
- 厂商virtio_net是否保留标准ethtool kicks字段。
- 真实IRQ命名、Guest共享MSI中断的映射验证。
- 测量扰动定量测试及任何EVENT_IDX性能收益验证。

所以，模拟测试通过不等于目标板性能验证。自动字段不可读时应报告N/A/REVIEW，而不是猜测或补0。
