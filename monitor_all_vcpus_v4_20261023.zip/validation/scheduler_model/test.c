/* Host model for the supplied scheduler's dependencies, not product headers. */
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef long atomic_t;
typedef int vmm_spinlock_t;
typedef uint64_t u64;
typedef uintptr_t virtual_addr_t;
typedef unsigned irq_flags_t;
typedef int arch_regs_t;
#define TRUE true
#define FALSE false
#define VMM_VCPU_STATE_UNKNOWN 1
#define VMM_VCPU_STATE_RESET 2
#define VMM_VCPU_STATE_READY 4
#define VMM_VCPU_STATE_RUNNING 8
#define VMM_VCPU_STATE_PAUSED 16
#define VMM_VCPU_STATE_HALTED 32
#define VMM_VCPU_STATE_SAVEABLE (8 | 16 | 32)
#define VMM_VCPU_DEF_TIME_SLICE 1000
#define CONTEXT_FLAG_IN_IRQ 1
#define VCPU_HCPU(p) ((u32)((p) >> 32))
#define VCPU_STATE(p) ((u32)(p))
#define VCPU_STATE_PACK(c,s) (((u64)(c) << 32) | (u32)(s))
#define BUG_ON(c) assert(!(c))
#define per_cpu(s,c) ((s)[c])
#define this_cpu(s) ((s)[fake_cpu])
struct vmm_guest { u32 id; };
struct ring_buffer;
struct vmm_vcpu {
    struct vmm_guest *guest;
    struct ring_buffer *sched_history;
    u32 id;
    u64 packed;
    int sched_lock;
    bool resumed, halt_flag, is_normal;
    u64 state_ready_nsecs, state_running_nsecs, state_paused_nsecs;
    u64 state_halted_nsecs, state_tstamp, system_nsecs, reset_tstamp;
    u32 reset_count, context_flag, priority, preempt_count;
    u64 state_ready_max_nsecs, state_running_max_nsecs, state_paused_max_nsecs;
    u64 state_halted_max_nsecs, irq_process_max_nsecs, exp_process_max_nsecs;
    long do_reboot;
    int *wq_lock;
    void (*wq_cleanup)(struct vmm_vcpu *);
    const char *name;
};
struct vmm_scheduler_ctrl {
    struct vmm_vcpu *idle_vcpu;
    struct ring_buffer *sched_history;
    u64 current_vcpu_irq_ns_back, current_vcpu_exp_ns_back;
    u64 current_vcpu_irq_max_ns, current_vcpu_exp_max_ns;
    struct vmm_vcpu *current_vcpu;
    u64 current_vcpu_irq_ns, current_vcpu_exp_ns, irq_process_ns, exp_process_ns;
    int ev;
    bool irq_context, yield_on_irq_exit;
    arch_regs_t *irq_regs;
    struct vmm_vcpu *ready[16];
    unsigned length;
};
static struct vmm_scheduler_ctrl sched[12];
static u64 ticks;
static unsigned timestamps, switches, callback_count, cleanup_calls;
static unsigned posts, restarts, trace_calls, fake_cpu, migrations, normal_pauses;
static u64 trace_diff, trace_a, trace_b, trace_c;
static u32 trace_mask;
static bool monitor_on;
static int enqueue_error, arch_init_error, resched_error;
static struct { struct vmm_vcpu *v; u32 kind; u64 a,b,packed; unsigned switches, posts; } calls[32];
static void take_lock(int *p) { assert(!*p); *p = 1; }
static void drop_lock(int *p) { assert(*p); *p = 0; }
#define arch_cpu_irq_save(f) ((f)=0)
#define arch_cpu_irq_restore(f) ((void)(f))
#define vmm_write_lock_irqsave_lite(p,f) do { (f)=0; take_lock(p); } while (0)
#define vmm_write_unlock_irqrestore_lite(p,f) do { (void)(f); drop_lock(p); } while (0)
#define vmm_write_lock_lite(p) take_lock(p)
#define vmm_write_unlock_lite(p) drop_lock(p)
#define vmm_spin_lock(p) take_lock(p)
#define vmm_spin_unlock_lite(p) drop_lock(p)
#define DEFINE_SPINLOCK(n) int n=0
#define vmm_spin_lock_irqsave_lite(p,f) vmm_write_lock_irqsave_lite(p,f)
#define vmm_spin_unlock_irqrestore_lite(p,f) vmm_write_unlock_irqrestore_lite(p,f)
#define vmm_panic(...) abort()
#define vmm_printf(...) ((void)0)
static u64 vmm_timer_timestamp(void) { timestamps++; return ++ticks; }
static u32 vmm_smp_processor_id(void) { return fake_cpu; }
static long arch_atomic_read(long *p) { return *p; }
static void arch_atomic_write(long *p, long v) { *p=v; }
static u64 vmm_scheduler_get_state_packed(struct vmm_vcpu *v) { return v->packed; }
static int vmm_scheduler_get_state(struct vmm_vcpu *v, u32 *s) { *s=VCPU_STATE(v->packed); return 0; }
static void vmm_scheduler_set_state_packed(struct vmm_vcpu *v,u64 p) { v->packed=p; }
static void vmm_scheduler_set_state_raw(struct vmm_vcpu *v,u32 s) { v->packed=VCPU_STATE_PACK(VCPU_HCPU(v->packed),s); }
static int rq_enqueue(struct vmm_scheduler_ctrl *s,struct vmm_vcpu *v) {
    if(enqueue_error) return enqueue_error;
    assert(s->length < 16); s->ready[s->length++]=v; return 0;
}
static int rq_dequeue(struct vmm_scheduler_ctrl *s,struct vmm_vcpu **v,u64 *slice) {
    assert(s->length); *v=s->ready[0]; *slice=123;
    memmove(s->ready,s->ready+1,--s->length*sizeof(s->ready[0])); return 0;
}
static int rq_detach(struct vmm_scheduler_ctrl *s,struct vmm_vcpu *v) {
    for(unsigned i=0;i<s->length;i++) if(s->ready[i]==v) {
        memmove(s->ready+i,s->ready+i+1,(--s->length-i)*sizeof(s->ready[0])); return 0;
    }
    return 0;
}
static bool rq_prempt_needed(struct vmm_scheduler_ctrl *s) { (void)s; return false; }
static void arch_vcpu_switch(struct vmm_vcpu *old,struct vmm_vcpu *next,arch_regs_t *regs) {
    (void)old; (void)regs; assert(next->sched_lock); switches++; ticks+=20;
}
static void vmm_timer_event_start(int *ev,u64 n) { (void)ev; assert(n==123); }
static int vmm_schedalgo_vcpu_setup(struct vmm_vcpu *v) { (void)v; return 0; }
static int vmm_schedalgo_vcpu_cleanup(struct vmm_vcpu *v) { (void)v; return 0; }
static int arch_vcpu_init(struct vmm_vcpu *v) { (void)v; return arch_init_error; }
static int vmm_vcpu_irq_init(struct vmm_vcpu *v) { (void)v; return 0; }
static int vmm_scheduler_force_resched(u32 c) { assert(c<12); return resched_error; }
static void vmm_scheduler_switch(struct vmm_scheduler_ctrl *,arch_regs_t *);
static void arch_vcpu_preempt_orphan(void) { }
static void cleanup(struct vmm_vcpu *v) { (void)v; cleanup_calls++; }

#include <vmm_monitor.h>

#ifdef CONFIG_MONITOR_AGENT
static struct vmm_vcpu *vmm_scheduler_idle_vcpu(u32 cpu) {
    return cpu < 12 ? sched[cpu].idle_vcpu : NULL;
}
#endif
#define unlikely(x) (x)
#define U8_MAX 255U
#define WARN_ON(x) assert(!(x))
enum sched_event { SCHED_IN, SCHED_OUT_RUNNABLE, SCHED_OUT_UNRUNNABLE,
                   SET_RUNNABLE, SET_UNRUNNABLE, MIGRATE_OUT, MIGRATE_IN };
struct sched_record { u64 tstamp; u8 executor,cpu,vcpu; u32 evt; };
struct ring_buffer { unsigned count; struct sched_record record[64]; };
static struct ring_buffer cpu_history[12], vcpu_history[4];
static struct vmm_guest guest={0};
#ifdef CONFIG_SCHED_HISTORY
static atomic_t sched_history_recording;
static int ring_buffer_write(struct ring_buffer *r,u8 *data,size_t size,bool *overwrite) {
    assert(r && r->count<64 && *overwrite && size==sizeof(struct sched_record));
    memcpy(&r->record[r->count++],data,size); return 0;
}
#endif
static void arch_vcpu_post_switch(struct vmm_vcpu *v,arch_regs_t *r) {
    (void)r; assert(v && !v->sched_lock); posts++; ticks+=40;
}
static void vmm_timer_event_restart(int *ev) { (void)ev; restarts++; }
static void arch_vcpu_prempt_normal(struct vmm_scheduler_ctrl *s) {
    normal_pauses++;
    if(s->current_vcpu->wq_lock) drop_lock(s->current_vcpu->wq_lock);
}
static void vmm_scheduler_do_migrate_action(struct vmm_vcpu *v,u32 old,u32 newcpu) {
    assert(v->sched_lock && old!=newcpu); migrations++;
}
static int vmm_scheduler_get_hcpu(struct vmm_vcpu *v,u32 *cpu) { *cpu=VCPU_HCPU(v->packed); return 0; }
static const void *vmm_cpumask_of(u32 cpu) { return (void *)(uintptr_t)(cpu+1); }
static void scheduler_system_time_sync(void *a,void *b,void *c) { (void)a; (void)b; (void)c; }
static int vmm_smp_ipi_sync_call(const void *mask,int n,void (*fn)(void *,void *,void *),void *a,void *b,void *c) {
    (void)mask; (void)n; fn(a,b,c); return 0;
}
#define TRACE_GRP_SCHEDULE 4U
#ifdef CONFIG_CMD_LAT_CTX
#define TAG_CONTEXT_SWITCH 123U
#define HYPERVISOR_ID 456U
static int TRACE_STATE;
static u32 vmm_manager_vcpu_get_hcpu(struct vmm_vcpu *v) { return VCPU_HCPU(v->packed); }
static u32 trace_grpmask(int *p) { assert(p==&TRACE_STATE); return trace_mask; }
static void trace(int *p,u32 tag,u32 domain,u64 a,u64 b,u64 c,u64 d) {
    assert(p==&TRACE_STATE && tag==TAG_CONTEXT_SWITCH && domain==HYPERVISOR_ID);
    trace_calls++; trace_a=a; trace_b=b; trace_c=c; trace_diff=d;
    ticks+=100;
}
#endif

#ifdef CONFIG_MONITOR_AGENT
#define CONFIG_MAX_VCPU_COUNT 4
struct latency { u64 count, sum, max; };
struct event {
	u64 seq, time, last, value, address, detail;
	u32 type, guest, vcpu, epoch, code, config_seq, sustain_s;
};
enum object_kind { OBJECT_GUEST, OBJECT_HOST, OBJECT_IDLE };
struct data {
	struct latency ready, dispatch;
	u64 ready_since, previous, exits, interval, count, sustained;
	u32 epoch, guest, last_exit, windows, config_seq, kind;
	bool present, waiting, active, valid;
	struct event memory;
};
struct slot { vmm_spinlock_t lock; struct data d; };
static struct slot slots[CONFIG_MAX_VCPU_COUNT + 1];
static DEFINE_SPINLOCK(event_lock);
static struct event ring[VMM_MONITOR_EVENTS];
static u64 head, cursor = 1, lost;
static atomic_t enabled=1, initialized=1;
static struct { u32 seq; } config={1};

static bool emit(struct event *e)
{
	irq_flags_t f;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	/* A concurrently published configuration invalidates an in-flight verdict. */
	if (e->type == 1 && e->config_seq != config.seq) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return FALSE;
	}
	e->seq = ++head;
	if (head - cursor >= VMM_MONITOR_EVENTS) { cursor++; lost++; }
	ring[(head - 1) % VMM_MONITOR_EVENTS] = *e;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return TRUE;
}

static __attribute__((noinline)) void memory_flush(struct data *d)
{
	if (d->memory.value) { emit(&d->memory); d->memory.value = 0; }
}

static void add(struct latency *s, u64 ns)
{
	s->count++; s->sum += ns;
	if (ns > s->max) s->max = ns;
}

static void monitor_core_record(struct vmm_vcpu *v, u32 hook, u64 a, u64 b)
{
	struct slot *s;
	struct data *d;
	irq_flags_t f;
	u32 run;
	bool reset = hook == MON_STATE &&
		(a == VMM_VCPU_STATE_RESET || a == VMM_VCPU_STATE_UNKNOWN);
	if (!arch_atomic_read(&initialized) ||
	    (!arch_atomic_read(&enabled) && !reset) ||
	    (v && (v->id >= CONFIG_MAX_VCPU_COUNT || (v->is_normal && !v->guest))) ||
	    (hook == MON_EXIT && (!v || !v->is_normal)) ||
	    (!v && hook <= MON_FAULT)) return;
	s = &slots[v ? v->id : CONFIG_MAX_VCPU_COUNT]; d = &s->d;
	vmm_spin_lock_irqsave_lite(&s->lock, f);
	run = arch_atomic_read(&enabled);
	if (!run && !reset) goto done;
	if (reset || d->epoch != run) {
		memory_flush(d);
		memset(d, 0, sizeof(*d));
		d->epoch = run;
		d->previous = vmm_timer_timestamp();
	}
	d->present = !(reset && a == VMM_VCPU_STATE_UNKNOWN);
	d->guest = v && v->is_normal ? v->guest->id : ~0U;
	if (v && v->is_normal) d->kind = OBJECT_GUEST;
	else {
		/* The idle pointer is installed after orphan creation. Recognize it
		 * on a local hook; retain that identity across remote state changes.
		 * This getter takes no scheduler lock (the caller may hold it). */
		if (d->kind != OBJECT_IDLE) d->kind = OBJECT_HOST;
		if (v && v == vmm_scheduler_idle_vcpu(vmm_smp_processor_id()))
			d->kind = OBJECT_IDLE;
	}
	switch (hook) {
	case MON_STATE:
		if (a == VMM_VCPU_STATE_READY) {
			if (!d->waiting) d->ready_since = b;
			d->waiting = TRUE;
		} else d->waiting = FALSE;
		break;
	case MON_SELECTED:
		if (d->waiting && a >= d->ready_since) add(&d->ready, a - d->ready_since);
		d->waiting = FALSE;
		break;
	case MON_DISPATCH:
		if (b >= a) add(&d->dispatch, b - a);
		break;
	case MON_EXIT:
		d->exits++; d->last_exit = a;
		break;
	default:
		d->memory.last = vmm_timer_timestamp();
		if (!d->memory.value) d->memory.time = d->memory.last;
		d->memory.value++;
		d->memory.type = 3;
		d->memory.guest = d->guest;
		d->memory.vcpu = v ? v->id : ~0U;
		d->memory.epoch = run;
		d->memory.code = hook - MON_FAULT;
		d->memory.address = a; d->memory.detail = b;
	}
done:
	vmm_spin_unlock_irqrestore_lite(&s->lock, f);
}

void vmm_monitor_record(struct vmm_vcpu *v,u32 hook,u64 a,u64 b) {
    assert(v && callback_count<32);
    if(hook==MON_DISPATCH) assert(!v->sched_lock);
    else assert(v->sched_lock);
    arch_atomic_write(&enabled,monitor_on?1:0);
    monitor_core_record(v,hook,a,b);
    if(!monitor_on) return;
    calls[callback_count].v=v; calls[callback_count].kind=hook;
    calls[callback_count].a=a; calls[callback_count].b=b;
    calls[callback_count].packed=v->packed;
    calls[callback_count].posts=posts;
    calls[callback_count++].switches=switches;
}
#endif

#ifdef CONFIG_SCHED_HISTORY

bool vmm_scheduler_sched_history_recording(void) {
        return (bool)arch_atomic_read(&sched_history_recording);
}

static void vmm_scheduler_record_cpu(struct vmm_scheduler_ctrl *schedp,
                                     u32 cpu, u32 vcpu,
                                     enum sched_event evt, u64 tstamp)
{
        struct sched_record record;
        bool overwrite = true;
        u32 executor = vmm_smp_processor_id();
        if (schedp->sched_history == NULL) {
                return;
        }
        WARN_ON(cpu > U8_MAX || vcpu > U8_MAX || executor > U8_MAX);
        record.tstamp = tstamp;
        record.executor = (u8)executor;
        record.cpu = (u8)cpu;
        record.vcpu = (u8)vcpu;
        record.evt = (u32)evt;
        ring_buffer_write(schedp->sched_history, (u8 *)&record, sizeof(record),
                          &overwrite);
}

static void vmm_scheduler_record_vcpu(struct vmm_vcpu *vcpu,
                                      u32 executor, u32 cpu,
                                      enum sched_event evt, u64 tstamp)
{
        struct sched_record record;
        bool overwrite = true;
        if (vcpu->sched_history == NULL) {
                return;
        }
        WARN_ON(cpu > U8_MAX || vcpu->id > U8_MAX || executor > U8_MAX);
        record.tstamp = tstamp;
        record.executor = (u8)executor;
        record.cpu = (u8)cpu;
        record.vcpu = (u8)vcpu->id;
        record.evt = (u32)evt;
        ring_buffer_write(vcpu->sched_history, (u8 *)&record, sizeof(record),
                          &overwrite);
}

#endif

static struct vmm_vcpu *__vmm_scheduler_next1(struct vmm_scheduler_ctrl *schedp,
                                              arch_regs_t *regs)
{
        int rc;
        irq_flags_t nf;
        u64 tstamp;
#ifdef CONFIG_SCHED_HISTORY
        u32 cpu = vmm_smp_processor_id();
        u64 sched_in_tstamp;
#endif
        u64 next_time_slice = VMM_VCPU_DEF_TIME_SLICE;
        struct vmm_vcpu *next = NULL;
        rc = rq_dequeue(schedp, &next, &next_time_slice);
        if (rc) {
                /* This should never happen !!! */
                vmm_panic("%s: dequeue error %d\n", __func__, rc);
        }
        vmm_write_lock_irqsave_lite(&next->sched_lock, nf);
        tstamp = vmm_timer_timestamp();
        vmm_monitor_selected(next, tstamp);
#ifdef CONFIG_SCHED_HISTORY
        sched_in_tstamp = tstamp;
#endif
        arch_vcpu_switch(NULL, next, regs);
        next->state_ready_nsecs += tstamp - next->state_tstamp;
        if (tstamp - next->state_tstamp > next->state_ready_max_nsecs) {
                next->state_ready_max_nsecs = tstamp - next->state_tstamp;
        }
        vmm_scheduler_set_state_raw(next, VMM_VCPU_STATE_RUNNING);
        next->resumed = FALSE;
        next->state_tstamp = tstamp;
        schedp->current_vcpu = next;
        schedp->current_vcpu_irq_ns_back = schedp->current_vcpu_irq_ns;
        schedp->current_vcpu_exp_ns_back = schedp->current_vcpu_exp_ns;
        schedp->current_vcpu_irq_max_ns = 0;
        schedp->current_vcpu_exp_max_ns = 0;
        vmm_timer_event_start(&schedp->ev, next_time_slice);
#ifdef CONFIG_SCHED_HISTORY
        if (unlikely(vmm_scheduler_sched_history_recording())) {
                vmm_scheduler_record_cpu(schedp, cpu, next->id, SCHED_IN,
                                         sched_in_tstamp);
                vmm_scheduler_record_vcpu(next, cpu, cpu, SCHED_IN,
                                          sched_in_tstamp);
        }
#endif
        vmm_write_unlock_irqrestore_lite(&next->sched_lock, nf);
        return next;
}

static void __vmm_scheduler_sync_system_time(struct vmm_scheduler_ctrl *schedp,
                                             struct vmm_vcpu *current)
{
        u64 system_nsecs;
        system_nsecs = schedp->current_vcpu_irq_ns - schedp->current_vcpu_irq_ns_back;
        system_nsecs += schedp->current_vcpu_exp_ns - schedp->current_vcpu_exp_ns_back;
        current->system_nsecs += system_nsecs;
        if (schedp->current_vcpu_irq_max_ns > current->irq_process_max_nsecs) {
                current->irq_process_max_nsecs =
                                        schedp->current_vcpu_irq_max_ns;
        }
        if (schedp->current_vcpu_exp_max_ns > current->exp_process_max_nsecs) {
                current->exp_process_max_nsecs =
                                        schedp->current_vcpu_exp_max_ns;
        }
        schedp->current_vcpu_irq_ns_back = schedp->current_vcpu_irq_ns;
        schedp->current_vcpu_exp_ns_back = schedp->current_vcpu_exp_ns;
        schedp->current_vcpu_irq_max_ns = 0;
        schedp->current_vcpu_exp_max_ns = 0;
}

static struct vmm_vcpu *__vmm_scheduler_next2(struct vmm_scheduler_ctrl *schedp,
                                              struct vmm_vcpu *current,
                                              arch_regs_t *regs)
{
        int rc;
        irq_flags_t nf = 0;
        u32 current_state, next_state;
        u64 tstamp = vmm_timer_timestamp();
#ifdef CONFIG_SCHED_HISTORY
        u32 cpu = vmm_smp_processor_id();
        u64 sched_out_tstamp, sched_in_tstamp;
        enum sched_event evt;
#endif
        u64 next_time_slice = VMM_VCPU_DEF_TIME_SLICE;
        struct vmm_vcpu *next = NULL;
        struct vmm_vcpu *tcurrent = NULL;
        /* Normal scheduling */
        BUG_ON(vmm_scheduler_get_state(current, &current_state) != VMM_OK);
        if (current_state & VMM_VCPU_STATE_SAVEABLE) {
                if (current_state == VMM_VCPU_STATE_RUNNING) {
                        __vmm_scheduler_sync_system_time(schedp, current);
                        current->state_running_nsecs +=
                                tstamp - current->state_tstamp;
                        if (tstamp - current->state_tstamp >
                            current->state_running_max_nsecs) {
                                current->state_running_max_nsecs =
                                        tstamp - current->state_tstamp;
                        }
                        vmm_scheduler_set_state_raw(current, VMM_VCPU_STATE_READY);
                        current->state_tstamp = tstamp;
                        vmm_monitor_state(current, VMM_VCPU_STATE_READY, tstamp);
                        rq_enqueue(schedp, current);
                }
                tcurrent = current;
        }
dequeue_again:
        rc = rq_dequeue(schedp, &next, &next_time_slice);
        if (rc) {
                /* This should never happen !!! */
                vmm_panic("%s: dequeue error %d\n", __func__, rc);
        }
        if (next != current) {
                vmm_write_lock_irqsave_lite(&next->sched_lock, nf);
                /* On SMP host, the next VCPU dequeued from ready queue can
                 * be RESET, PAUSED, or HALTED from another host CPU after
                 * it is dequeued and before we acquire next->sched_lock.
                 *
                 * To tackle the above situation, we check whether the next
                 * VCPU is in READY state or not before doing context switch.
                 * If the next VCPU is not in READY state then we try to
                 * dequeue another next VCPU.
                 */
                BUG_ON(vmm_scheduler_get_state(next, &next_state) != VMM_OK);
                if (next_state != VMM_VCPU_STATE_READY) {
                        vmm_write_unlock_irqrestore_lite(&next->sched_lock, nf);
                        goto dequeue_again;
                }
                /*
                 * The old tstamp is fetched before we acquiring
                 * next->sched_lock, which means next->state_tstamp may be
                 * after tstamp. So we need to update tstamp at this point.
                 */
                tstamp = vmm_timer_timestamp();
                vmm_monitor_selected(next, tstamp);
                arch_vcpu_switch(tcurrent, next, regs);
        }
#ifdef CONFIG_SCHED_HISTORY
        sched_out_tstamp = sched_in_tstamp = vmm_timer_timestamp();
        if (next == current) {
                vmm_monitor_selected(next, sched_in_tstamp);
        }
#else
        if (next == current) {
                vmm_monitor_selected(next, vmm_timer_timestamp());
        }
#endif
        next->state_ready_nsecs += tstamp - next->state_tstamp;
        if (tstamp - next->state_tstamp > next->state_ready_max_nsecs) {
                next->state_ready_max_nsecs = tstamp - next->state_tstamp;
        }
        vmm_scheduler_set_state_raw(next, VMM_VCPU_STATE_RUNNING);
        next->resumed = FALSE;
        next->state_tstamp = tstamp;
        schedp->current_vcpu = next;
        schedp->current_vcpu_irq_ns_back = schedp->current_vcpu_irq_ns;
        schedp->current_vcpu_exp_ns_back = schedp->current_vcpu_exp_ns;
        schedp->current_vcpu_irq_max_ns = 0;
        schedp->current_vcpu_exp_max_ns = 0;
        vmm_timer_event_start(&schedp->ev, next_time_slice);
        if (next != current) {
#ifdef CONFIG_SCHED_HISTORY
                if (unlikely(vmm_scheduler_sched_history_recording())) {
                        if ((current_state & VMM_VCPU_STATE_READY) != (u32)0 ||
                            (current_state & VMM_VCPU_STATE_RUNNING) != (u32)0) {
                                evt = SCHED_OUT_RUNNABLE;
                        } else {
                                evt = SCHED_OUT_UNRUNNABLE;
                        }
                        vmm_scheduler_record_cpu(schedp, cpu, current->id, evt,
                                                 sched_out_tstamp);
                        vmm_scheduler_record_vcpu(current, cpu, cpu, evt,
                                                  sched_out_tstamp);
                        vmm_scheduler_record_cpu(schedp, cpu, next->id,
                                                 SCHED_IN, sched_in_tstamp);
                        vmm_scheduler_record_vcpu(next, cpu, cpu, SCHED_IN,
                                                  sched_in_tstamp);
                }
#endif
                vmm_write_unlock_irqrestore_lite(&next->sched_lock, nf);
        }
        return (next != current) ? next : NULL;
}

#ifdef CONFIG_CMD_LAT_CTX
static void trace_ctx_switch(u64 diff, struct vmm_vcpu *current, struct vmm_vcpu *next){
        /*
                打点记录信息:
                a: 高32位: current  vcpuid 低32位: next vcpuid
                b: 高32位: current hcpu    低32位: next hcpu
                c: 高32位: current 优先级   低32位: next 优先级
                d: 本次切换的耗时(ns)
        */
        /* 检查SCHEDULE组使能 才打点 */
        if(TRACE_GRP_SCHEDULE & (u32)trace_grpmask(&TRACE_STATE)){
                u64 a = ((u64)current->id << 32) | (u64)next->id;
                u32 current_hcpu = vmm_manager_vcpu_get_hcpu(current);
                u32 next_hcpu = vmm_manager_vcpu_get_hcpu(next);
                u64 b = ((u64)current_hcpu << 32) | (u64)next_hcpu;
                u64 c = ((u64)current->priority << 32) | (u64)next->priority;
                u64 d = diff;
                trace(&TRACE_STATE, TAG_CONTEXT_SWITCH, HYPERVISOR_ID, a, b, c, d);
        }
}

#endif

static void vmm_scheduler_switch(struct vmm_scheduler_ctrl *schedp,
                                 arch_regs_t *regs)
{
        u32 preempt_min;
        struct vmm_vcpu *next;
        struct vmm_vcpu *current = schedp->current_vcpu;
#if defined(CONFIG_CMD_LAT_CTX) || defined(CONFIG_MONITOR_AGENT)
        u64 t1=0, t2=0;
#endif
#ifdef CONFIG_MONITOR_AGENT
        bool scheduled = FALSE;
#endif
        if (!regs) {
                /* This should never happen !!! */
                vmm_panic("%s: null pointer to regs.\n", __func__);
        }
        if (current) {
                preempt_min = (current->wq_lock) ? 1 : 0;
                if (current->preempt_count == preempt_min) {
                        irq_flags_t cf;
                        vmm_write_lock_irqsave_lite(&current->sched_lock, cf);
#if defined(CONFIG_CMD_LAT_CTX) || defined(CONFIG_MONITOR_AGENT)
                        /* 点位1: shared by trace and monitor. */
                        t1 = vmm_timer_timestamp();
#endif
#ifdef CONFIG_MONITOR_AGENT
                        scheduled = TRUE;
#endif
                        next = __vmm_scheduler_next2(schedp, current, regs);
                        vmm_write_unlock_irqrestore_lite(&current->sched_lock,
                                                         cf);
                        if (next != current) {
                                if (current->wq_lock) {
                                        vmm_spin_unlock_lite(current->wq_lock);
                                        arch_cpu_irq_save(cf);
                                        if (current->preempt_count) {
                                                current->preempt_count--;
                                        }
                                        arch_cpu_irq_restore(cf);
                                }
                        }
                } else {
                        vmm_timer_event_restart(&schedp->ev);
                        next = NULL;
                }
        } else {
#ifdef CONFIG_MONITOR_AGENT
                t1 = vmm_timer_timestamp();
                scheduled = TRUE;
#endif
                next = __vmm_scheduler_next1(schedp, regs);
        }
        if (next) {
                arch_vcpu_post_switch(next, regs);
#if defined(CONFIG_CMD_LAT_CTX) || defined(CONFIG_MONITOR_AGENT)
                /* 点位2: capture once, before either consumer runs. */
                t2 = vmm_timer_timestamp();
#endif
#ifdef CONFIG_CMD_LAT_CTX
                if(current && next != current){
                        trace_ctx_switch(t2 - t1, current, next);
                }
#endif
        }
#ifdef CONFIG_MONITOR_AGENT
        if (scheduled) {
                /* NULL also denotes current selected again, not only deferral. */
                if (!next) {
                        t2 = vmm_timer_timestamp();
                }
                vmm_monitor_dispatch(next ? next : current, t1, t2);
        }
#endif
}

int vmm_scheduler_state_change(struct vmm_vcpu *vcpu, u32 new_state)
{
begin:
        u64 tstamp;
        int rc = VMM_OK;
        irq_flags_t flags;
        bool resumed, preempt = FALSE;
        u32 chcpu = vmm_smp_processor_id(), vhcpu;
        struct vmm_scheduler_ctrl *schedp;
#ifdef CONFIG_SCHED_HISTORY
        struct vmm_scheduler_ctrl *cur_schedp;
#endif
        u32 current_state;
        u64 state_packed;
        long reboot_flag = 0L;
        if (!vcpu) {
                return VMM_EFAIL;
        }
        reboot_flag = arch_atomic_read(&vcpu->do_reboot);
        arch_cpu_irq_save(flags);
        vmm_write_lock_lite(&vcpu->sched_lock);
        state_packed = vmm_scheduler_get_state_packed(vcpu);
        vhcpu = VCPU_HCPU(state_packed);
        schedp = &per_cpu(sched, vhcpu);
#ifdef CONFIG_SCHED_HISTORY
        cur_schedp = &this_cpu(sched);
#endif
        current_state = VCPU_STATE(state_packed);
        switch (new_state) {
        case VMM_VCPU_STATE_UNKNOWN:
                /* Existing VCPU being destroyed */
                rc = vmm_schedalgo_vcpu_cleanup(vcpu);
                break;
        case VMM_VCPU_STATE_RESET:
                if (current_state == VMM_VCPU_STATE_UNKNOWN) {
                        /* New VCPU */
                        rc = vmm_schedalgo_vcpu_setup(vcpu);
                } else if (current_state != VMM_VCPU_STATE_RESET) {
                        /* Existing VCPU */
                        /* Clear resumed flag */
                        vcpu->resumed = FALSE;
                        /* Make sure VCPU is not in a ready queue */
                        if ((schedp->current_vcpu != vcpu) &&
                            (current_state == VMM_VCPU_STATE_READY)) {
                                if ((rc = rq_detach(schedp, vcpu))) {
                                        break;
                                }
#ifdef CONFIG_SCHED_HISTORY
                                tstamp = vmm_timer_timestamp();
                                if (unlikely(
                                    vmm_scheduler_sched_history_recording())) {
                                        vmm_scheduler_record_cpu(cur_schedp,
                                                        vhcpu, vcpu->id,
                                                        SET_UNRUNNABLE,
                                                        tstamp);
                                        vmm_scheduler_record_vcpu(vcpu, chcpu,
                                                        vhcpu, SET_UNRUNNABLE,
                                                        tstamp);
                                }
#endif
                        }
                        /* Make sure current VCPU is preempted */
                        if ((schedp->current_vcpu == vcpu) &&
                            (current_state == VMM_VCPU_STATE_RUNNING)) {
                                preempt = TRUE;
                        }
                        vcpu->reset_count++;
                        if ((rc = arch_vcpu_init(vcpu))) {
                                break;
                        }
                        if ((rc = vmm_vcpu_irq_init(vcpu))) {
                                break;
                        }
                } else {
                        goto skip_state_change;
                }
                break;
        case VMM_VCPU_STATE_READY:
                if ((current_state == VMM_VCPU_STATE_RESET) ||
                    (current_state == VMM_VCPU_STATE_PAUSED)) {
                        /* Enqueue VCPU to ready queue */
                        rc = rq_enqueue(schedp, vcpu);
#ifdef CONFIG_SCHED_HISTORY
                        tstamp = vmm_timer_timestamp();
                        if (unlikely(
                            vmm_scheduler_sched_history_recording())) {
                                vmm_scheduler_record_cpu(cur_schedp, vhcpu,
                                                         vcpu->id,
                                                         SET_RUNNABLE, tstamp);
                                vmm_scheduler_record_vcpu(vcpu, chcpu, vhcpu,
                                                          SET_RUNNABLE,
                                                          tstamp);
                        }
#endif
                        if (!rc && (schedp->current_vcpu != vcpu)) {
                                if (chcpu == vhcpu) {
                                        preempt = rq_prempt_needed(schedp);
                                } else {
#if defined(CONFIG_ADAPTIVE_HALT_TRAP)
                                        /*
                                         * Even if the VCPU has a lower
                                         * priority than target CPU's current
                                         * VCPU, we should still raise a notify
                                         * for fear that the target CPU's
                                         * current VCPU is not busy but not
                                         * trapped.
                                         */
                                        preempt = TRUE;
#else
                                        preempt = rq_prempt_needed(schedp);
#endif
                                }
                        }
                        if (vcpu->wq_cleanup)
                                vcpu->wq_cleanup(vcpu);
                } else if (current_state == VMM_VCPU_STATE_RUNNING) {
                        /* Set resumed flag. This means we catch
                         * resume event while VCPU is RUNNING.
                         */
                        vcpu->resumed = TRUE;
                        preempt = TRUE;
                        goto skip_state_change;
                } else if (current_state == VMM_VCPU_STATE_READY) {
                        /* READY->READY is a valid scenario... Do nothing. */
                        goto skip_state_change;
                } else {
                        rc = VMM_EINVALID;
                }
                break;
        case VMM_VCPU_STATE_RUNNING:
                /* Only context-switch can set RUNNING state.
                 * Any request for setting RUNNING state is invalid.
                 */
                rc = VMM_EINVALID;
                break;
        case VMM_VCPU_STATE_PAUSED:
                if (current_state == VMM_VCPU_STATE_PAUSED) {
                        goto skip_state_change;
                }
        case VMM_VCPU_STATE_HALTED:
                if ((current_state == VMM_VCPU_STATE_READY) ||
                    (current_state == VMM_VCPU_STATE_RUNNING)) {
                        resumed = vcpu->resumed;
                        vcpu->resumed = FALSE;
                        if (resumed && (new_state == VMM_VCPU_STATE_PAUSED)) {
                                if (vcpu->wq_cleanup)
                                        vcpu->wq_cleanup(vcpu);
                                goto skip_state_change;
                        } else if (schedp->current_vcpu == vcpu) {
                                /* Preempt current VCPU if paused or halted */
                                preempt = TRUE;
                        } else if (current_state == VMM_VCPU_STATE_READY) {
                                /* Make sure VCPU is not in a ready queue */
                                rc = rq_detach(schedp, vcpu);
#ifdef CONFIG_SCHED_HISTORY
                                if (rc != VMM_OK) {
                                        break;
                                }
                                tstamp = vmm_timer_timestamp();
                                if (unlikely(
                                    vmm_scheduler_sched_history_recording())) {
                                        vmm_scheduler_record_cpu(cur_schedp,
                                                        vhcpu, vcpu->id,
                                                        SET_UNRUNNABLE,
                                                        tstamp);
                                        vmm_scheduler_record_vcpu(vcpu, chcpu,
                                                        vhcpu, SET_UNRUNNABLE,
                                                        tstamp);
                                }
#endif
                        }
                } else {
                        if (vcpu->wq_cleanup)
                                vcpu->wq_cleanup(vcpu);
                        rc = VMM_EINVALID;
                }
                break;
        };
        if (rc == VMM_OK) {
                tstamp = vmm_timer_timestamp();
                switch (current_state) {
                case VMM_VCPU_STATE_READY:
                        vcpu->state_ready_nsecs +=
                                        tstamp - vcpu->state_tstamp;
                        if (tstamp - vcpu->state_tstamp >
                            vcpu->state_ready_max_nsecs) {
                                vcpu->state_ready_max_nsecs =
                                        tstamp - vcpu->state_tstamp;
                        }
                        break;
                case VMM_VCPU_STATE_RUNNING:
                        vcpu->state_running_nsecs +=
                                        tstamp - vcpu->state_tstamp;
                        if (tstamp - vcpu->state_tstamp >
                            vcpu->state_running_max_nsecs) {
                                vcpu->state_running_max_nsecs =
                                        tstamp - vcpu->state_tstamp;
                        }
                        break;
                case VMM_VCPU_STATE_PAUSED:
                        vcpu->state_paused_nsecs +=
                                        tstamp - vcpu->state_tstamp;
                        if (tstamp - vcpu->state_tstamp >
                            vcpu->state_paused_max_nsecs) {
                                vcpu->state_paused_max_nsecs =
                                        tstamp - vcpu->state_tstamp;
                        }
                        break;
                case VMM_VCPU_STATE_HALTED:
                        vcpu->state_halted_nsecs +=
                                        tstamp - vcpu->state_tstamp;
                        if (tstamp - vcpu->state_tstamp >
                            vcpu->state_halted_max_nsecs) {
                                vcpu->state_halted_max_nsecs =
                                        tstamp - vcpu->state_tstamp;
                        }
                        break;
                default:
                        break;
                }
                if (new_state == VMM_VCPU_STATE_RESET) {
                        vcpu->state_ready_nsecs = 0;
                        vcpu->state_running_nsecs = 0;
                        vcpu->state_paused_nsecs = 0;
                        vcpu->state_halted_nsecs = 0;
                        vcpu->system_nsecs = 0;
                        vcpu->state_ready_max_nsecs = 0;
                        vcpu->state_running_max_nsecs = 0;
                        vcpu->state_paused_max_nsecs = 0;
                        vcpu->state_halted_max_nsecs = 0;
                        vcpu->irq_process_max_nsecs = 0;
                        vcpu->exp_process_max_nsecs = 0;
                        vcpu->reset_tstamp = tstamp;
                }
                vmm_monitor_state(vcpu, new_state, tstamp);
                state_packed = VCPU_STATE_PACK(vhcpu, new_state);
                vmm_scheduler_set_state_packed(vcpu, state_packed);
                vcpu->state_tstamp = tstamp;
        }
skip_state_change:
        vmm_write_unlock_lite(&vcpu->sched_lock);
        if (preempt && schedp->current_vcpu) {
                if (chcpu == vhcpu) {
                        if ((u64)reboot_flag && (schedp->current_vcpu->context_flag & CONTEXT_FLAG_IN_IRQ)) {
                                        arch_atomic_write(&vcpu->do_reboot, 0L);
                                        schedp->yield_on_irq_exit = TRUE;
                        } else if (schedp->current_vcpu->is_normal && (new_state == VMM_VCPU_STATE_PAUSED) && schedp->current_vcpu->wq_lock){ //normal vcpu pause
                                arch_vcpu_prempt_normal(schedp);
                                if (schedp->current_vcpu->wq_lock) {
                                        vmm_spin_lock(
                                                schedp->current_vcpu->wq_lock);
                                }
                        } else if (schedp->current_vcpu->is_normal) {
                                schedp->yield_on_irq_exit = TRUE;
                        } else if (schedp->irq_context) {
                                vmm_scheduler_switch(schedp, schedp->irq_regs);
                        } else {
                                arch_vcpu_preempt_orphan();
                                if (schedp->current_vcpu->wq_lock) {
                                        vmm_spin_lock(
                                                schedp->current_vcpu->wq_lock);
                                }
                        }
                } else {
                        rc = vmm_scheduler_force_resched(vhcpu);
                }
        }
        arch_cpu_irq_restore(flags);
        if (rc) {
                vmm_printf("vcpu=%s current_state=0x%x to new_state=0x%x "
                           "failed (error %d)\n",
                           vcpu->name, current_state, new_state, rc);
        }
        //满足1、该vcpu前序处于paused状态且vcpu halt未成功 2、vcpu重新被调度为ready/running状态
        /* Started by AICoder, pid:n91168309es28aa144de0ac2305af70c7d79dfcc */
        // 如果vcpu的halt_flag为true，并且vcpu的状态为VMM_VCPU_STATE_READY或VMM_VCPU_STATE_RUNNING
        BUG_ON(vmm_scheduler_get_state(vcpu, &current_state) != VMM_OK);
        if(!rc && vcpu->halt_flag == true &&
           (current_state == VMM_VCPU_STATE_READY ||
            current_state == VMM_VCPU_STATE_RUNNING)) {
                // 将vcpu的halt_flag设置为false
                vcpu->halt_flag = false;
                // 将新状态设置为VMM_VCPU_STATE_HALTED
                new_state = VMM_VCPU_STATE_HALTED;
                // 跳转到begin标签处继续执行
                goto begin;
        }
        /* Ended by AICoder, pid:n91168309es28aa144de0ac2305af70c7d79dfcc */
        return rc;
}

int vmm_scheduler_stats(struct vmm_vcpu *vcpu,
                        u32 *state, u8 *priority, u32 *hcpu,
                        u32 *reset_count, u64 *last_reset_nsecs,
                        u64 *ready_nsecs, u64 *running_nsecs,
                        u64 *paused_nsecs, u64 *halted_nsecs,
                        u64 *system_nsecs,
                        u64 *ready_max_nsecs, u64 *running_max_nsecs,
                        u64 *paused_max_nsecs, u64 *halted_max_nsecs,
                        u64 *irq_process_max_nsecs,
                        u64 *exp_process_max_nsecs)
{
        int rc;
        irq_flags_t flags;
        u64 current_tstamp;
        u32 vcpu_hcpu, current_state;
        u64 state_packed;
        if (!vcpu) {
                return VMM_EFAIL;
        }
        /* Get host CPU assigned to given VCPU */
        rc = vmm_scheduler_get_hcpu(vcpu, &vcpu_hcpu);
        if (rc) {
                return rc;
        }
        /* Syncup system time on assigned host CPU */
        rc = vmm_smp_ipi_sync_call(vmm_cpumask_of(vcpu_hcpu), 0,
                                   scheduler_system_time_sync,
                                   NULL, NULL, NULL);
        if (rc) {
                return rc;
        }
        /* Current timestamp */
        current_tstamp = vmm_timer_timestamp();
        /* Acquire scheduling lock */
        vmm_write_lock_irqsave_lite(&vcpu->sched_lock, flags);
        state_packed = vmm_scheduler_get_state_packed(vcpu);
        /* Current state */
        current_state = VCPU_STATE(state_packed);
        /* Retrive current state and current hcpu */
        if (state) {
                *state = current_state;
        }
        if (priority) {
                *priority = vcpu->priority;
        }
        if (hcpu) {
                *hcpu = VCPU_HCPU(state_packed);
        }
        /* Syncup statistics based on current timestamp */
        switch (current_state) {
        case VMM_VCPU_STATE_READY:
                vcpu->state_ready_nsecs +=
                                current_tstamp - vcpu->state_tstamp;
                if (current_tstamp - vcpu->state_tstamp >
                    vcpu->state_ready_max_nsecs) {
                        vcpu->state_ready_max_nsecs =
                                current_tstamp - vcpu->state_tstamp;
                }
                vcpu->state_tstamp = current_tstamp;
                break;
        case VMM_VCPU_STATE_RUNNING:
                vcpu->state_running_nsecs +=
                                current_tstamp - vcpu->state_tstamp;
                if (current_tstamp - vcpu->state_tstamp >
                    vcpu->state_running_max_nsecs) {
                        vcpu->state_running_max_nsecs =
                                current_tstamp - vcpu->state_tstamp;
                }
                vcpu->state_tstamp = current_tstamp;
                break;
        case VMM_VCPU_STATE_PAUSED:
                vcpu->state_paused_nsecs +=
                                current_tstamp - vcpu->state_tstamp;
                if (current_tstamp - vcpu->state_tstamp >
                    vcpu->state_paused_max_nsecs) {
                        vcpu->state_paused_max_nsecs =
                                current_tstamp - vcpu->state_tstamp;
                }
                vcpu->state_tstamp = current_tstamp;
                break;
        case VMM_VCPU_STATE_HALTED:
                vcpu->state_halted_nsecs +=
                                current_tstamp - vcpu->state_tstamp;
                if (current_tstamp - vcpu->state_tstamp >
                    vcpu->state_halted_max_nsecs) {
                        vcpu->state_halted_max_nsecs =
                                current_tstamp - vcpu->state_tstamp;
                }
                vcpu->state_tstamp = current_tstamp;
                break;
        default:
                break;
        }
        /* Retrive statistics */
        if (reset_count) {
                *reset_count = vcpu->reset_count;
        }
        if (last_reset_nsecs) {
                *last_reset_nsecs = current_tstamp - vcpu->reset_tstamp;
        }
        if (ready_nsecs) {
                *ready_nsecs = vcpu->state_ready_nsecs;
        }
        if (running_nsecs) {
                *running_nsecs = vcpu->state_running_nsecs;
        }
        if (paused_nsecs) {
                *paused_nsecs = vcpu->state_paused_nsecs;
        }
        if (halted_nsecs) {
                *halted_nsecs = vcpu->state_halted_nsecs;
        }
        if (system_nsecs) {
                *system_nsecs = vcpu->system_nsecs;
        }
        if (ready_max_nsecs) {
                *ready_max_nsecs = vcpu->state_ready_max_nsecs;
        }
        if (running_max_nsecs) {
                *running_max_nsecs = vcpu->state_running_max_nsecs;
        }
        if (paused_max_nsecs) {
                *paused_max_nsecs = vcpu->state_paused_max_nsecs;
        }
        if (halted_max_nsecs) {
                *halted_max_nsecs = vcpu->state_halted_max_nsecs;
        }
        if (irq_process_max_nsecs) {
                *irq_process_max_nsecs = vcpu->irq_process_max_nsecs;
        }
        if (exp_process_max_nsecs) {
                *exp_process_max_nsecs = vcpu->exp_process_max_nsecs;
        }
        /* Release scheduling lock */
        vmm_write_unlock_irqrestore_lite(&vcpu->sched_lock, flags);
        return VMM_OK;
}

int vmm_scheduler_clear_stats(struct vmm_vcpu *vcpu)
{
        int rc;
        irq_flags_t flags;
        u32 vcpu_hcpu;
        if (!vcpu) {
                return VMM_EFAIL;
        }
        /* Get host CPU assigned to given VCPU */
        rc = vmm_scheduler_get_hcpu(vcpu, &vcpu_hcpu);
        if (rc) {
                return rc;
        }
        /* Syncup system time on assigned host CPU */
        rc = vmm_smp_ipi_sync_call(vmm_cpumask_of(vcpu_hcpu), 0,
                                   scheduler_system_time_sync,
                                   NULL, NULL, NULL);
        if (rc) {
                return rc;
        }
        /* Acquire scheduling lock */
        vmm_write_lock_irqsave_lite(&vcpu->sched_lock, flags);
        vcpu->reset_count = 0;
        vcpu->reset_tstamp = 0;
        vcpu->state_ready_nsecs = 0;
        vcpu->state_running_nsecs = 0;
        vcpu->state_paused_nsecs = 0;
        vcpu->state_halted_nsecs = 0;
        vcpu->system_nsecs = 0;
        vcpu->state_ready_max_nsecs = 0;
        vcpu->state_running_max_nsecs = 0;
        vcpu->state_paused_max_nsecs = 0;
        vcpu->state_halted_max_nsecs = 0;
        vcpu->irq_process_max_nsecs = 0;
        vcpu->exp_process_max_nsecs = 0;
        /* Release scheduling lock */
        vmm_write_unlock_irqrestore_lite(&vcpu->sched_lock, flags);
        return VMM_OK;
}

static void scheduler_ipi_migrate_vcpu(void *arg0, void *arg1, void *arg2)
{
        irq_flags_t flags;
        u32 old_hcpu = vmm_smp_processor_id(), hcpu;
#ifdef CONFIG_SCHED_HISTORY
        struct vmm_scheduler_ctrl *schedp = &this_cpu(sched);
        u64 tstamp;
#endif
        u64 state_packed;
        u32 state, new_hcpu = (u32)(virtual_addr_t)arg1;
        struct vmm_vcpu *vcpu = arg0;
        /* Lock VCPU scheduling */
        vmm_write_lock_irqsave_lite(&vcpu->sched_lock, flags);
        state_packed = vmm_scheduler_get_state_packed(vcpu);
        state = VCPU_STATE(state_packed);
        hcpu = VCPU_HCPU(state_packed);
        /* The VCPU has to be in READY state otherwise we skip */
        if ((state != VMM_VCPU_STATE_READY) ||
            (hcpu != old_hcpu) ||
            (hcpu == new_hcpu)) {
                goto skip;
        }
        /* Detach VCPU from old hcpu ready queue */
        rq_detach(&per_cpu(sched, old_hcpu), vcpu);
#ifdef CONFIG_SCHED_HISTORY
        tstamp = vmm_timer_timestamp();
        if (unlikely(vmm_scheduler_sched_history_recording())) {
                vmm_scheduler_record_cpu(schedp, old_hcpu, vcpu->id,
                                         MIGRATE_OUT, tstamp);
                vmm_scheduler_record_vcpu(vcpu, old_hcpu, old_hcpu,
                                          MIGRATE_OUT, tstamp);
        }
#endif
        state_packed = VCPU_STATE_PACK(new_hcpu, state);
        vmm_scheduler_set_state_packed(vcpu, state_packed);
        vmm_scheduler_do_migrate_action(vcpu, old_hcpu, new_hcpu);
        /* Enqueue VCPU to new hcpu ready queue */
        rq_enqueue(&per_cpu(sched, new_hcpu), vcpu);
#ifdef CONFIG_SCHED_HISTORY
        tstamp = vmm_timer_timestamp();
        if (unlikely(vmm_scheduler_sched_history_recording())) {
                vmm_scheduler_record_cpu(schedp, new_hcpu, vcpu->id,
                                         MIGRATE_IN, tstamp);
                vmm_scheduler_record_vcpu(vcpu, old_hcpu, new_hcpu,
                                          MIGRATE_IN, tstamp);
        }
#endif
        /* Trigger re-scheduling on new hcpu */
        vmm_scheduler_force_resched(new_hcpu);
skip:
        /* Unlock VCPU scheduling */
        vmm_write_unlock_irqrestore_lite(&vcpu->sched_lock, flags);
}

static unsigned target_kind; /* 0=Guest, 1=host priority 7, 2=idle */
static void reset_test(struct vmm_vcpu *v,u32 state,u32 cpu) {
    memset(sched,0,sizeof(sched)); memset(calls,0,sizeof(calls));
    memset(cpu_history,0,sizeof(cpu_history)); memset(vcpu_history,0,sizeof(vcpu_history));
    for(unsigned i=0;i<12;i++) sched[i].sched_history=&cpu_history[i];
    *v=(struct vmm_vcpu){.id=1,.packed=VCPU_STATE_PACK(cpu,state),.name="test",
        .is_normal=true,.state_tstamp=50,.wq_cleanup=cleanup,.priority=3,
        .guest=&guest,.sched_history=&vcpu_history[1]};
    ticks=100; timestamps=switches=callback_count=cleanup_calls=0;
    enqueue_error=arch_init_error=resched_error=0;
    posts=restarts=trace_calls=fake_cpu=migrations=normal_pauses=0;
    trace_diff=trace_a=trace_b=trace_c=0;
    trace_mask=TRACE_GRP_SCHEDULE; monitor_on=true;
#ifdef CONFIG_SCHED_HISTORY
    sched_history_recording=1;
#endif
#ifdef CONFIG_MONITOR_AGENT
    memset(slots,0,sizeof(slots)); memset(ring,0,sizeof(ring));
    enabled=initialized=1; event_lock=0; head=lost=0; cursor=1;
    for(unsigned i=0;i<=CONFIG_MAX_VCPU_COUNT;i++) slots[i].d.epoch=1;
#endif
}
static void count_hooks(unsigned n) {
#ifdef CONFIG_MONITOR_AGENT
    assert(callback_count==n);
#else
    (void)n; assert(callback_count==0);
#endif
}
#ifdef CONFIG_MONITOR_AGENT
static u64 state_ready_stamp(void) {
#ifdef CONFIG_SCHED_HISTORY
    return 102;
#else
    return 101;
#endif
}
#endif
static void test_outer(bool first,bool same,bool stale,bool waitqueue,
                       bool history,bool group,bool active,bool zero_start) {
    struct vmm_vcpu a,b,bad;
    arch_regs_t regs=0;
    int wq=1;
    reset_test(&a,VMM_VCPU_STATE_RUNNING,2); fake_cpu=2;
    b=a; b.id=2; b.priority=5; b.packed=VCPU_STATE_PACK(2,VMM_VCPU_STATE_READY);
    b.sched_history=&vcpu_history[2];
    bad=b; bad.id=3; bad.packed=VCPU_STATE_PACK(2,VMM_VCPU_STATE_PAUSED);
    bad.sched_history=&vcpu_history[3];
#ifdef CONFIG_SCHED_HISTORY
    sched_history_recording=history;
#else
    (void)history;
#endif
    trace_mask=group?TRACE_GRP_SCHEDULE:0; monitor_on=active;
    if(zero_start) ticks=UINT64_MAX;
    if(target_kind) {
        a.is_normal=b.is_normal=FALSE; a.guest=b.guest=NULL;
        a.priority=b.priority=7;
        if(target_kind==2) {
            sched[2].idle_vcpu=same?&a:&b;
            sched[2].idle_vcpu->priority=0;
        }
    }
    if(!first) sched[2].current_vcpu=&a;
    if(waitqueue) { a.wq_lock=&wq; a.preempt_count=1; }
    if(stale) rq_enqueue(&sched[2],&bad);
    if(!same) rq_enqueue(&sched[2],&b);
    vmm_scheduler_switch(&sched[2],&regs);
    struct vmm_vcpu *target=same?&a:&b;
    assert(sched[2].current_vcpu==target);
    assert(VCPU_STATE(target->packed)==VMM_VCPU_STATE_RUNNING);
    assert(VCPU_HCPU(a.packed)==2 && VCPU_HCPU(b.packed)==2);
    assert(switches==(unsigned)!same && posts==(unsigned)!same && restarts==0);
    assert(!a.sched_lock && !b.sched_lock && !bad.sched_lock);
    if(waitqueue) assert(wq==0 && a.preempt_count==0);
#ifdef CONFIG_CMD_LAT_CTX
    unsigned wanted=group && !first && !same;
    assert(trace_calls==wanted);
    if(wanted) {
        assert(trace_a==(((u64)a.id<<32)|b.id));
        assert(trace_b==(((u64)2<<32)|2));
        assert(trace_c==(((u64)a.priority<<32)|b.priority));
    }
#else
    assert(trace_calls==0);
#endif
#ifdef CONFIG_SCHED_HISTORY
    unsigned hist_count=history && !same ? (first?1:2):0;
    assert(cpu_history[2].count==hist_count);
    assert(vcpu_history[1].count==(unsigned)(history && !same && !first));
    assert(vcpu_history[2].count==(unsigned)(history && !same));
    assert(vcpu_history[3].count==0);
    if(hist_count) {
        const struct sched_record *in=&cpu_history[2].record[hist_count-1];
        assert(in->evt==SCHED_IN && in->vcpu==2 && in->cpu==2 && in->executor==2);
        assert(in->tstamp==vcpu_history[2].record[0].tstamp);
        if(!first) {
            assert(cpu_history[2].record[0].evt==SCHED_OUT_RUNNABLE);
            assert(cpu_history[2].record[0].tstamp==in->tstamp);
        }
    }
#else
    assert(cpu_history[2].count==0);
#endif
#ifdef CONFIG_MONITOR_AGENT
    count_hooks(active?(first?2:3):0);
    if(active) {
        unsigned selected=first?0:1, dispatch=selected+1;
        u64 base=zero_start?0:101;
        if(!first) {
            assert(calls[0].kind==MON_STATE && calls[0].v==&a);
            assert(calls[0].a==VMM_VCPU_STATE_READY && calls[0].b==base+1);
        }
        assert(calls[selected].kind==MON_SELECTED && calls[selected].v==target);
        assert(calls[selected].switches==0);
        assert(calls[selected].a==base+(first?1:2));
        assert(calls[dispatch].kind==MON_DISPATCH && calls[dispatch].v==target);
        assert(calls[dispatch].a==base && calls[dispatch].posts==(unsigned)!same);
        u64 duration=first?62:(same?3:63);
#ifdef CONFIG_SCHED_HISTORY
        if(!first && !same) duration++;
#endif
        assert(calls[dispatch].b==base+duration);
        assert(slots[target->id].d.kind==(target_kind==2 ? OBJECT_IDLE : target_kind==1 ? OBJECT_HOST : OBJECT_GUEST));
        assert(slots[target->id].d.guest==(target_kind ? ~0U : guest.id));
        assert(slots[target->id].d.dispatch.count==1);
        assert(slots[target->id].d.dispatch.sum==duration);
        if(same) {
            assert(slots[a.id].d.ready.count==1 && slots[a.id].d.ready.sum==1);
            assert(!slots[a.id].d.waiting);
        }
        if(trace_calls) {
            assert(trace_diff==calls[dispatch].b-calls[dispatch].a);
            assert(calls[dispatch].b+100==ticks);
        }
        for(unsigned i=0;i<callback_count;i++) assert(calls[i].v!=&bad);
    }
    unsigned clocks=first?3:4;
#ifdef CONFIG_SCHED_HISTORY
    if(!first && !same) clocks++;
#endif
    assert(timestamps==clocks);
#else
    count_hooks(0);
    unsigned clocks=first?1:(same?1:2);
#ifdef CONFIG_CMD_LAT_CTX
    clocks+=first||same?1:2;
#endif
#ifdef CONFIG_SCHED_HISTORY
    if(!first) clocks++;
#endif
    assert(timestamps==clocks);
#endif
}
static void test_deferred(void) {
    struct vmm_vcpu a,b;
    arch_regs_t regs=0;
    reset_test(&a,VMM_VCPU_STATE_RUNNING,0);
    a.preempt_count=2; b=a; b.id=2;
    b.packed=VCPU_STATE_PACK(0,VMM_VCPU_STATE_READY);
    sched[0].current_vcpu=&a; rq_enqueue(&sched[0],&b);
    vmm_scheduler_switch(&sched[0],&regs);
    assert(sched[0].current_vcpu==&a && sched[0].length==1);
    assert(restarts==1 && switches==0 && posts==0 && timestamps==0);
    assert(trace_calls==0 && cpu_history[0].count==0); count_hooks(0);
}
static void test_queries(void) {
    struct vmm_vcpu v;
    arch_regs_t regs=0;
    u64 ready=0,maximum=0;
    reset_test(&v,VMM_VCPU_STATE_PAUSED,0);
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0);
    u64 start=v.state_tstamp;
    ticks=start+40;
    assert(vmm_scheduler_stats(&v,NULL,NULL,NULL,NULL,NULL,&ready,NULL,NULL,NULL,NULL,
                               &maximum,NULL,NULL,NULL,NULL,NULL)==0);
    assert(ready==41 && maximum==41 && v.state_tstamp==start+41);
#ifdef CONFIG_MONITOR_AGENT
    assert(slots[v.id].d.waiting && slots[v.id].d.ready_since==start);
#endif
    assert(vmm_scheduler_clear_stats(&v)==0);
#ifdef CONFIG_MONITOR_AGENT
    assert(slots[v.id].d.waiting && slots[v.id].d.ready_since==start);
#endif
    ticks=start+100;
    vmm_scheduler_switch(&sched[0],&regs);
#ifdef CONFIG_MONITOR_AGENT
    assert(slots[v.id].d.ready.count==1 && slots[v.id].d.ready.sum==102);
    assert(slots[v.id].d.ready.max==102 && !slots[v.id].d.waiting);
    assert(v.state_ready_max_nsecs==61); /* The private counter still measures a segment. */
#endif
}
static void test_migrate(void) {
    struct vmm_vcpu v;
    arch_regs_t regs=0;
    reset_test(&v,VMM_VCPU_STATE_PAUSED,1);
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0);
#ifdef CONFIG_MONITOR_AGENT
    u64 start=slots[v.id].d.ready_since;
#endif
    ticks+=10; fake_cpu=1;
    scheduler_ipi_migrate_vcpu(&v,(void *)(uintptr_t)7,NULL);
    assert(VCPU_HCPU(v.packed)==7 && VCPU_STATE(v.packed)==VMM_VCPU_STATE_READY);
    assert(migrations==1 && sched[1].length==0 && sched[7].length==1 && !v.sched_lock);
    count_hooks(1);
#ifdef CONFIG_MONITOR_AGENT
    assert(slots[v.id].d.waiting && slots[v.id].d.ready_since==start);
#endif
    fake_cpu=7; ticks+=10; vmm_scheduler_switch(&sched[7],&regs);
#ifdef CONFIG_MONITOR_AGENT
    assert(slots[v.id].d.ready.count==1 && !slots[v.id].d.waiting);
    assert(slots[v.id].d.ready.sum==calls[1].a-start);
#endif
#ifdef CONFIG_SCHED_HISTORY
    assert(vcpu_history[1].count==4);
    assert(vcpu_history[1].record[1].evt==MIGRATE_OUT);
    assert(vcpu_history[1].record[2].evt==MIGRATE_IN);
#endif
}
static void test_failed_history(void) {
    struct vmm_vcpu v;
    reset_test(&v,VMM_VCPU_STATE_PAUSED,0); enqueue_error=VMM_EFAIL;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==VMM_EFAIL);
    assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_PAUSED); count_hooks(0);
#ifdef CONFIG_MONITOR_AGENT
    assert(!slots[v.id].d.waiting);
#endif
#ifdef CONFIG_SCHED_HISTORY
    /* Preserve input history behavior, but do not treat this event as success. */
    assert(vcpu_history[v.id].count==1 && vcpu_history[v.id].record[0].evt==SET_RUNNABLE);
#endif
}
static void test_normal_pause(void) {
    struct vmm_vcpu v;
    int wq=1;
    reset_test(&v,VMM_VCPU_STATE_RUNNING,0);
    v.wq_lock=&wq; sched[0].current_vcpu=&v;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_PAUSED)==0);
    assert(normal_pauses==1 && wq==1 && !v.sched_lock);
    count_hooks(1);
}

static void test_state(void) {
    struct vmm_vcpu v;
    reset_test(&v,VMM_VCPU_STATE_PAUSED,4);
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0);
    assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_READY && VCPU_HCPU(v.packed)==4);
    assert(sched[4].length==1 && !v.sched_lock && cleanup_calls==1);
    count_hooks(1);
#ifdef CONFIG_MONITOR_AGENT
    assert(calls[0].kind==MON_STATE && calls[0].a==VMM_VCPU_STATE_READY);
    assert(calls[0].b==state_ready_stamp() && VCPU_STATE(calls[0].packed)==VMM_VCPU_STATE_PAUSED);
#endif
    /* Repeated READY, and resume of RUNNING, do not invent a new READY period. */
    callback_count=0;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0);
    count_hooks(0);
    reset_test(&v,VMM_VCPU_STATE_RUNNING,4);
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0 && v.resumed);
    count_hooks(0); assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_RUNNING);
    /* Invalid transition and failed enqueue do not report success. */
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_RUNNING)==VMM_EINVALID);
    count_hooks(0);
    reset_test(&v,VMM_VCPU_STATE_PAUSED,4); enqueue_error=VMM_EFAIL;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==VMM_EFAIL);
    count_hooks(0); assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_PAUSED);
    /* Resume-vs-pause skip stays untouched. */
    reset_test(&v,VMM_VCPU_STATE_RUNNING,0); v.resumed=true;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_PAUSED)==0);
    count_hooks(0); assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_RUNNING);
    /* True PAUSE, HALT, RESET, destruction all reach the lifecycle hook. */
    const u32 endstates[]={VMM_VCPU_STATE_PAUSED,VMM_VCPU_STATE_HALTED,
                          VMM_VCPU_STATE_RESET,VMM_VCPU_STATE_UNKNOWN};
    for(unsigned i=0;i<4;i++) {
        reset_test(&v,VMM_VCPU_STATE_READY,9); rq_enqueue(&sched[9],&v);
        assert(vmm_scheduler_state_change(&v,endstates[i])==0);
        count_hooks(1); assert(VCPU_STATE(v.packed)==endstates[i] && VCPU_HCPU(v.packed)==9);
#ifdef CONFIG_MONITOR_AGENT
        assert(calls[0].kind==MON_STATE && calls[0].a==endstates[i]);
#endif
    }
    reset_test(&v,VMM_VCPU_STATE_RUNNING,0); arch_init_error=VMM_EFAIL;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_RESET)==VMM_EFAIL);
    count_hooks(0); assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_RUNNING);
    /* Product-specific halt_flag re-enters begin: preserve both real transitions. */
    reset_test(&v,VMM_VCPU_STATE_PAUSED,3); v.halt_flag=true;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_READY)==0);
    count_hooks(2); assert(!v.halt_flag && VCPU_STATE(v.packed)==VMM_VCPU_STATE_HALTED);
    assert(sched[3].length==0);
#ifdef CONFIG_MONITOR_AGENT
    assert(calls[0].a==VMM_VCPU_STATE_READY && calls[1].a==VMM_VCPU_STATE_HALTED);
#endif
    /* Remote notification fails AFTER the state commit: still record the commit. */
    reset_test(&v,VMM_VCPU_STATE_RUNNING,5); sched[5].current_vcpu=&v;
    resched_error=VMM_EFAIL;
    assert(vmm_scheduler_state_change(&v,VMM_VCPU_STATE_PAUSED)==VMM_EFAIL);
    count_hooks(1); assert(VCPU_STATE(v.packed)==VMM_VCPU_STATE_PAUSED);
}

int main(void) {
    for(target_kind=0;target_kind<3;target_kind++)
    for(int history=0;history<2;history++) for(int group=0;group<2;group++) for(int active=0;active<2;active++) {
        test_outer(false,false,false,false,history,group,active,false);
        test_outer(true,false,false,false,history,group,active,false);
        test_outer(false,true,false,false,history,group,active,false);
        test_outer(false,false,true,false,history,group,active,false);
        test_outer(false,false,false,true,history,group,active,false);
        test_outer(false,true,false,true,history,group,active,false);
    }
    target_kind=0;
    test_outer(false,false,false,false,true,true,true,true);
    test_outer(true,false,false,false,true,true,true,true);
    test_outer(false,true,false,false,true,true,true,true);
    test_deferred(); test_state(); test_queries(); test_migrate(); test_failed_history(); test_normal_pause();
    puts("PASS: Guest/host priority-7/idle hooks; shared timestamps; history/trace/monitor independence; actual monitor READY aggregation across queries/migration; lifecycle/errors; same/deferred; packed state/normal pause branch");
    return 0;
}
