import json,unittest
from verify_existing_logs import verify,CASES,FIELDS
class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.records=[]
        for i in range(1,4):
            self.records.append(dict(schema=3,seq=i,type=3 if i==1 else 1,guest=1,vcpu=29,epoch=4,
                time_ns=i*1000,last_ns=i*1000,code=5 if i==1 else 22,address=0x1000 if i==1 else 0,
                value=2 if i==1 else 2000,detail=16 if i==1 else 500,config_seq=1,sustain_s=2))
    def text(self):
        console='\n'.join(f'wboxtest: test={n} failures 0 out of 1' for n in sorted(CASES))+'\n'
        console+='\n'.join('monitor_live LOG '+' '.join(f'{k}={r[k]}' for k in FIELDS) for r in self.records)
        return console,'\n'.join('[monitor] '+json.dumps(r) for r in self.records)
    def test_complete(self):self.assertEqual(verify(*self.text())['matched_stored_events'],3)
    def test_permission(self):
        self.records[0]['code']=4
        self.assertEqual(verify(*self.text())['memory_categories_exercised'],[4])
    def test_missing(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c,'\n'.join(s.splitlines()[1:]))
    def test_duplicate(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c,s+'\n'+s.splitlines()[0])
    def test_wrong_vcpu(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c,s.replace('"vcpu": 29','"vcpu": 30'))
    def test_failed(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c.replace('failures 0','failures 1',1),s)
    def test_skipped(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c.replace('out of 1','out of 0',1),s)
    def test_wrong_boot(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c,s.replace('"epoch": 4','"epoch": 5'))
    def test_truncated(self):
        c,s=self.text()
        with self.assertRaises(ValueError):verify(c,s[:-10])
    def test_wrong_memory_code(self):
        self.records[0]['code']=99
        with self.assertRaises(ValueError):verify(*self.text())
if __name__=='__main__':unittest.main()
