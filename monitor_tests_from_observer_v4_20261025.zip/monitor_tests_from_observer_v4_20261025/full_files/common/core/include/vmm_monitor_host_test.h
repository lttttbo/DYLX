/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef VMM_MONITOR_HOST_TEST_H
#define VMM_MONITOR_HOST_TEST_H
#include <vmm_types.h>
struct vmm_chardev;
enum vmm_monitor_host_kind {
    VMM_MONITOR_HOST_RAM, VMM_MONITOR_HOST_DEVICE, VMM_MONITOR_HOST_GUEST
};
#ifdef CONFIG_WBOXTEST_MONITOR
/* These adapters run existing cmd_memory checks only; they never access PA. */
int vmm_monitor_host_probe(physical_addr_t addr, u32 width, u32 *kind);
int vmm_monitor_host_guard(struct vmm_chardev *out, physical_addr_t addr,
                           u32 width, bool write);
#endif
#endif
