/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
#include <libs/mathlib.h>
/* Real sampling windows are observed continuously. The Guest helper is
 * started from another console; no mailbox or Guest lifecycle changes. */
static int storm_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct vmm_monitor_test_slot s, confirmed;
    struct vmm_monitor_test_event e;
    struct vmm_monitor_test_state state;
    u64 start,deadline,previous=0,high_ns=0,last_event=0,high_after=0;
    u32 high_windows=0,low_windows=0,events=0,count,phase=0;
    bool high;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(c.baseline.config[VMM_MONITOR_SUSTAIN_S]>=2);
    ML_REQUIRE(!vmm_monitor_test_state(&state));
    start=vmm_timer_timestamp(); deadline=start+ml_timeout(&c);
    vmm_cprintf(out,"monitor_live WAIT: supply an existing controlled exit load on selected Guest vCPU\n");
    do {
        ML_REQUIRE(!ml_slot(&c,&s));
        if (s.previous!=previous && s.previous>=s.interval && s.previous-s.interval>=start) {
            /* The sampler publishes slot and event data under its lock. A
             * second slot read detects a sampling boundary between these
             * separate read-only calls; retry before advancing our state. */
            ML_REQUIRE(!ml_scan(&c,state.head,1,&e,&count));
            ML_REQUIRE(!ml_slot(&c,&confirmed));
            if (confirmed.previous!=s.previous) continue;
            ML_REQUIRE(s.valid && s.config_seq==c.baseline.config_seq);
            ML_REQUIRE(!previous || s.previous-s.interval==previous);
            previous=s.previous;
            high=s.exits>udiv64((u64)c.baseline.config[VMM_MONITOR_EXIT_LIMIT]*s.interval,VMM_MONITOR_NS);
            if (high) { high_windows++; high_ns+=s.interval; low_windows=0; }
            else { high_windows=0; high_ns=0; low_windows++; }
            ML_REQUIRE(count>=events && count<=events+1);
            if (count>events) {
                ML_REQUIRE((phase==1 || phase==3) && e.time_ns==s.previous);
                ML_REQUIRE(high_windows>=c.baseline.config[VMM_MONITOR_SUSTAIN_S] &&
                    high_ns>=(u64)c.baseline.config[VMM_MONITOR_SUSTAIN_S]*VMM_MONITOR_NS);
                ML_REQUIRE(e.config_seq==c.baseline.config_seq &&
                    e.detail==c.baseline.config[VMM_MONITOR_EXIT_LIMIT] &&
                    e.sustain_s==c.baseline.config[VMM_MONITOR_SUSTAIN_S]);
                last_event=e.seq; events=count;
                if (phase==1) { phase=2; high_after=0; }
                else { ML_REQUIRE(!ml_log_wait(&c,last_event)); rc=VMM_OK; goto out; }
            } else if (!phase && !high && low_windows>=2 && !s.active) {
                phase=1; vmm_cprintf(out,"monitor_live: quiet baseline established\n");
            } else if (phase==2) {
                if (high) high_after+=s.interval;
                else if (low_windows>=2 && !s.active) {
                    ML_REQUIRE(high_after>=(u64)c.baseline.config[VMM_MONITOR_SUSTAIN_S]*VMM_MONITOR_NS);
                    ML_REQUIRE(!ml_log_wait(&c,last_event));
                    phase=3; vmm_cprintf(out,"monitor_live: dedup and recovery observed\n");
                }
            }
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    vmm_cprintf(out,"monitor_live: incomplete evidence phase=%u events=%u; check CPU, load and threshold\n",phase,events);
    rc=VMM_ETIMEDOUT;
out:
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_storm,storm_run);
