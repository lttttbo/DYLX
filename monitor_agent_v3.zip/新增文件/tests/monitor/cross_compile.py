"""Compile touched ARM64 units; no firmware link or hardware execution.
Use a portable Zig compiler: --cc /path/to/zig --build-dir /tmp/monitor-build
Optional --baseline-ref REF compares against that local Git revision.
"""
import argparse
import os
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True
from elf_budget import totals

p=argparse.ArgumentParser()
p.add_argument('--cc',required=True)
p.add_argument('--build-dir',required=True)
p.add_argument('--baseline-ref')
p.add_argument('--baseline-dir', help='Extracted upstream sources, for offline review builds')
p.add_argument('--opt', default='s', choices=['s','z'])
p.add_argument('--enforce-rom',action='store_true')
args=p.parse_args()
root=Path(__file__).resolve().parents[2]
out=Path(args.build_dir).resolve()
out.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
defines=dict(CONFIG_64BIT=1,CONFIG_ARM64=1,CONFIG_ARM=1,CONFIG_ARMV8=1,
    CONFIG_SMP=1,CONFIG_CPU_COUNT=12,CONFIG_MAX_VCPU_COUNT=64,
    CONFIG_MAX_GUEST_COUNT=16,CONFIG_TSLICE_MS=10,CONFIG_ARM_MMU_LPAE=1,
    CONFIG_ARM_GENERIC_TIMER=1,CONFIG_HOST_IRQ_COUNT=1024,
    CONFIG_IRQ_STACK_SIZE=4096,CONFIG_THREAD_STACK_SIZE=8192,
    CONFIG_IDLE_PERIOD_SECS=2,CONFIG_IDLE_TSLICE_SECS=1,
    CONFIG_VGPA2REG_CACHE_SIZE=8,CONFIG_SCHEDALGO_PRR=1,
    CONFIG_LOG_LEVEL=6,CONFIG_MONITOR_AGENT=1,CONFIG_CMD_MONITOR=1,CONFIG_MONITOR_PRIORITY=3,
    CONFIG_MONITOR_EXIT_RATE=50000,CONFIG_MONITOR_STORM_SECONDS=5,
    CONFIG_MAJOR=0,CONFIG_MINOR=3,CONFIG_RELEASE=0,
    CONFIG_MAX_RAM_BANK_COUNT=16,CONFIG_MODULES=1,CONFIG_ARM_VGIC=1)
includes=['arch/arm/cpu/arm64/include','arch/arm/cpu/common/include',
    'arch/arm/board/generic/include','arch/arm/include','arch/include',
    'arch/common/include','core/include','drivers/include','libs/include']
new=['core/monitor/monitor_agent.c','commands/cmd_monitor.c']
changed=['core/vmm_scheduler.c','core/vmm_shmem.c','core/vmm_main.c',
    'arch/arm/cpu/arm64/cpu_interrupts.c','arch/arm/cpu/arm64/cpu_vcpu_excep.c']
results={}
modes=['on','boot_on','off','external']+(['baseline'] if args.baseline_ref or args.baseline_dir else [])
for mode in modes:
    config=defines.copy()
    if mode in ['off','baseline']:
        config.pop('CONFIG_MONITOR_AGENT'); config.pop('CONFIG_CMD_MONITOR')
    if mode=='external': config['CONFIG_MONITOR_EXTERNAL_EXECUTOR']=1
    if mode=='boot_on': config['CONFIG_MONITOR_START_ENABLED']=1
    flags=[args.cc,'cc','-target','aarch64-freestanding-none','-std=gnu11',
        '-O'+args.opt,'-ffreestanding','-fno-builtin','-fno-stack-protector',
        '-mgeneral-regs-only','-D__VMM__','-Wall','-Werror',
        '-ffile-prefix-map='+str(root)+'=xvisor',
        '-ffile-prefix-map='+str(out/'baseline')+'=xvisor',
        # These two warnings occur in unmodified upstream ARM headers.
        '-Wno-duplicate-decl-specifier','-Wno-asm-operand-widths',
        '-include',str(root/'core/include/vmm_openconf.h')]
    flags += [f'-D{k}={v}' for k,v in config.items()]
    flags += ['-I'+str(root/path) for path in includes]
    results[mode]={}
    for name in (changed if mode in ['off','baseline'] else new+changed):
        source=root/name
        if mode=='baseline':
            source=out/'baseline'/name
            source.parent.mkdir(parents=True,exist_ok=True)
            source.write_bytes((Path(args.baseline_dir)/name).read_bytes() if args.baseline_dir else subprocess.check_output(
                ['git','show',args.baseline_ref+':'+name],cwd=root))
        dest=out/(mode+'_'+Path(name).stem+'.o')
        run=subprocess.run(flags+['-DVMM_MODNAME='+Path(name).stem,
            '-c',str(source),'-o',str(dest)],capture_output=True,text=True)
        (out/(dest.stem+'.log')).write_text(run.stdout+run.stderr)
        if run.returncode:
            print(run.stdout+run.stderr)
            raise SystemExit(run.returncode)
        rom,bss=totals(dest)
        results[mode][name]=dict(rom=rom,bss=bss)
    print(f'PASS: {mode}: {len(results[mode])} ARM64 translation units')

rom=sum(results['on'][f]['rom'] for f in new)
bss=sum(results['on'][f]['bss'] for f in new)
delta=None
if 'baseline' in results:
    delta=sum(results['on'][f]['rom']-results['baseline'][f]['rom'] for f in changed)
boot_rom=sum(results['boot_on'][f]['rom'] for f in new)
boot_delta=sum(results['boot_on'][f]['rom']-results['baseline'][f]['rom'] for f in changed) if 'baseline' in results else 0
report=dict(configuration=defines,objects=results,new_rom=rom,new_bss=bss,
    hook_rom_delta=delta,total_rom_estimate=rom+(delta or 0),rom_limit=5120,
    boot_on_rom_estimate=boot_rom+boot_delta,
    limitation='Object section estimate; product link and hardware performance not tested')
(out/'report.json').write_text(json.dumps(report,indent=2))
print(f'New ROM: {rom} bytes; static BSS: {bss} bytes; hook ROM delta: {delta}')
print('ROM budget: '+('PASS' if report['total_rom_estimate']<=5120 else 'FAIL'))
if args.enforce_rom and max(report['total_rom_estimate'],report['boot_on_rom_estimate'])>5120: raise SystemExit(1)
