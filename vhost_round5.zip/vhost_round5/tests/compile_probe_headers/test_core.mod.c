#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

KSYMTAB_FUNC(vhost_n5_tx_begin, "_gpl", "");
KSYMTAB_FUNC(vhost_n5_tx_end, "_gpl", "");

SYMBOL_CRC(vhost_n5_tx_begin, 0xa2de3651, "_gpl");
SYMBOL_CRC(vhost_n5_tx_end, 0xd7bf49d6, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x581a7cd, "single_open" },
	{ 0x17de3d5, "nr_cpu_ids" },
	{ 0x9e683f75, "__cpu_possible_mask" },
	{ 0x53a1e8d9, "_find_next_bit" },
	{ 0xb19a5453, "__per_cpu_offset" },
	{ 0xdc679947, "proc_create" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xb43f9365, "ktime_get" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x77bc13a0, "strim" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x5a921311, "strncmp" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0xca25e87b, "proc_remove" },
	{ 0xa12d2260, "kmalloc_caches" },
	{ 0xc25f21b, "__kmalloc_cache_noprof" },
	{ 0x2529ebe1, "seq_printf" },
	{ 0xcffe8bb7, "seq_write" },
	{ 0x7abf3182, "seq_putc" },
	{ 0x37a0cba, "kfree" },
	{ 0xf99f317e, "seq_read" },
	{ 0x993ee334, "seq_lseek" },
	{ 0x768bc98e, "single_release" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xb609be75, "pv_ops" },
	{ 0xd4ec10e6, "BUG_func" },
	{ 0x53569707, "this_cpu_off" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x5002fa32, "module_layout" },
};

MODULE_INFO(depends, "");

