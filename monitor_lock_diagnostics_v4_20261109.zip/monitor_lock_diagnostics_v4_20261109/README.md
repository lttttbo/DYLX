# HOS monitor v4：目标槽取锁诊断

本包基于 `monitor_style_diagnostics_v4_20261109`，即已经输出
`monitor_storm_diag` 的 style 诊断版。用途是定位目标 vCPU 采样长期不更新的原因。
它是诊断补充，不是已经验证有效的故障修复。

## 下一步操作

1. 将本包的三个文件改动合入现有 HOS；使用 `changes.patch`，或者依据
   `merge_locations.txt` 手工合入。完整文件在 `full_files/`，不要覆盖项目中的其他私有修改。
2. 保留现有 `CONFIG_WBOXTEST_MONITOR=y`，不新增编译选项。不修改线程优先级、采样周期、
   有效窗口范围或超时。测试本身仍会临时调整 exit 阈值，并在结束时恢复。
3. 使用原来的板卡、Guest 和负载条件，仅运行这一项：

   ```text
   monitor start
   unittest run_tests 10 monitor_storm_runtime
   ```

   HOS 使用 `unittest` 命令；原生开源目录中命令名称为 `wboxtest`。
   无需运行整个 monitor 组，也无需新增 Guest 或修改 Linux/CCM。

4. 如果再次失败，保留该轮从 `target guest=...` 到 `restored ...` 的全部输出，尤其是
   `monitor_storm_diag` 和新增的 `monitor_lock_diag`。目标仍自动选择，可能不再是 vCPU 73，
   不要把任何一轮的目标都默认解释为 CPU3。

如果测试未复现，只能说明本轮没有观察到故障；诊断会改变少量执行时序，不能据此宣布修复。

## 目前证据说明了什么

用户现场三次超时中，全局 `sampler_passes` 在约 20 秒内增加 20，而目标
`target_passes` 只增加 0 或 1，目标快照停留约 18～20 秒。采样器整体仍在推进，
目标槽却几乎没有完成取锁后的采样流程。

这把排查重点缩小到目标槽的采样取锁路径，但旧的 `global_skipped` 是全局统计，
不能区分目标取锁失败原因，也不能证明 CPU3 连续持锁 20 秒。测试线程仍然能通过
阻塞式取锁读取目标槽，是另一个需要同时考虑的事实。

提供的 ARM64 trylock 返回值存在两种失败来源：

| 结果 | 本次尝试内看到的事实 | 尚不能断言 |
|---|---|---|
| busy | LDAXR 读到的锁值不是 `__ARCH_SPIN_UNLOCKED` | 持锁持续时间、具体是哪一个调用者 |
| exclusive | LDAXR 读到空闲，随后 STXR 返回非零 | 一定是缓存伪共享、一定是某个 CPU 或锁实现错误 |

这份实现中，已占用的锁值记录的是物理 CPU 编号。因此 busy 时可以记录当次读到的
owner。它不是 vCPU ID；vCPU 73 绑定 CPU3 与 `last_busy_owner=3` 是两种不同的信息。

## 改动文件和合入方式

固件只修改三个已有文件：

```text
core/include/vmm_monitor.h
core/monitor/monitor_agent.c
libs/wboxtest/monitor/storm_runtime.c
```

不修改 `cpu_locks.c`、通用 `vmm_spin_trylock_irqsave` 宏、调度器、CCM 或 Guest。
没有增加固件头文件、源文件或 Kconfig 开关；测试接口仍集中在 `vmm_monitor.h`。

- `changes.patch`：相对于上述 style 诊断基线的增量补丁。
- `full_files/`：这三个文件的完整修改版本。
- `merge_locations.txt`：按结构体、函数名称定位的改动说明及基线/修改后行号。
- `file_manifest.json`：三个文件合入前后 SHA256。
- `validation/`：参考编译、开发机模型结果、示例日志；不是板卡运行结果。

在文件与基线一致的源码根目录中可以执行：

```text
git apply --check changes.patch
git apply changes.patch
```

完整文件替换与应用补丁二选一。文件有私有改动时，按函数锚点手工合入；
这不是从最早 observer 包起算的累积补丁。

## 诊断实现

### 只观察一个目标

`monitor_storm_runtime` 完成目标选择后调用 `vmm_monitor_test_lock_begin()`。
生产 monitor 中新增一个静态 `test_lock_stats`，保存该目标的尝试、成功、失败原因等信息，
不是按 vCPU 新增一组诊断数组。测试完成或普通错误返回时调用 `..._end()` 结束观察。

`generation` 是本次取锁观察的编号，和 monitor 的 `epoch`、配置 `config_seq` 不同。
开始新观察时统计清零、generation 递增；旧采样调用晚到的统计因编号不符被丢弃。
同一时间只允许一个观察者，避免并发测试相互覆盖统计。

### 在本次取锁尝试中保留两份结果

`test_lock_try()` 在 ARM64+SMP 下使用与用户提供的算法一致的单次取锁流程，
将 LDAXR 的读取值和 STXR 的返回状态分别保留在两个寄存器输出中。
这样不会在失败之后重新读取锁、再把变化后的锁值误当成失败当时的证据。

CPU 编号在关闭中断、禁止抢占后读取，避免获取编号和真正尝试取锁之间迁移。
汇编独占指令序列中没有插入打印、计数写入、额外读写内存或函数调用。

失败时恢复抢占和原中断状态；成功时保持与原宏相同的持锁语义，由采样器正常解锁。
仍然只有一次尝试，失败仍走原来的 skipped 路径，没有增加重试、忙等或延迟任务。

仅测试选中的目标槽使用这一辅助函数；其他槽仍调用原有通用 trylock。
非 ARM64 或非 SMP 版本保留通用实现，只记录成功/原因未知的失败，不猜测原因。

### 先离开目标锁，再保存统计

`test_lock_note()` 在目标锁释放后更新统计，使用已有 `event_lock` 保护。
失败路径也先完成原 trylock 的中断/抢占恢复，再保存结果。不在持有目标锁时打印日志。

`vmm_monitor_sample()` 在原配置快照位置一并读取观察目标和 generation，
之后根据本次取锁结果记录统计。memory_flush、目标采样计数、sample_slot 的顺序不变。
没有改动有效窗口判定、持续时间、事件去重、阈值或日志策略。

### 每个阶段前后各读一次，超时后集中输出

`sr_phase()` 保存阶段开始的取锁统计；`sr_diagnostic_dump()` 在打印任何诊断文本前
先取得结束统计。`sr_lock_diagnostic_dump()` 随后输出新增信息。

正常 20 ms 轮询不新增逐次打印，不新增逐次读取锁统计；原有阶段提示和事件输出仍保留。
成功测试没有额外的 `monitor_lock_diag` 块。阶段超时之外的提前失败仍走原有具体报错。

本方案减少打印对现场的干扰，但不是零开销：保存寄存器、执行统计、代码布局和栈布局
都可能改变时序，实际复现率需要板卡验证。

## 新字段如何解释

| 字段 | 含义 |
|---|---|
| actor | 被观察的 vCPU/slot ID，应该与本轮 target 的 vCPU 相同 |
| generation | 取锁观察编号，防止跨测试统计混用 |
| precise | 1：ARM64+SMP 精确区分两条失败分支；0：通用回退，只能报告 unknown |
| active | 取锁观察是否仍启用；不是风暴是否 active，也不是 Guest 是否正在运行 |
| sampler_cpu | 最近一次记录此目标取锁结果时的物理 CPU 编号 |
| attempts=A->B | 阶段开始、超时前保存的累计尝试数；B-A 是本阶段增量 |
| acquired=A->B | 相同范围内成功取得目标锁的次数 |
| busy=A->B | LDAXR 当次读到锁被占用的次数 |
| exclusive=A->B | LDAXR 当次读到空闲，但 STXR 返回非零的次数 |
| unknown=A->B | 通用回退中无法细分原因的失败次数 |
| last_result | 0=成功，1=busy，2=exclusive，3=unknown；4294967295=尚未记录 |
| last_busy_owner | 最近一次 busy 当时读到的物理 CPU 编号；4294967295=尚未记录 busy |
| watch_owner_mask | 本次整个观察期间 busy 读到过哪些 CPU；bit n 对应 CPU n |
| last_attempt_ns | 最近尝试所属的采样批次时间戳，单位 ns |
| last_busy_ns | 最近 busy 所属的采样批次时间戳，单位 ns |
| lock_address | 被观察锁的 Hypervisor 虚拟地址，用于后续核对布局，不是 GPA/HPA |

每份快照中 `attempts = acquired + busy + exclusive + unknown`。
`last_busy_owner`、`watch_owner_mask` 跨阶段保留；如果本阶段 busy 增量为零，
这些值可能来自之前的阶段，不要据此认定本阶段发生过 busy。
编号大于等于 64 的 owner 仍保存在 last_busy_owner 中，但不置入 64 位 mask。

时间戳来自 `vmm_monitor_sample(now)`，不是每条汇编指令执行时重新读的时钟，
不能据此计算持锁时长。全局遍历、目标计数和取锁统计分别读取，不是跨结构体原子快照；
发生边界并发时计数差 1 需要结合时间观察。

### 例一：目标读到 CPU3 持锁

以下是模型演示，不是用户单板的新日志：

```text
monitor_lock_diag attempts=9->29 acquired=9->9
monitor_lock_diag busy=0->20
monitor_lock_diag exclusive=0->0
monitor_lock_diag unknown=0->0
monitor_lock_diag last_result=1 last_busy_owner=3 watch_owner_mask=0x8
```

这表示本阶段 20 次目标取锁都遇到 busy，最近一次读到 owner=CPU3。
下一步检查 CPU3 上对此 slot 的记录调用、临界区持续时间，以及 1 秒采样是否反复撞上
周期性写入。不能把 20 次瞬时观测解释成 CPU3 一次连续持锁 20 秒。
若 owner 与 sampler_cpu 相同，应另查重入或锁状态异常，不能直接归因于普通跨核竞争。

### 例二：空闲读取后独占写失败

```text
monitor_lock_diag attempts=9->29 acquired=9->9
monitor_lock_diag busy=0->0
monitor_lock_diag exclusive=0->20
monitor_lock_diag unknown=0->0
monitor_lock_diag last_result=2 last_busy_owner=4294967295 watch_owner_mask=0x0
```

下一步检查竞争写入和独占保留失效的来源，再评估监控采样路径的有限次数重试、
锁布局等措施。STXR 失败不是“CPU3 持锁”的证据，也不直接证明某一种缓存问题。
目前不修改全局架构锁，避免把一个监控定位问题扩散到整个 Hypervisor。

如果 attempts 不增长而 sampler_passes 明显增长，需先检查 actor、generation、active
和实际合入版本；不能沿用“目标取锁失败”的推断。

## 开销与验证范围

使用已有参考头文件、ARM64、MAX_VCPU_COUNT=64、CPU_COUNT=12、Zig 0.13.0/Clang `-Os`
测得本次相对于 style 诊断基线的变化如下，最终 HOS 镜像以实际 GCC/link map 为准：

| 项目 | 变化 |
|---|---|
| 新诊断结构 sizeof | 104 字节，一个静态实例 |
| monitor_agent 静态可写段 | 增加 112 字节，包含布局对齐影响 |
| storm_runtime 静态可写段 | 不变，仍为 2032 字节 |
| 两个目标文件装载段总增量 | 2323 字节，含代码/只读数据/初始化数据，未计最终链接对齐 |
| sr_diagnostics / sr_phase_state / sr_context sizeof | 632 / 664 / 168 字节 |

结构体 sizeof 不是实际函数栈高水位；函数中还可能有其他局部变量、寄存器保存和调用链。
新诊断不动态分配内存，但代码、静态段和局部变量仍占内存；对于之前缩小的 VAPOOL，
应结合实际 map 和可用空间评估，不能把测试选项视为零成本。

`CONFIG_WBOXTEST_MONITOR=n` 时新增状态、辅助函数、接口实现和分支全部编译移除。
四组参考配置（内置/外部执行 × Os/O2）中，对比该选项关闭后的新旧 agent，
ELF 已分配段的类型、大小和内容一致。

已完成：

- ARM64 内置/外部执行、Os/O2、测试开关开/关编译，包含 runtime 和私有 support 副本，
  共 29 次目标文件编译；使用 `-Wall -Wextra -Werror` 和 2048 字节单帧告警门限。
- 检查实际生成的 ARM64 独占汇编序列；没有在 LDAXR/STXR 之间加入统计读写或调用。
- 原有 34 个开发机行为/故障模型场景通过。
- 38 个精确结果分类模型场景通过，含 dedup/recover 中的 busy、exclusive 超时，
  正确错误码、字段分类、结束观察和恢复配置。
- 单独检查 CPU0/CPU3/CPU65、成功/失败的 IRQ 和抢占配对、无效参数、并发观察拒绝、
  旧 generation 丢弃、编号回绕和 begin/end 不修改配置/epoch。
- 6 个隔离白盒用例 × 3 个构建模式 × 3 次迭代，共 54 次通过。
- 三个交付文件检查零 goto、控制体大括号、结构成员分行；补丁正向、反向合入校验。

模型中的 ARM64 指令结果由开发机模拟；真实汇编只做了编译和检查，没有在开发机上
执行 ARM64 原子指令。这些验证不替代 HOS 的 GCC 12.3 完整链接或多核单板并发测试，
也不能证明原来的偶现问题已经修复。
