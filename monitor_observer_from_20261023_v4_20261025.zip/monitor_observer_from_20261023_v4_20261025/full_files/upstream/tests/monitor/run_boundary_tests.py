"""Run policy-preserving shmem checks in the isolated wboxtest suite.
The old additional authorization/wrap-rejection tests were withdrawn with
their policy changes. Fake backend checks never dereference invalid memory.
"""
import subprocess,sys
from pathlib import Path
if __name__=='__main__':
    raise SystemExit(subprocess.call([sys.executable,str(Path(__file__).with_name('run_wboxtests.py'))]+sys.argv[1:]))
