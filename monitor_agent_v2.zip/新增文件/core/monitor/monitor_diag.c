/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor_diag.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <libs/stringlib.h>

static DEFINE_SPINLOCK(diag_lock);
static atomic_t armed = {0};
static u64 begin_ns, end_ns, overflow;
static struct vmm_monitor_diag_record records[VMM_MONITOR_DIAG_SLOTS];

void vmm_monitor_diag_init(void) { INIT_SPIN_LOCK(&diag_lock); }

int vmm_monitor_diag_start(u32 ms)
{
	irq_flags_t flags;
	if (!ms || ms > 5000) return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&diag_lock, flags);
	if (arch_atomic_read(&armed)) {
		vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
		return VMM_EBUSY;
	}
	memset(records, 0, sizeof(records)); overflow = 0;
	begin_ns = vmm_timer_timestamp(); end_ns = begin_ns + (u64)ms * 1000000;
	arch_atomic_write(&armed, 1);
	vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
	return VMM_OK;
}

u64 vmm_monitor_diag_begin(void)
{
	return arch_atomic_read(&armed) ? vmm_timer_timestamp() : 0;
}

void vmm_monitor_diag_end(struct vmm_vcpu *v, u64 pc, u64 esr, u64 start, int rc)
{
	u32 i;
	u64 now, ns;
	irq_flags_t flags;
	struct vmm_monitor_diag_record *r;
	if (!start || !arch_atomic_read(&armed) || !v || !v->is_normal) return;
	now = vmm_timer_timestamp();
	vmm_spin_lock_irqsave_lite(&diag_lock, flags);
	if (!arch_atomic_read(&armed) || start < begin_ns || now < start || now > end_ns)
		goto done;
	ns = now - start;
	for (i = 0; i < VMM_MONITOR_DIAG_SLOTS; i++) {
		r = &records[i];
		if (!r->count || (r->guest == v->guest->id && r->vcpu == v->id &&
		    r->pc == pc && (r->esr >> 26) == (esr >> 26))) {
			r->guest = v->guest->id; r->vcpu = v->id;
			r->pc = pc; r->esr = esr; r->last_ns = now;
			r->count++; r->sum_ns += ns; if (ns > r->max_ns) r->max_ns = ns;
			if (rc) r->errors++;
			goto done;
		}
	}
	overflow++;
done:
	vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
}

void vmm_monitor_diag_stop(void)
{
	irq_flags_t flags;
	vmm_spin_lock_irqsave_lite(&diag_lock, flags);
	arch_atomic_write(&armed, 0);
	vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
}

int vmm_monitor_diag_get(u32 index, struct vmm_monitor_diag_record *out)
{
	irq_flags_t flags;
	if (!out || index >= VMM_MONITOR_DIAG_SLOTS) return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&diag_lock, flags);
	*out = records[index];
	vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
	return out->count ? VMM_OK : VMM_ENOTAVAIL;
}

u64 vmm_monitor_diag_overflow(void)
{
	u64 count;
	irq_flags_t flags;
	vmm_spin_lock_irqsave_lite(&diag_lock, flags);
	count = overflow;
	vmm_spin_unlock_irqrestore_lite(&diag_lock, flags);
	return count;
}
