/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "test_irq.h"
#include <vmm_mutex.h>
#include <vmm_manager.h>
#include <vmm_spinlocks.h>
#include <arch_cpu_irq.h>

#define IRQ_SELECT_MIN 89U
#define IRQ_SELECT_INVALID (~0U)
#define IRQ_SELECT_HW_STATE \
	(VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_MASKED)

u32 test_irq_spi_ids[TEST_IRQ_SPI_COUNT] = {
	IRQ_SELECT_INVALID, IRQ_SELECT_INVALID, IRQ_SELECT_INVALID,
	IRQ_SELECT_INVALID, IRQ_SELECT_INVALID, IRQ_SELECT_INVALID,
};

/* The wboxtest runner serializes .run() calls. This is not an IRQ reservation. */
enum irq_select_reason {
	IRQ_SELECT_OK,
	IRQ_SELECT_NOT_SPI,
	IRQ_SELECT_OWNER,
	IRQ_SELECT_STATE,
	IRQ_SELECT_API,
	IRQ_SELECT_LAYOUT,
	IRQ_SELECT_REASONS
};

static bool irq_select_has_actions(struct vmm_host_irq *irq)
{
	irq_flags_t flags;
	u32 cpu;
	bool found;

	for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
		vmm_read_lock_irqsave_lite(&irq->action_lock[cpu], flags);
		found = !list_empty(&irq->action_list[cpu]);
		vmm_read_unlock_irqrestore_lite(&irq->action_lock[cpu], flags);
		if (found) {
			return TRUE;
		}
	}
	return FALSE;
}

static enum irq_select_reason irq_select_check(u32 id)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(id);
	u32 hw = 0;
	u32 levels = 0;
	u32 pmr = 0;
	u8 priority = 0;

	/* Restrict this version to the HOS GICv3 ordinary SPI descriptors. */
	if (!irq || !irq->chip || !irq->chip->name || strcmp(irq->chip->name, "GICv3") ||
	    irq->hwirq < IRQ_SELECT_MIN || irq->hwirq >= 1020U ||
	    (irq->state & VMM_IRQ_STATE_EXTENDED) || vmm_host_irq_is_per_cpu(irq) ||
	    vmm_host_irq_is_ipi(irq) || vmm_host_irq_is_chained(irq)) {
		return IRQ_SELECT_NOT_SPI;
	}
	if (vmm_host_irq_is_routed(irq) || irq_select_has_actions(irq)) {
		return IRQ_SELECT_OWNER;
	}
	if (vmm_host_irq_get_routed_state(id, &hw, IRQ_SELECT_HW_STATE)) {
		return IRQ_SELECT_API;
	}
	/* A currently enabled line without an action is not used by this probe. */
	if (hw != VMM_ROUTED_IRQ_STATE_MASKED || !vmm_host_irq_is_masked(irq)) {
		return IRQ_SELECT_STATE;
	}
	if (vmm_host_irq_get_priority(id, &priority) ||
	    vmm_host_irq_priority_level(id, &levels, &pmr)) {
		return IRQ_SELECT_API;
	}
	if (levels < 2U || (u32)priority >= levels) {
		return IRQ_SELECT_API;
	}
	return IRQ_SELECT_OK;
}

static bool irq_select_used(u32 id, const u32 *chosen, u32 count)
{
	struct vmm_host_irq *candidate = vmm_host_irq_get(id);
	u32 i;

	for (i = 0; i < count; i++) {
		struct vmm_host_irq *previous = vmm_host_irq_get(chosen[i]);
		if (chosen[i] == id) {
			return TRUE;
		}
		/* Also avoid duplicate hardware identities in non-identity mappings. */
		if (candidate && previous && candidate->chip == previous->chip &&
		    candidate->chip_data == previous->chip_data &&
		    candidate->hwirq == previous->hwirq) {
			return TRUE;
		}
	}
	return FALSE;
}

static bool irq_select_pair_layout(u32 id)
{
	struct vmm_host_irq *first = vmm_host_irq_get(id);
	struct vmm_host_irq *second = vmm_host_irq_get(id + 1U);

	/* Check both the HOS wrapper's HIRQ boundary and the driver's HWIRQ bank. */
	if (!first || !second || ((id + 1U) % 32U) == 0U || first->chip != second->chip ||
	    first->chip_data != second->chip_data || second->hwirq != first->hwirq + 1U ||
	    first->hwirq / 32U != second->hwirq / 32U) {
		return FALSE;
	}
	return TRUE;
}

int test_irq_select_spis(struct vmm_chardev *cdev)
{
	u32 chosen[TEST_IRQ_SPI_COUNT] = {0};
	u32 rejected[IRQ_SELECT_REASONS] = {0};
	u32 irq_count = vmm_host_irq_count();
	u32 found = 0;
	u32 id;
	u32 i;
	enum irq_select_reason reason;

	/* On every failure leave invalid IDs, never yesterday's selection or SGI0. */
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		test_irq_spi_ids[i] = IRQ_SELECT_INVALID;
	}
	vmm_cprintf(cdev, "IRQSCAN: current registration/state only; board ownership unknown\n");
	if (irq_count < 2U) {
		return VMM_ENOTAVAIL;
	}
	for (id = IRQ_SELECT_MIN; id < irq_count - 1U && found < TEST_IRQ_SPI_COUNT; id++) {
		if (irq_select_used(id, chosen, found) || irq_select_used(id + 1U, chosen, found)) {
			continue;
		}
		reason = irq_select_check(id);
		if (reason == IRQ_SELECT_OK) {
			reason = irq_select_check(id + 1U);
		}
		if (reason != IRQ_SELECT_OK) {
			rejected[reason]++;
			continue;
		}
		if (!irq_select_pair_layout(id)) {
			rejected[IRQ_SELECT_LAYOUT]++;
			continue;
		}
		chosen[found++] = id;
		chosen[found++] = id + 1U;
	}
	if (found != TEST_IRQ_SPI_COUNT) {
		vmm_cprintf(cdev, "IRQSCAN: need 3 pairs, found=%u; test aborted\n", found / 2U);
		vmm_cprintf(cdev,
			    "IRQSCAN: rejected not_spi=%u owner=%u state=%u api=%u layout=%u\n",
			    rejected[IRQ_SELECT_NOT_SPI], rejected[IRQ_SELECT_OWNER],
			    rejected[IRQ_SELECT_STATE], rejected[IRQ_SELECT_API],
			    rejected[IRQ_SELECT_LAYOUT]);
		return VMM_ENOTAVAIL;
	}
	/* Recheck before publishing, but do not claim this is an atomic reservation. */
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		reason = irq_select_check(chosen[i]);
		if (reason != IRQ_SELECT_OK) {
			vmm_cprintf(cdev, "IRQSCAN: irq=%u changed, reason=%u; test aborted\n",
				    chosen[i], (u32)reason);
			return VMM_EBUSY;
		}
	}
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i++) {
		test_irq_spi_ids[i] = chosen[i];
	}
	for (i = 0; i < TEST_IRQ_SPI_COUNT; i += 2U) {
		vmm_cprintf(cdev, "IRQSCAN: pair%u hirq=%u/%u hwirq=%u/%u\n", i / 2U + 1U,
			    chosen[i], chosen[i + 1U], vmm_host_irq_get(chosen[i])->hwirq,
			    vmm_host_irq_get(chosen[i + 1U])->hwirq);
	}
	return VMM_OK;
}

/* Shared lifecycle for all interrupt cases. No extra object or configuration. */
struct irq_test_source {
	struct vmm_host_irq *irq;
	const char *name;
	struct vmm_cpumask cached_affinity;
	struct vmm_cpumask hardware_affinity;
	struct test_irq_result result;
	u32 id;
	u32 trigger;
	u32 affinity_flag;
	u8 priority;
	bool saved;
	bool masked;
	bool touched;
	bool register_attempted;
	bool registered;
	bool priority_changed;
	bool affinity_changed;
	bool type_changed;
	bool pending_owned;
	bool synthetic_active;
	bool armed;
};

struct irq_test_session {
	struct irq_test_source source[TEST_IRQ_TOTAL];
	struct vmm_vcpu *vcpu;
	struct vmm_cpumask vcpu_affinity;
	u32 count;
	u32 cpu;
	u32 order;
	u64 start_ns;
	int async_error;
	bool pin_attempted;
	bool pmr_saved;
	u32 pmr_irq;
	u8 pmr;
};

static struct irq_test_session irq_session;
static bool irq_session_dirty;
static DEFINE_MUTEX(irq_session_lock);
static DEFINE_SPINLOCK(irq_result_lock);

u32 test_irq_id(u32 slot)
{
	return slot < irq_session.count ? irq_session.source[slot].id : ~0U;
}

u32 test_irq_cpu(void)
{
	return irq_session.cpu;
}

static u32 irq_test_actions(struct irq_test_source *source, bool own_only)
{
	struct vmm_host_irq_action *action;
	irq_flags_t flags;
	u32 cpu;
	u32 count = 0;

	for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
		vmm_read_lock_irqsave_lite(&source->irq->action_lock[cpu], flags);
		list_for_each_entry(action, &source->irq->action_list[cpu], head)
		{
			if (!own_only || action->dev == source) {
				count++;
			}
		}
		vmm_read_unlock_irqrestore_lite(&source->irq->action_lock[cpu], flags);
	}
	return count;
}

static vmm_irq_return_t irq_test_handler(int irq, void *data)
{
	struct irq_test_source *source = data;
	irq_flags_t flags;
	u64 now = vmm_timer_timestamp();
	int rc = vmm_host_irq_mask((u32)irq);

	vmm_spin_lock_irqsave_lite(&irq_result_lock, flags);
	source->result.calls++;
	if (source->result.calls == 1U) {
		source->result.cpu = vmm_smp_processor_id();
		source->result.order = ++irq_session.order;
		source->result.latency_ns = now - irq_session.start_ns;
	}
	if (rc) {
		source->result.mask_rc = rc;
	}
	if (!source->armed || source->result.calls != 1U || rc) {
		irq_session.async_error = VMM_EFAIL;
	}
	vmm_spin_unlock_irqrestore_lite(&irq_result_lock, flags);
	return VMM_IRQ_HANDLED;
}

void test_irq_result(u32 slot, struct test_irq_result *result)
{
	irq_flags_t flags;

	vmm_spin_lock_irqsave_lite(&irq_result_lock, flags);
	*result = irq_session.source[slot].result;
	vmm_spin_unlock_irqrestore_lite(&irq_result_lock, flags);
}

static int irq_test_snapshot(u32 slot)
{
	struct irq_test_source *source = &irq_session.source[slot];
	u32 hw;
	int rc;

	source->id = slot < TEST_IRQ_SPI_COUNT ? test_irq_spi_ids[slot]
					       : (slot == TEST_IRQ_SGI1 ? SGI_ID1 : SGI_ID2);
	source->irq = vmm_host_irq_get(source->id);
	if (!source->irq || !source->irq->chip) {
		return VMM_ENOTAVAIL;
	}
	if (irq_test_actions(source, FALSE) || vmm_host_irq_is_routed(source->irq)) {
		return VMM_EBUSY;
	}
	if (slot >= TEST_IRQ_SPI_COUNT &&
	    (source->irq->hwirq >= 16U || !vmm_host_irq_is_per_cpu(source->irq))) {
		return VMM_EINVALID;
	}
	rc = vmm_host_irq_get_routed_state(source->id, &hw, TEST_IRQ_HW_STATE);
	if (rc || (hw & (VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE))) {
		return rc ? rc : VMM_EBUSY;
	}
	source->masked = !!(hw & VMM_ROUTED_IRQ_STATE_MASKED);
	if (slot < TEST_IRQ_SPI_COUNT && !source->masked) {
		return VMM_EBUSY;
	}
	rc = vmm_host_irq_get_priority(source->id, &source->priority);
	if (rc) {
		return rc;
	}
	source->name = vmm_host_irq_get_name(source->irq);
	source->trigger = vmm_host_irq_get_trigger_type(source->irq);
	source->saved = TRUE;
	return VMM_OK;
}

int test_irq_begin(struct vmm_chardev *out, u32 test_hcpu, u32 sgi_count)
{
	const struct vmm_cpumask *affinity;
	u32 i;
	int rc;

	if (!vmm_mutex_trylock(&irq_session_lock)) {
		return VMM_EBUSY;
	}
	if (irq_session_dirty || sgi_count > 2U || arch_cpu_irq_disabled() ||
	    test_hcpu >= CONFIG_CPU_COUNT || test_hcpu != vmm_smp_processor_id()) {
		vmm_cprintf(out, "IRQTEST unavailable: dirty=%u cpu=%u requested=%u\n",
			    (u32)irq_session_dirty, vmm_smp_processor_id(), test_hcpu);
		vmm_mutex_unlock(&irq_session_lock);
		return VMM_EBUSY;
	}
	memset(&irq_session, 0, sizeof(irq_session));
	irq_session.cpu = test_hcpu;
	irq_session.vcpu = vmm_scheduler_current_vcpu();
	affinity = vmm_manager_vcpu_get_affinity(irq_session.vcpu);
	if (!affinity) {
		vmm_mutex_unlock(&irq_session_lock);
		return VMM_ENOTAVAIL;
	}
	vmm_cpumask_copy(&irq_session.vcpu_affinity, affinity);
	irq_session.pin_attempted = TRUE;
	rc = vmm_manager_vcpu_set_affinity(irq_session.vcpu, vmm_cpumask_of(test_hcpu));
	if (!rc) {
		rc = test_irq_select_spis(out);
	}
	if (!rc) {
		irq_session.count = TEST_IRQ_SPI_COUNT + sgi_count;
		for (i = 0; i < irq_session.count; i++) {
			rc = irq_test_snapshot(i);
			if (rc) {
				break;
			}
		}
	}
	if (rc) {
		return test_irq_end(out, rc);
	}
	return VMM_OK;
}

int test_irq_mask(u32 slot)
{
	irq_session.source[slot].touched = TRUE;
	return vmm_host_irq_mask(test_irq_id(slot));
}

int test_irq_unmask(u32 slot)
{
	irq_session.source[slot].touched = TRUE;
	return vmm_host_irq_unmask(test_irq_id(slot));
}

int test_irq_register(u32 slot, const char *name)
{
	struct irq_test_source *source = &irq_session.source[slot];
	int rc;
	int mask_rc;

	if (source->registered) {
		return VMM_EBUSY;
	}
	source->touched = TRUE;
	source->register_attempted = TRUE;
	rc = vmm_host_irq_register(source->id, name, irq_test_handler, source);
	mask_rc = vmm_host_irq_mask(source->id);
	if (!rc) {
		source->registered = TRUE;
	}
	return rc ? rc : mask_rc;
}

int test_irq_unregister(u32 slot)
{
	struct irq_test_source *source = &irq_session.source[slot];
	int rc = vmm_host_irq_unregister(source->id, source);

	if (!irq_test_actions(source, TRUE)) {
		source->registered = FALSE;
	}
	return rc;
}

int test_irq_set_priority(u32 slot, u8 priority)
{
	struct irq_test_source *source = &irq_session.source[slot];
	u8 actual;
	int rc = test_irq_mask(slot);

	if (!rc) {
		source->priority_changed = TRUE;
		rc = vmm_host_irq_set_priority(source->id, priority);
	}
	if (!rc) {
		rc = vmm_host_irq_get_priority(source->id, &actual);
		if (!rc && actual != priority) {
			rc = VMM_EFAIL;
		}
	}
	return rc;
}

int test_irq_set_affinity(u32 slot, const struct vmm_cpumask *mask)
{
	struct irq_test_source *source = &irq_session.source[slot];
	int rc = test_irq_mask(slot);

	if (rc) {
		return rc;
	}
	if (!source->affinity_changed) {
		/* HOS exposes this chip callback (also used by its cache-miss getter). */
		if (!source->irq->chip->irq_get_affinity || source->irq->affinity_forced) {
			return VMM_ENOTAVAIL;
		}
		source->hardware_affinity = VMM_CPU_MASK_NONE;
		rc = source->irq->chip->irq_get_affinity(source->irq, &source->hardware_affinity);
		if (rc || vmm_cpumask_empty(&source->hardware_affinity)) {
			return rc ? rc : VMM_EFAIL;
		}
		vmm_cpumask_copy(&source->cached_affinity, &source->irq->affinity);
		source->affinity_flag = source->irq->state & VMM_IRQ_STATE_AFFINITY_SET;
		source->affinity_changed = TRUE;
	}
	return vmm_host_irq_set_affinity(source->id, mask, FALSE);
}

int test_irq_set_trigger(u32 slot, u32 trigger)
{
	struct irq_test_source *source = &irq_session.source[slot];
	int rc = test_irq_mask(slot);

	if (!rc) {
		source->type_changed = TRUE;
		rc = vmm_host_irq_set_type(source->id, trigger);
	}
	if (!rc && vmm_host_irq_get_trigger_type(source->irq) != trigger) {
		rc = VMM_EFAIL;
	}
	return rc;
}

static void irq_test_arm(u32 a, u32 b)
{
	irq_flags_t flags;
	u32 i;

	vmm_spin_lock_irqsave_lite(&irq_result_lock, flags);
	irq_session.order = 0;
	irq_session.start_ns = vmm_timer_timestamp();
	for (i = 0; i < irq_session.count; i++) {
		irq_session.source[i].armed = (i == a || i == b);
		if (i == a || i == b) {
			memset(&irq_session.source[i].result, 0, sizeof(struct test_irq_result));
		}
	}
	vmm_spin_unlock_irqrestore_lite(&irq_result_lock, flags);
}

static int irq_test_wait(u32 a, u32 b)
{
	struct test_irq_result first;
	struct test_irq_result second;
	u64 start = vmm_timer_timestamp();

	do {
		test_irq_result(a, &first);
		test_irq_result(b, &second);
		if (first.calls && second.calls) {
			if (first.calls != 1U || second.calls != 1U || first.mask_rc ||
			    second.mask_rc || first.cpu != irq_session.cpu ||
			    second.cpu != irq_session.cpu) {
				return VMM_EFAIL;
			}
			return VMM_OK;
		}
		vmm_udelay(10);
	} while (vmm_timer_timestamp() - start < 1000000000ULL);
	return VMM_ETIMEDOUT;
}

int test_irq_pair(u32 a, u32 b, u32 expected_first)
{
	struct test_irq_result first;
	irq_flags_t flags;
	u32 hw;
	u32 slot;
	int rc;

	if (a >= TEST_IRQ_SPI_COUNT || b >= TEST_IRQ_SPI_COUNT || b != a + 1U ||
	    (expected_first != a && expected_first != b)) {
		return VMM_EINVALID;
	}
	for (slot = a; slot <= b; slot++) {
		if (!irq_session.source[slot].registered) {
			return VMM_EINVALID;
		}
		rc = vmm_host_irq_get_routed_state(test_irq_id(slot), &hw, TEST_IRQ_HW_STATE);
		if (rc || hw != VMM_ROUTED_IRQ_STATE_MASKED) {
			return rc ? rc : VMM_EBUSY;
		}
	}
	/* Both SPIs target this pinned CPU. Queue both before allowing delivery. */
	arch_cpu_irq_save(flags);
	irq_test_arm(a, b);
	rc = test_irq_unmask(a);
	if (!rc) {
		rc = test_irq_unmask(b);
	}
	if (!rc) {
		irq_session.source[a].pending_owned = TRUE;
		irq_session.source[b].pending_owned = TRUE;
		rc = vmm_host_irq_trigger_two(test_irq_id(a));
	}
	arch_cpu_irq_restore(flags);
	if (!rc) {
		rc = irq_test_wait(a, b);
	}
	if (!rc) {
		test_irq_result(expected_first, &first);
		if (first.order != 1U) {
			rc = VMM_EFAIL;
		}
	}
	return rc;
}

int test_irq_sgi(u32 slot)
{
	irq_flags_t flags;
	int rc;

	if (slot < TEST_IRQ_SPI_COUNT || slot >= irq_session.count ||
	    !irq_session.source[slot].registered) {
		return VMM_EINVALID;
	}
	arch_cpu_irq_save(flags);
	irq_test_arm(slot, slot);
	irq_session.source[slot].pending_owned = TRUE;
	rc = test_irq_unmask(slot);
	if (!rc) {
		rc = vmm_host_irq_raise(test_irq_id(slot), vmm_cpumask_of(irq_session.cpu));
	}
	arch_cpu_irq_restore(flags);
	return rc ? rc : irq_test_wait(slot, slot);
}

int test_irq_software(u32 slot, bool active)
{
	struct irq_test_source *source = &irq_session.source[slot];
	u32 hw;
	int rc = test_irq_mask(slot);

	if (!source->registered) {
		return VMM_EINVALID;
	}
	if (!rc && active) {
		source->synthetic_active = TRUE;
		rc = vmm_host_irq_set_routed_state(source->id, VMM_ROUTED_IRQ_STATE_ACTIVE,
						   VMM_ROUTED_IRQ_STATE_ACTIVE);
		if (!rc) {
			rc = vmm_host_irq_get_routed_state(source->id, &hw, TEST_IRQ_HW_STATE);
			if (!rc &&
			    hw != (VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_MASKED)) {
				rc = VMM_EFAIL;
			}
		}
	}
	if (!rc) {
		irq_test_arm(slot, slot);
		rc = vmm_host_generic_irq_exec(source->id);
	}
	return rc ? rc : irq_test_wait(slot, slot);
}

int test_irq_pmr(u32 slot)
{
	irq_flags_t flags;
	int old;
	int rc;
	int restore_rc;

	/* PMR belongs to the CPU interface, not to one IRQ. Keep this section short. */
	arch_cpu_irq_save(flags);
	old = vmm_host_irq_get_pmr(test_irq_id(slot));
	if (old < 0 || old > 255) {
		arch_cpu_irq_restore(flags);
		return old < 0 ? old : VMM_EINVALID;
	}
	irq_session.pmr_saved = TRUE;
	irq_session.pmr_irq = test_irq_id(slot);
	irq_session.pmr = (u8)old;
	rc = vmm_host_irq_set_pmr(irq_session.pmr_irq, 0xf0);
	if (!rc && vmm_host_irq_get_pmr(irq_session.pmr_irq) != 0xf0) {
		rc = VMM_EFAIL;
	}
	restore_rc = vmm_host_irq_set_pmr(irq_session.pmr_irq, irq_session.pmr);
	if (!restore_rc && vmm_host_irq_get_pmr(irq_session.pmr_irq) != old) {
		restore_rc = VMM_EFAIL;
	}
	if (!restore_rc) {
		irq_session.pmr_saved = FALSE;
	}
	arch_cpu_irq_restore(flags);
	return rc ? rc : restore_rc;
}

static int irq_test_restore(struct irq_test_source *source)
{
	struct vmm_cpumask actual = VMM_CPU_MASK_NONE;
	u64 start;
	u32 hw;
	u8 priority;
	int rc;
	int first_rc = VMM_OK;

	if (source->touched) {
		first_rc = vmm_host_irq_mask(source->id);
	}
	if (source->register_attempted && irq_test_actions(source, TRUE)) {
		/* Registration can fail after installing a prefix of per-CPU actions. */
		vmm_host_irq_unregister(source->id, source);
	}
	if (irq_test_actions(source, FALSE) || vmm_host_irq_is_routed(source->irq)) {
		return VMM_EBUSY;
	}
	if (first_rc) {
		return first_rc;
	}
	if (source->synthetic_active) {
		rc = vmm_host_irq_set_routed_state(source->id, 0, VMM_ROUTED_IRQ_STATE_ACTIVE);
		if (rc) {
			return rc;
		}
	}
	start = vmm_timer_timestamp();
	do {
		rc = vmm_host_irq_get_routed_state(source->id, &hw, TEST_IRQ_HW_STATE);
		if (rc || !(hw & VMM_ROUTED_IRQ_STATE_ACTIVE)) {
			break;
		}
		vmm_udelay(10);
	} while (vmm_timer_timestamp() - start < 10000000ULL);
	if (rc || (hw & VMM_ROUTED_IRQ_STATE_ACTIVE)) {
		return rc ? rc : VMM_EBUSY;
	}
	if (source->pending_owned) {
		rc = vmm_host_irq_set_routed_state(source->id, 0, VMM_ROUTED_IRQ_STATE_PENDING);
		if (rc) {
			return rc;
		}
	}
	if (source->type_changed && source->trigger != VMM_IRQ_TYPE_NONE) {
		rc = vmm_host_irq_set_type(source->id, source->trigger);
		if (rc || vmm_host_irq_get_trigger_type(source->irq) != source->trigger) {
			return rc ? rc : VMM_EFAIL;
		}
	}
	if (source->priority_changed) {
		rc = vmm_host_irq_set_priority(source->id, source->priority);
		if (rc) {
			return rc;
		}
	}
	if (source->affinity_changed) {
		rc = vmm_host_irq_set_affinity(source->id, &source->hardware_affinity, FALSE);
		if (!rc) {
			rc = source->irq->chip->irq_get_affinity(source->irq, &actual);
		}
		if (rc || !vmm_cpumask_equal(&actual, &source->hardware_affinity)) {
			return rc ? rc : VMM_EFAIL;
		}
		vmm_cpumask_copy(&source->irq->affinity, &source->cached_affinity);
		source->irq->state =
			(source->irq->state & ~VMM_IRQ_STATE_AFFINITY_SET) | source->affinity_flag;
	}
	if (source->register_attempted) {
		vmm_host_irq_set_name(source->irq, source->name);
	}
	if (source->touched) {
		rc = source->masked ? vmm_host_irq_mask(source->id)
				    : vmm_host_irq_unmask(source->id);
		if (rc) {
			return rc;
		}
	}
	rc = vmm_host_irq_get_routed_state(source->id, &hw, TEST_IRQ_HW_STATE);
	if (rc || hw != (source->masked ? VMM_ROUTED_IRQ_STATE_MASKED : 0U)) {
		return rc ? rc : VMM_EFAIL;
	}
	rc = vmm_host_irq_get_priority(source->id, &priority);
	if (rc || priority != source->priority) {
		return rc ? rc : VMM_EFAIL;
	}
	/* HOS is_masked() may refresh its cache on the first call. */
	(void)vmm_host_irq_is_masked(source->irq);
	if (vmm_host_irq_is_masked(source->irq) != source->masked) {
		return VMM_EFAIL;
	}
	return VMM_OK;
}

int test_irq_end(struct vmm_chardev *out, int test_rc)
{
	irq_flags_t flags;
	u32 i;
	u32 reusable = 0;
	int cleanup_rc = VMM_OK;
	int rc;

	for (i = 0; i < irq_session.count; i++) {
		struct irq_test_source *source = &irq_session.source[i];
		if (!source->saved) {
			continue;
		}
		rc = irq_test_restore(source);
		if (rc) {
			vmm_cprintf(out, "IRQTEST cleanup irq=%u rc=%d\n", source->id, rc);
			cleanup_rc = rc;
		} else if (i < TEST_IRQ_SPI_COUNT) {
			reusable++;
		}
	}
	if (irq_session.pmr_saved) {
		arch_cpu_irq_save(flags);
		rc = vmm_host_irq_set_pmr(irq_session.pmr_irq, irq_session.pmr);
		if (!rc && vmm_host_irq_get_pmr(irq_session.pmr_irq) != irq_session.pmr) {
			rc = VMM_EFAIL;
		}
		arch_cpu_irq_restore(flags);
		if (rc) {
			cleanup_rc = rc;
		}
	}
	vmm_spin_lock_irqsave_lite(&irq_result_lock, flags);
	if (!test_rc && irq_session.async_error) {
		test_rc = irq_session.async_error;
	}
	vmm_spin_unlock_irqrestore_lite(&irq_result_lock, flags);
	if (irq_session.pin_attempted) {
		rc = vmm_manager_vcpu_set_affinity(irq_session.vcpu, &irq_session.vcpu_affinity);
		if (rc) {
			cleanup_rc = rc;
		}
	}
	irq_session_dirty = (cleanup_rc != VMM_OK);
	vmm_cprintf(out, "IRQTEST cleanup rc=%d reusable_spis=%u/%u\n", cleanup_rc, reusable,
		    TEST_IRQ_SPI_COUNT);
	if (irq_session_dirty) {
		vmm_cprintf(out, "IRQTEST cleanup incomplete; stop and reboot before retry\n");
	}
	vmm_mutex_unlock(&irq_session_lock);
	return test_rc ? test_rc : cleanup_rc;
}
