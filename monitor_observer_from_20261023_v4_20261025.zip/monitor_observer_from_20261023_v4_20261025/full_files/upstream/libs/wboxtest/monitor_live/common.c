/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
#include <vmm_mutex.h>
#include <vmm_cmdmgr.h>

static DEFINE_MUTEX(live_lock);
static u32 selected=~0U, timeout_s=90;
static int decimal(const char *s, u32 *out)
{
    u32 n=0;
    if (!s || !*s) return VMM_EINVALID;
    for (; *s; s++) {
        if (*s<'0' || *s>'9' || n>(~0U-(u32)(*s-'0'))/10) return VMM_EINVALID;
        n=n*10+(u32)(*s-'0');
    }
    *out=n; return VMM_OK;
}
static void usage(struct vmm_chardev *out)
{
    vmm_cprintf(out,"monitor_live target <global-vcpu-id>\nmonitor_live timeout <30..180 seconds>\n");
}
static int command(struct vmm_chardev *out, int argc, char **argv)
{
    u32 value;
    int rc=VMM_EINVALID;
    if (argc!=3 || decimal(argv[2],&value)) { usage(out); return rc; }
    if (!vmm_mutex_trylock(&live_lock)) return VMM_EBUSY;
    if (!strcmp(argv[1],"target") && value<CONFIG_MAX_VCPU_COUNT) {
        struct vmm_vcpu *v=vmm_manager_vcpu(value);
        if (v && v->is_normal && v->guest) { selected=value; rc=VMM_OK; }
    } else if (!strcmp(argv[1],"timeout") && value>=30 && value<=180) {
        timeout_s=value; rc=VMM_OK;
    }
    if (!rc) vmm_cprintf(out,"OK: target=%u timeout=%us\n",selected,timeout_s);
    vmm_mutex_unlock(&live_lock);
    return rc;
}
static struct vmm_cmd live_cmd={.name="monitor_live",.desc="Select an existing Guest for live tests",
    .usage=usage,.exec=command};
static int __init live_init(void) { return vmm_cmdmgr_register_cmd(&live_cmd); }
static void __exit live_exit(void) { vmm_cmdmgr_unregister_cmd(&live_cmd); }
VMM_DECLARE_MODULE2(monitor_live_control,"Existing Guest test control","Monitor maintainers","GPL",
    WBOXTEST_IPRIORITY+1,live_init,live_exit);

u64 ml_timeout(struct ml_context *c) { return (u64)c->timeout_s*VMM_MONITOR_NS; }
int ml_check(struct ml_context *c)
{
    struct vmm_monitor_test_state s;
    if (vmm_manager_vcpu(c->id)!=c->vcpu || c->vcpu->guest!=c->guest ||
        vmm_monitor_test_state(&s) || s.enabled!=c->baseline.enabled ||
        s.epoch!=c->baseline.epoch || s.config_seq!=c->baseline.config_seq ||
        s.lost!=c->baseline.lost || s.errors!=c->baseline.errors) {
        vmm_cprintf(c->out,"monitor_live: target/config changed, lost evidence, or executor error\n");
        return VMM_EFAIL;
    }
    return VMM_OK;
}
int ml_slot(struct ml_context *c, struct vmm_monitor_test_slot *s)
{
    if (ml_check(c) || vmm_monitor_test_slot(c->id,s)) return VMM_EFAIL;
    return s->present && s->epoch==c->baseline.epoch && s->kind==0 &&
        s->guest==c->guest_id ? VMM_OK : VMM_EFAIL;
}
int ml_begin(struct ml_context *c, struct vmm_chardev *out)
{
    struct vmm_monitor_test_slot s;
    u64 first,deadline;
    memset(c,0,sizeof(*c)); c->out=out;
    if (!vmm_mutex_trylock(&live_lock)) return VMM_EBUSY;
    c->locked=TRUE; c->id=selected; c->timeout_s=timeout_s;
    c->vcpu=vmm_manager_vcpu(c->id);
    if (!c->vcpu || !c->vcpu->is_normal || !c->vcpu->guest) {
        vmm_cprintf(out,"monitor_live: select an existing Guest vCPU first\n"); return VMM_EINVALID;
    }
    c->guest=c->vcpu->guest; c->guest_id=c->guest->id;
    /* The caller must keep VM lifetime, affinity and mappings stable during tests. */
    if (vmm_monitor_test_state(&c->baseline) || !c->baseline.enabled) return VMM_ENOTAVAIL;
    if (c->baseline.config[VMM_MONITOR_SUSTAIN_S]>10 ||
        c->baseline.config[VMM_MONITOR_WINDOW_MAX_MS]>2000) return VMM_EINVALID;
    if (vmm_monitor_test_slot(c->id,&s)) return VMM_EFAIL;
    first=s.previous; deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        if (ml_check(c) || vmm_monitor_test_slot(c->id,&s)) return VMM_EFAIL;
        if (s.present && s.epoch==c->baseline.epoch && s.kind==0 && s.guest==c->guest_id &&
            s.previous>first && s.valid) {
            vmm_cprintf(out,"monitor_live TARGET guest=%u vcpu=%u epoch=%u config_seq=%u\n",
                c->guest_id,c->id,c->baseline.epoch,c->baseline.config_seq);
            return VMM_OK;
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    return VMM_ETIMEDOUT;
}
int ml_end(struct ml_context *c, int rc)
{
    if (c->locked) vmm_mutex_unlock(&live_lock);
    return rc;
}
int ml_scan(struct ml_context *c,u64 after,u32 type,struct vmm_monitor_test_event *found,u32 *count)
{
    struct vmm_monitor_test_state state;
    struct vmm_monitor_test_event e;
    u64 seq;
    *count=0;
    if (ml_check(c) || vmm_monitor_test_state(&state) || state.head<after ||
        state.head-after>VMM_MONITOR_EVENTS) return VMM_EFAIL;
    for (seq=after+1; seq<=state.head; seq++) {
        if (vmm_monitor_test_event(seq,&e)) return VMM_EFAIL;
        if (e.type==type && e.guest==c->guest_id && e.vcpu==c->id && e.epoch==c->baseline.epoch) {
            if (e.log_calls>1) return VMM_EFAIL;
            *found=e; (*count)++;
        }
    }
    return VMM_OK;
}
int ml_log_wait(struct ml_context *c,u64 seq)
{
    struct vmm_monitor_test_event e;
    u64 deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        if (ml_check(c) || vmm_monitor_test_event(seq,&e)) return VMM_EFAIL;
        if (e.log_returned) {
            if (e.log_calls!=1) return VMM_EFAIL;
            vmm_cprintf(c->out,"monitor_live LOG seq=%llu type=%u guest=%u vcpu=%u epoch=%u time_ns=%llu code=%u address=%llu value=%llu detail=%llu\n",
                ML_U(e.seq),e.type,e.guest,e.vcpu,e.epoch,ML_U(e.time_ns),e.code,
                ML_U(e.address),ML_U(e.value),ML_U(e.detail));
            return VMM_OK;
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    return VMM_ETIMEDOUT;
}
