/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor_guest.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <libs/stringlib.h>

static struct {
	vmm_spinlock_t lock;
	struct vmm_monitor_guest report;
	u64 last_notice, last_sample_sequence;
} guests[CONFIG_MAX_GUEST_COUNT];

void vmm_monitor_guest_init(void)
{
	u32 i;
	for (i = 0; i < CONFIG_MAX_GUEST_COUNT; i++)
		INIT_SPIN_LOCK(&guests[i].lock);
}

void vmm_monitor_guest_reset(u32 id)
{
	irq_flags_t flags;
	if (id >= CONFIG_MAX_GUEST_COUNT) return;
	vmm_spin_lock_irqsave_lite(&guests[id].lock, flags);
	memset(&guests[id].report, 0, sizeof(guests[id].report));
	guests[id].last_notice = guests[id].last_sample_sequence = 0;
	vmm_spin_unlock_irqrestore_lite(&guests[id].lock, flags);
}

int vmm_monitor_guest_report(struct vmm_vcpu *actor, u64 session, u64 sequence,
		u64 cpu_bp, u64 total, u64 available, u64 free_bytes, u64 valid)
{
	u32 id;
	int rc = VMM_EINVALID;
	irq_flags_t flags;
	struct vmm_monitor_guest *r;
	/* Identity comes only from the trapping vCPU, never from Guest input. */
	if (!actor || !actor->is_normal || !actor->guest ||
	    actor->guest->id >= CONFIG_MAX_GUEST_COUNT || !session || !sequence ||
	    !valid || valid > 3 || cpu_bp > 10000 || available > total ||
	    free_bytes > total || ((valid & 2) && !total))
		return VMM_EINVALID;
	if (!vmm_monitor_enabled()) return VMM_ENOTAVAIL;
	id = actor->guest->id;
	vmm_spin_lock_irqsave_lite(&guests[id].lock, flags);
	r = &guests[id].report;
	if (r->session != session || sequence > r->sequence) {
		if (r->session != session) {
			guests[id].last_notice = 0;
			guests[id].last_sample_sequence = 0;
		}
		r->session = session; r->sequence = sequence;
		r->received_ns = vmm_timer_timestamp();
		r->total_bytes = total; r->available_bytes = available;
		r->free_bytes = free_bytes; r->cpu_bp = cpu_bp; r->valid = valid;
		rc = VMM_OK;
	}
	vmm_spin_unlock_irqrestore_lite(&guests[id].lock, flags);
	return rc;
}

int vmm_monitor_guest_get(u32 id, struct vmm_monitor_guest *out)
{
	irq_flags_t flags;
	if (id >= CONFIG_MAX_GUEST_COUNT || !out) return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&guests[id].lock, flags);
	*out = guests[id].report;
	vmm_spin_unlock_irqrestore_lite(&guests[id].lock, flags);
	return out->sequence ? VMM_OK : VMM_ENOTAVAIL;
}

void vmm_monitor_guest_sample(u64 now, u32 limit_bp)
{
	u32 i, value;
	bool alarm;
	irq_flags_t flags;
	struct vmm_monitor_guest *r;
	for (i = 0; i < CONFIG_MAX_GUEST_COUNT; i++) {
		if (!vmm_spin_trylock_irqsave(&guests[i].lock, flags)) continue;
		r = &guests[i].report;
		alarm = FALSE; value = r->cpu_bp;
		if (r->sequence != guests[i].last_sample_sequence && now >= r->received_ns &&
		    now - r->received_ns <= 3 * VMM_MONITOR_NS) {
			guests[i].last_sample_sequence = r->sequence;
			if ((r->valid & 1) && limit_bp && value > limit_bp &&
			    (!guests[i].last_notice || now - guests[i].last_notice >= 10 * VMM_MONITOR_NS)) {
				guests[i].last_notice = now; alarm = TRUE;
			}
		}
		vmm_spin_unlock_irqrestore(&guests[i].lock, flags);
		if (alarm) vmm_monitor_guest_event(i, now, value, limit_bp);
	}
}
