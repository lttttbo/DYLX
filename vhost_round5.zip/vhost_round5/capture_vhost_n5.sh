#!/bin/sh
# Capture aggregate counters only. Does not change any affinity or feature.
set -eu
LC_ALL=C
export LC_ALL

usage() { echo "Usage: $0 IOEVENT_TID VHOST_TID LABEL [DURATION_SECONDS=3]" >&2; exit 2; }
[ "$#" -ge 3 ] && [ "$#" -le 4 ] || usage
IO_TID=$1
VH_TID=$2
LABEL=$3
CAPTURE_SECONDS=${4:-3}
REPORT_DELAY=${REPORT_DELAY:-60}
PROBE=${PROBE:-/proc/vhost_n5}
PHY_IF=${PHY_IF:-eth0}
TAP_IF=${TAP_IF:-tap1}
OUT_BASE=${OUT_BASE:-/tmp/vhost_n5_capture}
LOCK_DIR=${LOCK_DIR:-/tmp/vhost_n5_capture.lock}

for number in "$IO_TID" "$VH_TID"; do
    case "$number" in ''|*[!0-9]*) usage;; esac
    [ "$number" -gt 0 ] && [ "$number" -le 2147483647 ] || usage
done
case "$LABEL" in ''|*[!A-Za-z0-9_.-]*) echo "Invalid label" >&2; exit 2;; esac
for iface in "$PHY_IF" "$TAP_IF"; do
    case "$iface" in ''|*[!A-Za-z0-9_.:-]*) echo "Invalid interface" >&2; exit 2;; esac
done
awk -v n="$CAPTURE_SECONDS" 'BEGIN {exit !(n ~ /^[0-9]+([.][0-9]+)?$/ && n>0 && n<=5)}' || {
    echo "Duration must be >0 and <=5 seconds" >&2; exit 2;
}
awk -v n="$REPORT_DELAY" 'BEGIN {exit !(n ~ /^[0-9]+([.][0-9]+)?$/ && n>=0 && n<=600)}' || {
    echo "Invalid REPORT_DELAY" >&2; exit 2;
}
[ -r "$PROBE" ] && [ -w "$PROBE" ] || { echo "Missing read/write probe: $PROBE" >&2; exit 1; }
for tid in "$IO_TID" "$VH_TID"; do
    [ -r "/proc/$tid/status" ] || { echo "TID $tid does not exist" >&2; exit 1; }
done
case "$(cat "/proc/$IO_TID/comm")" in *ioeventfd*) ;; *) echo "IOEVENT_TID is not an ioeventfd task" >&2; exit 1;; esac
case "$(cat "/proc/$VH_TID/comm")" in vhost-*) ;; *) echo "VHOST_TID is not a vhost worker" >&2; exit 1;; esac
# Fail rather than silently altering another active measurement.
for p in /sys/module/ccm_proxy/parameters/ioem_run \
         /sys/module/ccm_proxy/parameters/n4_run \
         /sys/module/vhost_net/parameters/n4_run; do
    if [ -r "$p" ]; then
        value=$(cat "$p")
        case "$value" in 0|N|n) ;; *) echo "Stop old probe first: $p=$value" >&2; exit 1;; esac
    fi
done
mkdir -p "$OUT_BASE"
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    echo "Capture lock exists: $LOCK_DIR (check any active capture before removing a stale lock)" >&2
    exit 1
fi
ACTIVE=0
OUT=''
cleanup() {
    rc=$?
    trap - EXIT HUP INT TERM
    if [ "$ACTIVE" -eq 1 ]; then
        printf '%s\n' stop > "$PROBE" || :
    fi
    rmdir "$LOCK_DIR" 2>/dev/null || :
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM
OUT=$OUT_BASE/${LABEL}_$(date +%Y%m%d_%H%M%S)_$$
mkdir "$OUT"

context() {
    printf 'label=%s io_tid=%s vhost_tid=%s capture_seconds=%s report_delay=%s\n' \
        "$LABEL" "$IO_TID" "$VH_TID" "$CAPTURE_SECONDS" "$REPORT_DELAY"
    uname -a
    cat /proc/sys/kernel/random/boot_id 2>/dev/null || :
    for tid in "$IO_TID" "$VH_TID"; do
        echo "--- TID=$tid ---"
        if [ -r "/proc/$tid/status" ]; then
            grep -E '^(Name|Pid|Tgid|Cpus_allowed_list):' "/proc/$tid/status"
            # Raw stat preserves task starttime; compare before/after for PID reuse.
            cat "/proc/$tid/stat"
        else
            echo "MISSING_TID=$tid"
        fi
    done
    for irq in $IRQ_LIST; do
        echo "--- IRQ=$irq interface=$PHY_IF ---"
        for key in smp_affinity_list effective_affinity_list; do
            printf '%s=' "$key"
            cat "/proc/irq/$irq/$key" 2>/dev/null || echo unavailable
        done
    done
    p=/sys/module/vhost_net/parameters/experimental_zcopytx
    if [ -r "$p" ]; then printf 'experimental_zcopytx='; cat "$p"; fi
}
snapshot() {
    printf 'uptime='; cat /proc/uptime
    for dev in "$PHY_IF" "$TAP_IF"; do
        for field in tx_packets rx_packets tx_bytes rx_bytes; do
            p=/sys/class/net/$dev/statistics/$field
            if [ -r "$p" ]; then printf '%s_%s=' "$dev" "$field"; cat "$p"; fi
        done
    done
    for irq in $IRQ_LIST; do
        awk -v key="$irq:" '$1==key {print}' /proc/interrupts
    done
}
# IRQ numbering is dynamic; look for an exact interface action-name token.
IRQ_LIST=$(awk -v dev="$PHY_IF" '{for (i=2;i<=NF;i++) if ($i==dev) {s=$1; sub(/:$/,"",s); print s; break}}' /proc/interrupts)
context > "$OUT/context_before.txt"
cat "$PROBE" > "$OUT/previous_probe.txt"
if grep -q 'run=1' "$OUT/previous_probe.txt"; then
    echo "N5 is already running; will not clear it" >&2; exit 1
fi
EXPECTED_EPOCH=$(awk '{for(i=1;i<=NF;i++) if($i ~ /^epoch=/){split($i,a,"="); n=a[2]+1; if(n>4294967295)n=1; printf "%.0f",n; exit}}' "$OUT/previous_probe.txt")
[ -n "$EXPECTED_EPOCH" ] || { echo "Unrecognized probe report header" >&2; exit 1; }

# Start only AFTER Android traffic has reached the first 10-second interval.
# No polling, no trace reading, no ps scans in the timed window.
snapshot > "$OUT/counters_before.txt"
printf 'start %s\n' "$VH_TID" > "$PROBE"
ACTIVE=1
sleep "$CAPTURE_SECONDS"
printf '%s\n' stop > "$PROBE"
ACTIVE=0
snapshot > "$OUT/counters_after.txt"
context > "$OUT/context_after.txt"
# Reading the aggregate report is deferred until the iperf run has finished.
sleep "$REPORT_DELAY"
cat "$PROBE" > "$OUT/vhost_n5.txt"
if ! awk -v epoch="$EXPECTED_EPOCH" -v tid="$VH_TID" '
    NR==1 {for(i=1;i<=NF;i++){if($i=="epoch="epoch)e=1; if($i=="tid="tid)t=1; if($i=="run=0")r=1}}
    END {exit !(e && t && r)}' "$OUT/vhost_n5.txt"; then
    echo "Probe epoch/target changed externally; do not use this capture" >&2; exit 1
fi
if ! grep -q '^IDENTITY,bound=1,' "$OUT/vhost_n5.txt"; then
    echo "No selected TX handler was captured; check worker TID and traffic" >&2
    echo "OUTPUT_DIR=$OUT"
    exit 1
fi
if grep -q 'run=1' "$OUT/vhost_n5.txt"; then
    echo "Probe was restarted externally; report is not this capture" >&2; exit 1
fi
printf 'OUTPUT_DIR=%s\n' "$OUT"
echo "Send vhost_n5.txt + context_before/after.txt + iperf command and final result. No raw trace required."
