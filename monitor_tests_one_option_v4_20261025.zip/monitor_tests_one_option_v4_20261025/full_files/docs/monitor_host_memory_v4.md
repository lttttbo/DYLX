# Monitor v4：Hypervisor 侧内存测试补充

> 配置更新：当前统一使用 CONFIG_WBOXTEST_MONITOR，一个开关运行 6 个隔离用例和 3 个 Hypervisor 用例。下文 HOST/LIVE 子开关及 12 用例组合属于历史版本；当前执行步骤以 [单开关说明](monitor_one_option_v4.md) 为准。Guest 现场源码保留但本阶段不编译。

日期：2026-10-25。本次优先验证 Hypervisor 自身能触发的已有错误路径，不需要 Guest 用户态刺激程序、新 Guest 或 CCM 驱动修改。日志作为人工检查项。

## 1. 新增三个用例

| 用例 | 自动执行的操作 | 判定 |
|---|---|---|
| monitor_host_range | 通过只做检查的探测接口寻找原命令策略拒绝的地址；调用原 RAM 读取检查和原写入检查 | 原返回值分别为 VMM_ERANGE、VMM_EFAIL；真实 monitor 事件 type=3/code=8，地址、操作、宽度、执行线程、epoch 和次数匹配 |
| monitor_host_guest_guard | 从现有 Guest RAM/ROM 映射收集候选 HPA，再检查是否命中原禁止写 Guest 内存分支 | 原写入检查拒绝，产生 type=3/code=3；不会映射、读取或写入目标 Guest 地址 |
| monitor_host_shmem | 创建一个测试专用共享内存对象；先做合法读写填充，再分别构造读、写、填充越界 | 合法访问数据正确且无异常；越界原返回值为 0，分别产生 type=3/code=1；拒绝后首尾校验数据未改变；结束释放对象 |

三个用例均注册到 `monitor` 组，源码在 `libs/wboxtest/monitor/host/memory.c`。现场调用真实检查函数和真实 monitor 实例，不调用 monitor 的事件注入、sample 或 drain 接口来制造成功。

命令检查用例通过仅测试配置下存在的适配函数调用 `check_read_memory()`、`check_write_memory()`。它验证的是“原检查拒绝—真实监控记录—周期采样—事件查询”链路，不包含命令行解析、mterm 认证或实际非法物理访存。不会向一个未知物理地址裸写来测试。

共享内存用例调用真实 `vmm_shmem_create/read/write/set/destroy`，只操作自己分配的对象。实际大小以创建结果为准，通常为一页；不会使用 Guest 业务缓冲区。

## 2. 配置与执行

只做本次 Hypervisor 测试时：

```text
CONFIG_MONITOR_AGENT=y
CONFIG_CMD_MONITOR=y
CONFIG_CMD_MEMORY=y
CONFIG_WBOXTEST=y
CONFIG_CMD_WBOXTEST=y
CONFIG_WBOXTEST_MONITOR=y
CONFIG_WBOXTEST_MONITOR_HOST=y
CONFIG_WBOXTEST_MONITOR_LIVE=n
```

`CONFIG_CMD_MEMORY` 必须为 y，且使用你提供的带检查版本，并合入本包的记录点和测试适配函数。不能只用未适配的开源 cmd_memory.c。

开关组合：

| 开关 | monitor 组用例数 |
|---|---|
| 仅 MONITOR | 原 6 个隔离用例 |
| MONITOR + HOST | 原 6 个 + 新 3 个，共 9 个；不需要 Guest 负载程序 |
| MONITOR + LIVE | 原 6 个 + 原 3 个 Guest 现场用例，共 9 个 |
| MONITOR + HOST + LIVE | 共 12 个；原 LIVE 用例仍需要自己的场景 |

执行：

```text
monitor start
wboxtest test_list
wboxtest run_tests 1 monitor_host_range
wboxtest run_tests 1 monitor_host_guest_guard
wboxtest run_tests 1 monitor_host_shmem
```

也可在只开 HOST 子选项时执行：

```text
wboxtest run_groups 1 monitor
```

不需要 `monitor_live target`。Guest 写入拒绝用例需要至少一个已创建、符合原命令检查条件的 Guest RAM/ROM 映射，但 Guest 可以不运行。测试期间保持 VM 生命周期和映射不变。

如果没有可达的原拒绝分支，会返回 `VMM_ENOTAVAIL` 并显示原因，wboxtest 将其计为失败，不算 PASS。例如：Guest 尚未创建，或项目的 host RAM bank 列表与 Guest 映射没有满足前序检查的交集。

## 3. cmd_memory 的修改

只追加三处生产记录，不改变原条件、返回值、读写动作或授权规则：

1. `check_read_memory()`：原结果为 `VMM_ERANGE` 时记录 code=8，再原样返回；`VMM_ENOMEM` 等其他结果不作为读取范围拒绝记录。
2. `check_write_memory()`：原 `check_type_memory()` 失败分支记录 code=8，再原样返回。
3. `check_write_memory()`：原“地址属于 Guest，不能修改”分支记录 code=3，再返回原来的 `VMM_EFAIL`。

原写入分类函数可能将下层错误合并为 VMM_EFAIL。因此 code=8 的精确含义是“原命令地址范围/分类检查拒绝”，不额外断言所有拒绝均由实际物理越界导致。这里保留原处理，不新增分类或修复策略。

没有在纯探测函数 `check_type_memory()`、RAM bank 检查或 Guest 列表遍历中直接打点，避免它们被用于内部探测时产生误报。实际操作检查拒绝时才记录。

两个测试专用适配接口只在 HOST 开关打开时编译：

- `vmm_monitor_host_probe()`：复用已有分类和 Guest 映射检查，探测候选地址，不记录事件、不访问物理地址。
- `vmm_monitor_host_guard()`：调用原读/写检查，可由原失败分支产生事件，不执行物理读写。

适配接口只接受 1/2/4 字节及不发生地址加法回绕的测试参数；这些限制不作用于原 mem 命令，不能据此声称修复了命令原有整数溢出问题。

上传的 cmd_memory.c.txt 首行是 `*`，缺少注释开头的 `/`。完整参考文件补齐为 `/*` 以便编译；如果工程源文件本来有完整头注释，不用合入这一处注释修正。

## 4. 事件解释与人工日志检查

schema 仍为 3，内存事件 type 仍为 3。旧 code=1..7 不变，新增 code=8。

| 记录点 | code | address | detail | 主体 |
|---|---|---|---|---|
| mem 原地址范围/分类检查拒绝 | 8 | 实际检查的 HPA | 高 32 位：0 读、1 写；低 32 位：检查宽度 | 当前执行检查的 host vCPU；guest=无归属 |
| mem 原禁止写 Guest 内存分支 | 3 | 实际检查的 HPA | 同上 | 当前执行检查的 host vCPU；不把被保护的 Guest 冒充发起者 |
| shmem 越界 | 1 | 对象内 offset | 请求长度 | 原接口 actor=NULL，guest/vcpu=4294967295 |

例如 detail=4294967297 表示写、宽度 1；detail=1 表示读、宽度 1。code=3 在其他工程记录点的 detail 仍按其原定义解释。

测试输出示意：

```text
monitor_host EVENT seq=... epoch=... vcpu=... code=8 address=... detail=...; log=manual
wboxtest: test=monitor_host_range failures 0 out of 1
```

自动测试检查事件，不等待 `vmm_lprintf` 返回，也不读取磁盘。人工根据输出的 seq、epoch、主体和参数核对原日志后端中的 JSON；事件尚未输出时等待正常后台日志执行。这里不新增日志存储实现。

本次三个新用例采用人工日志口径；没有修改旧 LIVE 用例及其原日志回执断言。

## 5. 事件判定如何避免假通过

- 开始前要求真实 monitor 已启用，运行期间不修改启停、配置或退出阈值。
- 新增仅测试构建存在的“采样完成序号”，在真实 `vmm_monitor_sample()` 执行末尾递增；测试只能读取它。
- 操作前记录事件游标、采样序号和时间，之后等待两个采样完成，覆盖操作前已在执行的那一次采样。
- 每次请求单独核对，不让读/写/填充三个失败在同一窗口聚合后冒充分别通过。
- 匹配 code、address、detail、主体、epoch、时间和 value=1。无归属事件也单独核对，不只筛选 Guest vCPU。
- `lost`、`skipped` 或执行器错误增加、事件环覆盖本次证据、同一主体有其他混入事件时，保守判定失败。
- 采样器不执行则超时；monitor 未启动则明确失败；缺少 Guest 映射则明确不可执行。均不静默算通过。
- 仅检查真实事件，不依赖日志回执。测试用例没有直接调用 `vmm_monitor_mem_fault()`。

正常内部采样周期下整组通常需数十秒；每次等待最多 8 秒。测试时避免同时制造大量内存错误，以免聚合或覆盖使证据无法区分。

## 6. 内存与资源边界

这次覆盖非法地址检查、原禁止写 Guest 内存策略、共享内存 API 的普通范围越界，以及合法访问负例。不证明任意 Hypervisor 指针越界都可捕获，也不证明所有 Guest 自行发起的越权路径已测试。

Guest 拒绝用例会从最多 64 个候选映射中选择一个实际可达的原拒绝分支，并输出候选 Guest ID 和 HPA。它验证此分支，不声称逐个测试了所有域；不创建、重置或销毁 Guest。

测试代码会申请专用共享内存，cmd_memory 原检查也有自己的临时分配；退出时释放测试对象。它们属于测试/命令行为，不能据此计算 monitor 采集路径的动态分配或 CPU/ROM 开销。量产关闭 HOST/LIVE/整个 MONITOR 测试选项。

## 7. 合入与验证结果

交付分为：

1. `monitor_support.patch`：基于已合入的记录版，追加 code=8、扩展只读观察接口的编译条件，增加测试专用采样完成序号。
2. `cmd_memory_from_uploaded.patch`：基于你上传的 cmd_memory.c，补原失败分支记录和测试适配函数。
3. 三份测试补丁选择一份：`tests_from_unified.patch`、`tests_from_observer.patch`、`tests_from_20261023.patch`。按当前测试目录版本选择，不能叠加。

核心支持补丁始终基于已经合入的记录版，不需要重做旧 CCM 改动。测试如果仍停留在 23 日版，第三项会一并迁移到统一目录与当前测试实现。

本机已完成：

- 去掉三处记录、测试适配函数、追加 include 和注释修复后，cmd_memory 与上传原文精确一致。
- 360 组原/新函数对照，包含运行开关、分配失败、RAM/Guest/设备/非法地址与不同宽度；返回值和分类一致，未发生物理访问。
- 9 个 ARM64 编译单元检查：HOST 单独开启、HOST 与 LIVE 同开、monitor 编译关闭。
- 新三个用例在本机平台模型中通过，未调用日志后端；关闭采样、采样跳过、关闭监控、缺少 Guest 的场景不会假通过。
- 删除真实记录调用、写错事件类型，两种变异均被新用例检测到。
- 原隔离白盒 54 次执行，以及只读观察接口/历史日志解析回归通过。
- 各补丁应用、结果比对和反向还原校验通过。

这些是编译和平台模型验证，未执行你的私有工程完整链接、QEMU 或板卡现场运行。ROM ≤5KB、CPU <0.5% 等约束不由本次测试结果代替验收。

本机模型复验命令（在合入后的源码根目录，使用本包附带的上传原文参考文件）：

```sh
python3 tests/monitor/run_host_memory_checks.py --cc /path/to/zig --out /tmp/monitor-host-check \
  --original-command /path/to/reference/cmd_memory.c.txt --command commands/cmd_memory.c
```
