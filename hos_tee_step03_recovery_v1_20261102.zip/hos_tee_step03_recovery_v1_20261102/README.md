# hos TEE 第三步：经典 SMC 路径的错误恢复与边界校验

版本：step03 / v1，2026-11-02。增量基线：`hos_tee_step02_threads_v1_20261102`。

本包提供第三步代码，按你的安排，板端测试留到后续。第一步能力屏蔽和第二步线程数量查询
均保留。本步只修改 `arch/arm/cpu/common/optee.c`，不改 OP-TEE OS、Linux/Android 内核、
CCM、设备树或编译选项。完整文件包含前三步；patch 只包含第二步到第三步的差异。

## 1. 本次具体修复

| 原路径 | 问题 | 第三步行为 |
|---|---|---|
| DISABLE_SHM_CACHE | 仅透传成功 cookie，hos 的 RPC 影子缓冲区未同步回收 | 仅在返回 OK 时按当前 VM 的 cookie 移除影子对象；仍有使用者则延后实际释放 |
| RPC 请求写 Guest 失败 | 原 EAGAIN 分支将 0xffffxxxx RPC 返回值重新作为 SMC 调用号 | 在已知且合法的影子参数中写通信错误，用 CALL_RETURN_FROM_RPC 恢复原线程 |
| RPC_ALLOC 分配失败 | 直接销毁 call，而安全线程还挂起 | 按 RPC 协议恢复 NULL 分配结果；Guest 已分配的独立参数缓冲区先请求 Guest FREE |
| RPC 返回 cookie 不可信 | 使用 Guest 寄存器里的 cookie 查找并操作影子对象 | 使用本次安全侧 CMD 返回时保存的 rpc_cookie；不允许替换到其他 RPC 缓冲区 |
| num_params / NONCONTIG size | 先乘、加、缩窄再比较，可能溢出；Guest 两次读取间可改变长度 | 先约束数量与跨度，再计算长度；使用 hos 私有快照校验和处理 |
| NONCONTIG 页面地址 | 原来只验证地址的第 1 字节 | 检查 4 KiB 对齐、整页 RAM 映射可用长度和 Host PA 对齐 |
| 标准调用结果回写 | 忽略回写失败，Guest 仍看到 SMC OK | 安全调用已完成但无法回写时返回 EBADADDR，不伪报成功 |
| Guest 内存拷贝 | 映射可用长度为 0 可能不前进；地址范围可能回绕 | 拒绝回绕和零进度，每次 host 映射限制为一页 |

## 2. 三类资源与所有权

### 2.1 标准调用 `optee_std_call`

`hos_arg_pg` 是安全侧看到的影子参数页。新增 `guest_arg` 是原始 Guest 参数的私有快照，
`arg_size` 是已校验长度。它保存 Guest 地址、cookie、属性和参数数量，不受后续 Guest 修改影响。

进入时先读固定头，再校验数量，分配不超过一页的快照，读取完整参数；完整读取中的参数数量
必须与第一次头部一致。随后从快照复制到安全侧影子页并翻译地址。Guest 若并发修改其他内容，
实际采用的是复制到 hos 后的值；这不保证 Guest 多字段写入具有事务一致性，但后续解析不再
随 Guest 内存变化而变化。

返回时保留快照中的 Guest 地址、cookie、attr 等布局，仅更新 ret、ret_origin、session、
VALUE 输出和 TMEM/RMEM 输出长度，不把影子页中的 Host PA 写回 Guest。安全侧返回的数量若
与保存的数量不符则拒绝回写。`optee_destroy_call()` 新增释放 guest_arg。

新增快照使用现有堆分配接口，最大一页/活动调用；另有短期 RPC 响应快照。TEE 原实现本身就
使用动态分配，本包没有把 monitor 的“静态采集内存”约束套用到 TEE。

### 2.2 RPC 参数缓冲区 `optee_shm_rpc`

`capacity` 记录安全侧 RPC_ALLOC 当时申请的参数字节数，不能仅凭 host 分配了一整页就允许
向 Guest 写一整页。`refs` 是链表所有权加临时使用者的引用数，受 ctx->lock 保护。

- `optee_alloc_shm_rpc()` 分配影子页，锁内拒绝同 VM 的重复 cookie，建立链表引用和返回引用。
- `optee_get_shm_rpc()` 查找并获取一个临时引用。
- `optee_put_shm_rpc()` 释放引用，引用数变为 0 才释放影子页和对象。
- `optee_free_shm_rpc()` 将对象从列表摘除，再释放链表引用；未知 cookie 不会释放其他对象。

DISABLE_SHM_CACHE 返回 OK+cookie，表示安全侧交回该缓存对象；此时回收对应 hos 对象。
EBUSY、ENOTAVAIL 不表示带回了有效 cookie，不进行释放。不同 VM 的 cookie 空间仍分属各自 ctx。
临时引用覆盖本次 RPC 处理及其恢复 SMC，避免对象在使用途中被回收。

### 2.3 NONCONTIG payload 页表

仍复用原来的 `optee_shm_buf` / `tmp_shm_bufs` / `rpc_data_sb`，保留单缓冲区 129 页等既有额度。
本次在加偏移、向上取整和转换到 u32 之前先按额度限制 size，避免超大长度通过回绕变成小长度。
检查页表页地址、数据页 GPA 和 HPA 的 4 KiB 对齐及整页 RAM 映射。计数配额比较改成先减后比较，
避免 `shm_page_count + page_cnt` 的加法回绕。

本 mediator 的 NONCONTIG 实现仍要求 hos 页大小与 OP-TEE 4 KiB 协议页相同；不相同时明确拒绝。
本包没有实现 64 KiB hos 页的协议适配，也没有新增 Guest 页面 pin/unpin 机制。

## 3. RPC 恢复状态机

| 状态 | 含义 | 下一步 |
|---|---|---|
| NORMAL | 常规 RPC 或标准调用 | 按实际安全侧 RPC 功能处理 |
| HOS_RPC | 原 SHM_ALLOC payload 翻译失败，已向 Guest 发出合成 SHM_FREE | 收到返回后给原 SHM_ALLOC 填通信错误，再恢复安全线程 |
| FREE_ARG | Guest 参数缓冲区已分配，但 hos 建立影子失败，已向 Guest 发出合成 RPC_FREE | 收到返回后恢复原 RPC_ALLOC，返回 NULL 地址和 cookie |
| FAILED | 无法可靠恢复的挂起调用 | 拒绝再次按该 thread_id 领取；保留 hos 资源直到正常 VM 销毁确认 |

### 3.1 参数缓冲区分配失败

RPC_ALLOC 是 0xffff0000；它和 CMD_SHM_ALLOC（共享参数页里的命令 6）不是同一个层级。
对于 RPC_ALLOC，Guest 返回 NULL，hos 用 `OPTEE_SMC_CALL_RETURN_FROM_RPC`、a1/a2=0、a4/a5=0、
a3=原 thread_id 通知安全侧分配失败，而不是直接终止 hos 上下文。

若 Guest 已返回分配 cookie，但 hos 分配影子页失败，先向 Guest 返回 `RPC_FREE` 请求清理该
cookie；Guest 再次返回后，才将原 RPC_ALLOC 以 NULL 结果恢复。重复 cookie 不会触发对已有
有效影子对象的 Guest FREE，以免破坏另一调用。该保护不意味着可修复恶意 Guest 的所有分配记录。

对于申请长度小于消息头或超过一页的 RPC_ALLOC，hos 不向 Guest 请求超限分配，直接恢复失败结果。

### 3.2 RPC CMD 参数传递失败

安全侧 CMD cookie 能找到影子对象且头部数量合法，但向 Guest 写入失败时，直接在这个影子页内
设置 `TEEC_ERROR_COMMUNICATION`，保留有界的参数布局，再恢复原安全线程。

Guest 回复时，读取长度来自影子中的原始请求，Guest 回复必须保持相同 cmd 和 num_params。
普通 RPC 只能返回原有属性允许的 VALUE 输出和内存长度，不能替换地址、cookie 或属性。
SHM_ALLOC 允许协议规定的 VALUE_INPUT → TMEM_OUTPUT 转换，随后必须进行地址翻译校验。

读回复失败、回复格式错误、分配响应快照失败、Guest 替换 cookie，都在已知原影子中设置通信错误
并恢复线程。无法得知 Guest 私下分配的有效 cookie 时，不猜测或释放任意 Guest 资源。

### 3.3 payload 翻译失败

合法 SHM_ALLOC 回复中的 NONCONTIG payload 如果翻译失败，沿用原来的合成 SHM_FREE 机制清理
Guest 分配，再以通信错误恢复原 SHM_ALLOC。合成清理请求本身无法写 Guest 时，只能向安全侧
报告失败，不能承诺该 Guest 分配已经释放；后续需 Guest 驱动/VM 的正常清理流程处理。

**兼容边界：本包明确拒绝没有 NONCONTIG 的非空 RPC payload。** 原代码在这个分支没有 GPA→HPA
翻译，原样透传并不等于正确支持。第三步阻止未翻译地址进入安全侧，并尽可能发 SHM_FREE 清理。
用户提供的 smc_abi.c 在动态共享内存具有 pages 时返回 NONCONTIG；保留共享内存池等无 pages
分支可能返回连续 TMEM。后者需要独立实现完整地址转换和生命周期，再谈支持；不能假设 GPA=HPA。
如果私有业务实际依赖这个分支，应先保留第二步版本、确认需求后再适配该分支，不能把本步当成
对所有共享内存模式的无条件兼容保证。

### 3.4 无法可靠恢复时

安全侧 CMD cookie 没有对应对象、影子头部超过容量、未知 RPC 功能、恢复 SMC 被安全侧拒绝，
都无法证明安全线程已经结束。此时返回 ERESUME，打印一条包含 client_id/thread_id/RPC 功能的
诊断信息，将 call 标记 FAILED，保留 host 影子页、快照和临时页表，继续占用原来的 call 配额。

单次调用中因本地故障连续自动恢复超过 8 次，也转入 FAILED，防止在 hos 内无限重试。
正常 RPC 交还 Guest 的路径不计入这次本地恢复预算。

```text
OPTEE: client=1 thread=2 RPC=5 suspended; resources retained until VM stop
```

这不是自动修复完成，也不是自动重置。Guest 仍可使用剩余额度；额度全部被占用后新标准调用
会按原有机制返回 ETHREAD_LIMIT。正常 VM stop 先请求安全侧 VM_DESTROYED，只有成功后才释放
保留资源。VM_DESTROYED 失败则继续保留。不能手工清空 call_count 或直接释放这些页代替恢复。

既有 VM 停止/销毁流程仍须先阻止该 VM 新的 SMC 并排空正在执行的处理函数。本包未改该外层
生命周期同步；对象引用计数也不能替代 ctx 的停止同步。FAILED 只保护 hos 拥有的资源，
不保证 Guest 在收到错误后仍保留自己的所有业务缓冲区。

## 4. 返回结果及错误含义

| 情况 | Guest 可见结果 |
|---|---|
| 标准调用完成且成功回写 | SMC a0=OK；业务结果仍看消息 arg.ret |
| 参数翻译失败，但通信错误成功回写 | a0=OK、arg.ret=TEEC_ERROR_COMMUNICATION |
| 标准调用完成/本地拒绝，但消息无法回写 | a0=EBADADDR，不宣称回写成功 |
| 新调用未获安全线程，安全侧返回 ETHREAD_LIMIT | 保留原错误供 Guest 重试；销毁尚未被安全侧挂起的 call |
| 已挂起调用无法确认恢复 | a0=ERESUME、call=FAILED，等待正常 VM stop 清理 |

正常返回的 SMC OK 和 TA 业务成功不同；TA 的业务错误仍可能在 arg.ret 中。
本包保留 client_id 由 hos 强制填充的规则，不信任 Guest 的 a7；既有 VM 生命周期及 max_calls
配置不变。第一步 RPC_ARG、ASYNC_NOTIF 屏蔽和第二步 GET_THREAD_COUNT 入口保持不变。

## 5. 合入文件和函数

`MANUAL_MERGE.txt` 给出原文件函数行号、新文件函数行号、修改顺序，并包含每个修改/新增函数
的完整内容。新增结构体字段必须一起合入，不要只复制某一个 RPC 函数。

`full_files/arch/arm/cpu/common/optee.c` 是可对照的完整结果。
`step03_recovery.patch` 是仅相对第二步的补丁；应用前先 `git apply --check`。
私有源码路径不同时按函数名合入。不要将本包直接叠加到未做前两步的原始文件。

## 6. 本地检查和后续板端验证

已对本包完整 C 文件进行 ARM64 freestanding 编译，使用用户提供的 OP-TEE 三个头文件，
hos/平台接口采用测试替身；`-O2 -Wall -Wextra -Werror` 通过。并把同一完整文件编入主机测试，
模拟 Guest 内存、SMC 返回和分配失败。32 组场景通过，详见 validation.json。

包括：参数数量上限/乘法溢出、快照期间头部改变、快照分配失败、输出布局恢复、整页权限/跨度、
地址回绕、零进度、跨页拷贝、NONCONTIG 溢出与正常翻译；缓存释放及延迟释放、忙/空返回、
重复/未知/跨 VM cookie；RPC 参数分配成功和失败、合成 FREE、CMD 回写失败的正确 SMC 调用号、
未知 cookie 的资源保留、恢复被拒绝、Guest 替换 cookie/参数数量/属性、RPC 响应快照分配失败、
payload 翻译成功/失败/连续地址拒绝、自动恢复预算；普通完成和回写失败、外国中断恢复、
VM_DESTROYED 成功前不回收、第一步能力和第二步线程查询回归。

这些是同步模拟接口测试，未执行真实 SMC、实际固件、SMP 竞争、TA、Android KeyMint/DRM 或
tee-supplicant；不是完整 hos 私有工程构建。没有宣称已在 OP-TEE OS 4.0.0-55 上验证通过。
本地测试代码保留在工作目录，未作为生产模块加入交付源码。

补丁正向应用与完整文件逐字节一致；反向应用恢复第二步基线；压缩包解压内容及 SHA256 校验通过。

后续板端测试建议按以下顺序执行，不要求现在执行：

1. 完整编译 hos；启动 serverVM/Android，复测原先可用的 TA 和安全业务。
2. 运行两 VM 并发会话及持续调用，确认普通 RPC/中断返回路径没有回归。
3. 在维护环境、业务已停且驱动支持卸载的前提下，反复卸载/装载 OP-TEE 驱动以覆盖缓存释放；
   不在正在使用 TEE 的产品系统强制卸载。核对缓存对象和 host 页不随重复操作单调增长。
4. 用现有故障注入/调试手段模拟分配与回写失败，记录 Guest 返回码、call_count 和 RPC cookie；
   本包没有额外提供运行时故障注入命令。
5. 出现保留资源诊断时核对正常 VM stop 成功后是否回收，不能以“没有新增打印”代替这项验证。

## 7. 协议依据与下一步

RPC 恢复调用号、ALLOC 的 NULL 失败结果、FREE/CMD cookie 和缓存返回约定参照
[OP-TEE OS 4.0.0 SMC 协议](https://raw.githubusercontent.com/OP-TEE/optee_os/4.0.0/core/arch/arm/include/sm/optee_smc.h)。
安全线程在 RPC 中挂起、错误结果如何继续执行，以及缓存对象释放时机参照
[OP-TEE OS 4.0.0 线程与 RPC 实现](https://raw.githubusercontent.com/OP-TEE/optee_os/4.0.0/core/arch/arm/kernel/thread_optee_smc.c)。
Guest 处理合成 FREE 和 SHM_FREE 的流程还核对了你提供的 smc_abi.c。
厂商 4.0.0-55 可能含私有改动，本次没有完整固件源码，不能把上游 4.0.0 检查等同于该构建验证。

第三步加固的是目前仍使用的经典 CALL_WITH_ARG + RETURN_FROM_RPC 路径。
RPC_ARG / CALL_WITH_RPC_ARG / CALL_WITH_REGD_ARG，以及异步通知仍留给后续独立步骤，未在本包打开。
