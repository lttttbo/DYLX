#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/virtio_config.h>
#include <linux/virtio_ring.h>
/* Test-only stand-in for the unavailable vendor-private vhost.h.
 * Only fields used by the NEW helper are represented. This does NOT build
 * the vendor net.c/vhost.c or validate their full ABI.
 */
struct vhost_work { unsigned long flags; };
struct vhost_dev { struct task_struct *worker; int weight, byte_weight; };
struct vhost_poll { struct vhost_work work; };
struct vhost_virtqueue {
    struct vhost_dev *dev;
    struct vhost_poll poll;
    unsigned int num, busyloop_timeout;
    u16 last_avail_idx;
    u64 acked_features;
};
static bool vhost_has_feature(struct vhost_virtqueue *vq, unsigned int bit)
{ return (vq->acked_features & (1ULL << bit)) != 0; }
#include "vhost_round5_impl.h"
/* Keep the static observation helpers visible to the compile test. */
void compile_n5_hooks(struct vhost_dev *d, struct vhost_work *w);
void compile_n5_hooks(struct vhost_dev *d, struct vhost_work *w)
{ n5_note_queue(d, w, N5_SRC_POLL_EVENT, 0); n5_note_execute(d, w); }
static int __init t_init(void) { return vhost_n5_debug_init(); }
static void __exit t_exit(void) { vhost_n5_debug_exit(); }
module_init(t_init);
module_exit(t_exit);
MODULE_LICENSE("GPL");
