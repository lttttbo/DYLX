/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Preserved Guest-assisted tests. Deliberately absent from objects.mk.
 * They require a selected existing Guest and external test conditions;
 * the active Hypervisor-only suite remains nine cases.
 */
#include "common.h"
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_mutex.h>
#include <vmm_cmdmgr.h>
#include <vmm_threads.h>
#include <vmm_scheduler.h>
#include <vmm_completion.h>
#include <libs/mathlib.h>

#define ML_U(x) ((unsigned long long)(x))
struct ml_context {
    struct vmm_guest *guest;
    struct vmm_vcpu *vcpu;
    struct vmm_chardev *out;
    struct vmm_monitor_test_state baseline;
    u32 id, guest_id, timeout_s;
    bool locked;
};
static int ml_begin(struct ml_context *, struct vmm_chardev *);
static int ml_end(struct ml_context *, int);
static int ml_check(struct ml_context *);
static int ml_slot(struct ml_context *, struct vmm_monitor_test_slot *);
static int ml_scan(struct ml_context *, u64, u32, struct vmm_monitor_test_event *, u32 *);
static int ml_log_wait(struct ml_context *, u64);
static u64 ml_timeout(struct ml_context *);
#define ML_REQUIRE(expr) do { if (!(expr)) { \
    vmm_cprintf(c.out,"monitor_live FAIL %s:%u: %s\n",__func__,__LINE__,#expr); \
    rc=VMM_EFAIL; goto out; } } while (0)
#define ML_REGISTER(test_name,fn) \
static struct wboxtest test_name={.name=#test_name,.run=fn}; \
static int __init test_name##_init(void) { return wboxtest_register("monitor",&test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name,#test_name,"Monitor maintainers","GPL",WBOXTEST_IPRIORITY+1, \
    test_name##_init,test_name##_exit)

/* Preserved from the previous Guest-assisted common.c. */
static DEFINE_MUTEX(live_lock);
static u32 selected=~0U, timeout_s=90;
static int decimal(const char *s, u32 *out)
{
    u32 n=0;
    if (!s || !*s) return VMM_EINVALID;
    for (; *s; s++) {
        if (*s<'0' || *s>'9' || n>(~0U-(u32)(*s-'0'))/10) return VMM_EINVALID;
        n=n*10+(u32)(*s-'0');
    }
    *out=n; return VMM_OK;
}
static void usage(struct vmm_chardev *out)
{
    vmm_cprintf(out,"monitor_live target <global-vcpu-id>\nmonitor_live timeout <30..180 seconds>\n");
}
static int command(struct vmm_chardev *out, int argc, char **argv)
{
    u32 value;
    int rc=VMM_EINVALID;
    if (argc!=3 || decimal(argv[2],&value)) { usage(out); return rc; }
    if (!vmm_mutex_trylock(&live_lock)) return VMM_EBUSY;
    if (!strcmp(argv[1],"target") && value<CONFIG_MAX_VCPU_COUNT) {
        struct vmm_vcpu *v=vmm_manager_vcpu(value);
        if (v && v->is_normal && v->guest) { selected=value; rc=VMM_OK; }
    } else if (!strcmp(argv[1],"timeout") && value>=30 && value<=180) {
        timeout_s=value; rc=VMM_OK;
    }
    if (!rc) vmm_cprintf(out,"OK: target=%u timeout=%us\n",selected,timeout_s);
    vmm_mutex_unlock(&live_lock);
    return rc;
}
static struct vmm_cmd live_cmd={.name="monitor_live",.desc="Select an existing Guest for live tests",
    .usage=usage,.exec=command};
static int __init live_init(void) { return vmm_cmdmgr_register_cmd(&live_cmd); }
static void __exit live_exit(void) { vmm_cmdmgr_unregister_cmd(&live_cmd); }
VMM_DECLARE_MODULE2(monitor_live_control,"Existing Guest test control","Monitor maintainers","GPL",
    WBOXTEST_IPRIORITY+1,live_init,live_exit);

static u64 ml_timeout(struct ml_context *c) { return (u64)c->timeout_s*VMM_MONITOR_NS; }
static int ml_check(struct ml_context *c)
{
    struct vmm_monitor_test_state s;
    if (vmm_manager_vcpu(c->id)!=c->vcpu || c->vcpu->guest!=c->guest ||
        vmm_monitor_test_state(&s) || s.enabled!=c->baseline.enabled ||
        s.epoch!=c->baseline.epoch || s.config_seq!=c->baseline.config_seq ||
        s.lost!=c->baseline.lost || s.errors!=c->baseline.errors) {
        vmm_cprintf(c->out,"monitor_live: target/config changed, lost evidence, or executor error\n");
        return VMM_EFAIL;
    }
    return VMM_OK;
}
static int ml_slot(struct ml_context *c, struct vmm_monitor_test_slot *s)
{
    if (ml_check(c) || vmm_monitor_test_slot(c->id,s)) return VMM_EFAIL;
    return s->present && s->epoch==c->baseline.epoch && s->kind==0 &&
        s->guest==c->guest_id ? VMM_OK : VMM_EFAIL;
}
static int ml_begin(struct ml_context *c, struct vmm_chardev *out)
{
    struct vmm_monitor_test_slot s;
    u64 first,deadline;
    memset(c,0,sizeof(*c)); c->out=out;
    if (!vmm_mutex_trylock(&live_lock)) return VMM_EBUSY;
    c->locked=TRUE; c->id=selected; c->timeout_s=timeout_s;
    c->vcpu=vmm_manager_vcpu(c->id);
    if (!c->vcpu || !c->vcpu->is_normal || !c->vcpu->guest) {
        vmm_cprintf(out,"monitor_live: select an existing Guest vCPU first\n"); return VMM_EINVALID;
    }
    c->guest=c->vcpu->guest; c->guest_id=c->guest->id;
    /* The caller must keep VM lifetime, affinity and mappings stable during tests. */
    if (vmm_monitor_test_state(&c->baseline) || !c->baseline.enabled) return VMM_ENOTAVAIL;
    if (c->baseline.config[VMM_MONITOR_SUSTAIN_S]>10 ||
        c->baseline.config[VMM_MONITOR_WINDOW_MAX_MS]>2000) return VMM_EINVALID;
    if (vmm_monitor_test_slot(c->id,&s)) return VMM_EFAIL;
    first=s.previous; deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        if (ml_check(c) || vmm_monitor_test_slot(c->id,&s)) return VMM_EFAIL;
        if (s.present && s.epoch==c->baseline.epoch && s.kind==0 && s.guest==c->guest_id &&
            s.previous>first && s.valid) {
            vmm_cprintf(out,"monitor_live TARGET guest=%u vcpu=%u epoch=%u config_seq=%u\n",
                c->guest_id,c->id,c->baseline.epoch,c->baseline.config_seq);
            return VMM_OK;
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    return VMM_ETIMEDOUT;
}
static int ml_end(struct ml_context *c, int rc)
{
    if (c->locked) vmm_mutex_unlock(&live_lock);
    return rc;
}
static int ml_scan(struct ml_context *c,u64 after,u32 type,struct vmm_monitor_test_event *found,u32 *count)
{
    struct vmm_monitor_test_state state;
    struct vmm_monitor_test_event e;
    u64 seq;
    *count=0;
    if (ml_check(c) || vmm_monitor_test_state(&state) || state.head<after ||
        state.head-after>VMM_MONITOR_EVENTS) return VMM_EFAIL;
    for (seq=after+1; seq<=state.head; seq++) {
        if (vmm_monitor_test_event(seq,&e)) return VMM_EFAIL;
        if (e.type==type && e.guest==c->guest_id && e.vcpu==c->id && e.epoch==c->baseline.epoch) {
            if (e.log_calls>1) return VMM_EFAIL;
            *found=e; (*count)++;
        }
    }
    return VMM_OK;
}
static int ml_log_wait(struct ml_context *c,u64 seq)
{
    struct vmm_monitor_test_event e;
    u64 deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        if (ml_check(c) || vmm_monitor_test_event(seq,&e)) return VMM_EFAIL;
        if (e.log_returned) {
            if (e.log_calls!=1) return VMM_EFAIL;
            vmm_cprintf(c->out,"monitor_live LOG seq=%llu type=%u guest=%u vcpu=%u epoch=%u time_ns=%llu code=%u address=%llu value=%llu detail=%llu\n",
                ML_U(e.seq),e.type,e.guest,e.vcpu,e.epoch,ML_U(e.time_ns),e.code,
                ML_U(e.address),ML_U(e.value),ML_U(e.detail));
            return VMM_OK;
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    return VMM_ETIMEDOUT;
}

/* Preserved from the previous Guest-assisted scheduler.c. */
struct hold_context {
    struct ml_context *live;
    struct vmm_completion done;
    struct vmm_monitor_test_slot held;
    u64 start,end;
    int rc;
};
static int hold_worker(void *arg)
{
    struct hold_context *h=arg;
    struct vmm_vcpu *v=h->live->vcpu;
    h->rc=VMM_EFAIL;
    vmm_scheduler_preempt_disable();
    /* Guest was descheduled naturally. Never pause/reset/resume its state. */
    if (vmm_manager_vcpu_get_state(v)==VMM_VCPU_STATE_READY && !ml_slot(h->live,&h->held) && h->held.waiting) {
        h->start=vmm_timer_timestamp();
        vmm_udelay(2000);
        h->end=vmm_timer_timestamp();
        if (vmm_manager_vcpu_get_state(v)==VMM_VCPU_STATE_READY) h->rc=VMM_OK;
    }
    vmm_scheduler_preempt_enable();
    vmm_completion_complete(&h->done);
    return 0;
}
static int schedule_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct hold_context h={0};
    struct vmm_thread *worker=NULL;
    struct vmm_monitor_test_slot before,after;
    u64 timeout=5*VMM_MONITOR_NS,deadline,minimum;
    u32 target_cpu;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(c.vcpu->priority<=3);
    ML_REQUIRE(vmm_cpumask_weight(vmm_manager_vcpu_get_affinity(c.vcpu))==1);
    ML_REQUIRE(!vmm_manager_vcpu_get_hcpu(c.vcpu,&target_cpu));
    /* Keep auth/mterm CPU out of this bounded interference test. */
    ML_REQUIRE(target_cpu!=0);
    h.live=&c; INIT_COMPLETION(&h.done);
    worker=vmm_threads_create("monitor-test-hold",hold_worker,&h,3,VMM_THREAD_DEF_TIME_SLICE);
    ML_REQUIRE(worker);
    ML_REQUIRE(!vmm_threads_set_affinity(worker,vmm_cpumask_of(target_cpu)));
    ML_REQUIRE(!vmm_threads_start(worker));
    ML_REQUIRE(!vmm_completion_wait_timeout(&h.done,&timeout));
    ML_REQUIRE(!h.rc && h.end>=h.start+2000000ULL);
    /* Use the snapshot taken while the target was actually waiting.
     * Earlier dispatches before the worker started are not test evidence. */
    before=h.held;
    minimum=h.end-h.start;
    deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        ML_REQUIRE(!ml_slot(&c,&after));
        if (after.ready.count>before.ready.count && after.dispatch.count>before.dispatch.count) break;
        vmm_msleep(10);
    } while (vmm_timer_timestamp()<deadline);
    ML_REQUIRE(after.ready.count>before.ready.count && after.ready.sum>=before.ready.sum+minimum);
    ML_REQUIRE(after.ready.max>=minimum);
    ML_REQUIRE(after.dispatch.count>before.dispatch.count && after.dispatch.sum>before.dispatch.sum);
    vmm_cprintf(out,"monitor_live SCHEDULE vcpu=%u hold_ns=%llu ready_count_delta=%llu dispatch_count_delta=%llu\n",
        c.id,ML_U(minimum),ML_U(after.ready.count-before.ready.count),ML_U(after.dispatch.count-before.dispatch.count));
out:
    if (worker) {
        if (vmm_threads_stop(worker)) rc=VMM_EFAIL;
        if (vmm_threads_destroy(worker)) rc=VMM_EFAIL;
    }
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_schedule,schedule_run);

/* Preserved from the previous Guest-assisted memory.c. */
/* Observe an existing error path. Never provoke a fault, change permissions,
 * inject an event, register a buffer or invoke a test hypercall here. */
static int memory_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct vmm_monitor_test_event e;
    struct vmm_monitor_test_state state;
    u64 start,deadline;
    u32 count;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(!vmm_monitor_test_state(&state));
    start=vmm_timer_timestamp(); deadline=start+ml_timeout(&c);
    vmm_cprintf(out,"monitor_live WAIT: observe a real memory/CCM failure on selected vCPU; no injection\n");
    do {
        ML_REQUIRE(!ml_scan(&c,state.head,3,&e,&count));
        if (count) break;
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    ML_REQUIRE(count==1 && e.time_ns>=start && e.value>0);
    ML_REQUIRE(e.code>=VMM_MONITOR_SHMEM_BOUNDS && e.code<=VMM_MONITOR_CCM_ELEMENT_REJECTED);
    ML_REQUIRE(!ml_log_wait(&c,e.seq));
out:
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_memory,memory_run);

/* Preserved from the previous Guest-assisted storm.c. */
/* Real sampling windows are observed continuously. The Guest helper is
 * started from another console; no mailbox or Guest lifecycle changes. */
static int storm_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct vmm_monitor_test_slot s, confirmed;
    struct vmm_monitor_test_event e;
    struct vmm_monitor_test_state state;
    u64 start,deadline,previous=0,high_ns=0,last_event=0,high_after=0;
    u32 high_windows=0,low_windows=0,events=0,count,phase=0;
    bool high;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(c.baseline.config[VMM_MONITOR_SUSTAIN_S]>=2);
    ML_REQUIRE(!vmm_monitor_test_state(&state));
    start=vmm_timer_timestamp(); deadline=start+ml_timeout(&c);
    vmm_cprintf(out,"monitor_live WAIT: supply an existing controlled exit load on selected Guest vCPU\n");
    do {
        ML_REQUIRE(!ml_slot(&c,&s));
        if (s.previous!=previous && s.previous>=s.interval && s.previous-s.interval>=start) {
            /* The sampler publishes slot and event data under its lock. A
             * second slot read detects a sampling boundary between these
             * separate read-only calls; retry before advancing our state. */
            ML_REQUIRE(!ml_scan(&c,state.head,1,&e,&count));
            ML_REQUIRE(!ml_slot(&c,&confirmed));
            if (confirmed.previous!=s.previous) continue;
            ML_REQUIRE(s.valid && s.config_seq==c.baseline.config_seq);
            ML_REQUIRE(!previous || s.previous-s.interval==previous);
            previous=s.previous;
            high=s.exits>udiv64((u64)c.baseline.config[VMM_MONITOR_EXIT_LIMIT]*s.interval,VMM_MONITOR_NS);
            if (high) { high_windows++; high_ns+=s.interval; low_windows=0; }
            else { high_windows=0; high_ns=0; low_windows++; }
            ML_REQUIRE(count>=events && count<=events+1);
            if (count>events) {
                ML_REQUIRE((phase==1 || phase==3) && e.time_ns==s.previous);
                ML_REQUIRE(high_windows>=c.baseline.config[VMM_MONITOR_SUSTAIN_S] &&
                    high_ns>=(u64)c.baseline.config[VMM_MONITOR_SUSTAIN_S]*VMM_MONITOR_NS);
                ML_REQUIRE(e.config_seq==c.baseline.config_seq &&
                    e.detail==c.baseline.config[VMM_MONITOR_EXIT_LIMIT] &&
                    e.sustain_s==c.baseline.config[VMM_MONITOR_SUSTAIN_S]);
                last_event=e.seq; events=count;
                if (phase==1) { phase=2; high_after=0; }
                else { ML_REQUIRE(!ml_log_wait(&c,last_event)); rc=VMM_OK; goto out; }
            } else if (!phase && !high && low_windows>=2 && !s.active) {
                phase=1; vmm_cprintf(out,"monitor_live: quiet baseline established\n");
            } else if (phase==2) {
                if (high) high_after+=s.interval;
                else if (low_windows>=2 && !s.active) {
                    ML_REQUIRE(high_after>=(u64)c.baseline.config[VMM_MONITOR_SUSTAIN_S]*VMM_MONITOR_NS);
                    ML_REQUIRE(!ml_log_wait(&c,last_event));
                    phase=3; vmm_cprintf(out,"monitor_live: dedup and recovery observed\n");
                }
            }
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    vmm_cprintf(out,"monitor_live: incomplete evidence phase=%u events=%u; check CPU, load and threshold\n",phase,events);
    rc=VMM_ETIMEDOUT;
out:
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_storm,storm_run);
