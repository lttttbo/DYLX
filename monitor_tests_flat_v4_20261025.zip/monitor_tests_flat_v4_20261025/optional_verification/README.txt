可选开发机验证工具

板端构建和 wboxtest 执行不需要本目录的补丁。
如需在开发机复验，先合入板端两份补丁，再使用 tools_from_observer.patch；路径相对源码根目录。
本目录完整文件包含 host.h（复用已有头）、host_memory_model.c、run_host_memory_checks.py、
run_live_checks.py 和 run_wboxtests.py。最后一个脚本明确选择六个隔离编译单元，避免目录平铺后
误将真实内存或 Guest 配合用例编入模拟环境。

运行示例：
python3 tests/monitor/run_wboxtests.py --cc /path/to/zig --build-dir /tmp/monitor-isolated
python3 tests/monitor/run_live_checks.py --cc /path/to/zig --out /tmp/monitor-inspection
python3 tests/monitor/run_host_memory_checks.py --cc /path/to/zig --out /tmp/monitor-memory --original-command /path/to/package/reference/cmd_memory.c.txt --command commands/cmd_memory.c

这些脚本只在指定的输出目录生成平台替代头文件，不将其复制到 core/include。
模型验证不能代替真实板卡的调度、Guest 访存、实际 exit、日志落盘及资源测量。
