/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __WBOXTEST_IRQ_H__
#define __WBOXTEST_IRQ_H__

#include <libs/stringlib.h>
#include <libs/wboxtest.h>
#include <vmm_delay.h>
#include <vmm_error.h>
#include <vmm_host_irq.h>
#include <vmm_modules.h>
#include <vmm_scheduler.h>
#include <vmm_semaphore.h>
#include <vmm_smp.h>
#include <vmm_stdio.h>
#include <vmm_threads.h>
#include <vmm_timer.h>
#include <vmm_types.h>

/* Runtime candidates, not proof that the board has reserved these IRQs. */
#define TEST_IRQ_SPI_COUNT 6U
extern u32 test_irq_spi_ids[TEST_IRQ_SPI_COUNT];

/* Call at the start of every serial .run(), before any SPI access. */
int test_irq_select_spis(struct vmm_chardev *cdev);

#define SPI_ID1 (test_irq_spi_ids[0])
#define SPI_ID2 (test_irq_spi_ids[1])
#define SPI_ID3 (test_irq_spi_ids[2])
#define SPI_ID4 (test_irq_spi_ids[3])
#define SPI_ID5 (test_irq_spi_ids[4])
#define SPI_ID6 (test_irq_spi_ids[5])

/* SGIs retain the existing configuration; they are not auto-selected. */
#define SGI_ID1 5U
#define SGI_ID2 6U

#endif
