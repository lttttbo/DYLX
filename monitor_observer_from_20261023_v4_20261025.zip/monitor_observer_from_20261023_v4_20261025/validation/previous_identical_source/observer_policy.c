
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do { if(!(x)){fprintf(stderr,"CHECK failed %s:%u: %s\n",__FILE__,__LINE__,#x);exit(1);} } while(0)
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int32_t s32; typedef int64_t s64; typedef u64 physical_addr_t,physical_size_t; typedef uintptr_t virtual_addr_t;
#define TRUE true
#define VMM_OK 0
#define VMM_EINVALID -5
#define VMM_EIO -16
#define VMM_EACCESS -12
#define VMM_PAGE_SIZE 4096
#define VMM_MEMORY_FLAGS_NORMAL 0
#define SBUF_HEAD_SIZE 64
#define SBUF_MAGIC 0x5aa57aa71aa13aa3ULL
#define U32_MAX UINT32_MAX
#define OVERWRITE_EN 2
#define OVERRUN_CNT_EN 1
#define VMM_MONITOR_SHMEM_BOUNDS 1
#define VMM_MONITOR_CCM_READ_FAILED 5
#define VMM_MONITOR_CCM_REGISTER_FAILED 6
#define VMM_MONITOR_CCM_ELEMENT_REJECTED 7
#define arch_smp_mb() ((void)0)
struct vmm_guest { u32 id; };
struct vmm_vcpu { struct vmm_guest *guest; };
static u32 events,kind,actor_id; static u64 address,detail; static bool recording;
#ifndef MONITOR_OFF
static void vmm_monitor_mem_fault(struct vmm_vcpu *v,u32 k,u64 a,u64 d) {
    if(recording){events++;kind=k;address=a;detail=d;actor_id=v?v->guest->id:U32_MAX;}
}
#else
#define vmm_monitor_mem_fault(...) ((void)0)
#endif
static struct { u64 a[32]; unsigned n; } trace;
static void call(u64 a) { CHECK(trace.n<32); trace.a[trace.n++]=a; }
static unsigned mode;
struct shared_buf {
        u64 magic;
        u32 ele_num;            /* number of elements */
        u32 ele_size;           /* sizeof of elements */
        u32 head;               /* offset from base, to read */
        u32 tail;               /* offset from base, to write */
        u32 flags;
        u32 reserved;
        u32 overrun_cnt;        /* count of overrun */
        u32 size;               /* ele_num * ele_size */
        u32 padding[6];
};
struct sbuf_param {
    /** sbuf cpu id */
    u16 cpu_id;
    /** Reserved */
    u16 reserved;
    /** sbuf id */
    u32 sbuf_id;
    /** sbuf's guest physical address */
    u64 gpa;
} ;
static struct sbuf_param request;
static u32 vmm_guest_memory_read(struct vmm_guest *g,u64 a,void *out,u32 n,bool cache) {
    (void)cache;call(1);call(g->id);call(a);call(n);
    if(mode==1) return 8;
    CHECK(n==sizeof(request));memcpy(out,&request,n);return n;
}
static int vmm_guest_physical_map(struct vmm_guest *g,u64 a,u64 n,u64 *h,u64 *sz,u32 *flags) {
    call(2);call(g->id);call(a);call(n);*h=(mode==2||mode==7)?0:0x3000;
    *sz=mode==9?16:4096;*flags=mode==8?8:1;
    return mode==2||mode==3?-16:0;
}
static uintptr_t vmm_host_memmap(u64 a,u64 n,u32 flags) {
    call(3);call(a);call(n);call(flags);return mode==6?0:0x9000;
}
static int sbuf_setup_common(struct vmm_guest *g,u16 cpu,u32 id,u64 *va,u64 hpa) {
    call(4);call(g->id);call(cpu);call(id);call((uintptr_t)va);call(hpa);
    return mode==4||mode==6?-5:mode==5?-1:0;
}
s32 hcall_original(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_sbuf_param) {
        struct sbuf_param sp;
    physical_addr_t hpa;
        virtual_addr_t hva;
        physical_size_t hpa_size;
        u32 reg_flags = 0x0;
        u32 res;
        int ret = -1;
        if (!vcpu || !target_vm) {
                return VMM_EINVALID;
        }
        res = vmm_guest_memory_read(vcpu->guest, gpa_sbuf_param, &sp, sizeof(sp), TRUE);
        if (res != sizeof(sp)){
                return VMM_EIO;
        }
        // GPA convert to HPA
        ret = vmm_guest_physical_map(vcpu->guest, sp.gpa, sizeof(sp), &hpa, &hpa_size, &reg_flags);
        if (hpa) {
                hva = vmm_host_memmap(hpa, VMM_PAGE_SIZE, VMM_MEMORY_FLAGS_NORMAL);
                ret = sbuf_setup_common(target_vm, sp.cpu_id, sp.sbuf_id, (u64*)hva, hpa);
        } else {
                ret = VMM_EINVALID;
        }
    return ret;
}
s32 hcall_observed(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_sbuf_param) {
        struct sbuf_param sp;
    physical_addr_t hpa;
        virtual_addr_t hva;
        physical_size_t hpa_size;
        u32 reg_flags = 0x0;
        u32 res;
        int ret = -1;
        if (!vcpu || !target_vm) {
                return VMM_EINVALID;
        }
        res = vmm_guest_memory_read(vcpu->guest, gpa_sbuf_param, &sp, sizeof(sp), TRUE);
        if (res != sizeof(sp)){
                vmm_monitor_mem_fault(vcpu, VMM_MONITOR_CCM_READ_FAILED,
                                      gpa_sbuf_param, sizeof(sp));
                return VMM_EIO;
        }
        // GPA convert to HPA
        ret = vmm_guest_physical_map(vcpu->guest, sp.gpa, sizeof(sp), &hpa, &hpa_size, &reg_flags);
        if (hpa) {
                hva = vmm_host_memmap(hpa, VMM_PAGE_SIZE, VMM_MEMORY_FLAGS_NORMAL);
                ret = sbuf_setup_common(target_vm, sp.cpu_id, sp.sbuf_id, (u64*)hva, hpa);
        } else {
                ret = VMM_EINVALID;
        }
    if (ret != VMM_OK)
        vmm_monitor_mem_fault(vcpu, VMM_MONITOR_CCM_REGISTER_FAILED,
                              sp.gpa, (u64)(s64)ret);
    return ret;
}
u32 sbuf_next_ptr(u32 pos_arg, u32 span, u32 scope) {
        u32 pos = pos_arg;
        pos += span;
        pos = (pos >= scope) ? (pos - scope) : pos;
        return pos;
}
u32 put_original(struct shared_buf *sbuf, u8 *data, u32 max_len) {
        void *to;
        u32 next_tail;
        u32 ele_size, ret;
        bool trigger_overwrite = false;
        ele_size = sbuf->ele_size;
        next_tail = sbuf_next_ptr(sbuf->tail, ele_size, sbuf->size);
        if ((next_tail == sbuf->head) && ((sbuf->flags & OVERWRITE_EN) == 0U)) {
                /* 如果覆盖未启用，直接返回0 */
                ret = 0U;
        }
        else if (ele_size <= max_len) {
                if (next_tail == sbuf->head) {
                        /* 如果有必要，累积覆盖计数 */
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        trigger_overwrite = true;
                }
                to = (void *)sbuf + SBUF_HEAD_SIZE + sbuf->tail;
                memmove(to, data, (size_t)ele_size);
                /* 确保在更新头部之前写入数据 */
                arch_smp_mb();
                if (trigger_overwrite) {
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        sbuf->head = sbuf_next_ptr(sbuf->head, ele_size, sbuf->size);
                }
                sbuf->tail = next_tail;
                ret = ele_size;
        } else {
                ret = U32_MAX;
        }
        return ret;
}
u32 put_observed(struct shared_buf *sbuf, u8 *data, u32 max_len) {
        void *to;
        u32 next_tail;
        u32 ele_size, ret;
        bool trigger_overwrite = false;
        ele_size = sbuf->ele_size;
        next_tail = sbuf_next_ptr(sbuf->tail, ele_size, sbuf->size);
        if ((next_tail == sbuf->head) && ((sbuf->flags & OVERWRITE_EN) == 0U)) {
                /* 如果覆盖未启用，直接返回0 */
                ret = 0U;
        }
        else if (ele_size <= max_len) {
                if (next_tail == sbuf->head) {
                        /* 如果有必要，累积覆盖计数 */
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        trigger_overwrite = true;
                }
                to = (void *)sbuf + SBUF_HEAD_SIZE + sbuf->tail;
                memmove(to, data, (size_t)ele_size);
                /* 确保在更新头部之前写入数据 */
                arch_smp_mb();
                if (trigger_overwrite) {
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        sbuf->head = sbuf_next_ptr(sbuf->head, ele_size, sbuf->size);
                }
                sbuf->tail = next_tail;
                ret = ele_size;
        } else {
                vmm_monitor_mem_fault(NULL, VMM_MONITOR_CCM_ELEMENT_REJECTED,
                                      0, ((u64)ele_size << 32) | max_len);
                ret = U32_MAX;
        }
        return ret;
}

struct vmm_shmem { u64 size,addr; };
static u32 vmm_host_memory_read(u64 a,void *buf,u32 n,bool c) { (void)buf;call(10);call(a);call(n);call(c);return n; }
static u32 vmm_host_memory_write(u64 a,void *buf,u32 n,bool c) { (void)buf;call(11);call(a);call(n);call(c);return n; }
static u32 vmm_host_memory_set(u64 a,u8 byte,u32 n,bool c) { call(12);call(a);call(n);call(c);call(byte);return n; }
u32 vmm_shmem_read_original(struct vmm_shmem *shm, physical_addr_t off,
		   void *dst, u32 len, bool cacheable)
{
	if (!shm || !dst)
		return 0;
	if (shm->size < (off + len))
		return 0;

	return vmm_host_memory_read(shm->addr + off, dst, len, cacheable);
}
u32 vmm_shmem_read_observed(struct vmm_shmem *shm, physical_addr_t off,
		   void *dst, u32 len, bool cacheable)
{
	if (!shm || !dst)
		return 0;
	if (shm->size < (off + len)) {
		vmm_monitor_mem_fault(NULL, VMM_MONITOR_SHMEM_BOUNDS, off, len);
		return 0;
	}

	return vmm_host_memory_read(shm->addr + off, dst, len, cacheable);
}
u32 vmm_shmem_write_original(struct vmm_shmem *shm, physical_addr_t off,
		    void *src, u32 len, bool cacheable)
{
	if (!shm || !src)
		return 0;
	if (shm->size < (off + len))
		return 0;

	return vmm_host_memory_write(shm->addr + off, src, len, cacheable);
}
u32 vmm_shmem_write_observed(struct vmm_shmem *shm, physical_addr_t off,
		    void *src, u32 len, bool cacheable)
{
	if (!shm || !src)
		return 0;
	if (shm->size < (off + len)) {
		vmm_monitor_mem_fault(NULL, VMM_MONITOR_SHMEM_BOUNDS, off, len);
		return 0;
	}

	return vmm_host_memory_write(shm->addr + off, src, len, cacheable);
}
u32 vmm_shmem_set_original(struct vmm_shmem *shm, physical_addr_t off,
		  u8 byte, u32 len, bool cacheable)
{
	if (!shm)
		return 0;
	if (shm->size < (off + len))
		return 0;

	return vmm_host_memory_set(shm->addr + off, byte, len, cacheable);
}
u32 vmm_shmem_set_observed(struct vmm_shmem *shm, physical_addr_t off,
		  u8 byte, u32 len, bool cacheable)
{
	if (!shm)
		return 0;
	if (shm->size < (off + len)) {
		vmm_monitor_mem_fault(NULL, VMM_MONITOR_SHMEM_BOUNDS, off, len);
		return 0;
	}

	return vmm_host_memory_set(shm->addr + off, byte, len, cacheable);
}

static unsigned cases;
static bool expect_record(void) {
#ifdef MONITOR_OFF
    return false;
#else
    return recording;
#endif
}
static void hcall_tests(void) {
    struct vmm_guest guests[2]={{0},{1}},target={2};
    for(unsigned id=0;id<2;id++) for(mode=0;mode<12;mode++) {
        struct vmm_vcpu v={&guests[id]};
        request=(struct sbuf_param){.cpu_id=0,.sbuf_id=64,.gpa=0x2000};
        if(mode==10){request.gpa++;request.reserved=7;}
        memset(&trace,0,sizeof(trace)); events=0;
        int a=hcall_original(&v,&target,0x1000); typeof(trace) before=trace;
        memset(&trace,0,sizeof(trace));events=0;
        int b=hcall_observed(&v,&target,0x1000);
        CHECK(a==b && !memcmp(&trace,&before,sizeof(trace)));
        CHECK(events==(expect_record() && b!=0));
        if(events){CHECK(actor_id==id);CHECK(kind==(mode==1?5:6));CHECK(address==(mode==1?0x1000:request.gpa));
            CHECK(detail==(mode==1?sizeof(request):(u64)(s64)b));}
        cases++;
    }
    events=0;trace.n=0;
    CHECK(hcall_original(NULL,&target,0)==hcall_observed(NULL,&target,0));
    CHECK(!events && !trace.n); cases++;
    struct vmm_vcpu v={&guests[0]};
    CHECK(hcall_original(&v,NULL,0)==hcall_observed(&v,NULL,0));
    CHECK(!events && !trace.n); cases++;
}
static void put_tests(void) {
    struct fixture { struct shared_buf h; u8 data[128]; } a,b;
    u8 payload[32];memset(payload,0x36,sizeof(payload));
    for(unsigned n=0;n<8;n++) {
        memset(&a,0,sizeof(a));memset(a.data,0xa5,sizeof(a.data));
        a.h.magic=SBUF_MAGIC;a.h.ele_num=2;a.h.ele_size=8;a.h.size=16;
        if(n==1 || n==2)a.h.tail=8;
        if(n==2)a.h.flags=OVERWRITE_EN|OVERRUN_CNT_EN;
        if(n==3){a.h.ele_size=16;a.h.size=32;}
        if(n==4)a.h.tail=24; /* Legacy behavior inside test-owned fixture. */
        if(n==5)a.h.head=24;
        if(n==6)a.h.size=64;
        if(n==7)a.h.ele_num=1;
        b=a;u32 x=put_original(&a.h,payload,8);events=0;
        u32 y=put_observed(&b.h,payload,8);
        CHECK(x==y && !memcmp(&a,&b,sizeof(a)));
        CHECK(events==(expect_record() && n==3));
        if(events){CHECK(kind==7 && actor_id==U32_MAX && !address && detail==((16ULL<<32)|8));}
        if(n==2)CHECK(b.h.overrun_cnt==2); /* No unrelated counter fix. */
        cases++;
    }
}
static void shmem_tests(void) {
    u64 offsets[]={0,28,31,32,33,UINT64_MAX-1}; u32 lengths[]={0,1,2,4};u8 data[32];
    struct vmm_shmem shm={32,0x100000};
    for(unsigned op=0;op<3;op++)for(unsigned i=0;i<6;i++)for(unsigned j=0;j<4;j++) {
        u64 off=offsets[i];u32 len=lengths[j],x,y;memset(&trace,0,sizeof(trace));events=0;
        if(op==0)x=vmm_shmem_read_original(&shm,off,data,len,false);
        else if(op==1)x=vmm_shmem_write_original(&shm,off,data,len,false);
        else x=vmm_shmem_set_original(&shm,off,0x5a,len,false);
        typeof(trace) before=trace;memset(&trace,0,sizeof(trace));events=0;
        if(op==0)y=vmm_shmem_read_observed(&shm,off,data,len,false);
        else if(op==1)y=vmm_shmem_write_observed(&shm,off,data,len,false);
        else y=vmm_shmem_set_observed(&shm,off,0x5a,len,false);
        CHECK(x==y && !memcmp(&trace,&before,sizeof(trace)));
        CHECK(events==(expect_record() && shm.size<off+len));
        if(events)CHECK(kind==1 && address==off && detail==len);
        cases++;
    }
}
int main(void) {
    for(unsigned active=0;active<2;active++){recording=active;hcall_tests();put_tests();shmem_tests();}
    printf("PASS %u differential cases; return values, backend calls, data and existing policy unchanged\n",cases);
    return 0;
}
