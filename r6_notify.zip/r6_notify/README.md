# R6 跨CPU通知成本分解：接入与测试

版本v1.0，2026-10-08。基于当前R5代码保留旧探针、关闭旧采集。**先检查、再应用、目标板编译验证后测试。**

## 1. 本轮回答什么

将两类实际对象分别配对，不拼接不相关时间戳：

- 同一个任务唤醒周期：发起→TTWU队列发布→接收端摘队列→激活→sched_switch→首次实际handler入口。
- 同一vhost TX work排队代次：发布→执行→TX入口→获取mutex→处理结束→work返回。

同时记录真实TTWU数量、generic call-function handler进入数、wake_up_process原返回值、split avail链头推进，以及eth0/tap1端点计数。**不生成全量trace，不逐包printk。**

本轮可以验证“哪些跨核通知阶段变长，是否伴随TX推进变慢”。不能预先承诺所有调度损耗均由IPI引起，也不能把每次通知的延迟直接乘成全部吞吐损失。

必须纠正前述文字方案中的几个口径：

1. 源端发布函数可能晚于接收端完成才返回。时间起点放在原llist_add之前，源端返回耗时独立统计，不与接收延迟相加。
2. sched_switch在实际上下文切换前发生，不是目标第一条指令。另加CCM/TX实际service标记。
3. 1/PPS是输出平均间距，不是一次请求的延迟；任务、work、通知、包不是一一对应。并发、批次和重叠等待必须分别考虑。
4. C/D移走vhost时会同时改变其与eth0 IRQ的相对位置，因此先只做A/B，不预设四组效果可线性相加。

完整CCM请求发布/完成和HOS等待/恢复源码尚未提供，本包不会虚构Guest请求端到端标识。**同周期时间分解闭合是测量记账校验，不单独等于吞吐根因证明。**

## 2. 源码范围与依赖

已经按上传net.c.txt、vhost.c.txt及原R5补丁构造基线，验证两个vhost文件的插入位置。完整本地smp.c和CCM工程未提供：安装器依据现有四个ipio hook及已贴出的CCM handler，在你的真实源码上做单一定义/唯一锚点检查；形态不匹配就拒绝。

文件：

```text
apply_r6.py                 检查、生成实际diff、备份、应用、回退
src/r6_notify.c             内置kernel的统计实现
src/r6_notify.h             include/linux公共声明
src/r6_math.h               kernel内部分布/配对运算
capture_r6.sh               ServerVM采集脚本
analyze_r6.py               PC汇总、校验、A/B比较
INSERTION_POINTS.md        每个函数的确切插入位置
VALIDATION.md              已执行/未执行的验证
```

需要CONFIG_SMP=y、CONFIG_TRACEPOINTS=y、CONFIG_PROC_FS=y和现有网络支持。不需要新增kprobe/BPF/function_graph。调度tracepoint由R6直接注册内核回调，不向ftrace文件写逐条事件。

安装器从本地include/trace/events/sched.h检查sched_switch回调签名，生成kernel/r6_build_config.h，不按版本字符串猜ABI。

## 3. 应用

在编译主机解压本包后执行；替换路径：

```sh
KERNEL=/实际/ServerVM/Linux源码
CCM_IOEVENTFD=/实际/CCM/ioeventfd.c

python3 apply_r6.py --kernel "$KERNEL" --ccm "$CCM_IOEVENTFD" \
    --check --out ./r6_check
# 查看r6_check/r6_changes.patch；check不会改源码。

python3 apply_r6.py --kernel "$KERNEL" --ccm "$CCM_IOEVENTFD" \
    --apply --out ./r6_applied
```

CCM可以在内核树外，但必须是实际编入ccm_proxy的实现，不是未使用的ACRN文件。当前必须保留R5的vhost_work_queue_tagged和N5 TX hook，handle_tx_net已为n4_handle_tx(net,2)。

应用器保存原文件到 `$KERNEL/.r6_notify_backup/`，生成实际差异和SHA256清单。若提示REFUSED，先看具体函数；不要强行模糊覆盖。合并diff中CCM_EXTERNAL是展示路径，使用安装器应用，不直接对合并diff执行git apply。

**修改位置详见INSERTION_POINTS.md。安装后不要再照说明手工重复添加。** 原业务调用、queued位清除、锁顺序及返回值均保留；原eventfd_signal/wake_up_process不多调用一次。

## 4. 构建与部署

| 组件 | 本轮要求 |
|---|---|
| ServerVM kernel | 必须包含kernel/r6_notify.c和smp hook |
| vhost核心 | 内置随kernel；模块则更新对应新模块 |
| vhost-net | 同上，与vhost核心及新kernel配套 |
| ccm_proxy | 包含新增r6_io_service调用，模块则更新新模块 |
| DSM | 不修改，保持现有版本及配置 |
| Android | 不修改内核或iperf二进制 |

使用现有交叉构建流程。**只烧kernel不会替换rootfs里的旧.ko；CCM/vhost模块必须与新kernel/Module.symvers匹配。** 不在Guest运行中强制卸载这些模块。

启动后：

```sh
ls -l /proc/r6_notify
cat /proc/r6_notify
```

run=0、TX bound=0初始正常。接口是/proc/r6_notify，不是/sys/module/.../parameters。正在采集时读取报告会返回EBUSY；停止后使用seq_file输出，不受module_param单页报告的旧问题影响。

## 5. 旧打点保留，旧采集全部关闭

```sh
[ ! -e /proc/ipi_origin ] || echo stop > /proc/ipi_origin
[ ! -e /proc/vhost_n5 ] || echo stop > /proc/vhost_n5
for p in /sys/module/ccm_proxy/parameters/ioem_run \
         /sys/module/ccm_proxy/parameters/n4_run \
         /sys/module/vhost_net/parameters/n4_run; do
    [ ! -e "$p" ] || echo 0 > "$p"
done
```

不要同时运行collect_notify_chain、capture_n4、capture_vhost_n5、capture_sched_wait、eth0周期脚本或其他全量trace。初始化VQMAP、IOEM_CFG日志可以保留。R6关闭后仍有快速退出分支，所以同镜像关闭探针的基线不等于完全移除调试代码的生产镜像。

## 6. 时间字段及闭合关系

### 6.1 同一个任务唤醒周期

| W/Q/D/A/R/H | 位置 |
|---|---|
| W | sched_waking |
| Q | 原__smp_call_single_queue发布之前 |
| D | 接收批次摘下、reverse之后，callback之前 |
| A | sched_wakeup，任务激活事件 |
| R | sched_switch即将切入目标，尚非切换完成 |
| H | 本次唤醒后的第一次选中CCM/TX handler入口 |

对同一组完整样本验证：

```text
(A-W)+(R-A)=R-W
(Q-W)+(D-Q)+(A-D)=A-W       仅实际排入TTWU队列的周期
```

Q-D包含发布、等待接收与摘队列前处理，不是纯硬件IPI传播时间。D-A可能包含同批前序工作和激活处理。记录rx_ipi与rx_other，不将非IPI清空当作新IPI。没有经过此队列的远端激活也单独分类，不叫“本地无IPI”。

H不是全部请求的入口配对：一次唤醒可处理多条请求，已运行worker也可能无需新唤醒。H相关样本可能少于W→R样本，不能把不同cohort的均值直接相加。R→H还可能包含后续再次被调度出去的时间，post_switch_out用于提示。

### 6.2 同一work排队代次

Qw=发布前，X=原clear queued位之前，H=TX入口，L=原mutex获取后，F=TX退出前，E=work回调返回后。

```text
(X-Qw)+(H-X)+(L-H)+(F-L)+(E-F)=E-Qw
```

pending和executing代次分离，回调期间重新排队不会覆盖旧样本。合并提交不被伪造为新代次。按原N5 source分别统计，其中2=poll_event、6/7=copy收尾重排；这些都不是IPI次数。

**任务表与work表相互重叠，不能把两表的时间总和相加。** 源端返回时间标为NOT_ADDITIVE，也不参与上述求和。

默认按hash选中约1/256的周期/代次计时，其余仍累计相关事件数量。输出均值、累计时间、直方图；P50/P95/P99给分箱范围，不给假的精确分位数。时钟统一ktime_get_ns；负序、丢失点和迁移单列，不强行清零。

## 7. A/B具体测试

所有CPU号均为ServerVM逻辑CPU，不改变HOS的pCPU/vCPU绑定。

| 组别 | ioeventfd | vhost | eth0 IRQ有效CPU |
|---|---:|---:|---:|
| A | 1 | 0 | 0 |
| B | 0 | 0 | 0 |

不强绑通用kworker；从SOURCE检查主来源是否确实稳定CPU0。不是CPU0时不能强行解释为CPU0→CPU1→CPU0。

### 7.1 查本次身份并设置A

在同一个ServerVM root终端执行。188/1009只是例子，替换为本次有效TID：

```sh
ps -eLo pid,tid,psr,comm | grep -E 'ioeventfd|vhost-'
IO_TID=188
VH_TID=1009
cat /proc/$IO_TID/comm
cat /proc/$VH_TID/comm

IRQS=$(awk '$NF=="eth0" {gsub(":","",$1);print $1}' /proc/interrupts)
# 确认IRQS非空且每条确实是eth0；不要固定沿用IRQ131。
for IRQ in $IRQS; do
    echo 0 > /proc/irq/$IRQ/smp_affinity_list
    cat /proc/irq/$IRQ/effective_affinity_list
done

taskset -pc 1 "$IO_TID"
taskset -pc 0 "$VH_TID"
```

采集期间不重启DSM/Guest，不做STR、CPU热插拔、模块卸载或自动亲和性调整。EVENT_IDX/busyloop/asyncio不修改。

### 7.2 保留原Android上行命令

PC服务端维持原配置。Android每次都执行：

```sh
./iperf3 -p 5201 -c 192.168.1.1 \
    -b 1000M -t 60 -l 1400 -i 10 -u
```

不加-R。原有-A/--cport策略存在时各组保留一致，不换二进制。

### 7.3 A组先baseline，再timing

第一次Android测试出现第一个10秒输出后，ServerVM执行：

```sh
MODE=baseline sh capture_r6.sh "$IO_TID" "$VH_TID" A_base 3
```

baseline只做两个网络端点快照，不注册调度回调，不启用R6热路径计数。它用来检查观察扰动，不是一次新的性能优化配置。

等本次iperf及脚本报告结束，**重新启动同样的Android命令**，稳定后：

```sh
MODE=timing SAMPLE_SHIFT=8 \
sh capture_r6.sh "$IO_TID" "$VH_TID" A_time 3
```

采集约3秒，停止后默认再等60秒才导出。期间长时间没有输出是预期行为。脚本不自动等待流量，所以必须先启动Android压测。

### 7.4 B组只移动ioeventfd

```sh
taskset -pc 0 "$IO_TID"
```

vhost和eth0维持CPU0。两次独立的同参数Android测试分别采：

```sh
MODE=baseline sh capture_r6.sh "$IO_TID" "$VH_TID" B_base 3
# 等上一遍测试结束，重新运行Android命令；稳定后：
MODE=timing SAMPLE_SHIFT=8 \
sh capture_r6.sh "$IO_TID" "$VH_TID" B_time 3
```

A/B只是目录标签，脚本不会替你绑核。建议核对前后context，避免误标。

可选COLLECT_CPU=5仅给采集shell及子进程设亲和性，不改变网络任务；两组使用相同设置。

timing相比同布局baseline若有明显额外PPS下降，应复核采样扰动。约3%～5%可作为工程警戒线，但不是统计置信阈值。先增加SAMPLE_SHIFT，再用MODE=counts（不计时，只计数）检查是否计数/锁本身的干扰。**不能在明显扰动的结果上硬做时间归因。**

先完成上述四次，再视重复性需要回切A或A-B-B-A复测，不先扩展CPU组合。

## 8. 分析与最小反馈

将目录拷到自己的PC，逐个运行：

```sh
python3 analyze_r6.py /实际/A_base目录
python3 analyze_r6.py /实际/A_time目录
python3 analyze_r6.py /实际/B_base目录
python3 analyze_r6.py /实际/B_time目录
python3 analyze_r6.py --compare /实际/A_time目录 /实际/B_time目录 \
    --out r6_comparison.json
```

先提供四个r6_compact.txt、r6_comparison.json、A_time/B_time的context_before/after，以及四次iperf最后sender/receiver/丢包行。详细r6_summary.json和原始r6_report.txt本地保留，异常时再定向提供。**没有几万行trace要上传。**

必须检查：

| 字段 | 要求 |
|---|---|
| TX bound、completed | timing/counts为1/非零；baseline为0正常 |
| identity_error、bad_heads、config_changes | 应为0 |
| task invalid/duplicate/incomplete_rx | 出现必须解释，不直接做归因 |
| work overwritten/invalid/missing_tx | 应为0；否则关联无效 |
| SOURCE | 核对实际源CPU/TID及任务或中断上下文 |
| valid_samples | 样本少不作尾时延结论 |
| wake0/wake1 | 原唤醒返回值，不能换算成IPI数 |
| NET边界偏差 | 大于1%会提示，不能声称严格同窗逐包比例 |
| partition残差 | 同一cohort应为0，这是记账校验而非因果证明 |

开始时已有work、停止时在途样本可能造成少量prewindow/pending/发布返回计数差，单列而不当作丢包。网络读取也不是与所有CPU原子同步，起止跨度被保留，不假装零误差。

## 9. 如何判断本轮是否支持假设

若A实际TTWU/queued_ipi更多，对应交接阶段更长，B消除这段远程交接后TX work更早推进且PPS上升，支持该路径的额外成本。若激活时间下降但runnable等待增加，要保留这项代价；不是所有调度等待都应归给IPI。

若PPS改善却每次work延迟不降，应检查并行度/供给节奏，不能用1/PPS强行凑等式。要给出“解释了全部吞吐差额的X%”，还需证明该区间是瓶颈或Guest必须等待的串行依赖；现有CCM/HOS完成代码缺口不能靠统计假设填补。

这版不会改变通知机制。得到可信结果后才选择亲和性工程化、减少一次client交接、或其他单一可回退优化。

## 10. 停止与回退

```sh
echo stop > /proc/r6_notify
```

Ctrl+C通常会自动stop。被kill -9后手动stop；确认没有采集进程后再删除残留的空/tmp/r6_notify_capture.lock目录。

源码回退：

```sh
python3 apply_r6.py --kernel "$KERNEL" --restore
```

若源码在安装后又改过，SHA256不匹配会拒绝覆盖，需手动合并。回退同样需要重新构建配套kernel及模块，不能只退kernel而保留引用新R6符号的模块。

## 11. 验证边界

详见VALIDATION.md。已进行宿主对象编译、数学配对测试、安装器检查/回退和原队列操作次数比较，**没有宣称已在你的完整ARM64 5.15.158-rt76内核编译链接或运行成功。**
