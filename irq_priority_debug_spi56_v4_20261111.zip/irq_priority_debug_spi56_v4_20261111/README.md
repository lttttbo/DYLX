# HOS IRQ 诊断 v4：扩展 SPI5/SPI6（2026-11-11）

本包基于 irq_priority_debug_v4_20261110，只更新已有的
`libs/wboxtest/interrupt/test_irq_priority_debug.c`。不新增文件到 HOS，
不增加 Kconfig 或对象编译项，不修改 GIC、Guest 或 monitor。

## 本次日志的结论

141/142 已观察到正常的单次优先级送达：

- 初始 actions=0、routed=0，硬件 masked，软件 mask 与硬件一致。
- 两次 register 返回 0，注册后硬件解除 mask，说明本次路径确实有注册自动 unmask 行为。
- 两路逻辑优先级读回 0、1；levels=16、pmr_level=15。
- 两个回调均在 CPU0、trigger 阶段执行，141 在前、142 在后。
- calls=fired=1、各核增量仅 CPU0=1，outside_trigger_wait=0、dropped=0。
- 两路 unregister 成功，cleanup_rc=0，优先级恢复 10，mask 恢复开启。
- 后续原 irq_priority 的 TEST1 也通过。由此支持此前 107/108 的资源占用冲突
  是原第一用例失败的关键因素；不能据此证明所有中断测试和所有内核变化均无问题。

trigger 帧中 141 的 hw=0x5 不能单独当作故障：采集不是原子快照。
该帧 time_ns=44477528780，而回调分别为 44477529540、44477530160，
说明回调可以发生在这一帧读取各字段的过程中。pending、active、masked 又可能来自不同寄存器读取。
因此同一帧可出现读取早期的 pending 与回调后的 masked/calls。finish 中两路均为 0x4，
且各收到一次，没有持续 pending/active 的证据。确切寄存器读取顺序仍以 HOS 实现为准。

## TEST4 的失败和误报 PASS

原 TEST4 使用 SPI_ID5/SPI_ID6，不是 SPI_ID1/SPI_ID2。
如果仍沿用最初配置，它们为 89/90；本次输出没有显示实际号码，不能直接认定当前仍是 89/90。

按此前提供的源码，test_irq_high_freq() 超时会返回 VMM_EFAIL，
test_irq_priority_case4() 却忽略返回值，继续循环直到 60 秒，然后返回 0。
所以一串 timeout 后仍显示 PASS，是失败结果没有向上传递；不是超时可以忽略。
这种执行也没有实现预期的每 100us 一次触发，因为每轮很可能消耗了约 1 秒的超时等待。

即便把 case4 的错误返回传递上去，也需要统一处理每条退出路径的 action 注销和状态恢复，
不能只增加一个 return 就当作完整修复。当前包聚焦补齐定位证据，未覆盖或声称修复原测试的误判。

原源码还存在：

1. case1 结束后 current_index 已为 2，case2/case3 未重置，仍向 exec_order[2] 之外写入。
   如果当前代码没有修过，这是确定的数组越界，可能影响后续用例状态。
2. 每轮高频函数都 register，未检查返回值；不能据此假设每轮都成功注册。
3. 延迟起点 test_start_time 只在整段 60 秒开始时设置，测得的是从整段开始的时间，
   不是每次 pending 写入至 ISR 入口的延迟。
4. 累加器/计数未按本轮测试重置；case4 又忽略包括延迟比较失败在内的返回值。
5. 失败直接返回时没有统一清理，成功路径也没有完整恢复原始 IRQ 配置。

本次 heap leakage=21312 是测试前后统计的差值，值得排查，但不能只凭这个数认定
就是这 60 次调用分配并泄漏了 21312 字节。需要结合注册返回值、action 数和框架全局内存变化。
某些 register 实现会拒绝重复 dev 而不再分配；运行中的其他模块也可能影响全局堆差值。

## 手动合入

已经合入 2026-11-10 诊断版时：

- 用 full_files 中的完整 C 文件替换此前新增的同名诊断文件；或应用 changes.patch。
- changes.patch 的基线是 irq_priority_debug_v4_20261110，不是原生产测试代码。
- objects.mk 不用再加一条，因为仍是同一个对象文件。
- 继续使用现有 test_irq.h，其中应已有 SPI_ID5/SPI_ID6 定义。

新增/修改函数：

| 函数 | 修改 |
|---|---|
| ipd_prepare | 接收 high_irq/low_irq，保存并检查调用者选定的一对 IRQ |
| ipd_run_pair | 从原 ipd_run 提取公共流程，新增实际 IRQ 对的输出；共享静态记录、运行互斥和失败保护 |
| ipd_run | 保持原测试入口，使用 SPI_ID1/SPI_ID2 |
| ipd_run_spi56 | 新入口，使用 SPI_ID5/SPI_ID6 |
| ipd_init | 注册两个测试，第二个注册失败时注销第一个 |
| ipd_exit | 注销两个测试 |

ipd_test_spi56 是新增的 wboxtest 描述符。未增加第二套帧/回调缓冲，
两个用例共用互斥锁；清理不完整时禁止继续复用缓冲的保护仍然生效。

## 先运行哪项

先确认 SPI_ID5/SPI_ID6 对应的实际硬件资源专门留给测试。
IRQ stats 没有列出某号码、计数为零，都不能代替设备树/板级资源归属确认。
本例发现已有 action、Guest routed、初始 pending/active 等情况会拒绝运行，
不会删除未知 owner 的处理函数。

重新启动后，只运行下面这一个用例，不先运行原 priority 或整个 interrupt group：

```text
hos irq stats
unittest run_tests 1 irq_priority_debug_spi56
hos irq stats
```

输出开头新增：

```text
IRQDBG pair high_irq=实际SPI5 low_irq=实际SPI6; single trigger
```

该用例是对 TEST4 使用的 IRQ 对做一次受控触发，并不是新的 60 秒高频性能测试。
它沿用已通过的单次诊断流程，检查注册/优先级设置/读回/unmask/触发，
等待最多 1 秒，然后记录现场并清理。这可以避开旧 case2/case3 的越界和旧 case4 的重复注册循环。

如果本例单次也超时，就按现场区分资源、寄存器状态、CPU 送达、回调路径；
如果本例通过，则继续检查原高频循环与旧用例间的状态污染，不能直接宣布高频测试已通过。
多次运行本例依然是多次“设置、单次触发、清理”，不等于高频连续中断验证。

## 保留哪些日志

请提供 begin 到 result 的完整 IRQDBG 输出，以及前后 hos irq stats。
原字段格式保持不变：

| 字段 | 重点 |
|---|---|
| initial actions / routed | 是否已有注册处理函数、是否路由到 Guest；actions 包含各 CPU 副本 |
| step / rc | 哪次 API 操作失败；0 是 API 成功，不等于中断已送达 |
| hw_rc / hw | hw_rc=0 才解析硬件位：pending=1、active=2、masked=4 |
| sw_mask | 读取 CPU 视角的软件状态，不代替硬件 enable 位 |
| prio_rc / prio | 逻辑优先级读回，设置后应为 high=0、low=1 |
| pmr_level | 当前实现读出的 PMR 逻辑门限；未读其他目标 CPU 的 PMR |
| calls / fired | 总回调数 / trigger、wait 阶段的回调数 |
| cpu_count_delta | 相对 before 的各核 Host IRQ 计数增量，包含可能的提前回调 |
| callback / stage / cpu | 回调发生在哪里、什么时候；回调内不打印，只记录 |
| outside_trigger_wait | 正式触发/等待之外的回调，非零时不能当作干净的优先级证据 |
| finish | 清理之前的现场；超时原因重点看这一帧 |
| cleanup_rc | 注销和恢复是否成功，不能被 result=0 掩盖 |

finish 时 pending 且 unmasked，可继续查路由、PMR、Group enable 等送达条件；
pending 且 masked，要结合早期回调及各步骤查何时被屏蔽；
计数增加而本例 calls=0，需核查分发流和 action；active 仅一帧出现不等于异常。
cleanup 的 mask 是恢复操作结果，不能用它倒推超时发生前状态。

## 验证情况

新版本已通过 ARM64 freestanding 的 12/16 核、-Os/-O2 四种对象编译，
使用 -Wall -Wextra -Werror 和既有参考头文件警告豁免。
HOS 私有优先级/触发接口使用根据已提供代码补入的验证声明；未执行 HOS 完整 GCC12 链接。

两种入口分别通过 16 种接口模拟场景，共 32 次，包括正常、超时、单路送达、提前回调、
顺序颠倒、跨 CPU、部分注册失败、优先级设置失败、错误读回、已占用、初始 pending、
查询不支持、IRQ 关闭、active 不退、注销失败和 mask 失败。
另验证模块注册回滚。模拟不等于 GIC 硬件验证。

本次用户日志验证的是前一版在 141/142 上的单板结果；本包新增 SPI5/SPI6 入口尚待单板验证。
12 核 -Os 参考对象静态可写空间 3552 字节，比前版增加 112 字节的测试描述符；
16 核为 3936 字节。最终以 HOS 链接结果为准。
