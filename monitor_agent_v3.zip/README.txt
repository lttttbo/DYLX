monitor_agent v3 手工合入包

先看 monitor_agent_v3_手工合入说明.md。
未合入监控：选择 完整合入.patch。
已合入 v2：选择 从v2升级.patch。
两份 patch 不能叠加使用；私有文件按函数及行号定位.txt 手工合入。
新增文件目录提供完整内容。请保留私有 auth/mterm、GICv3/LPI、packed state 的功能。

保留：vCPU调度/READY时间、内存拒绝事件、exit风暴、shell/JSON、编译与启停。
移除：Guest遥测/HVC、指令诊断、IRQ注入时延、P99及相应旧命令。
新JSON schema=3，ready/dispatch=[次数,平均ns,最大ns]。

容量：ARM64对象增量5067B；开机自动启用5075B；按5120B预算通过对象估算。
余量很小，最终产品链接仍必须复测。CPU<0.5%、目标板确定性和认证长稳未验证。
DM/CCM私有路径仍需按文档接入；不将API存在视为已完成产品覆盖。
