"""Run the actual libs/wboxtest/monitor cases with host platform stubs.
This is not a full firmware, IRQ, scheduler or Guest execution test.
"""
import argparse, json, os, re, subprocess
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--cc',required=True); p.add_argument('--build-dir',required=True)
a=p.parse_args(); root=Path(__file__).resolve().parents[2]; out=Path(a.build_dir).resolve()
out.mkdir(parents=True,exist_ok=True); os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
inc=out/'include'
for n in ['vmm_types.h','vmm_manager.h','vmm_stdio.h','vmm_modules.h','vmm_timer.h','vmm_smp.h',
          'vmm_scheduler.h','vmm_mutex.h','vmm_cmdmgr.h','arch_barrier.h','vmm_shmem.h',
          'vmm_guest_aspace.h','vmm_host_aspace.h','vmm_host_ram.h','vmm_heap.h',
          'libs/stringlib.h','libs/mathlib.h','libs/wboxtest.h']:
    f=inc/n; f.parent.mkdir(parents=True,exist_ok=True); f.write_text('#include "wboxtest_host.h"\n',encoding='utf-8')
(inc/'vmm_error.h').write_text('\n'.join(s for s in (root/'core/include/vmm_error.h').read_text(encoding='utf-8').splitlines()
    if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',s))+'\n',encoding='utf-8')
cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
flags=['-std=gnu11','-O2','-Wall','-Werror','-I'+str(inc),'-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
defs=['-DCONFIG_MONITOR_AGENT=1','-DCONFIG_CMD_MONITOR=1','-DCONFIG_WBOXTEST_MONITOR=1',
      '-DCONFIG_MAX_VCPU_COUNT=64','-DCONFIG_CPU_COUNT=12','-DCONFIG_MONITOR_EXIT_RATE=50000',
      '-DCONFIG_MONITOR_STORM_SECONDS=5']
sources=[str(f) for f in (root/'libs/wboxtest/monitor').glob('*.c')]+[str(root/'tests/monitor/test_wboxtest.c')]
report={}
for mode in ['internal','external','boot']:
    more=['-DCONFIG_MONITOR_EXTERNAL_EXECUTOR=1'] if mode=='external' else ['-DCONFIG_MONITOR_START_ENABLED=1'] if mode=='boot' else []
    exe=out/(mode+'.exe')
    subprocess.run(cc+flags+defs+more+sources+['-o',str(exe)],check=True)
    run=subprocess.run([str(exe)],capture_output=True,text=True)
    (out/(mode+'.txt')).write_text(run.stdout+run.stderr,encoding='utf-8')
    assert run.returncode==0,run.stdout+run.stderr
    assert len(run.stdout.splitlines())==18 and all(' PASS' in s for s in run.stdout.splitlines())
    report[mode]={'tests':6,'iterations':3,'passed':18}
    print('PASS:',mode,'6 cases x 3 iterations',flush=True)
(out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
