HOS network troubleshooting v2 - 2026-11-23

主文档: hos_network_troubleshooting_v2_20261123.md
主入口: scripts/hos_net_diag.sh
计数辅助: scripts/hos_net_delta.awk (与主入口放在同一目录)
HOS 人工命令: scripts/hos_commands.txt

本版变化:
- 第4-13章按基础配置 -> 小流量 -> 抓包划段 -> 转发/前端/后端/通知 -> 性能/升级逐层排查。
- 每层给命令用途、示意输出、分析边界与下一步。
- 删除旧14章；旧15-16章改为脚本与使用流程，连续编号为14-15。
- 默认采集只读网络信息；只有显式 probe 发 ping，capture 抓包。
- 不修改接口、路由、防火墙、offload、优先级或 HOS/CCM 策略。
- 示例输出是说明用数据，不是单板实测。

开始:
  sh scripts/hos_net_diag.sh --help
  sh scripts/hos_net_diag.sh selfcheck --role servervm --out ./case
  sh scripts/hos_net_diag.sh basic --role servervm --out ./case

Android:
  将 scripts 内两个文件复制到 /data/local/tmp/hos_net_diag/
  sh /data/local/tmp/hos_net_diag/hos_net_diag.sh selfcheck --role android --out /data/local/tmp/case

脚本不自动选择网卡、DM PID 或命名空间，不把采集成功标成网络通过。
先按主文档确认实际对象。没有 reliable timeout 时主动测试拒绝执行。
本地验证范围见 VALIDATION.md；HOS 单板、Android mksh/BusyBox 环境需再回归。
