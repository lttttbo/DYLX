// SPDX-License-Identifier: GPL-2.0-or-later
/* ARM64 Guest kernel bridge. Load only with the matching monitor HVC firmware. */
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/random.h>
#include <linux/capability.h>
#include "monitor_uapi.h"
#ifndef CONFIG_ARM64
#error "xvisor_monitor_bridge requires an ARM64 Guest"
#endif

static DEFINE_MUTEX(report_lock);
static u64 session, sequence;

static long xm_call(const struct xm_report *r)
{
	register u64 x0 asm("x0") = XM_HVC_MAGIC;
	register u64 x1 asm("x1") = session;
	register u64 x2 asm("x2") = ++sequence;
	register u64 x3 asm("x3") = r->cpu_bp;
	register u64 x4 asm("x4") = r->total_bytes;
	register u64 x5 asm("x5") = r->available_bytes;
	register u64 x6 asm("x6") = r->free_bytes;
	register u64 x7 asm("x7") = r->valid;
	/* The private ABI preserves x1..x7. Declare them read/write conservatively. */
	asm volatile("hvc #0x4d4f" : "+r"(x0), "+r"(x1), "+r"(x2), "+r"(x3),
		"+r"(x4), "+r"(x5), "+r"(x6), "+r"(x7) : : "memory");
	return (long)x0;
}

static ssize_t xm_write(struct file *file, const char __user *buffer,
			size_t length, loff_t *position)
{
	struct xm_report r;
	long rc;
	if (!capable(CAP_SYS_ADMIN)) return -EPERM;
	if (length != sizeof(r)) return -EINVAL;
	if (copy_from_user(&r, buffer, sizeof(r))) return -EFAULT;
	if (!r.valid || r.valid > 3 || r.cpu_bp > 10000 ||
	    r.available_bytes > r.total_bytes || r.free_bytes > r.total_bytes ||
	    ((r.valid & 2) && !r.total_bytes)) return -EINVAL;
	if (mutex_lock_interruptible(&report_lock)) return -ERESTARTSYS;
	rc = xm_call(&r);
	mutex_unlock(&report_lock);
	/* HV error numbers are not Linux errno; do not pass them through. */
	return rc ? -EAGAIN : sizeof(r);
}

static const struct file_operations xm_fops = {
	.owner = THIS_MODULE, .write = xm_write, .open = nonseekable_open,
};
static struct miscdevice xm_device = {
	.minor = MISC_DYNAMIC_MINOR, .name = "xvisor_monitor",
	.fops = &xm_fops, .mode = 0600,
};
static int __init xm_init(void)
{
	get_random_bytes(&session, sizeof(session));
	if (!session) session = 1;
	return misc_register(&xm_device);
}
static void __exit xm_exit(void) { misc_deregister(&xm_device); }
module_init(xm_init);
module_exit(xm_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Xvisor monitor ARM64 Guest telemetry bridge");
