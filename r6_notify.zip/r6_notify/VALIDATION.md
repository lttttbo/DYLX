# R6 v1.0 验证记录

## 实際执行并通过

1. `src/r6_notify.c`连同交付的两个头文件，在本环境Linux **6.12.107+deb13-amd64**头文件上通过`r6_notify.o`对象编译。回调配置使用该环境的四参数sched_switch签名。日志：tests/host_object_build.txt。
2. 生产用r6_math.h的宿主C断言：完整remote/local分解，缺失时间点、倒序、等时刻、直方图边界及累计。`-Wall -Wextra -Werror`编译通过。
3. Python 12项测试通过：SMP发布与接收锚点顺序、work代次分离位置、禁止双wake、未知锚点拒绝、origin错误拒绝、CCM位置、两种sched_switch ABI和未知ABI拒绝、check/apply/restore、正确分解、错误分解检测、baseline语义、分位数区间。
4. 将当前上传的net.c.txt/vhost.c.txt应用原R5补丁后，对**两个vhost真实文件**生成R6插入计划成功。SMP及CCM完整工程没有提供，相关计划只在已知形态的合成fixture上验证，没有冒称是完整厂商源码。
5. 用实际改写后的vhost_work_queue_tagged函数体，执行原R5的work队列宿主harness：20个新提交/合并组合及无worker情形，原bit/list/wake操作输出与R5原函数一致。R6函数在该测试中是无业务副作用的stub，验证的是原操作保留，而非多CPU并发运行。结果：tests/queue_operations.txt。
6. capture_r6.sh通过sh、Bash和BusyBox ash语法检查；Python脚本通过py_compile。时长变量为CAPTURE_S，不使用特殊变量SECONDS。

## 未完成且不能宣称完成

- 没有完整厂商ARM64 Linux 5.15.158-rt76内核构建、链接、modpost或上板测试。
- 本环境对象编译不证明目标厂商的完整配置、所有私有接口或模块符号一定兼容；需在目标构建执行。
- 没有实机多CPU压力/并发正确性验证、插桩开销测量，也没有假定探针完全无扰动。
- 未测Guest/HOS请求端到端等待；没有虚构单包或完整请求ID。
- 未证明所有性能下降都由IPI导致。算术phase闭合是采样配对一致性校验，不是因果归因完成。

## 风险控制

- 插入器仅改唯一锚点，记录SHA256并保存完整原文件；未知源码形态拒绝应用，不使用fuzzy patch。
- 旧探针保留但关闭；原业务wake_up_process/eventfd_signal/test_and_set_bit只运行原有次数。
- 源端timestamp在发布前，返回值以不可变token记录，不在node可能复用后读取旧载荷。
- work pending/executing分离，消费元数据在原queued位清除之前。
- diag短raw-spinlock不跨越任何业务调用；热路径不分配、不printk、不抓栈。
- baseline/counts/timing三模式和同布局对照检查扰动；报告放在停止后导出。
- 同一Linux monotonic时钟；负序/缺失/重叠身份/配置变化明确报告，不能静默把错误计时归零。
- 首次绑定和停止边界可能有少量在途事件，保留诊断；跨CPU/网络端点不是原子快照。
