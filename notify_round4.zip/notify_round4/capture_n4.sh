#!/bin/sh
# Run while Android traffic is steady. Does not change affinity or traffic.
set -eu
[ "$#" -ge 3 ] || { echo "Usage: sh $0 IOEVENT_TID VHOST_TID LABEL [SECONDS=3]" >&2; exit 2; }
IO=$1; VH=$2; LABEL=$3; SECONDS=${4:-3}
for v in "$IO" "$VH"; do case "$v" in ''|*[!0-9]*|0) echo "Invalid TID $v" >&2; exit 2;; esac; done
case "$LABEL" in ''|*[!A-Za-z0-9_-]*) echo "Label: use letters, digits, underscore or hyphen" >&2; exit 2;; esac
case "$SECONDS" in ''|*[!0-9]*|0) echo "SECONDS must be positive integer" >&2; exit 2;; esac
CCM=${CCM_DIR:-/sys/module/ccm_proxy/parameters}
VHROOT=${VHOST_DIR:-/sys/module/vhost_net/parameters}
ADDR=${TX_ADDR:-0x6020003004}
SHIFT=${SAMPLE_SHIFT:-10}
DELAY=${REPORT_DELAY:-60}
for d in "$CCM" "$VHROOT"; do
    for n in n4_run n4_report n4_tid n4_shift n4_addr; do
        [ -e "$d/$n" ] || { echo "Missing $d/$n; inspect actual module name/build/deployment" >&2; exit 1; }
    done
    [ "$(cat "$d/n4_run")" = 0 ] || { echo "An n4 capture is already running in $d" >&2; exit 1; }
done
[ -r "/proc/$IO/status" ] && [ -r "/proc/$VH/status" ] || { echo "Target TID no longer exists" >&2; exit 1; }
# Do not silently stop another investigation. Disable it BEFORE throughput test.
if [ -r "$CCM/ioem_run" ] && [ "$(cat "$CCM/ioem_run")" != 0 ]; then
    echo "Stop old ioem capture before this test" >&2; exit 1
fi
OUT=${OUT_BASE:-/tmp/notify_round4}/"${LABEL}_$(date +%Y%m%d_%H%M%S)_$$"
mkdir -p "$OUT"
{
 echo "label=$LABEL ccm=$CCM vhost=$VHROOT io_tid=$IO vh_tid=$VH seconds=$SECONDS shift=$SHIFT tx_addr=$ADDR"
 uname -a
 for t in "$IO" "$VH"; do echo "TID=$t"; cat "/proc/$t/comm"; grep -E '^(Pid|Tgid|Cpus_allowed_list):' "/proc/$t/status"; done
 grep -w eth0 /proc/interrupts || true
} > "$OUT/context_before.txt"
echo "$IO" > "$CCM/n4_tid"; echo "$ADDR" > "$CCM/n4_addr"; echo "$SHIFT" > "$CCM/n4_shift"
echo "$VH" > "$VHROOT/n4_tid"; echo 0 > "$VHROOT/n4_addr"; echo "$SHIFT" > "$VHROOT/n4_shift"
cleanup() { echo 0 > "$CCM/n4_run" 2>/dev/null || :; echo 0 > "$VHROOT/n4_run" 2>/dev/null || :; }
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
echo 1 > "$CCM/n4_run"
echo 1 > "$VHROOT/n4_run"
sleep "$SECONDS"
cleanup
# No report reads / terminal dumps during the traffic interval.
sleep "$DELAY"
cat "$CCM/n4_report" > "$OUT/ccm_n4.txt"
cat "$VHROOT/n4_report" > "$OUT/vhost_n4.txt"
{
 for t in "$IO" "$VH"; do echo "TID=$t"; cat "/proc/$t/comm" 2>/dev/null || true; grep -E '^(Pid|Tgid|Cpus_allowed_list):' "/proc/$t/status" || true; done
 grep -w eth0 /proc/interrupts || true
} > "$OUT/context_after.txt"
dmesg | grep -E 'VQMAP |VQCFG |IOEM_CFG |NETNEG' > "$OUT/config_logs.txt" || true
trap - EXIT INT TERM
echo "OUTPUT_DIR=$OUT"
