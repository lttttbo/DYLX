# Monitor v4：测试入口

当前以 monitor_observer_from_20261023_v4_20261025 为基线，统一使用 CONFIG_WBOXTEST_MONITOR。

先执行 monitor start，再执行 wboxtest run_groups 1 monitor，共 6 项隔离测试和 3 项 Hypervisor 内存测试。

原 Guest 现场源码合并到 libs/wboxtest/monitor/guest_cases.c 保留，本阶段不编译、不注册，不需要 monitor_live target 或 Guest 用户态程序。

完整配置、前置条件、覆盖边界及合入步骤见 [统一测试说明](monitor_tests_flat_v4.md)。
