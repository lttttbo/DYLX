#!/bin/sh
# Capture finite source stacks and matched ioeventfd objects. Does not bind CPUs.
# Start Android traffic first; run this during its stable phase.
set -eu
umask 077

fail() { echo "ERROR: $*" >&2; exit 1; }
[ "$#" -ge 3 ] && [ "$#" -le 4 ] ||
    fail "usage: IOEM_DIR=<module>/parameters sh $0 <worker_tid|0> <ioevent_tid> <vhost_tid> [seconds]"
[ "$(id -u)" = 0 ] || fail "run in ServerVM as root"
W=$1; I=$2; V=$3; SECONDS=${4:-3}
DELAY=${REPORT_DELAY:-60}
for n in "$W" "$I" "$V" "$SECONDS" "$DELAY"; do
    case "$n" in ''|*[!0-9]*) fail "TIDs/time must be decimal integers";; esac
done
[ "$I" -gt 0 ] && [ "$V" -gt 0 ] && [ "$I" != "$V" ] || fail "invalid target TIDs"
[ "$W" != "$I" ] && [ "$W" != "$V" ] || fail "worker must differ from target tasks"
[ "$SECONDS" -ge 1 ] && [ "$SECONDS" -le 10 ] || fail "use a short 1..10 second source capture"
[ -r /proc/ipi_origin ] && [ -w /proc/ipi_origin ] || fail "/proc/ipi_origin unavailable"

check_task() {
    tid=$1; kind=$2
    [ -r "/proc/$tid/comm" ] || fail "TID $tid does not exist"
    comm=$(cat "/proc/$tid/comm")
    case "$kind:$comm" in
      worker:kworker/*|io:*ioeventfd*|vhost:vhost-*) :;;
      *) fail "TID $tid is '$comm', not the expected $kind task";;
    esac
}
check_task "$I" io
check_task "$V" vhost
[ "$W" -eq 0 ] || check_task "$W" worker
SKIP=${SKIP_OBJECTS:-0}
[ "$SKIP" = 0 ] || [ "$SKIP" = 1 ] || fail "SKIP_OBJECTS must be 0 or 1"
IOEM=${IOEM_DIR:-}
if [ "$SKIP" = 0 ]; then
    [ -n "$IOEM" ] || fail "set IOEM_DIR from find /sys/module -path '*/parameters/ioem_run', before testing"
    [ -w "$IOEM/ioem_run" ] && [ -r "$IOEM/ioem_report" ] || fail "ioem parameters not present at $IOEM"
    [ "$(cat "$IOEM/ioem_run")" = 0 ] || fail "ioeventfd object capture is already running; stop/save it first"
fi
BASE=${OUT_BASE:-/tmp/notify_chain}
mkdir -p "$BASE"
OUT=$(mktemp -d "$BASE/capture_$(date +%Y%m%d_%H%M%S)_XXXXXX")
# Refuse to erase an active/older collection without saving it.
if ! cat /proc/ipi_origin > "$OUT/previous_ipi_report.txt"; then
    fail "existing ipi collection is running or unreadable; stop/save it first; output=$OUT"
fi
grep -q '^# ipi_origin v2;' "$OUT/previous_ipi_report.txt" || fail "v2 header is not running"
{
    echo "date=$(date '+%Y-%m-%d %H:%M:%S')"
    echo "kernel=$(uname -r)"
    echo "worker=$W ioevent=$I vhost=$V seconds=$SECONDS report_delay=$DELAY"
    echo "ioem_dir=$IOEM skip_objects=$SKIP"
    for tid in "$W" "$I" "$V"; do
        [ "$tid" -eq 0 ] && continue
        echo "--- task $tid before ---"
        grep -E '^(Name|Pid|Tgid|PPid|Cpus_allowed_list):' "/proc/$tid/status"
        cat "/proc/$tid/stat"
    done
} > "$OUT/context.txt"
IPI_STARTED=0; OBJ_STARTED=0
cleanup() {
    if [ "$IPI_STARTED" = 1 ]; then echo stop > /proc/ipi_origin 2>/dev/null || true; fi
    if [ "$OBJ_STARTED" = 1 ]; then echo 0 > "$IOEM/ioem_run" 2>/dev/null || true; fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [ "$SKIP" = 0 ]; then
    echo 1 > "$IOEM/ioem_run"
    OBJ_STARTED=1
fi
printf 'start_stacks %s %s %s\n' "$W" "$I" "$V" > /proc/ipi_origin
IPI_STARTED=1
sleep "$SECONDS"
echo stop > /proc/ipi_origin
IPI_STARTED=0
if [ "$SKIP" = 0 ]; then
    echo 0 > "$IOEM/ioem_run"
    OBJ_STARTED=0
fi
# No periodic snapshots/parsing/output during the capture. Defer formatting too.
sleep "$DELAY"
cat /proc/ipi_origin > "$OUT/ipi_stacks.txt"
if [ "$SKIP" = 0 ]; then
    cat "$IOEM/ioem_report" > "$OUT/ioeventfd_match.txt"
fi
if dmesg > "$OUT/.dmesg.tmp" 2> "$OUT/dmesg_error.txt"; then
    grep 'VQMAP ' "$OUT/.dmesg.tmp" > "$OUT/vqmap.txt" || true
fi
rm -f "$OUT/.dmesg.tmp"
{
    for tid in "$W" "$I" "$V"; do
        [ "$tid" -eq 0 ] && continue
        echo "--- task $tid after ---"
        if [ -r "/proc/$tid/status" ]; then
            grep -E '^(Name|Pid|Tgid|PPid|Cpus_allowed_list):' "/proc/$tid/status"
            cat "/proc/$tid/stat"
        else
            echo "task_missing=1"
        fi
    done
} >> "$OUT/context.txt"
STACKS=$(grep -c '^STACK,' "$OUT/ipi_stacks.txt" || true)
echo "Saved $STACKS bounded stack samples. OUTPUT_DIR=$OUT"
[ "$STACKS" -gt 0 ] || echo "WARNING: no selected source stack; check actual task IDs, source hook and cross-CPU activity"
if [ "$SKIP" = 0 ] && [ ! -s "$OUT/vqmap.txt" ]; then
    echo "WARNING: VQMAP log missing; object-to-queue identification is incomplete"
fi
