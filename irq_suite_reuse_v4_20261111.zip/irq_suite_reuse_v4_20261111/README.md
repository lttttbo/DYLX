# HOS 中断测试整组复用修正版 v4

日期：2026-11-11。范围：当前 interrupt 测试集，沿用从 89 开始的自动 SPI 扫描。

此包包含七个完整文件，统一修正 priority、affinity、type、base 及两个 debug 用例的资源恢复。
以本包 full_files 中的一组文件共同合入，不需要拼接前几次单文件修改。

## 目录

```text
full_files/libs/wboxtest/interrupt/
    test_irq.h
    test_irq_select.c
    test_irq_priority.c
    test_irq_affinity.c
    test_irq_type.c
    test_irq_base.c
    test_irq_priority_debug.c
manual_merge.txt
validation.json
SHA256SUMS.txt
```

公共代码集中在原有 test_irq_select.c，声明放在原有 test_irq.h。
仍使用现有中断测试编译开关、现有六个 C 对象；生产 IRQ 核心、GIC 驱动、Guest 均不需要修改。
debug 文件中仍注册 irq_priority_debug、irq_priority_debug_spi56 两个用例。

## 为什么之前只复用部分号码

每个 .run 都重新扫描，只有满足“没有 action、非 routed、硬件无 pending/active、软硬件 masked”
等条件的 IRQ 才入选。原 affinity 不注册回调，却在结束时 unmask 再 unregister(NULL)；
原 type 仅注册一个 SPI，却对多个未注册 SPI 做同样收尾。注销不存在的 action 失败后，
这些 IRQ 留在未屏蔽状态，下一次扫描便会跳过。人工设置的 ACTIVE、未恢复的 affinity
也会污染后续测试条件。六个号码足够，不代表每次扫描必然还能找到原来六个。

## 本版生命周期

每个 .run 自己调用 test_irq_begin，然后执行本用例，最后调用 test_irq_end。
begin 失败会自行清理已经建立的状态；成功的 begin 恰好对应一次 end。
运行失败同样进入 end，后续子测试不继续执行。

1. 获取测试互斥锁，把当前测试线程暂时绑定在执行核，保存原线程 affinity。
2. 扫描三对 SPI，保存初始名称、逻辑优先级、触发类型、硬件屏蔽状态；检查 SGI 使用条件。
3. 修改 IRQ affinity 时，分别保存 HOS 缓存 mask 和芯片接口读出的实际路由 mask。
4. 注册回调使用本测试的静态上下文指针作 dev 标识；仅注销这个标识对应的 action。
5. 收尾屏蔽已改动的 IRQ，注销自己的 action，并检查所有 CPU 的 action 列表。
6. 清除自己注入的 ACTIVE，以及本测试触发前已确认不存在的 pending。
   实际硬件处理中产生的 ACTIVE 等待退出，超时报告失败，不强行清除。
7. 恢复有明确原值的触发类型、优先级、通过 affinity API 表达的硬件路由和软件缓存、名称。
8. SPI 保持最初的 masked 状态；SGI 恢复最初屏蔽状态；恢复线程 affinity。
9. 读回检查并打印 `IRQTEST cleanup rc=0 reusable_spis=6/6`。

一次清理失败仍会尝试清理其他已保存 IRQ，并使本次测试失败。
存在未清理资源时禁止继续复用静态上下文，打印 `cleanup incomplete`，保留诊断状态。
正常测试无需依赖 debug 或名为 select 的测试先运行，单独运行任何一个用例均有上述流程。

## 各文件的修正

| 文件 | 修正内容 |
| --- | --- |
| test_irq_select.c | 原 min89 扫描器保留；增加统一保存、回调、等待、错误处理及恢复代码。 |
| test_irq.h | 保留运行时 SPI 宏和 SGI5/6，增加上述公共接口及回调结果结构。 |
| test_irq_priority.c | SPI 两种优先级顺序检查；SGI 顺序触发检查；60 秒重复触发；优先级读取。取消重复注册和越界数组写入，逐轮检查错误。 |
| test_irq_affinity.c | 查询当前有效 mask；非法参数、单核、多核 mask、SGI 不支持改 affinity 和硬件回读路径。结束恢复路由和缓存。 |
| test_irq_type.c | type/state 读取、level/edge 设置、SGI 非法类型、LEVEL 标志、masked/ACTIVE 状态和软件回调。清理自己注入的 ACTIVE，恢复已知类型。 |
| test_irq_base.c | 描述符、名称、SGI 次数、raise、软件分发、屏蔽/使能状态、注册注销及 PMR。统一返回和清理，PMR 测完立即恢复。 |
| test_irq_priority_debug.c | 保留阶段快照和回调轨迹；两个入口接入统一选择、执行核绑定、IRQ 路由保存/恢复及最终检查。 |

### priority 额外修正

- 高频测试开始时注册一次 SPI5/6，整个 60 秒循环复用这两个 action；每次注册、设置和触发的失败均返回。
- 每轮都重置回调结果和本轮起始时间，不再以整段 60 秒的起始时刻计算“延迟”。
- 每轮验证两个回调各一次、目标 CPU 一致、高优先级先进入；任一轮失败立即结束，经过清理后返回失败。
- 原 case2/case3 没有重置 current_index，可能写出 exec_order[2] 的问题已消除。
- ISR 中不打印串口；结束打印完成次数和平均入口延迟。
- 100us 是完成一对后的间隔，不代表精确的 10kHz 实时触发频率。
- 相同优先级 SGI 测试先等待 SGI6 完成再发 SGI5；它验证两者可投递，不宣称 GIC 对同时 pending 的相同优先级中断保证 FIFO。

### affinity 额外修正

- 重用后的 IRQ 当前 affinity 可以是单核或其他有效 mask，不再断言必须等于 CPU_MASK_ALL。
- 多核用例选择两个在线核，不硬编码 CPU2/3；检查 API 保存的请求 mask，不声称硬件把一个 SPI 同时投递到两个 CPU。
- 不再构造可能越界的 cpumask_of(cpu_count + 1)，改用 NULL 和空 mask 的非法参数测试。
- 保留原“清空缓存后走硬件读取”的测试目的，结束恢复测试前的实际路由及缓存。
- HOS 的 irq->chip->irq_get_affinity 和 irq->affinity_forced 已在你提供的 vmm_host_irq.c.txt 中核对。
  若实际头文件/驱动与该参考又有不同，应按其真实签名适配，不能用仅修改缓存的方法冒充恢复硬件路由。

### base / type 的边界

- base 检查 descriptor.num 与 HIRQ 一致，不要求所有平台 HIRQ 恒等于 HWIRQ。
- 名称使用完整 strcmp，不再拿指针 sizeof 作为字符串长度。
- SGI 计数检查等回调完成后执行，不再固定延迟 10us 即假定完成。
- PMR 是当前 CPU 接口状态；测试绑定执行核，并在很短的关本地 IRQ 区间内修改和恢复。
- generic_irq_exec 是软件分发；type 中手工注入 ACTIVE 后调用它，测试状态接口与回调，不能解释为物理中断真实投递。
- 回调返回 VMM_IRQ_HANDLED。测试没有注册的 action 不进行批量 NULL 注销。

## 复用与恢复的边界

扫描不是排他预留，仍按你选择的“扫描当前未注册 IRQ”方式工作，不能据此确认板级硬件永久未使用。
外部没有新增注册、路由或状态变化时，整组应反复选回同样六个 SPI；有真实占用变化时允许换号或失败。
不采用固定缓存号码绕过重新检查。历史中断计数保留，不清零统计值。

原 trigger=NONE/Unspecified 只是软件未指定，不提供硬件原始类型。
set_type(NONE) 通常不会恢复硬件，因此本版只恢复明确的原触发类型；原先未指定的 SPI 保留测试后
明确的 level/edge 类型，并保持 masked/no pending/no active。这不妨碍当前扫描器再次选择。
硬件 affinity 恢复以 HOS 芯片 getter/setter 可表达的 mask 为准，不声称逐位还原原始 IROUTER 寄存器。

## 单板回归

合入全部七个文件并重新编译启动后执行：

```text
unittest run_groups 2 interrupt
```

观察每个用例每次迭代：

- `IRQTEST cleanup rc=0 reusable_spis=6/6`。
- 各次 IRQSCAN 的三对号码一致，前提是外部使用状态不变。
- priority 的 TEST4 打印完成次数、平均延迟；出现超时必须报告 FAILED，不应再报 PASS。
- 两次 group 迭代都能完成；debug 仍输出轨迹，普通用例不在 IRQ 回调中打印。

可单独重复验证：

```text
unittest run_tests 2 irq_affinity
unittest run_tests 2 irq_type
unittest run_tests 2 irq_base
unittest run_tests 2 irq_priority
```

每轮 priority 仍包含 60 秒测试。先用完整 interrupt 组验证各用例之间的复用，再做多轮稳定性回归。
全局 heap 差值受同期其他模块分配/释放影响；本版消除了高频循环反复注册 action 的问题，
但不能仅凭一条全局 heap 数值认定所有内存变化都来自本测试。

## 本地验证结果

六个 C 文件均通过 12 核、16 核配置的 ARM64 freestanding -O2 -Wall -Wextra -Werror 对象编译。
本地使用 Xvisor 参考头文件，并在验证目录补充已提供的 HOS 私有 IRQ API/成员声明；
该验证头文件不属于交付代码，不要覆盖你的真实核心头文件。
仅豁免参考头文件原有的 unused-parameter、duplicate-decl-specifier、asm-operand-widths 警告。
另检查两个配置下所有 test_irq_* 跨对象引用都存在唯一的全局定义。

20 个接口模拟场景通过：明确原类型和 Unspecified 各执行两轮完整六用例组，检查再次选回同一六个 SPI；
18 个故障场景验证写入读回不符、部分注册失败、高频漏回调、类型设置失败、ACTIVE 设置失败、
affinity 变更后失败、注销失败、PMR 读回失败、优先级恢复失败、affinity 恢复失败、
注册期间意外中断、重复回调、SGI 被占用、ACTIVE 无法清除、线程绑定失败、执行 CPU 不符、
软件分发失败、软件分发未调用回调。
检查了错误传播、清理、测试 action 分配/释放计数以及无法清理时禁止重用。

这不等于完成真实 HOS 镜像链接及 GIC 单板回归；后两项需在你的工程上运行。
详细结果见 validation.json。
