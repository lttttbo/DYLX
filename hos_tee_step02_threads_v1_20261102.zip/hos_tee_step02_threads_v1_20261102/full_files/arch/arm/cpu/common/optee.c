#include <vmm_error.h>
 #include <vmm_stdio.h>
 #include <vmm_compiler.h>
 #include <vmm_macros.h>
 #include <vmm_types.h>
 #include <vmm_spinlocks.h>
 #include <vmm_heap.h>
 #include <vmm_manager.h>
 #include <vmm_host_aspace.h>
 #include <vmm_host_ram.h>
 #include <vmm_guest_aspace.h>
 #include <cpu_vcpu_helper.h>
 #include <arch_regs.h>
 
 #include <tee.h>
 #include <smccc.h>
 #include <optee_msg.h>
 #include <optee_smc.h>
 #include <optee_rpc_cmd.h>
 
 /* -------------------------------------------------------------------------- */
 /* Compatibility glue for older vendor trees */
 
 #ifndef TEEC_SUCCESS
 #define TEEC_SUCCESS                        0x00000000
 #define TEEC_ERROR_GENERIC                  0xFFFF0000
 #define TEEC_ERROR_BAD_PARAMETERS           0xFFFF0006
 #define TEEC_ERROR_OUT_OF_MEMORY            0xFFFF000C
 #define TEEC_ERROR_COMMUNICATION            0xFFFF000E
 #define TEEC_ORIGIN_COMMS                   0x00000002
 #endif
 
 /* -------------------------------------------------------------------------- */
 /* Debug switches
  *
  */
 #define OPTEE_DEBUG_MASTER                  0
 
 #if OPTEE_DEBUG_MASTER
 #define OPTEE_DEBUG_SMC                     0
 #define OPTEE_DEBUG_REGION                  0
 #define OPTEE_DEBUG_FLOW                    0
 #else
 #define OPTEE_DEBUG_SMC                     0
 #define OPTEE_DEBUG_REGION                  0
 #define OPTEE_DEBUG_FLOW                    0
 #endif
 
 #if OPTEE_DEBUG_SMC
 #define OPTEE_SMC_DBG(fmt, ...) \
         vmm_printf("OPTEE-SMC: " fmt "\n", ##__VA_ARGS__)
 #else
 #define OPTEE_SMC_DBG(fmt, ...) do { } while (0)
 #endif
 
 #if OPTEE_DEBUG_REGION
 #define OPTEE_REGION_DBG(fmt, ...) \
         vmm_printf("OPTEE-REGION: " fmt "\n", ##__VA_ARGS__)
 #else
 #define OPTEE_REGION_DBG(fmt, ...) do { } while (0)
 #endif
 
 #if OPTEE_DEBUG_FLOW
 #define OPTEE_FLOW_DBG(fmt, ...) \
         vmm_printf("OPTEE-FLOW: " fmt "\n", ##__VA_ARGS__)
 #else
 #define OPTEE_FLOW_DBG(fmt, ...) do { } while (0)
 #endif
 
 /* -------------------------------------------------------------------------- */
 /* Mediator policy / limits */
 
 #define OPTEE_KNOWN_NSEC_CAPS      (OPTEE_SMC_NSEC_CAP_UNIPROCESSOR)
 #define OPTEE_KNOWN_SEC_CAPS       (OPTEE_SMC_SEC_CAP_HAVE_RESERVED_SHM | \
                                     OPTEE_SMC_SEC_CAP_UNREGISTERED_SHM  | \
                                     OPTEE_SMC_SEC_CAP_DYNAMIC_SHM       | \
                                     OPTEE_SMC_SEC_CAP_VIRTUALIZATION    | \
                                     OPTEE_SMC_SEC_CAP_MEMREF_NULL)
 
 /*
  * This should match the number of OP-TEE SMC function IDs explicitly handled
  * by the mediator.
  */
 #define OPTEE_MEDIATOR_SMC_COUNT   12U
 
 /*
  * Local resource limits. These are hypervisor-side limits, independent from
  * secure world thread count.
  */
 #define OPTEE_MAX_SHM_BUFS_DEFAULT   128U
 #define OPTEE_MAX_SHM_PAGES_DEFAULT  2048U
 #define OPTEE_MAX_SHM_BUFFER_PG      129U
 
 #define OPTEE_PAGE_SIZE              VMM_PAGE_SIZE
 
 #define OPTEE_NONCONTIG_ENTRIES_PER_PAGE \
         ((OPTEE_MSG_NONCONTIG_PAGE_SIZE / sizeof(u64)) - 1U)
 
 /* -------------------------------------------------------------------------- */
 /* Data structures */
 
 enum optee_call_state {
         OPTEE_CALL_STATE_NORMAL = 0,
         OPTEE_CALL_STATE_HOS_RPC = 1,
 };
 
 struct optee_msg_noncontig_page {
         u64 pages[OPTEE_NONCONTIG_ENTRIES_PER_PAGE];
         u64 next;
 };
 
 struct optee_host_page {
         physical_addr_t pa;
         void *va;
         physical_size_t sz;
 };
 
 struct optee_shm_buf {
         struct optee_shm_buf *next;
         u64 cookie;
         u32 page_cnt;
 
         u32 pg_list_cnt;
         struct optee_host_page *pg_list;
 };
 
 struct optee_shm_rpc {
         struct optee_shm_rpc *next;
         u64 cookie;
 
         physical_addr_t guest_cmd_gpa;
         struct optee_host_page hos_arg_pg;
 };
 
 struct optee_std_call {
         struct optee_std_call *next;
 
         physical_addr_t guest_arg_gpa;
 
         struct optee_host_page hos_arg_pg;
         struct optee_msg_arg *arg;
 
         u32 thread_id;
         bool in_flight;
 
         u32 rpc_func;
         u32 rpc_buffer_type;
 
         /*
          * Temporary NONCONTIG shadow pagelists created for this call only.
          */
         struct optee_shm_buf *tmp_shm_bufs;
 
         /*
          * Pointer to the most recent translated RPC data SHM returned by guest.
          * Kept so we can release only the page-list pages when a later RPC
          * reuses/overwrites the same slot.
          */
         struct optee_shm_buf *rpc_data_sb;
 
         enum optee_call_state state;
 };
 
 struct optee_ctx {
         u32 client_id;
         bool vm_live;
 
         u32 max_calls;
 
         u32 max_shm_bufs;
         u32 max_shm_pages;
 
         u32 call_count;
         u32 shm_buf_count;
         u32 shm_page_count;
 
         vmm_spinlock_t lock;
 
         struct optee_std_call *calls;
         struct optee_shm_rpc  *shm_rpcs;
 };
 
 /* -------------------------------------------------------------------------- */
 /* Static globals */
 
 static vmm_spinlock_t optee_smc_lock;
 static bool optee_smc_lock_init;
 
 static u32 __read_mostly optee_max_threads;
 static u32  optee_host_sec_caps;
 static bool optee_host_probe_done;
 static bool optee_dyn_shm_supported;
 static bool optee_virt_supported;
 
 static inline u64 optee_regpair_to_u64(u64 reg_hi, u64 reg_lo)
 {
         return (((u64)(reg_hi & 0xffffffffULL)) << 32) |
                ((u64)(reg_lo & 0xffffffffULL));
 }
 
 static inline void optee_u64_to_regpair(u64 v, u64 *reg_hi, u64 *reg_lo)
 {
         *reg_hi = (u32)((v >> 32) & 0xffffffffULL);
         *reg_lo = (u32)(v & 0xffffffffULL);
 }
 
 static inline bool optee_is_rpc_foreign_intr(unsigned long ret)
 {
         return OPTEE_SMC_RETURN_IS_RPC(ret) &&
                (OPTEE_SMC_RETURN_GET_RPC_FUNC(ret) ==
                 OPTEE_SMC_RPC_FUNC_FOREIGN_INTR);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Debug helpers */
 
 static void optee_dbg_dump_region(struct vmm_guest *guest,
                                   physical_addr_t gpa,
                                   const char *tag)
 {
 #if OPTEE_DEBUG_REGION
         struct vmm_region *reg;
         const char *name = "<anon>";
 
         if (!guest)
                 return;
 
         reg = vmm_guest_find_region(guest, gpa, (u32)0, FALSE);
         if (!reg) {
                 OPTEE_REGION_DBG("%s gpa=%#llx region=NOT-FOUND",
                                  tag, (unsigned long long)gpa);
                 return;
         }
 
         if (reg->node)
                 name = VMM_REGION_NAME(reg);
 
         OPTEE_REGION_DBG("%s gpa=%#llx region=%s flags=%#x gphys=[%#llx..%#llx]",
                          tag,
                          (unsigned long long)gpa,
                          name,
                          VMM_REGION_FLAGS(reg),
                          (unsigned long long)VMM_REGION_GPHYS_START(reg),
                          (unsigned long long)VMM_REGION_GPHYS_END(reg));
 #else
         (void)guest;
         (void)gpa;
         (void)tag;
 #endif
 }
 
 static int optee_dbg_require_ram_region(struct vmm_guest *guest,
                                         physical_addr_t gpa,
                                         const char *tag)
 {
         struct vmm_region *reg;
         u32 flags;
 
 #if !OPTEE_DEBUG_REGION
         (void)tag;
 #endif
 
         if (!guest)
                 return VMM_EINVALID;
 
         reg = vmm_guest_find_region(guest, gpa, (u32)0, FALSE);
         if (!reg) {
 #if OPTEE_DEBUG_REGION
                 OPTEE_REGION_DBG("%s gpa=%#llx region=NOT-FOUND -> reject",
                                  tag, (unsigned long long)gpa);
 #endif
                 return VMM_EFAULT;
         }
 
         flags = VMM_REGION_FLAGS(reg);
 
         /*
          * Dynamic SHM buffers must come from RAM only.
          * Explicitly reject DEVICE / ROM regions.
          */
         if (!(flags & VMM_REGION_ISRAM) ||
             (flags & (VMM_REGION_ISDEVICE | VMM_REGION_ISROM))) {
 #if OPTEE_DEBUG_REGION
                 const char *name = reg->node ? VMM_REGION_NAME(reg) : "<anon>";
                 OPTEE_REGION_DBG("%s gpa=%#llx region=%s flags=%#x -> NOT RAM, reject",
                                  tag, (unsigned long long)gpa, name, flags);
 #endif
                 return VMM_EACCESS;
         }
 
         return VMM_OK;
 }
 
 static void optee_dump_calls(struct optee_ctx *ctx, const char *where)
 {
 #if OPTEE_DEBUG_FLOW
         struct optee_std_call *c;
         int idx = 0;
 
         if (!ctx) {
                 OPTEE_FLOW_DBG("%s ctx=NULL", where);
                 return;
         }
 
         vmm_spin_lock(&ctx->lock);
         OPTEE_FLOW_DBG("%s: ctx=%p client_id=%u call_count=%u",
                        where, ctx, ctx->client_id, ctx->call_count);
 
         for (c = ctx->calls; c; c = c->next) {
                 OPTEE_FLOW_DBG("  [%d] call=%p thr=%u inflight=%d state=%u rpc_func=%u rpc_buf_type=%u guest_arg_gpa=%#llx cmd=%u",
                                idx, c, c->thread_id, c->in_flight,
                                c->state, c->rpc_func, c->rpc_buffer_type,
                                (unsigned long long)c->guest_arg_gpa,
                                c->arg ? c->arg->cmd : 0U);
                 idx++;
         }
         vmm_spin_unlock(&ctx->lock);
 #else
         (void)ctx;
         (void)where;
 #endif
 }
 
 /* -------------------------------------------------------------------------- */
 /* Capability dump */
 
 static void optee_dump_host_caps(u32 caps, unsigned long a2, unsigned long a3)
 {
         vmm_init_printf("OPTEE: host sec_caps=0x%x a2=%#lx a3=%#lx\n", caps, a2, a3);
         if (caps & OPTEE_SMC_SEC_CAP_HAVE_RESERVED_SHM)
                 vmm_init_printf("OPTEE:   - HAVE_RESERVED_SHM\n");
         if (caps & OPTEE_SMC_SEC_CAP_UNREGISTERED_SHM)
                 vmm_init_printf("OPTEE:   - UNREGISTERED_SHM\n");
         if (caps & OPTEE_SMC_SEC_CAP_DYNAMIC_SHM)
                 vmm_init_printf("OPTEE:   - DYNAMIC_SHM\n");
         if (caps & OPTEE_SMC_SEC_CAP_VIRTUALIZATION)
                 vmm_init_printf("OPTEE:   - VIRTUALIZATION\n");
         if (caps & OPTEE_SMC_SEC_CAP_MEMREF_NULL)
                 vmm_init_printf("OPTEE:   - MEMREF_NULL\n");
         if (caps & OPTEE_SMC_SEC_CAP_RPC_ARG)
                 vmm_init_printf("OPTEE:   - RPC_ARG (max_params=%lu)\n", a3);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Lock / SMC helpers */
 
 static inline void optee_lock_init_once(void)
 {
         if (!optee_smc_lock_init) {
                 INIT_SPIN_LOCK(&optee_smc_lock);
                 optee_smc_lock_init = true;
         }
 }
 
 static inline void optee_smc_call(u32 client_id,
                                   unsigned long a0, unsigned long a1,
                                   unsigned long a2, unsigned long a3,
                                   unsigned long a4, unsigned long a5,
                                   unsigned long a6,
                                   struct arm_smccc_res *res)
 {
         vmm_spin_lock(&optee_smc_lock);
         OPTEE_SMC_DBG("enter fid=%#lx a1=%#lx a2=%#lx a3=%#lx a4=%#lx a5=%#lx a6=%#lx cid=%u",
                       a0, a1, a2, a3, a4, a5, a6, client_id);
         arm_smccc_smc(a0, a1, a2, a3, a4, a5, a6,
                       (unsigned long)client_id, res);
         OPTEE_SMC_DBG("exit  fid=%#lx -> a0=%#lx a1=%#lx a2=%#lx a3=%#lx",
                       a0, res->a0, res->a1, res->a2, res->a3);
         vmm_spin_unlock(&optee_smc_lock);
 }
 
 static inline void optee_smc_call_host(unsigned long a0, unsigned long a1,
                                        unsigned long a2, unsigned long a3,
                                        unsigned long a4, unsigned long a5,
                                        unsigned long a6,
                                        struct arm_smccc_res *res)
 {
         vmm_spin_lock(&optee_smc_lock);
         arm_smccc_smc(a0, a1, a2, a3, a4, a5, a6,
                       0 /* a7 = 0 for host */, res);
         vmm_spin_unlock(&optee_smc_lock);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Host VA/PA wrappers */
 
 static inline void *optee_host_memmap_dbg(const char *tag,
                                           physical_addr_t pa,
                                           virtual_size_t sz,
                                           u32 mem_flags)
 {
         virtual_addr_t va = vmm_host_memmap(pa, sz, mem_flags);
 
 #if OPTEE_DEBUG_FLOW
         OPTEE_FLOW_DBG("memmap %s pa=%#lx sz=%#lx flags=%#x -> va=%#lx",
                        tag, pa, sz, mem_flags, va);
 #else
         (void)tag;
 #endif
 
         return (void *)va;
 }

static inline void optee_host_memunmap_dbg(const char *tag, void *ptr)
 {
         if (!ptr)
                 return;
 
 #if OPTEE_DEBUG_FLOW
         OPTEE_FLOW_DBG("memunmap %s va=%p", tag, ptr);
 #else
         (void)tag;
 #endif
         vmm_host_memunmap((virtual_addr_t)ptr);
 }
 
 static int optee_host_page_alloc(struct optee_host_page *pg, physical_size_t sz)
 {
         int rc;
         virtual_addr_t hva = 0;
         physical_addr_t hpa = 0;
 
         if (!pg || !sz)
                 return VMM_EINVALID;
 
         sz = VMM_ROUNDUP2_PAGE_SIZE(sz);
 
         /*
          * vmm_host_alloc_aligned_pages() returns host VA.
          * Then convert VA -> PA so OP-TEE can access it via physical address.
          */
         hva = vmm_host_alloc_aligned_pages(VMM_SIZE_TO_PAGE(sz),
                                            VMM_PAGE_SHIFT,
                                            VMM_MEMORY_FLAGS_NORMAL);
         if (!hva)
                 return VMM_ENOMEM;
 
         rc = vmm_host_va2pa(hva, &hpa);
         if (rc != VMM_OK) {
                 vmm_host_free_pages(hva, VMM_SIZE_TO_PAGE(sz));
                 return rc;
         }
 
         if (hva & VMM_PAGE_MASK) {
                 vmm_printf("OPTEE: host_page_alloc hva NOT aligned: %#lx sz=%#lx\n",
                            hva, sz);
                 vmm_host_free_pages(hva, VMM_SIZE_TO_PAGE(sz));
                 return VMM_EFAIL;
         }
 
         if (hpa & VMM_PAGE_MASK) {
                 vmm_printf("OPTEE: host_page_alloc hpa NOT aligned: %#lx sz=%#lx\n",
                            hpa, sz);
                 vmm_host_free_pages(hva, VMM_SIZE_TO_PAGE(sz));
                 return VMM_EFAIL;
         }
 
         pg->va = (void *)hva;
         pg->pa = hpa;
         pg->sz = sz;
         memset(pg->va, 0, sz);
 
         return VMM_OK;
 }
 
 static void optee_host_page_free(struct optee_host_page *pg)
 {
         if (!pg || !pg->va || !pg->sz)
                 return;
 
         vmm_host_free_pages((virtual_addr_t)pg->va, VMM_SIZE_TO_PAGE(pg->sz));
 
         pg->pa = 0;
         pg->va = NULL;
         pg->sz = 0;
 }
 
 /* -------------------------------------------------------------------------- */
 /* Guest IPA -> Host PA helpers */
 
 static int optee_guest_pa_to_host_pa(struct vmm_guest *guest,
                                      physical_addr_t gpa,
                                      physical_addr_t *hpa)
 {
         physical_size_t availsz = 0;
         u32 reg_flags = 0;
         int rc;
 
         if (!guest || !hpa)
                 return VMM_EINVALID;
 
         rc = optee_dbg_require_ram_region(guest, gpa, "gpa2hpa");
         if (rc != VMM_OK)
                 return rc;
 
         rc = vmm_guest_physical_map(guest, gpa, 1, hpa, &availsz, &reg_flags);
         if (rc != VMM_OK)
                 return rc;
 
         if (!(reg_flags & VMM_REGION_ISRAM) ||
             (reg_flags & (VMM_REGION_ISDEVICE | VMM_REGION_ISROM)))
                 return VMM_EACCESS;
 
         return VMM_OK;
 }
 
 static int optee_guest_read(struct vmm_guest *guest,
                             physical_addr_t gpa,
                             void *dst,
                             unsigned long len)
 {
         unsigned long done = 0;
 
         if (!guest || (!dst && len))
                 return VMM_EINVALID;
 
         while (done < len) {
                 physical_addr_t hpa;
                 physical_size_t availsz = 0;
                 u32 reg_flags = 0;
                 int rc;
                 physical_addr_t base;
                 unsigned long off;
                 unsigned long chunk;
                 virtual_size_t map_sz;
                 void *hva;
 
                 rc = optee_dbg_require_ram_region(guest, gpa + done, "guest_read");
                 if (rc != VMM_OK)
                         return rc;
 
                 rc = vmm_guest_physical_map(guest, gpa + done, len - done,
                                             &hpa, &availsz, &reg_flags);
                 if (rc != VMM_OK)
                         return rc;
 
                 if (!(reg_flags & VMM_REGION_ISRAM) ||
                     (reg_flags & (VMM_REGION_ISDEVICE | VMM_REGION_ISROM)))
                         return VMM_EACCESS;
 
                 chunk = min_t(unsigned long, (unsigned long)availsz, len - done);
                 base = (physical_addr_t)VMM_PAGE_ALIGN(hpa);
                 off = (unsigned long)(hpa - base);
                 map_sz = (virtual_size_t)VMM_ROUNDUP2_PAGE_SIZE(off + chunk);
 
                 hva = optee_host_memmap_dbg("guest_read", base, map_sz,
                                             VMM_MEMORY_FLAGS_NORMAL);
                 if (!hva)
                         return VMM_ENOMEM;
 
                 memcpy((u8 *)dst + done, (u8 *)hva + off, chunk);
                 optee_host_memunmap_dbg("guest_read", hva);
                 done += chunk;
         }
 
         return VMM_OK;
 }
 
 static int optee_guest_write(struct vmm_guest *guest,
                              physical_addr_t gpa,
                              const void *src,
                              unsigned long len)
 {
         unsigned long done = 0;
 
         if (!guest || (!src && len))
                 return VMM_EINVALID;
 
         while (done < len) {
                 physical_addr_t hpa;
                 physical_size_t availsz = 0;
                 u32 reg_flags = 0;
                 int rc;
                 physical_addr_t base;
                 unsigned long off;
                 unsigned long chunk;
                 virtual_size_t map_sz;
                 void *hva;
 
                 rc = optee_dbg_require_ram_region(guest, gpa + done, "guest_write");
                 if (rc != VMM_OK)
                         return rc;
 
                 rc = vmm_guest_physical_map(guest, gpa + done, len - done,
                                             &hpa, &availsz, &reg_flags);
                 if (rc != VMM_OK)
                         return rc;
 
                 if (!(reg_flags & VMM_REGION_ISRAM) ||
                     (reg_flags & (VMM_REGION_ISDEVICE | VMM_REGION_ISROM)))
                         return VMM_EACCESS;
 
                 chunk = min_t(unsigned long, (unsigned long)availsz, len - done);
                 base = (physical_addr_t)VMM_PAGE_ALIGN(hpa);
                 off = (unsigned long)(hpa - base);
                 map_sz = (virtual_size_t)VMM_ROUNDUP2_PAGE_SIZE(off + chunk);
 
                 hva = optee_host_memmap_dbg("guest_write", base, map_sz,
                                             VMM_MEMORY_FLAGS_NORMAL);
                 if (!hva)
                         return VMM_ENOMEM;
 
                 memcpy((u8 *)hva + off, (const u8 *)src + done, chunk);
                 optee_host_memunmap_dbg("guest_write", hva);
                 done += chunk;
         }
 
         return VMM_OK;
 }
 
 /* -------------------------------------------------------------------------- */
 /* Linked-list helpers */
 
 static struct optee_shm_rpc *optee_find_shm_rpc(struct optee_ctx *ctx, u64 cookie)
 {
         struct optee_shm_rpc *p;
 
         for (p = ctx->shm_rpcs; p; p = p->next)
                 if (p->cookie == cookie)
                         return p;
         return NULL;
 }
 
 static void optee_remove_shm_rpc_locked(struct optee_ctx *ctx,
                                         struct optee_shm_rpc *sr)
 {
         struct optee_shm_rpc **pp = &ctx->shm_rpcs;
 
         while (*pp) {
                 if (*pp == sr) {
                         *pp = sr->next;
                         return;
                 }
                 pp = &(*pp)->next;
         }
 }

static struct optee_std_call *optee_find_call_by_thread(struct optee_ctx *ctx,
                                                         u32 thread_id,
                                                         bool require_not_inflight)
 {
         struct optee_std_call *c;
 
         for (c = ctx->calls; c; c = c->next) {
                 if (c->thread_id == thread_id) {
                         if (require_not_inflight && c->in_flight)
                                 continue;
                         return c;
                 }
         }
         return NULL;
 }
 
 static void optee_remove_call_locked(struct optee_ctx *ctx,
                                      struct optee_std_call *c)
 {
         struct optee_std_call **pp = &ctx->calls;
 
         while (*pp) {
                 if (*pp == c) {
                         *pp = c->next;
                         return;
                 }
                 pp = &(*pp)->next;
         }
 }
 
 /* -------------------------------------------------------------------------- */
 /* Temporary SHM buffer management (per-call, not global by cookie) */
 
 static struct optee_shm_buf *optee_alloc_tmp_shm_buf(struct optee_ctx *ctx,
                                                      u64 cookie,
                                                      u32 page_cnt)
 {
         struct optee_shm_buf *sb;
 
         vmm_spin_lock(&ctx->lock);
         if (ctx->shm_buf_count >= ctx->max_shm_bufs ||
             (ctx->shm_page_count + page_cnt) > ctx->max_shm_pages) {
                 vmm_spin_unlock(&ctx->lock);
                 return NULL;
         }
         ctx->shm_buf_count++;
         ctx->shm_page_count += page_cnt;
         vmm_spin_unlock(&ctx->lock);
 
         sb = vmm_zalloc(sizeof(*sb));
         if (!sb) {
                 vmm_spin_lock(&ctx->lock);
                 ctx->shm_buf_count--;
                 ctx->shm_page_count -= page_cnt;
                 vmm_spin_unlock(&ctx->lock);
                 return NULL;
         }
 
         sb->cookie = cookie;
         sb->page_cnt = page_cnt;
         sb->pg_list_cnt = 0;
         sb->pg_list = NULL;
         sb->next = NULL;
 
         return sb;
 }
 
 static void optee_release_tmp_shm_buf_pages(struct optee_shm_buf *sb)
 {
         u32 i;
 
         if (!sb || !sb->pg_list || !sb->pg_list_cnt)
                 return;
 
         for (i = 0; i < sb->pg_list_cnt; i++)
                 optee_host_page_free(&sb->pg_list[i]);
 
         vmm_free(sb->pg_list);
         sb->pg_list = NULL;
         sb->pg_list_cnt = 0;
 }
 
 static void optee_free_tmp_shm_buf(struct optee_ctx *ctx,
                                    struct optee_shm_buf *sb)
 {
         if (!ctx || !sb)
                 return;
 
         vmm_spin_lock(&ctx->lock);
         if (ctx->shm_buf_count)
                 ctx->shm_buf_count--;
         if (ctx->shm_page_count >= sb->page_cnt)
                 ctx->shm_page_count -= sb->page_cnt;
         else
                 ctx->shm_page_count = 0;
         vmm_spin_unlock(&ctx->lock);
 
         optee_release_tmp_shm_buf_pages(sb);
         vmm_free(sb);
 }
 
 static void optee_free_call_tmp_shm(struct optee_ctx *ctx,
                                     struct optee_std_call *call)
 {
         struct optee_shm_buf *sb, *next;
 
         if (!ctx || !call)
                 return;
 
         sb = call->tmp_shm_bufs;
         while (sb) {
                 next = sb->next;
                 optee_free_tmp_shm_buf(ctx, sb);
                 sb = next;
         }
 
         call->tmp_shm_bufs = NULL;
         call->rpc_data_sb = NULL;
 }
 
 /* -------------------------------------------------------------------------- */
 /* RPC SHM management */
 
 static struct optee_shm_rpc *optee_alloc_shm_rpc(struct optee_ctx *ctx,
                                                  u64 cookie,
                                                  physical_addr_t guest_cmd_gpa)
 {
         struct optee_shm_rpc *sr;
         int rc;
 
         sr = vmm_zalloc(sizeof(*sr));
         if (!sr)
                 return NULL;
 
         sr->cookie = cookie;
         sr->guest_cmd_gpa = guest_cmd_gpa;
 
         rc = optee_host_page_alloc(&sr->hos_arg_pg, OPTEE_PAGE_SIZE);
         if (rc != VMM_OK) {
                 vmm_free(sr);
                 return NULL;
         }
 
         vmm_spin_lock(&ctx->lock);
         sr->next = ctx->shm_rpcs;
         ctx->shm_rpcs = sr;
         vmm_spin_unlock(&ctx->lock);
 
         return sr;
 }
 
 static void optee_free_shm_rpc(struct optee_ctx *ctx, u64 cookie)
 {
         struct optee_shm_rpc *sr;
 
         vmm_spin_lock(&ctx->lock);
         sr = optee_find_shm_rpc(ctx, cookie);
         if (sr)
                 optee_remove_shm_rpc_locked(ctx, sr);
         vmm_spin_unlock(&ctx->lock);
 
         if (!sr)
                 return;
 
         optee_host_page_free(&sr->hos_arg_pg);
         vmm_free(sr);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Standard call context */
 
 static struct optee_std_call *optee_alloc_call(struct optee_ctx *ctx, int *error)
 {
         struct optee_std_call *c;
         int rc;
 
         if (error)
                 *error = VMM_OK;
 
         vmm_spin_lock(&ctx->lock);
         if (ctx->call_count >= ctx->max_calls) {
                 OPTEE_FLOW_DBG("call limit hit: client_id=%u call_count=%u max_calls=%u",
                                ctx->client_id, ctx->call_count, ctx->max_calls);
                 vmm_spin_unlock(&ctx->lock);
                 if (error)
                         *error = VMM_ENOSPC;
                 return NULL;
         }
         ctx->call_count++;
         vmm_spin_unlock(&ctx->lock);
 
         c = vmm_zalloc(sizeof(*c));
         if (!c) {
                 vmm_spin_lock(&ctx->lock);
                 ctx->call_count--;
                 vmm_spin_unlock(&ctx->lock);
                 if (error)
                         *error = VMM_ENOMEM;
                 return NULL;
         }
 
         rc = optee_host_page_alloc(&c->hos_arg_pg, OPTEE_PAGE_SIZE);
         if (rc != VMM_OK) {
                 vmm_free(c);
                 vmm_spin_lock(&ctx->lock);
                 ctx->call_count--;
                 vmm_spin_unlock(&ctx->lock);
                 if (error)
                         *error = rc;
                 return NULL;
         }
 
         c->arg = (struct optee_msg_arg *)c->hos_arg_pg.va;
         c->thread_id = 0;
         c->in_flight = true;
         c->rpc_func = 0;
         c->rpc_buffer_type = 0;
         c->tmp_shm_bufs = NULL;
         c->rpc_data_sb = NULL;
         c->state = OPTEE_CALL_STATE_NORMAL;
         c->next = NULL;
 
         vmm_spin_lock(&ctx->lock);
         c->next = ctx->calls;
         ctx->calls = c;
         vmm_spin_unlock(&ctx->lock);
 
         OPTEE_FLOW_DBG("alloc_call: ctx=%p call=%p shadow_pa=%#lx shadow_va=%p",
                        ctx, c, c->hos_arg_pg.pa, c->hos_arg_pg.va);
         optee_dump_calls(ctx, "after alloc_call");
 
         return c;
 }
 
 static void optee_put_call(struct optee_ctx *ctx, struct optee_std_call *c)
 {
         if (!c)
                 return;
 
         vmm_spin_lock(&ctx->lock);
         c->in_flight = false;
         vmm_spin_unlock(&ctx->lock);
 
         OPTEE_FLOW_DBG("put_call: ctx=%p call=%p thr=%u state=%u rpc_func=%u",
                        ctx, c, c->thread_id, c->state, c->rpc_func);
         optee_dump_calls(ctx, "after put_call");
 }
 
 static struct optee_std_call *optee_get_call_by_thread(struct optee_ctx *ctx,
                                                        u32 thread_id)
 {
         struct optee_std_call *c;
 
         vmm_spin_lock(&ctx->lock);
         c = optee_find_call_by_thread(ctx, thread_id, true);
         if (c)
                 c->in_flight = true;
         vmm_spin_unlock(&ctx->lock);
 
         if (c) {
                 OPTEE_FLOW_DBG("get_call_by_thread: ctx=%p thr=%u -> call=%p ok",
                                ctx, thread_id, c);
         } else {
                 OPTEE_FLOW_DBG("get_call_by_thread: ctx=%p thr=%u -> NOT FOUND",
                                ctx, thread_id);
                 optee_dump_calls(ctx, "get_call_by_thread miss");
         }
 
         return c;
 }
 
 static void optee_destroy_call(struct optee_ctx *ctx,
                                struct optee_std_call *c)
 {
         if (!c)
                 return;
 
         OPTEE_FLOW_DBG("destroy_call: ctx=%p call=%p thr=%u state=%u rpc_func=%u guest_arg_gpa=%#lx cmd=%u",
                        ctx, c, c->thread_id, c->state, c->rpc_func,
                        c->guest_arg_gpa, c->arg ? c->arg->cmd : 0U);
         optee_dump_calls(ctx, "before destroy_call");
 
         optee_free_call_tmp_shm(ctx, c);
 
         vmm_spin_lock(&ctx->lock);
         optee_remove_call_locked(ctx, c);
         if (ctx->call_count)
                 ctx->call_count--;
         vmm_spin_unlock(&ctx->lock);
 
         optee_host_page_free(&c->hos_arg_pg);
         vmm_free(c);
 }
 
 static void optee_cleanup_runtime(struct optee_ctx *ctx)
 {
         if (!ctx)
                 return;
 
         while (ctx->calls)
                 optee_destroy_call(ctx, ctx->calls);
 
         while (ctx->shm_rpcs)
                 optee_free_shm_rpc(ctx, ctx->shm_rpcs->cookie);
 }

/* -------------------------------------------------------------------------- */
 /* NONCONTIG translation */
 
 static int optee_translate_noncontig(struct optee_ctx *ctx,
                                      struct vmm_guest *guest,
                                      struct optee_std_call *call,
                                      struct optee_msg_param *p,
                                      struct optee_shm_buf **out_sb)
 {
         u64 buf_ptr = p->u.tmem.buf_ptr;
         u64 size = p->u.tmem.size;
         u64 cookie = p->u.tmem.shm_ref;
         unsigned long offset;
         physical_addr_t list_gpa;
         unsigned long total;
         u32 page_cnt;
         u32 list_pages_needed;
         struct optee_shm_buf *sb = NULL;
         struct optee_msg_noncontig_page *guest_pg = NULL;
         u32 gi = 0;
         u32 pi = 0;
         u32 li = 0;
         u32 i, j, n;
         int rc;
 
         if (out_sb)
                 *out_sb = NULL;
 
         if (!call)
                 return VMM_EINVALID;
 
         if (!buf_ptr || !size)
                 return VMM_OK;
 
         offset = (unsigned long)(buf_ptr & VMM_PAGE_MASK);
         list_gpa = (physical_addr_t)VMM_PAGE_ALIGN(buf_ptr);
 
         total = VMM_ROUNDUP2_PAGE_SIZE((unsigned long)size + offset);
         page_cnt = (u32)(total / OPTEE_PAGE_SIZE);
 
         if (!cookie)
                 return VMM_EINVALID;
         if (!page_cnt || page_cnt > OPTEE_MAX_SHM_BUFFER_PG)
                 return VMM_EOVERFLOW;
 
         list_pages_needed = (page_cnt + OPTEE_NONCONTIG_ENTRIES_PER_PAGE - 1U) /
                             OPTEE_NONCONTIG_ENTRIES_PER_PAGE;
 
         sb = optee_alloc_tmp_shm_buf(ctx, cookie, page_cnt);
         if (!sb)
                 return VMM_ENOMEM;
 
         sb->pg_list_cnt = list_pages_needed;
         sb->pg_list = vmm_zalloc(sizeof(struct optee_host_page) * list_pages_needed);
         if (!sb->pg_list) {
                 optee_free_tmp_shm_buf(ctx, sb);
                 return VMM_ENOMEM;
         }
 
         guest_pg = vmm_zalloc(sizeof(*guest_pg));
         if (!guest_pg) {
                 optee_free_tmp_shm_buf(ctx, sb);
                 return VMM_ENOMEM;
         }
 
         for (i = 0; i < list_pages_needed; i++) {
                 rc = optee_host_page_alloc(&sb->pg_list[i], OPTEE_PAGE_SIZE);
                 if (rc != VMM_OK) {
                         for (j = 0; j < i; j++)
                                 optee_host_page_free(&sb->pg_list[j]);
                         vmm_free(sb->pg_list);
                         sb->pg_list = NULL;
                         sb->pg_list_cnt = 0;
                         vmm_free(guest_pg);
                         optee_free_tmp_shm_buf(ctx, sb);
                         return rc;
                 }
         }
 
         for (n = 0; n < page_cnt; n++) {
                 physical_addr_t page_gpa;
                 physical_addr_t page_hpa;
                 struct optee_msg_noncontig_page *host_pg;
 
                 if (gi == 0) {
                         rc = optee_guest_read(guest, list_gpa, guest_pg, sizeof(*guest_pg));
                         if (rc != VMM_OK) {
                                 vmm_free(guest_pg);
                                 optee_free_tmp_shm_buf(ctx, sb);
                                 return rc;
                         }
                 }
 
                 page_gpa = (physical_addr_t)guest_pg->pages[gi];
                 optee_dbg_dump_region(guest, page_gpa, "noncontig.page");
 
                 rc = optee_guest_pa_to_host_pa(guest, page_gpa, &page_hpa);
                 if (rc != VMM_OK) {
                         vmm_free(guest_pg);
                         optee_free_tmp_shm_buf(ctx, sb);
                         return rc;
                 }
 
                 host_pg = (struct optee_msg_noncontig_page *)sb->pg_list[pi].va;
                 host_pg->pages[li] = (u64)page_hpa;
 
                 gi++;
                 li++;
 
                 if (gi >= OPTEE_NONCONTIG_ENTRIES_PER_PAGE) {
                         list_gpa = (physical_addr_t)guest_pg->next;
                         gi = 0;
                 }
 
                 if (li >= OPTEE_NONCONTIG_ENTRIES_PER_PAGE) {
                         if ((pi + 1U) < sb->pg_list_cnt)
                                 host_pg->next = (u64)sb->pg_list[pi + 1U].pa;
                         li = 0;
                         pi++;
                 }
         }
 
         vmm_free(guest_pg);
 
         sb->next = call->tmp_shm_bufs;
         call->tmp_shm_bufs = sb;
 
         if (out_sb)
                 *out_sb = sb;
 
         p->u.tmem.buf_ptr = ((u64)sb->pg_list[0].pa) | (u64)offset;
         return VMM_OK;
 }
 
 /* -------------------------------------------------------------------------- */
 /* Shadow request/response */
 
 static int optee_copy_std_request(struct vmm_guest *guest,
                                   struct optee_std_call *call,
                                   physical_addr_t guest_arg_gpa)
 {
         int rc;
         u32 arg_sz;
 
         optee_dbg_dump_region(guest, guest_arg_gpa, "std_arg");
         rc = optee_dbg_require_ram_region(guest, guest_arg_gpa, "std_arg");
         if (rc != VMM_OK)
                 return rc;
 
         call->guest_arg_gpa = guest_arg_gpa;
 
         rc = optee_guest_read(guest, guest_arg_gpa, call->hos_arg_pg.va,
                               sizeof(struct optee_msg_arg));
         if (rc != VMM_OK)
                 return rc;
 
         arg_sz = OPTEE_MSG_GET_ARG_SIZE(call->arg->num_params);
         if (arg_sz > OPTEE_PAGE_SIZE)
                 return VMM_EOVERFLOW;
 
         return optee_guest_read(guest, guest_arg_gpa, call->hos_arg_pg.va, arg_sz);
 }
 
 static int optee_copy_std_response_back(struct vmm_guest *guest,
                                         struct optee_std_call *call)
 {
         u8 *guest_buf = NULL;
         struct optee_msg_arg hdr;
         struct optee_msg_arg *garg;
         u32 arg_sz;
         int rc;
         u32 n, i;
 
         rc = optee_guest_read(guest, call->guest_arg_gpa, &hdr, sizeof(hdr));
         if (rc != VMM_OK)
                 return rc;
 
         arg_sz = OPTEE_MSG_GET_ARG_SIZE(hdr.num_params);
         if (arg_sz > OPTEE_PAGE_SIZE)
                 return VMM_EOVERFLOW;
 
         guest_buf = vmm_zalloc(arg_sz);
         if (!guest_buf)
                 return VMM_ENOMEM;
 
         rc = optee_guest_read(guest, call->guest_arg_gpa, guest_buf, arg_sz);
         if (rc != VMM_OK) {
                 vmm_free(guest_buf);
                 return rc;
         }
 
         garg = (struct optee_msg_arg *)guest_buf;
         garg->ret = call->arg->ret;
         garg->ret_origin = call->arg->ret_origin;
         garg->session = call->arg->session;
 
         n = (garg->num_params < call->arg->num_params) ?
             garg->num_params : call->arg->num_params;
 
         for (i = 0; i < n; i++) {
                 struct optee_msg_param *gp = &garg->params[i];
                 struct optee_msg_param *hp = &call->arg->params[i];
                 u32 gt = (u32)(gp->attr & OPTEE_MSG_ATTR_TYPE_MASK);
 
                 if (gt == OPTEE_MSG_ATTR_TYPE_VALUE_OUTPUT ||
                     gt == OPTEE_MSG_ATTR_TYPE_VALUE_INOUT) {
                         gp->u.value.a = hp->u.value.a;
                         gp->u.value.b = hp->u.value.b;
                         gp->u.value.c = hp->u.value.c;
                 }
 
                 if (gt == OPTEE_MSG_ATTR_TYPE_TMEM_OUTPUT ||
                     gt == OPTEE_MSG_ATTR_TYPE_TMEM_INOUT)
                         gp->u.tmem.size = hp->u.tmem.size;
 
                 if (gt == OPTEE_MSG_ATTR_TYPE_RMEM_OUTPUT ||
                     gt == OPTEE_MSG_ATTR_TYPE_RMEM_INOUT)
                         gp->u.rmem.size = hp->u.rmem.size;
         }
 
         rc = optee_guest_write(guest, call->guest_arg_gpa, guest_buf, arg_sz);
         vmm_free(guest_buf);
         return rc;
 }
 
 static int optee_translate_params(struct optee_ctx *ctx,
                                   struct vmm_guest *guest,
                                   struct optee_std_call *call,
                                   struct optee_msg_arg *arg)
 {
         u32 i;
 
         for (i = 0; i < arg->num_params; i++) {
                 struct optee_msg_param *p = &arg->params[i];
                 u32 t = (u32)(p->attr & OPTEE_MSG_ATTR_TYPE_MASK);
 
                 if (t == OPTEE_MSG_ATTR_TYPE_TMEM_INPUT ||
                     t == OPTEE_MSG_ATTR_TYPE_TMEM_OUTPUT ||
                     t == OPTEE_MSG_ATTR_TYPE_TMEM_INOUT) {
 
                         if (p->u.tmem.buf_ptr) {
                                 optee_dbg_dump_region(guest,
                                                       (physical_addr_t)p->u.tmem.buf_ptr,
                                                       "tmem.buf_ptr");
                                 if (optee_dbg_require_ram_region(
                                                 guest,
                                                 (physical_addr_t)p->u.tmem.buf_ptr,
                                                 "tmem.buf_ptr") != VMM_OK)
                                         return VMM_EACCESS;
                         }
 
                         if (p->attr & OPTEE_MSG_ATTR_NONCONTIG) {
                                 int rc = optee_translate_noncontig(ctx, guest, call, p, NULL);
                                 if (rc != VMM_OK)
                                         return rc;
                         } else {
                                 /*
                                  * Dynamic SHM mediator supports NONCONTIG guest buffers only.
                                  */
                                 if (p->u.tmem.buf_ptr)
                                         return VMM_EINVALID;
                         }
                 }
         }
 
         return VMM_OK;
 }
 
 /* -------------------------------------------------------------------------- */
 /* RPC helpers */
 
 static int optee_rpc_copy_to_guest(struct vmm_guest *guest,
                                    struct optee_shm_rpc *sr)
 {
         struct optee_msg_arg *xarg = (struct optee_msg_arg *)sr->hos_arg_pg.va;
         u32 sz = OPTEE_MSG_GET_ARG_SIZE(xarg->num_params);
 
         if (sz > OPTEE_PAGE_SIZE)
                 return VMM_EOVERFLOW;
 
         return optee_guest_write(guest, sr->guest_cmd_gpa, xarg, sz);
 }
 
 static int optee_rpc_copy_from_guest(struct vmm_guest *guest,
                                      struct optee_shm_rpc *sr)
 {
         u8 tmp[sizeof(struct optee_msg_arg)];
         struct optee_msg_arg *hdr = (struct optee_msg_arg *)tmp;
         u32 sz;
         int rc;
 
         rc = optee_guest_read(guest, sr->guest_cmd_gpa, tmp, sizeof(tmp));
         if (rc != VMM_OK)
                 return rc;
 
         sz = OPTEE_MSG_GET_ARG_SIZE(hdr->num_params);
         if (sz > OPTEE_PAGE_SIZE)
                 return VMM_EOVERFLOW;
 
         return optee_guest_read(guest, sr->guest_cmd_gpa, sr->hos_arg_pg.va, sz);
 }
 
 static bool optee_issue_rpc_cmd_free(struct optee_ctx *ctx,
                                      struct vmm_vcpu *vcpu,
                                      arch_regs_t *regs,
                                      struct optee_std_call *call,
                                      struct optee_shm_rpc *sr,
                                      u64 cookie_to_free)
 {
         struct optee_msg_arg *xarg = (struct optee_msg_arg *)sr->hos_arg_pg.va;
         u64 reg_hi, reg_lo;
 
         (void)ctx;
 
         memset(xarg, 0, OPTEE_PAGE_SIZE);
         xarg->cmd = OPTEE_RPC_CMD_SHM_FREE;
         xarg->ret = TEEC_ERROR_GENERIC;
         xarg->ret_origin = TEEC_ORIGIN_COMMS;
         xarg->num_params = 1;
         xarg->params[0].attr = OPTEE_MSG_ATTR_TYPE_VALUE_INPUT;
         xarg->params[0].u.value.a = (u64)call->rpc_buffer_type;
         xarg->params[0].u.value.b = cookie_to_free;
         xarg->params[0].u.value.c = 0;
 
         if (optee_rpc_copy_to_guest(vcpu->guest, sr) != VMM_OK)
                 return false;
 
         optee_u64_to_regpair(sr->cookie, &reg_hi, &reg_lo);
         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_RPC_CMD);
         cpu_vcpu_reg_write(vcpu, regs, 1, reg_hi);
         cpu_vcpu_reg_write(vcpu, regs, 2, reg_lo);
 
         call->state = OPTEE_CALL_STATE_HOS_RPC;
         call->rpc_func = OPTEE_SMC_RPC_FUNC_CMD;
 
         return true;
 }
 
 /* -------------------------------------------------------------------------- */
 /* RPC path */
 
 static int optee_handle_rpc_return(struct optee_ctx *ctx,
                                    struct vmm_vcpu *vcpu,
                                    arch_regs_t *regs,
                                    struct optee_std_call *call,
                                    struct arm_smccc_res *res)
 {
         call->thread_id = (u32)(res->a3 & 0xffffffffUL);
         call->rpc_func = OPTEE_SMC_RETURN_GET_RPC_FUNC(res->a0);
 
         OPTEE_FLOW_DBG("handle_rpc_return: call=%p set thr=%u rpc_func=%u raw_a0=%#lx a1=%#lx a2=%#lx a3=%#lx",
                        call, call->thread_id, call->rpc_func,
                        res->a0, res->a1, res->a2, res->a3);
         optee_dump_calls(ctx, "after handle_rpc_return set thread");
 
         cpu_vcpu_reg_write(vcpu, regs, 0, res->a0);
         cpu_vcpu_reg_write(vcpu, regs, 1, res->a1);
         cpu_vcpu_reg_write(vcpu, regs, 2, res->a2);
         cpu_vcpu_reg_write(vcpu, regs, 3, res->a3);
 
         if (call->rpc_func == OPTEE_SMC_RPC_FUNC_FREE) {
                 u64 cookie = optee_regpair_to_u64(res->a1, res->a2);
                 optee_free_shm_rpc(ctx, cookie);
                 return VMM_OK;
         }
 
         if (call->rpc_func == OPTEE_SMC_RPC_FUNC_CMD) {
                 u64 cookie = optee_regpair_to_u64(res->a1, res->a2);
                 struct optee_shm_rpc *sr;
                 struct optee_msg_arg *xarg;
                 int rc;
 
                 vmm_spin_lock(&ctx->lock);
                 sr = optee_find_shm_rpc(ctx, cookie);
                 vmm_spin_unlock(&ctx->lock);
                 if (!sr)
                         return VMM_EAGAIN;
 
                 rc = optee_rpc_copy_to_guest(vcpu->guest, sr);
                 if (rc != VMM_OK)
                         return VMM_EAGAIN;
 
                 xarg = (struct optee_msg_arg *)sr->hos_arg_pg.va;
 
                 if (xarg->num_params >= 1 &&
                     ((xarg->params[0].attr & OPTEE_MSG_ATTR_TYPE_MASK) ==
                      OPTEE_MSG_ATTR_TYPE_VALUE_INPUT)) {
                         call->rpc_buffer_type =
                                 (u32)(xarg->params[0].u.value.a & 0xffffffffUL);
                 }
 
                 return VMM_OK;
         }
 
         return VMM_OK;
 }

static void optee_do_call_with_arg(struct optee_ctx *ctx,
                                    struct vmm_vcpu *vcpu,
                                    arch_regs_t *regs,
                                    struct optee_std_call *call,
                                    unsigned long smc_fid,
                                    unsigned long a1,
                                    unsigned long a2,
                                    unsigned long a3,
                                    unsigned long a4,
                                    unsigned long a5)
 {
         struct arm_smccc_res res;
 
         optee_smc_call(ctx->client_id, smc_fid, a1, a2, a3, a4, a5, 0, &res);
 
         while (OPTEE_SMC_RETURN_IS_RPC(res.a0)) {
                 int rc;
 
                 if (!optee_is_rpc_foreign_intr(res.a0))
                         OPTEE_FLOW_DBG("do_call_with_arg: call=%p got RPC a0=%#lx rpc_func=%u a1=%#lx a2=%#lx a3=%#lx",
                                        call, res.a0,
                                        OPTEE_SMC_RETURN_GET_RPC_FUNC(res.a0),
                                        res.a1, res.a2, res.a3);
 
                 rc = optee_handle_rpc_return(ctx, vcpu, regs, call, &res);
 
                 if (rc == VMM_EAGAIN) {
                         optee_smc_call(ctx->client_id,
                                        res.a0, res.a1, res.a2, res.a3,
                                        0, 0, 0, &res);
                         continue;
                 }
 
                 optee_put_call(ctx, call);
                 return;
         }
 
         optee_copy_std_response_back(vcpu->guest, call);
         cpu_vcpu_reg_write(vcpu, regs, 0, res.a0);
 
         optee_destroy_call(ctx, call);
 }
 
 /* -------------------------------------------------------------------------- */
 /* SMC handlers */
 
 static void optee_handle_exchange_caps(struct optee_ctx *ctx,
                                        struct vmm_vcpu *vcpu,
                                        arch_regs_t *regs)
 {
         struct arm_smccc_res res;
         u32 nsec_caps = (u32)cpu_vcpu_reg_read(vcpu, regs, 1);
         u32 sec_caps;
 
         nsec_caps &= OPTEE_KNOWN_NSEC_CAPS;
 
         optee_smc_call(ctx->client_id,
                        OPTEE_SMC_EXCHANGE_CAPABILITIES,
                        (unsigned long)nsec_caps, 0, 0, 0, 0, 0, &res);
 
         if ((u32)res.a0 != OPTEE_SMC_RETURN_OK) {
                 cpu_vcpu_reg_write(vcpu, regs, 0, res.a0);
                 cpu_vcpu_reg_write(vcpu, regs, 1, res.a1);
                 cpu_vcpu_reg_write(vcpu, regs, 2, res.a2);
                 cpu_vcpu_reg_write(vcpu, regs, 3, res.a3);
                 return;
         }
 
         sec_caps = (u32)res.a1;
         sec_caps &= OPTEE_KNOWN_SEC_CAPS;
 
         /* Guests must not use global static SHM in this mediator. */
         sec_caps &= ~OPTEE_SMC_SEC_CAP_HAVE_RESERVED_SHM;
 
         if (!(sec_caps & OPTEE_SMC_SEC_CAP_DYNAMIC_SHM)) {
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ENOTAVAIL);
                 cpu_vcpu_reg_write(vcpu, regs, 1, sec_caps);
                 return;
         }
 
         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_OK);
         cpu_vcpu_reg_write(vcpu, regs, 1, sec_caps);
         cpu_vcpu_reg_write(vcpu, regs, 2, res.a2);
         cpu_vcpu_reg_write(vcpu, regs, 3, res.a3);
 }
 
 static void optee_handle_get_thread_count(struct optee_ctx *ctx,
                                           struct vmm_vcpu *vcpu,
                                           arch_regs_t *regs)
 {
         struct arm_smccc_res res;
         u32 secure_threads, max_calls, guest_threads;

         /* Query with this Guest's client ID, never a Guest-supplied a7. */
         optee_smc_call(ctx->client_id, OPTEE_SMC_GET_THREAD_COUNT,
                        0, 0, 0, 0, 0, 0, &res);
         if ((u32)res.a0 != OPTEE_SMC_RETURN_OK) {
                 /* On failure the ABI preserves a1-a7. */
                 cpu_vcpu_reg_write(vcpu, regs, 0, res.a0);
                 return;
         }

         secure_threads = (u32)res.a1;
         vmm_spin_lock(&ctx->lock);
         max_calls = ctx->max_calls;
         vmm_spin_unlock(&ctx->lock);

         /* Report total capacity, not max_calls minus active calls. */
         guest_threads = secure_threads < max_calls ? secure_threads : max_calls;
         if (!guest_threads) {
                 cpu_vcpu_reg_write(vcpu, regs, 0,
                                    OPTEE_SMC_RETURN_UNKNOWN_FUNCTION);
                 return;
         }

         OPTEE_FLOW_DBG("get_thread_count: client_id=%u secure=%u limit=%u exposed=%u",
                        ctx->client_id, secure_threads, max_calls, guest_threads);
         /* The successful query only changes a0 and a1; preserve a2-a7. */
         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_OK);
         cpu_vcpu_reg_write(vcpu, regs, 1, guest_threads);
 }

 static void optee_handle_get_shm_config(struct vmm_vcpu *vcpu, arch_regs_t *regs)
 {
         /* multi-VM mediator forbids global static SHM for guests */
         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ENOTAVAIL);
 }
 
 static void optee_handle_std_call(struct optee_ctx *ctx,
                                   struct vmm_vcpu *vcpu,
                                   arch_regs_t *regs)
 {
         struct optee_std_call *call;
         int error = VMM_OK;
         u64 gpa;
         unsigned long a3 = (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 3);
         u64 reg_hi, reg_lo;
         u32 arg_sz;
         int rc;
 
         gpa = optee_regpair_to_u64(cpu_vcpu_reg_read(vcpu, regs, 1),
                                    cpu_vcpu_reg_read(vcpu, regs, 2));
 
         call = optee_alloc_call(ctx, &error);
         if (!call) {
                 if (error == VMM_ENOSPC)
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ETHREAD_LIMIT);
                 else
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ENOMEM);
                 return;
         }
 
         rc = optee_copy_std_request(vcpu->guest, call, (physical_addr_t)gpa);
         if (rc != VMM_OK) {
                 optee_destroy_call(ctx, call);
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_EBADADDR);
                 return;
         }
 
         arg_sz = OPTEE_MSG_GET_ARG_SIZE(call->arg->num_params);
         if (arg_sz > OPTEE_PAGE_SIZE) {
                 optee_destroy_call(ctx, call);
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_EBADADDR);
                 return;
         }
 
         rc = optee_translate_params(ctx, vcpu->guest, call, call->arg);
         if (rc != VMM_OK) {
                 call->arg->ret = TEEC_ERROR_COMMUNICATION;
                 call->arg->ret_origin = TEEC_ORIGIN_COMMS;
                 optee_copy_std_response_back(vcpu->guest, call);
                 optee_destroy_call(ctx, call);
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_OK);
                 return;
         }
 
         optee_u64_to_regpair(call->hos_arg_pg.pa, &reg_hi, &reg_lo);
 
         optee_do_call_with_arg(ctx, vcpu, regs, call,
                                OPTEE_SMC_CALL_WITH_ARG,
                                (unsigned long)reg_hi, (unsigned long)reg_lo,
                                a3, 0, 0);
 }
 
 static void optee_handle_rpc(struct optee_ctx *ctx,
                              struct vmm_vcpu *vcpu,
                              arch_regs_t *regs)
 {
         u32 thread_id = (u32)(cpu_vcpu_reg_read(vcpu, regs, 3) & 0xffffffffUL);
         struct optee_std_call *call = optee_get_call_by_thread(ctx, thread_id);
 
         if (!call) {
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ERESUME);
                 return;
         }
 
         if (call->rpc_func == OPTEE_SMC_RPC_FUNC_ALLOC) {
                 u64 ptr = optee_regpair_to_u64(cpu_vcpu_reg_read(vcpu, regs, 1),
                                                cpu_vcpu_reg_read(vcpu, regs, 2));
                 u64 cookie = optee_regpair_to_u64(cpu_vcpu_reg_read(vcpu, regs, 4),
                                                   cpu_vcpu_reg_read(vcpu, regs, 5));
                 struct optee_shm_rpc *sr;
                 u64 reg_hi, reg_lo;
 
                 if (optee_dbg_require_ram_region(vcpu->guest,
                                                  (physical_addr_t)ptr,
                                                  "rpc_alloc.ptr") != VMM_OK) {
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_EBADADDR);
                         optee_destroy_call(ctx, call);
                         return;
                 }
 
                 if (ptr & VMM_PAGE_MASK) {
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_EBADADDR);
                         optee_destroy_call(ctx, call);
                         return;
                 }
 
                 if (!optee_alloc_shm_rpc(ctx, cookie, (physical_addr_t)ptr)) {
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ENOMEM);
                         optee_destroy_call(ctx, call);
                         return;
                 }
 
                 vmm_spin_lock(&ctx->lock);
                 sr = optee_find_shm_rpc(ctx, cookie);
                 vmm_spin_unlock(&ctx->lock);
 
                 optee_u64_to_regpair(sr->hos_arg_pg.pa, &reg_hi, &reg_lo);
 
                 optee_do_call_with_arg(ctx, vcpu, regs, call,
                                        OPTEE_SMC_CALL_RETURN_FROM_RPC,
                                        (unsigned long)reg_hi, (unsigned long)reg_lo,
                                        thread_id,
                                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 4),
                                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 5));
                 return;
         }
 
         if (call->rpc_func == OPTEE_SMC_RPC_FUNC_CMD) {
                 u64 cookie = optee_regpair_to_u64(cpu_vcpu_reg_read(vcpu, regs, 1),
                                                   cpu_vcpu_reg_read(vcpu, regs, 2));
                 struct optee_shm_rpc *sr;
                 struct optee_msg_arg *xarg;
                 int rc;
 
                 vmm_spin_lock(&ctx->lock);
                 sr = optee_find_shm_rpc(ctx, cookie);
                 vmm_spin_unlock(&ctx->lock);
 
                 if (!sr) {
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ERESUME);
                         optee_destroy_call(ctx, call);
                         return;
                 }
 
                 rc = optee_rpc_copy_from_guest(vcpu->guest, sr);
                 if (rc != VMM_OK) {
                         cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_SMC_RETURN_ERESUME);
                         optee_destroy_call(ctx, call);
                         return;
                 }
 
                 xarg = (struct optee_msg_arg *)sr->hos_arg_pg.va;
 
                 if (call->state == OPTEE_CALL_STATE_HOS_RPC) {
                         call->state = OPTEE_CALL_STATE_NORMAL;
                         memset(xarg, 0, OPTEE_PAGE_SIZE);
                         xarg->ret = TEEC_ERROR_GENERIC;
                         xarg->ret_origin = TEEC_ORIGIN_COMMS;
                         xarg->num_params = 0;
                 } else {
                         if (xarg->num_params >= 1) {
                                 struct optee_msg_param *p0 = &xarg->params[0];
                                 u32 t0 = (u32)(p0->attr & OPTEE_MSG_ATTR_TYPE_MASK);
 
                                 if ((p0->attr & OPTEE_MSG_ATTR_NONCONTIG) &&
                                     (t0 == OPTEE_MSG_ATTR_TYPE_TMEM_OUTPUT ||
                                      t0 == OPTEE_MSG_ATTR_TYPE_TMEM_INOUT)) {
 
                                         if (call->rpc_data_sb) {
                                                 optee_release_tmp_shm_buf_pages(call->rpc_data_sb);
                                                 call->rpc_data_sb = NULL;
                                         }
 
                                         rc = optee_translate_noncontig(ctx, vcpu->guest,
                                                                        call, p0,
                                                                        &call->rpc_data_sb);
                                         if (rc != VMM_OK) {
                                                 u64 cfree = p0->u.tmem.shm_ref;
 
                                                 call->rpc_data_sb = NULL;
 
                                                 if (optee_issue_rpc_cmd_free(ctx, vcpu, regs,
                                                                              call, sr, cfree)) {
                                                         optee_put_call(ctx, call);
                                                         return;
                                                 }
 
                                                 memset(xarg, 0, OPTEE_PAGE_SIZE);
                                                 xarg->ret = TEEC_ERROR_GENERIC;
                                                 xarg->ret_origin = TEEC_ORIGIN_COMMS;
                                                 xarg->num_params = 0;
                                         }
                                 }
                         }
                 }
 
                 optee_do_call_with_arg(ctx, vcpu, regs, call,
                                        OPTEE_SMC_CALL_RETURN_FROM_RPC,
                                        0, 0, thread_id, 0, 0);
                 return;
         }
 
         optee_do_call_with_arg(ctx, vcpu, regs, call,
                                OPTEE_SMC_CALL_RETURN_FROM_RPC,
                                0, 0, thread_id, 0, 0);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Fastcall passthrough */
 
 static inline void optee_forward_x0_to_x3(struct optee_ctx *ctx,
                                           struct vmm_vcpu *vcpu,
                                           arch_regs_t *regs,
                                           unsigned long fid)
 {
         struct arm_smccc_res res;
 
         optee_smc_call(ctx->client_id,
                        fid,
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 1),
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 2),
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 3),
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 4),
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 5),
                        (unsigned long)cpu_vcpu_reg_read(vcpu, regs, 6),
                        &res);
 
         cpu_vcpu_reg_write(vcpu, regs, 0, res.a0);
         cpu_vcpu_reg_write(vcpu, regs, 1, res.a1);
         cpu_vcpu_reg_write(vcpu, regs, 2, res.a2);
         cpu_vcpu_reg_write(vcpu, regs, 3, res.a3);
 }
 
 /* -------------------------------------------------------------------------- */
 /* Probe */
 
 static bool optee_probe(void)
 {
         struct arm_smccc_res res;
         u32 nsec_caps = OPTEE_KNOWN_NSEC_CAPS;
 
         optee_lock_init_once();
 
         optee_smc_call_host(OPTEE_SMC_CALLS_UID, 0, 0, 0, 0, 0, 0, &res);
         vmm_init_printf("OPTEE: CALLS_UID = %08lx %08lx %08lx %08lx\n",
                         res.a0, res.a1, res.a2, res.a3);
 
         if (res.a0 != OPTEE_MSG_UID_0 || res.a1 != OPTEE_MSG_UID_1 ||
             res.a2 != OPTEE_MSG_UID_2 || res.a3 != OPTEE_MSG_UID_3) {
                 vmm_printf("OPTEE: UID mismatch, not OP-TEE?\n");
                 return false;
         }
 
         optee_smc_call_host(OPTEE_SMC_GET_THREAD_COUNT, 0, 0, 0, 0, 0, 0, &res);
         if ((u32)res.a0 == OPTEE_SMC_RETURN_OK && (u32)res.a1 > 0)
                 optee_max_threads = (u32)res.a1;
 
         optee_smc_call_host(OPTEE_SMC_EXCHANGE_CAPABILITIES,
                             (unsigned long)nsec_caps, 0, 0, 0, 0, 0, &res);
 
         if ((u32)res.a0 != OPTEE_SMC_RETURN_OK) {
                 vmm_printf("OPTEE: host EXCHANGE_CAPS failed: a0=%#lx\n", res.a0);
                 optee_host_probe_done = false;
                 return false;
         }
 
         optee_host_sec_caps = (u32)res.a1;
         optee_dyn_shm_supported = !!(optee_host_sec_caps & OPTEE_SMC_SEC_CAP_DYNAMIC_SHM);
         optee_virt_supported = !!(optee_host_sec_caps & OPTEE_SMC_SEC_CAP_VIRTUALIZATION);
         optee_host_probe_done = true;
 
         optee_dump_host_caps(optee_host_sec_caps, res.a2, res.a3);
 
         if (!optee_dyn_shm_supported || !optee_virt_supported) {
                 vmm_printf("OPTEE: multi-VM dynamic SHM not possible: sec_caps=0x%x\n",
                            optee_host_sec_caps);
                 return false;
         }
 
         return true;
 }
 
 /* -------------------------------------------------------------------------- */
 /* Guest lifecycle */
 
 static int optee_guest_init(struct vmm_guest *guest)
 {
         struct optee_ctx *ctx;
 
         if (!guest)
                 return VMM_EINVALID;
         if (!optee_host_probe_done)
                 return VMM_ENOTAVAIL;
 
         ctx = vmm_zalloc(sizeof(*ctx));
         if (!ctx)
                 return VMM_ENOMEM;
 
         ctx->client_id = (u32)guest->id + 1U;
         ctx->max_calls = optee_max_threads ? optee_max_threads : 1U;
         ctx->max_shm_bufs = OPTEE_MAX_SHM_BUFS_DEFAULT;
         ctx->max_shm_pages = OPTEE_MAX_SHM_PAGES_DEFAULT;
         ctx->vm_live = false;
         ctx->call_count = 0;
         ctx->shm_buf_count = 0;
         ctx->shm_page_count = 0;
         ctx->calls = NULL;
         ctx->shm_rpcs = NULL;
         INIT_SPIN_LOCK(&ctx->lock);
 
         arm_guest_priv(guest)->tee = ctx;
         vmm_init_printf("OPTEE: bound guest '%s' id=%u -> client_id=%u\n",
                         guest->name, guest->id, ctx->client_id);
         return VMM_OK;
 }

static int optee_guest_start(struct vmm_guest *guest)
 {
         struct optee_ctx *ctx;
         struct arm_smccc_res res;
 
         if (!guest)
                 return VMM_EINVALID;
 
         ctx = (struct optee_ctx *)arm_guest_priv(guest)->tee;
         if (!ctx)
                 return VMM_EFAIL;
 
         if (ctx->vm_live)
                 return VMM_OK;
 
         optee_smc_call_host(OPTEE_SMC_VM_CREATED,
                             (unsigned long)ctx->client_id,
                             0, 0, 0, 0, 0, &res);
         if ((u32)res.a0 != OPTEE_SMC_RETURN_OK) {
                 vmm_printf("OPTEE: VM_CREATED vm id=%u failed: a0=%#lx\n",
                            ctx->client_id, res.a0);
                 return VMM_EFAIL;
         }
 
         ctx->vm_live = true;
         return VMM_OK;
 }
 
 static int optee_guest_stop(struct vmm_guest *guest)
 {
         struct optee_ctx *ctx;
         struct arm_smccc_res res;
 
         if (!guest)
                 return VMM_EINVALID;
 
         ctx = (struct optee_ctx *)arm_guest_priv(guest)->tee;
         if (!ctx)
                 return VMM_OK;
 
         if (ctx->vm_live) {
                 optee_smc_call_host(OPTEE_SMC_VM_DESTROYED,
                                     (unsigned long)ctx->client_id,
                                     0, 0, 0, 0, 0, &res);
                 if ((u32)res.a0 != OPTEE_SMC_RETURN_OK) {
                         vmm_printf("OPTEE: VM_DESTROYED vm id=%u failed: a0=%#lx\n",
                                    ctx->client_id, res.a0);
                         return VMM_EFAIL;
                 }
                 ctx->vm_live = false;
         }
 
         optee_cleanup_runtime(ctx);
         return VMM_OK;
 }
 
 static int optee_guest_teardown(struct vmm_guest *guest)
 {
         struct optee_ctx *ctx;
         int rc;
 
         if (!guest)
                 return VMM_EINVALID;
 
         ctx = (struct optee_ctx *)arm_guest_priv(guest)->tee;
         if (!ctx)
                 return VMM_OK;
 
         rc = optee_guest_stop(guest);
         if (rc)
                 return rc;
 
         arm_guest_priv(guest)->tee = NULL;
         vmm_free(ctx);
         return VMM_OK;
 }
 
 /* -------------------------------------------------------------------------- */
 /* Main handler */
 
 static bool optee_handle_call(struct vmm_vcpu *vcpu, arch_regs_t *regs)
 {
         struct optee_ctx *ctx;
         u32 fid;
 
         if (!vcpu || !regs)
                 return false;
 
         ctx = (struct optee_ctx *)arm_guest_priv(vcpu->guest)->tee;
         if (!ctx)
                 return false;
 
         fid = (u32)(cpu_vcpu_reg_read(vcpu, regs, 0) & 0xffffffffUL);
 
         switch (fid) {
         case OPTEE_SMC_CALLS_COUNT:
                 cpu_vcpu_reg_write(vcpu, regs, 0, OPTEE_MEDIATOR_SMC_COUNT);
                 return true;
 
         case OPTEE_SMC_CALLS_UID:
         case OPTEE_SMC_CALLS_REVISION:
         case OPTEE_SMC_CALL_GET_OS_UUID:
         case OPTEE_SMC_CALL_GET_OS_REVISION:
         case OPTEE_SMC_ENABLE_SHM_CACHE:
         case OPTEE_SMC_DISABLE_SHM_CACHE:
                 optee_forward_x0_to_x3(ctx, vcpu, regs, (unsigned long)fid);
                 return true;
 
         case OPTEE_SMC_EXCHANGE_CAPABILITIES:
                 optee_handle_exchange_caps(ctx, vcpu, regs);
                 return true;
 
         case OPTEE_SMC_GET_THREAD_COUNT:
                 optee_handle_get_thread_count(ctx, vcpu, regs);
                 return true;

         case OPTEE_SMC_GET_SHM_CONFIG:
                 optee_handle_get_shm_config(vcpu, regs);
                 return true;
 
         case OPTEE_SMC_CALL_WITH_ARG:
                 optee_handle_std_call(ctx, vcpu, regs);
                 return true;
 
         case OPTEE_SMC_CALL_RETURN_FROM_RPC:
                 optee_handle_rpc(ctx, vcpu, regs);
                 return true;
 
         default:
                 return false;
         }
 }
 
 /* -------------------------------------------------------------------------- */
 
 static const struct tee_mediator_ops optee_ops = {
         .probe = optee_probe,
         .guest_init = optee_guest_init,
         .guest_start = optee_guest_start,
         .guest_stop = optee_guest_stop,
         .guest_teardown = optee_guest_teardown,
         .handle_call = optee_handle_call,
 };
 
 REGISTER_TEE_MEDIATOR(optee, "OP-TEE", TEE_TYPE_OPTEE, &optee_ops);
