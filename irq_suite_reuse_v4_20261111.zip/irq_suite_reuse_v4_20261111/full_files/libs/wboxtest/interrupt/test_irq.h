/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __WBOXTEST_IRQ_H__
#define __WBOXTEST_IRQ_H__

#include <libs/stringlib.h>
#include <libs/wboxtest.h>
#include <vmm_delay.h>
#include <vmm_error.h>
#include <vmm_host_irq.h>
#include <vmm_modules.h>
#include <vmm_scheduler.h>
#include <vmm_semaphore.h>
#include <vmm_smp.h>
#include <vmm_stdio.h>
#include <vmm_threads.h>
#include <vmm_timer.h>
#include <vmm_types.h>

/* Runtime candidates, not proof that the board has reserved these IRQs. */
#define TEST_IRQ_SPI_COUNT 6U
extern u32 test_irq_spi_ids[TEST_IRQ_SPI_COUNT];

/* Call at the start of every serial .run(), before any SPI access. */
int test_irq_select_spis(struct vmm_chardev *cdev);

#define SPI_ID1 (test_irq_spi_ids[0])
#define SPI_ID2 (test_irq_spi_ids[1])
#define SPI_ID3 (test_irq_spi_ids[2])
#define SPI_ID4 (test_irq_spi_ids[3])
#define SPI_ID5 (test_irq_spi_ids[4])
#define SPI_ID6 (test_irq_spi_ids[5])

/* SGIs retain the existing configuration; they are not auto-selected. */
#define SGI_ID1 5U
#define SGI_ID2 6U

#define TEST_IRQ_SGI1 6U
#define TEST_IRQ_SGI2 7U
#define TEST_IRQ_TOTAL 8U
#define TEST_IRQ_HW_STATE \
	(VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_MASKED)

struct test_irq_result {
	u32 calls;
	u32 cpu;
	u32 order;
	u64 latency_ns;
	int mask_rc;
};

/* A successful begin must have exactly one matching end, also on test failure. */
int test_irq_begin(struct vmm_chardev *out, u32 test_hcpu, u32 sgi_count);
int test_irq_end(struct vmm_chardev *out, int test_rc);
u32 test_irq_id(u32 slot);
u32 test_irq_cpu(void);
int test_irq_register(u32 slot, const char *name);
int test_irq_unregister(u32 slot);
int test_irq_set_priority(u32 slot, u8 priority);
int test_irq_set_affinity(u32 slot, const struct vmm_cpumask *mask);
int test_irq_set_trigger(u32 slot, u32 trigger);
int test_irq_mask(u32 slot);
int test_irq_unmask(u32 slot);
int test_irq_pair(u32 a, u32 b, u32 expected_first);
int test_irq_sgi(u32 slot);
int test_irq_software(u32 slot, bool active);
void test_irq_result(u32 slot, struct test_irq_result *result);
int test_irq_pmr(u32 slot);

#endif
