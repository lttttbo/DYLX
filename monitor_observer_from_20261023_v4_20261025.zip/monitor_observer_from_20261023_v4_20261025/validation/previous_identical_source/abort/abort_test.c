
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef u64 physical_addr_t;
typedef u64 physical_size_t;
typedef struct { u64 pc,pstate; } arch_regs_t;
struct vmm_guest { int ttbl; };
struct vmm_vcpu { struct vmm_guest *guest; };
struct mmu_page { u64 ia,oa,sz; u32 flags; };
#define VMM_OK 0
#define VMM_EFAIL -1
#define TRUE 1
#define VMM_REGION_ISRAM 256
#define VMM_REGION_ISROM 512
#define TTBL_L3_MAP_MASK (~4095ULL)
#define TTBL_L2_MAP_MASK (~((1ULL<<21)-1))
#define TTBL_L1_MAP_MASK (~((1ULL<<30)-1))
#define TTBL_L3_BLOCK_SIZE 4096
#define TTBL_L2_BLOCK_SIZE (1ULL<<21)
#define TTBL_L1_BLOCK_SIZE (1ULL<<30)
#define VMM_MONITOR_MAP_REJECT 2
#define VMM_MONITOR_PERMISSION 4
#define MMU_STAGE2 2
#define PSR_THUMB_ENABLED 32
#define PAR_PA_MASK (~4095ULL)
#define VA2PA_STAGE12 0
#define VA2PA_EL1 0
#define VA2PA_RD 0
#define arm_guest_priv(g) (g)
#define mrs(reg) (fake_##reg)
#define vmm_printf(...) ((void)0)
#define va2pa_at(a,b,c,d) ((void)0)
static u64 fake_far_el2=0xabcdef,fake_par_el1=0x1234000,last_addr,last_detail;
static int map_fail,map_page_fail,recheck_fail,faults,last_kind,emulated;
static void vmm_monitor_mem_fault(struct vmm_vcpu *v,u32 kind,u64 address,u64 detail) {
    (void)v; faults++; last_kind=kind; last_addr=address; last_detail=detail;
}
static int vmm_guest_physical_map(struct vmm_guest *g,u64 in,u64 size,u64 *out,u64 *available,u32 *flags) {
    (void)g; *out=in; *available=size; *flags=VMM_REGION_ISRAM; return map_fail?-1:0;
}
static void arch_mmu_pgflags_set(u32 *f,int stage,u32 flags) { (void)stage; *f=flags; }
static int mmu_map_page(int table,struct mmu_page *p) { (void)table; (void)p; return map_page_fail?-1:0; }
static int mmu_get_page(int table,u64 addr,struct mmu_page *p) { (void)table; (void)addr; (void)p; return recheck_fail?-1:0; }
static u32 vmm_host_memory_read(u64 addr,void *out,u32 size,int cacheable) { (void)addr; (void)cacheable; memset(out,0,size); return size; }
static int emulate_arm_inst(struct vmm_vcpu *v,arch_regs_t *r,u32 inst) { (void)v; (void)r; (void)inst; emulated++; return 0; }
static int emulate_thumb_inst(struct vmm_vcpu *v,arch_regs_t *r,u32 inst) { return emulate_arm_inst(v,r,inst); }
static int cpu_vcpu_emulate_load(struct vmm_vcpu *v,arch_regs_t *r,u32 il,u32 iss,u64 addr) { (void)il; (void)addr; return emulate_arm_inst(v,r,iss); }
static int cpu_vcpu_emulate_store(struct vmm_vcpu *v,arch_regs_t *r,u32 il,u32 iss,u64 addr) { return cpu_vcpu_emulate_load(v,r,il,iss,addr); }
#define ISS_ABORT_ISV_MASK				0x01000000
#define ISS_ABORT_SAS_MASK				0x00C00000
#define ISS_ABORT_SSE_MASK				0x00200000
#define ISS_ABORT_SRT_MASK				0x001F0000
#define ISS_ABORT_SF_MASK				0x00008000
#define ISS_ABORT_AR_MASK				0x00004000
#define ISS_ABORT_EA_MASK				0x00000200
#define ISS_ABORT_CM_MASK				0x00000100
#define ISS_ABORT_S1PTW_MASK				0x00000080
#define ISS_ABORT_WNR_MASK				0x00000040
#define ISS_ABORT_FSC_MASK				0x0000003F
#define FSC_TRANS_FAULT_LEVEL0				0x04
#define FSC_TRANS_FAULT_LEVEL1				0x05
#define FSC_TRANS_FAULT_LEVEL2				0x06
#define FSC_TRANS_FAULT_LEVEL3				0x07
#define FSC_ACCESS_FAULT_LEVEL0				0x08
#define FSC_ACCESS_FAULT_LEVEL1				0x09
#define FSC_ACCESS_FAULT_LEVEL2				0x0A
#define FSC_ACCESS_FAULT_LEVEL3				0x0B
#define FSC_PERM_FAULT_LEVEL0				0x0C
#define FSC_PERM_FAULT_LEVEL1				0x0D
#define FSC_PERM_FAULT_LEVEL2				0x0E
#define FSC_PERM_FAULT_LEVEL3				0x0F
#define FSC_SYNC_EXTERNAL_ABORT				0x10
#define FSC_ASYNC_EXTERNAL_ABORT			0x11
#define FSC_SYNC_TWALK_EXTERNAL_ABORT_LEVEL0		0x14
#define FSC_SYNC_TWALK_EXTERNAL_ABORT_LEVEL1		0x15
#define FSC_SYNC_TWALK_EXTERNAL_ABORT_LEVEL2		0x16
#define FSC_SYNC_TWALK_EXTERNAL_ABORT_LEVEL3		0x17
#define FSC_SYNC_PARITY_ERROR				0x18
#define FSC_ASYNC_PARITY_ERROR				0x19
#define FSC_SYNC_TWALK_PARITY_ERROR_LEVEL0		0x1C
#define FSC_SYNC_TWALK_PARITY_ERROR_LEVEL1		0x1D
#define FSC_SYNC_TWALK_PARITY_ERROR_LEVEL2		0x1E
#define FSC_SYNC_TWALK_PARITY_ERROR_LEVEL3		0x1F
#define FSC_ALIGN_FAULT					0x21
#define FSC_DEBUG_EVENT					0x22
#define FSC_TLB_CONFLICT_ABORT				0x30
#define FSC_DOMAIN_FAULT_LEVEL0				0x3C
#define FSC_DOMAIN_FAULT_LEVEL1				0x3D
#define FSC_DOMAIN_FAULT_LEVEL2				0x3E
#define FSC_DOMAIN_FAULT_LEVEL3				0x3F
static int cpu_vcpu_stage2_map(struct vmm_vcpu *vcpu,
			       arch_regs_t *regs,
			       physical_addr_t fipa)
{
	int rc, rc1;
	u32 reg_flags = 0x0, pg_reg_flags = 0x0;
	struct mmu_page pg;
	physical_addr_t inaddr, outaddr;
	physical_size_t size, availsz;

	memset(&pg, 0, sizeof(pg));

	inaddr = fipa & TTBL_L3_MAP_MASK;
	size = TTBL_L3_BLOCK_SIZE;

	rc = vmm_guest_physical_map(vcpu->guest, inaddr, size,
				    &outaddr, &availsz, &reg_flags);
	if (rc) {
		vmm_monitor_mem_fault(vcpu, VMM_MONITOR_MAP_REJECT, fipa, rc);
		vmm_printf("%s: IPA=0x%lx size=0x%lx map failed\n",
			   __func__, inaddr, size);
		return rc;
	}

	if (availsz < TTBL_L3_BLOCK_SIZE) {
		vmm_printf("%s: availsz=0x%lx insufficent for IPA=0x%lx\n",
			   __func__, availsz, inaddr);
		return VMM_EFAIL;
	}

	pg.ia = inaddr;
	pg.sz = size;
	pg.oa = outaddr;
	pg_reg_flags = reg_flags;

	if (reg_flags & (VMM_REGION_ISRAM | VMM_REGION_ISROM)) {
		inaddr = fipa & TTBL_L2_MAP_MASK;
		size = TTBL_L2_BLOCK_SIZE;
		rc = vmm_guest_physical_map(vcpu->guest, inaddr, size,
				    &outaddr, &availsz, &reg_flags);
		if (!rc && (availsz >= TTBL_L2_BLOCK_SIZE)) {
			pg.ia = inaddr;
			pg.sz = size;
			pg.oa = outaddr;
			pg_reg_flags = reg_flags;
		}
		inaddr = fipa & TTBL_L1_MAP_MASK;
		size = TTBL_L1_BLOCK_SIZE;
		rc = vmm_guest_physical_map(vcpu->guest, inaddr, size,
				    &outaddr, &availsz, &reg_flags);
		if (!rc && (availsz >= TTBL_L1_BLOCK_SIZE)) {
			pg.ia = inaddr;
			pg.sz = size;
			pg.oa = outaddr;
			pg_reg_flags = reg_flags;
		}
	}

	arch_mmu_pgflags_set(&pg.flags, MMU_STAGE2, pg_reg_flags);

	/* Try to map the page in Stage2 */
	rc = mmu_map_page(arm_guest_priv(vcpu->guest)->ttbl, &pg);
	if (rc) {
		/* On SMP Guest, two different VCPUs may try to map same
		 * Guest region in Stage2 at the same time. This may cause
		 * mmu_lpae_map_page() to fail for one of the Guest VCPUs.
		 *
		 * To take care of this situation, we recheck Stage2 mapping
		 * when mmu_lpae_map_page() fails.
		 */
		memset(&pg, 0, sizeof(pg));
		rc1 = mmu_get_page(arm_guest_priv(vcpu->guest)->ttbl,
				   fipa, &pg);
		if (rc1) {
			return rc1;
		}
		rc = VMM_OK;
	}

	return rc;
}

int cpu_vcpu_inst_abort(struct vmm_vcpu *vcpu,
			arch_regs_t *regs,
			u32 il, u32 iss,
			physical_addr_t fipa)
{
	if ((iss & ISS_ABORT_FSC_MASK) >= FSC_PERM_FAULT_LEVEL0 &&
	    (iss & ISS_ABORT_FSC_MASK) <= FSC_PERM_FAULT_LEVEL3)
		/* HPFAR is not universally valid for permission faults. Record FAR
		 * as a virtual address; ISS.FnV tells consumers when it is invalid. */
		vmm_monitor_mem_fault(vcpu, VMM_MONITOR_PERMISSION, mrs(far_el2), iss);

	switch (iss & ISS_ABORT_FSC_MASK) {
	case FSC_TRANS_FAULT_LEVEL1:
	case FSC_TRANS_FAULT_LEVEL2:
	case FSC_TRANS_FAULT_LEVEL3:
		return cpu_vcpu_stage2_map(vcpu, regs, fipa);
	default:
		break;
	};

	return VMM_EFAIL;
}

int cpu_vcpu_data_abort(struct vmm_vcpu *vcpu,
			arch_regs_t *regs,
			u32 il, u32 iss,
			physical_addr_t fipa)
{
	u32 read_count, inst;
	physical_addr_t inst_pa;

	if ((iss & ISS_ABORT_FSC_MASK) >= FSC_PERM_FAULT_LEVEL0 &&
	    (iss & ISS_ABORT_FSC_MASK) <= FSC_PERM_FAULT_LEVEL3)
		/* HPFAR is not universally valid for permission faults. Record FAR
		 * as a virtual address; ISS.FnV tells consumers when it is invalid. */
		vmm_monitor_mem_fault(vcpu, VMM_MONITOR_PERMISSION, mrs(far_el2), iss);

	switch (iss & ISS_ABORT_FSC_MASK) {
	case FSC_TRANS_FAULT_LEVEL1:
	case FSC_TRANS_FAULT_LEVEL2:
	case FSC_TRANS_FAULT_LEVEL3:
		return cpu_vcpu_stage2_map(vcpu, regs, fipa);
	case FSC_ACCESS_FAULT_LEVEL1:
	case FSC_ACCESS_FAULT_LEVEL2:
	case FSC_ACCESS_FAULT_LEVEL3:
		if (!(iss & ISS_ABORT_ISV_MASK)) {
			/* Determine instruction physical address */
			va2pa_at(VA2PA_STAGE12, VA2PA_EL1, VA2PA_RD, regs->pc);
			inst_pa = mrs(par_el1);
			inst_pa &= PAR_PA_MASK;
			inst_pa |= (regs->pc & 0x00000FFF);

			/* Read the faulting instruction */
			/* FIXME: Should this be cacheable memory access ? */
			read_count = vmm_host_memory_read(inst_pa,
						&inst, sizeof(inst), TRUE);
			if (read_count != sizeof(inst)) {
				return VMM_EFAIL;
			}
			if (regs->pstate & PSR_THUMB_ENABLED) {
				return emulate_thumb_inst(vcpu, regs, inst);
			} else {
				return emulate_arm_inst(vcpu, regs, inst);
			}
		}
		if (iss & ISS_ABORT_WNR_MASK) {
			return cpu_vcpu_emulate_store(vcpu, regs,
						      il, iss, fipa);
		} else {
			return cpu_vcpu_emulate_load(vcpu, regs,
						     il, iss, fipa);
		}
	default:
		vmm_printf("%s: Unhandled FSC=0x%x\n",
			   __func__, iss & ISS_ABORT_FSC_MASK);
		break;
	};

	return VMM_EFAIL;
}


int main(void) {
    struct vmm_guest g={0}; struct vmm_vcpu v={&g}; arch_regs_t regs={0}; int n;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    assert(!cpu_vcpu_inst_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    map_page_fail=1;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    recheck_fail=1; assert(cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    map_page_fail=recheck_fail=0; map_fail=1;
    assert(cpu_vcpu_inst_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x5000));
    assert(faults==1 && last_kind==2 && last_addr==0x5000); map_fail=0;
    assert(cpu_vcpu_data_abort(&v,&regs,1,FSC_PERM_FAULT_LEVEL3|0x400,0xdead));
    assert(faults==2 && last_kind==4 && last_addr==fake_far_el2 && (last_detail&0x400));
    assert(cpu_vcpu_inst_abort(&v,&regs,1,FSC_PERM_FAULT_LEVEL1,0xdead) && faults==3);
    n=faults;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3|ISS_ABORT_ISV_MASK,0x6000));
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3|ISS_ABORT_ISV_MASK|ISS_ABORT_WNR_MASK,0x6000));
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3,0x6000));
    assert(faults==n && emulated==3);
    puts("PASS: lazy map and SMP recovery not alarms; denied mapping/permission logged; FAR/FnV preserved; MMIO not misclassified");
    return 0;
}
