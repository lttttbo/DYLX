/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"

static int lifecycle_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	int rc=VMM_OK;
	struct mt_global g;
	struct mt_snapshot s;
	struct mt_event e;
	u32 epoch;
	(void)test; (void)cpu;
	mt_begin();
	mt_exits(0,1,1); mt_snapshot(0,&s); MT_CHECK(!s.present);
	MT_CHECK(mt_enable(TRUE)==VMM_OK); mt_global(&g); epoch=g.epoch;
	MT_CHECK(epoch && g.enabled==epoch);
	MT_CHECK(mt_enable(TRUE)==VMM_OK); mt_global(&g); MT_CHECK(g.epoch==epoch);
	mt_record(0,MON_STATE,VMM_VCPU_STATE_READY,mt_now()); mt_exits(0,1,1);
	mt_fault(mt_vcpu(0),VMM_MONITOR_PERMISSION,0x1234,7);
	MT_CHECK(mt_enable(FALSE)==VMM_OK);
	mt_exits(0,100,1); mt_snapshot(0,&s); MT_CHECK(s.exits==1);
	mt_sample(mt_now()+VMM_MONITOR_NS);
	MT_CHECK(mt_event(1,&e) && e.type==3 && e.epoch==epoch && e.value==1);
	MT_CHECK(mt_enable(TRUE)==VMM_OK);
	MT_CHECK(mt_command("status",NULL,NULL)==VMM_OK);
	MT_CHECK(!strstr(mt_output(),"\"vcpu\":")); /* stale epoch hidden */
	mt_record(0,MON_SELECTED,mt_now(),0); mt_snapshot(0,&s);
	MT_CHECK(s.epoch!=epoch && s.present && !s.ready.count && !s.exits);
	mt_fault(mt_vcpu(0),VMM_MONITOR_MAP_REJECT,0x2000,1);
	mt_record(0,MON_STATE,VMM_VCPU_STATE_UNKNOWN,mt_now());
	mt_snapshot(0,&s); MT_CHECK(!s.present && mt_event(2,&e) && e.address==0x2000);
	mt_vcpu(0)->is_normal=FALSE; mt_vcpu(0)->guest=NULL;
	mt_record(0,MON_STATE,VMM_VCPU_STATE_RESET,mt_now());
	mt_record(0,MON_DISPATCH,10,30); mt_snapshot(0,&s);
	MT_CHECK(s.kind==1 && s.guest==~0U && s.dispatch.count==1 && !s.ready.count);
	mt_vcpu(0)->id=MT_COUNT; mt_record(0,MON_DISPATCH,10,50); mt_snapshot(0,&s);
	MT_CHECK(s.dispatch.count==1); mt_vcpu(0)->id=0;
	mt_vcpu(1)->guest=NULL; mt_exits(1,10,1); mt_snapshot(1,&s);
	MT_CHECK(!s.present); /* malformed normal vCPU rejected before dereference */
	MT_CHECK(mt_enable(FALSE)==VMM_OK);
	mt_record(0,MON_STATE,VMM_VCPU_STATE_UNKNOWN,mt_now()); mt_snapshot(0,&s);
	MT_CHECK(!s.present && !s.dispatch.count && !mt_overflow());
out:
	mt_end(); return rc;
}
MT_REGISTER(monitor_lifecycle, lifecycle_run);

static int config_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	int rc=VMM_OK;
	u32 i, seq;
	struct mt_global before, after;
	const char *bad[]={"","0","-1","+1","1.0","100x","0x64"," 100","100 ",
		"4294967296","18446744073709551616","1000000001"};
	const u32 bounds[][2]={{1,1000000000},{1,60},{1,1000},{1000,10000}};
	(void)test; (void)cpu;
	mt_begin();
	MT_CHECK(mt_enable(TRUE)==VMM_OK);
	MT_CHECK(mt_command("config","exit_limit","100")==VMM_OK);
	MT_CHECK(!strcmp(mt_output(),"OK: exit_limit=100\n"));
	mt_global(&before);
	for (i=0;i<sizeof(bad)/sizeof(bad[0]);i++) {
		MT_CHECK(mt_command("config","exit_limit",bad[i])!=VMM_OK);
		mt_global(&after); MT_CHECK(after.config_seq==before.config_seq);
		MT_CHECK(!memcmp(before.config,after.config,sizeof(before.config)));
		MT_CHECK(!strchr(mt_output(),'{'));
	}
	MT_CHECK(mt_command("config","unknown","100")!=VMM_OK);
	for (i=0;i<VMM_MONITOR_CONFIG_KEYS;i++) {
		MT_CHECK(mt_config(i,bounds[i][0])==VMM_OK);
		MT_CHECK(mt_config(i,bounds[i][1])==VMM_OK);
		mt_global(&before); seq=before.config_seq;
		MT_CHECK(mt_config(i,bounds[i][1])==VMM_OK);
		mt_global(&after); MT_CHECK(after.config_seq==seq);
		MT_CHECK(mt_config(i,bounds[i][0]-1)!=VMM_OK);
		MT_CHECK(mt_config(i,bounds[i][1]+1)!=VMM_OK);
		mt_global(&after); MT_CHECK(after.config_seq==seq);
	}
	MT_CHECK(mt_config(VMM_MONITOR_CONFIG_KEYS,1)!=VMM_OK);
	MT_CHECK(mt_command("config",NULL,NULL)==VMM_OK && !strchr(mt_output(),'{'));
	MT_CHECK(!mt_overflow());
out:
	mt_end(); return rc;
}
MT_REGISTER(monitor_config, config_run);
