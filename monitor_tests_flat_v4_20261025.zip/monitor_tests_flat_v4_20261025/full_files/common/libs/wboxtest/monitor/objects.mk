libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/support.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/lifecycle.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/scheduler.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/memory.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/storm.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/output.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/memory_runtime.o

# guest_cases.c preserves the existing Guest-assisted cases; not built in this phase.
