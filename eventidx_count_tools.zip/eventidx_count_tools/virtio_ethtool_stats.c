/* Optional read-only ETHTOOL_G* helper. No kernel/DSM modification.
 * Usage: virtio_ethtool_stats -S eth0
 * Useful on Android images without the ethtool executable.
 * Build with the target toolchain (see README); do not run a host x86 binary there.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <inttypes.h>
#include <linux/ethtool.h>
#include <linux/if.h>
#include <linux/sockios.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

static int query(int fd, const char *ifname, void *data)
{
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    memcpy(ifr.ifr_name, ifname, strlen(ifname) + 1);
    ifr.ifr_data = (char *)data;
    return ioctl(fd, SIOCETHTOOL, &ifr);
}
int main(int argc, char **argv)
{
    struct ethtool_drvinfo info;
    struct ethtool_gstrings *names = NULL;
    struct ethtool_stats *stats = NULL;
    const char *ifname;
    uint32_t n, i;
    int fd = -1, rc = EXIT_FAILURE;
    if (argc != 3 || strcmp(argv[1], "-S") ||
        !argv[2][0] || strlen(argv[2]) >= IFNAMSIZ) {
        fprintf(stderr, "Usage: %s -S interface\n", argv[0]);
        return EXIT_FAILURE;
    }
    ifname = argv[2];
    fd = socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
    if (fd < 0) { perror("socket"); goto out; }
    memset(&info, 0, sizeof(info));
    info.cmd = ETHTOOL_GDRVINFO;
    if (query(fd, ifname, &info) < 0) { perror("ETHTOOL_GDRVINFO"); goto out; }
    n = info.n_stats;
    if (!n || n > 65536U) {
        fprintf(stderr, "Unsupported/invalid driver statistics count: %u\n", n);
        goto out;
    }
    names = calloc(1, sizeof(*names) + (size_t)n * ETH_GSTRING_LEN);
    stats = calloc(1, sizeof(*stats) + (size_t)n * sizeof(uint64_t));
    if (!names || !stats) { perror("calloc"); goto out; }
    names->cmd = ETHTOOL_GSTRINGS;
    names->string_set = ETH_SS_STATS;
    names->len = n;
    if (query(fd, ifname, names) < 0) { perror("ETHTOOL_GSTRINGS"); goto out; }
    if (names->len != n) { fprintf(stderr, "Statistics layout changed\n"); goto out; }
    stats->cmd = ETHTOOL_GSTATS;
    stats->n_stats = n;
    if (query(fd, ifname, stats) < 0) { perror("ETHTOOL_GSTATS"); goto out; }
    if (stats->n_stats != n) { fprintf(stderr, "Statistics layout changed\n"); goto out; }
    printf("NIC statistics (driver=%.*s):\n", (int)sizeof(info.driver), info.driver);
    for (i = 0; i < n; i++)
        printf("    %.*s: %" PRIu64 "\n", ETH_GSTRING_LEN,
               (char *)names->data + (size_t)i * ETH_GSTRING_LEN,
               (uint64_t)stats->data[i]);
    if (fflush(stdout) != 0) { perror("stdout"); goto out; }
    rc = EXIT_SUCCESS;
out:
    free(names);
    free(stats);
    if (fd >= 0) close(fd);
    return rc;
}
