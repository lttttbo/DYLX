/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
#include <vmm_timer.h>
#include <vmm_smp.h>
#include <vmm_scheduler.h>
#include <vmm_mutex.h>
#include <vmm_cmdmgr.h>
#include <arch_barrier.h>
#include <libs/mathlib.h>

/* Compile the actual implementation under private names. No live monitor
 * slots, scheduler objects, timers, workqueues or log sinks are used. Keep
 * platform headers above these macros so their declarations remain intact. */
static DEFINE_MUTEX(fixture_lock);
static struct vmm_vcpu actors[MT_COUNT];
static struct vmm_guest guests[2];
static u64 test_time;
static u32 test_cpu;
static u32 log_count;
static char output[8192];
static char log_line[384];
static u32 output_used;
static bool overflow;

static u64 mt_clock(void)
{
	return test_time;
}

static u32 mt_processor(void)
{
	return test_cpu;
}

static struct vmm_vcpu *mt_idle(u32 cpu)
{
	return cpu ? NULL : &actors[MT_IDLE];
}

static int mt_print(struct vmm_chardev *c, const char *fmt, ...)
{
	int n;
	va_list ap;
	(void)c;
	va_start(ap, fmt);
	n = __vmm_snprintf(output + output_used, sizeof(output) - output_used, fmt, ap);
	va_end(ap);
	if (n < 0 || (u32)n >= sizeof(output) - output_used) {
		overflow = TRUE;
	} else {
		output_used += n;
	}
	return n;
}

static void mt_warning(const char *prefix, const char *fmt, ...)
{
	int n;
	va_list ap;
	if (strcmp(prefix, "monitor")) {
		overflow = TRUE;
	}
	va_start(ap, fmt);
	n = __vmm_snprintf(log_line, sizeof(log_line), fmt, ap);
	va_end(ap);
	if (n < 0 || (u32)n >= sizeof(log_line)) {
		overflow = TRUE;
	}
	log_count++;
}

static int mt_command_registry_stub(struct vmm_cmd *cmd)
{
	(void)cmd;
	return VMM_OK;
}

#undef CONFIG_MAX_VCPU_COUNT
#define CONFIG_MAX_VCPU_COUNT MT_COUNT
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
#define CONFIG_MONITOR_EXTERNAL_EXECUTOR 1
#endif
#undef CONFIG_MONITOR_START_ENABLED
/* Live inspection belongs only to the production monitor instance. */
#undef CONFIG_WBOXTEST_MONITOR
/* Private init is executed for each test; it must not live in freed init text. */
#undef __init
#define __init
#undef VMM_EXPORT_SYMBOL
#define VMM_EXPORT_SYMBOL(symbol)
#define vmm_monitor_ready wb_agent_ready
#define vmm_monitor_record wb_agent_record
#define vmm_monitor_enable wb_agent_enable
#define vmm_monitor_configure wb_agent_configure
#define vmm_monitor_sample wb_agent_sample
#define vmm_monitor_drain wb_agent_drain
#define vmm_monitor_dump wb_agent_dump
#define vmm_monitor_init wb_agent_init
#define vmm_timer_timestamp mt_clock
#undef vmm_smp_processor_id
#define vmm_smp_processor_id mt_processor
#define vmm_scheduler_idle_vcpu mt_idle
#define vmm_cprintf mt_print
#undef vmm_lwarning
#define vmm_lwarning(prefix, msg...) mt_warning(prefix, msg)
#define vmm_cmdmgr_register_cmd mt_command_registry_stub
#define vmm_cmdmgr_unregister_cmd mt_command_registry_stub
#include "../../../core/monitor/monitor_agent.c"

/* Compile the command parser without a second real command module.
 * The unused helper references init/exit for strict warning checks only.
 * Restore the framework macro after this private source inclusion. */
#pragma push_macro("VMM_DECLARE_MODULE")
#undef VMM_DECLARE_MODULE
#define VMM_DECLARE_MODULE(desc, author, license, priority, init, exit) \
	static void __attribute__((unused)) mt_command_module(void) \
	{ \
		(void)init; \
		(void)exit; \
	}
#include "../../../commands/cmd_monitor.c"
#pragma pop_macro("VMM_DECLARE_MODULE")

void mt_reset(void)
{
	u32 i;
	memset(slots, 0, sizeof(slots));
	memset(ring, 0, sizeof(ring));
	memset(actors, 0, sizeof(actors));
	memset(guests, 0, sizeof(guests));
	for (i = 0; i < MT_COUNT; i++) {
		actors[i].id = i;
	}
	guests[1].id = 1;
	for (i = 0; i < 2; i++) {
		actors[i].is_normal = TRUE;
		actors[i].guest = &guests[i];
	}
	INIT_SPIN_LOCK(&event_lock);
	head = 0;
	lost = 0;
	epoch = 0;
	sampler_cpu = 0;
	cursor = 1;
	arch_atomic_write(&enabled, 0);
	arch_atomic_write(&initialized, 0);
	arch_atomic_write(&skipped, 0);
	arch_atomic_write(&errors, 0);
	config.value[0] = CONFIG_MONITOR_EXIT_RATE;
	config.value[1] = CONFIG_MONITOR_STORM_SECONDS;
	config.value[2] = 750;
	config.value[3] = 1250;
	config.seq = 1;
	test_time = 100 * VMM_MONITOR_NS;
	test_cpu = 0;
	log_count = 0;
	output_used = 0;
	output[0] = 0;
	log_line[0] = 0;
	overflow = FALSE;
	/* External-executor init only initializes this instance's locks/atomics. */
	wb_agent_init();
}

void mt_begin(void)
{
	vmm_mutex_lock(&fixture_lock);
	mt_reset();
}

void mt_end(void)
{
	vmm_mutex_unlock(&fixture_lock);
}

u64 mt_now(void)
{
	return test_time;
}

void mt_time(u64 ns)
{
	test_time = ns;
}

void mt_cpu(u32 cpu)
{
	test_cpu = cpu;
}

struct vmm_vcpu *mt_vcpu(u32 id)
{
	return id < MT_COUNT ? &actors[id] : NULL;
}

int mt_enable(bool on)
{
	return wb_agent_enable(on);
}

int mt_config(u32 key, u32 value)
{
	return wb_agent_configure(key, value);
}

void mt_record(u32 id, u32 hook, u64 a, u64 b)
{
	wb_agent_record(mt_vcpu(id), hook, a, b);
}

void mt_fault(struct vmm_vcpu *v, u32 kind, u64 addr, u64 detail)
{
	wb_agent_record(v, MON_FAULT + kind, addr, detail);
}

void mt_exits(u32 id, u32 count, u32 reason)
{
	while (count--) {
		wb_agent_record(mt_vcpu(id), MON_EXIT, reason, 0);
	}
}

void mt_sample(u64 now)
{
	test_time = now;
	wb_agent_sample(now);
}

void mt_sample_skip(u32 id, u64 now)
{
	irq_flags_t f;
	if (id > MT_COUNT) {
		return;
	}
	vmm_spin_lock_irqsave_lite(&slots[id].lock, f);
	mt_sample(now);
	vmm_spin_unlock_irqrestore_lite(&slots[id].lock, f);
}

void mt_drain(void)
{
	wb_agent_drain();
}

void mt_snapshot(u32 id, struct mt_snapshot *s)
{
	struct data *d;
	memset(s, 0, sizeof(*s));
	if (id > MT_COUNT) {
		return;
	}
	d = &slots[id].d;
	s->ready = (struct mt_latency){d->ready.count, d->ready.sum, d->ready.max};
	s->dispatch = (struct mt_latency){d->dispatch.count, d->dispatch.sum, d->dispatch.max};
	s->ready_since = d->ready_since;
	s->exits = d->exits;
	s->count = d->count;
	s->interval = d->interval;
	s->sustained = d->sustained;
	s->epoch = d->epoch;
	s->guest = d->guest;
	s->kind = d->kind;
	s->windows = d->windows;
	s->present = d->present;
	s->waiting = d->waiting;
	s->active = d->active;
	s->valid = d->valid;
}

void mt_global(struct mt_global *g)
{
	g->head = head;
	g->cursor = cursor;
	g->lost = lost;
	g->epoch = epoch;
	g->enabled = arch_atomic_read(&enabled);
	g->skipped = arch_atomic_read(&skipped);
	g->logs = log_count;
	g->config_seq = config.seq;
	memcpy(g->config, config.value, sizeof(g->config));
}

bool mt_event(u64 seq, struct mt_event *out)
{
	struct event e;
	if (!event_get(seq, &e)) {
		return FALSE;
	}
	*out = (struct mt_event){e.seq,	   e.time,	 e.last,     e.value, e.address,
				 e.detail, e.type,	 e.guest,    e.vcpu,  e.epoch,
				 e.code,   e.config_seq, e.sustain_s};
	return TRUE;
}

int mt_command(const char *verb, const char *key, const char *value)
{
	char *args[] = {(char *)"monitor", (char *)verb, (char *)key, (char *)value};
	output_used = 0;
	output[0] = 0;
	return monitor_exec(NULL, key ? 4 : 2, args);
}

const char *mt_output(void)
{
	return output;
}

const char *mt_log(void)
{
	return log_line;
}

bool mt_overflow(void)
{
	return overflow;
}
