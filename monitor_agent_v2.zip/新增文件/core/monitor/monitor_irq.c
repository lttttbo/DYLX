/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <vmm_smp.h>
#include <vmm_modules.h>
#include <arch_atomic64.h>

/* One slot per outstanding physical-to-virtual delivery, not per interrupt.
 * Static storage: no changes to the allocation size of Guest/VGIC objects.
 * Caller holds VGIC dist_lock for pending/injected/reset routing operations.
 */
struct pending_irq { u64 start; u32 virq; };
static struct {
	vmm_spinlock_t lock;
	u64 epoch_ns;
	struct pending_irq irq[CONFIG_MONITOR_IRQ_SLOTS];
} pending[CONFIG_MAX_VCPU_COUNT];
static struct vmm_monitor_hirq_context current[CONFIG_CPU_COUNT];
static atomic64_t untracked = { 0 };

/* Called once from monitor init, before collection can be enabled. */
void vmm_monitor_irq_init(void)
{
	u32 i;
	for (i = 0; i < CONFIG_MAX_VCPU_COUNT; i++)
		INIT_SPIN_LOCK(&pending[i].lock);
}

void vmm_monitor_irq_restart(u64 now)
{
	u32 v, i;
	irq_flags_t flags;
	for (v = 0; v < CONFIG_MAX_VCPU_COUNT; v++) {
		vmm_spin_lock_irqsave_lite(&pending[v].lock, flags);
		pending[v].epoch_ns = now;
		for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++)
			pending[v].irq[i].start = 0;
		vmm_spin_unlock_irqrestore_lite(&pending[v].lock, flags);
	}
}

struct vmm_monitor_hirq_context vmm_monitor_hirq_enter(u32 hirq)
{
	u32 cpu = vmm_smp_processor_id();
	struct vmm_monitor_hirq_context old = current[cpu];
	current[cpu].timestamp_ns = vmm_monitor_enabled() ? vmm_timer_timestamp() : 0;
	current[cpu].hirq = hirq;
	return old;
}

void vmm_monitor_hirq_exit(struct vmm_monitor_hirq_context old)
{
	current[vmm_smp_processor_id()] = old;
}

void vmm_monitor_irq_reset(struct vmm_vcpu *v)
{
	u32 i;
	irq_flags_t flags;
	if (!v || !v->is_normal || v->id >= CONFIG_MAX_VCPU_COUNT)
		return;
	vmm_spin_lock_irqsave_lite(&pending[v->id].lock, flags);
	pending[v->id].epoch_ns = vmm_timer_timestamp();
	for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++)
		pending[v->id].irq[i].start = 0;
	vmm_spin_unlock_irqrestore_lite(&pending[v->id].lock, flags);
}

void vmm_monitor_irq_pending(struct vmm_vcpu *v, u32 virq, u32 hirq)
{
	struct vmm_monitor_hirq_context c;
	if (!vmm_monitor_enabled() || !v || !v->is_normal ||
	    v->id >= CONFIG_MAX_VCPU_COUNT || hirq == VMM_MONITOR_UNKNOWN)
		return;
	c = current[vmm_smp_processor_id()];
	/* Do not pair an unrelated interrupt or a software-generated assertion. */
	if (!c.timestamp_ns || c.hirq != hirq) {
		arch_atomic64_inc(&untracked);
		return;
	}
	vmm_monitor_irq_pending_at(v, virq, c.timestamp_ns);
}

void vmm_monitor_irq_pending_at(struct vmm_vcpu *v, u32 virq, u64 start)
{
	u32 i, free_slot = CONFIG_MONITOR_IRQ_SLOTS;
	irq_flags_t flags;
	struct pending_irq *p;
	if (!vmm_monitor_enabled() || !v || !v->is_normal ||
	    v->id >= CONFIG_MAX_VCPU_COUNT || !start) return;
	vmm_spin_lock_irqsave_lite(&pending[v->id].lock, flags);
	if (!vmm_monitor_enabled() || start < pending[v->id].epoch_ns)
		goto done;
	p = pending[v->id].irq;
	for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++) {
		if (p[i].start && p[i].virq == virq)
			goto done; /* Coalesced level: preserve earliest receipt. */
		if (!p[i].start)
			free_slot = i;
	}
	if (free_slot < CONFIG_MONITOR_IRQ_SLOTS) {
		p[free_slot].virq = virq;
		p[free_slot].start = start;
	} else {
		arch_atomic64_inc(&untracked);
	}
done:
	vmm_spin_unlock_irqrestore_lite(&pending[v->id].lock, flags);
}

/* Caller serializes the real IRQ route/MOVI with pending/injection operations. */
void vmm_monitor_irq_move(struct vmm_vcpu *from, struct vmm_vcpu *to, u32 virq)
{
	u32 first, second, i, free_slot = CONFIG_MONITOR_IRQ_SLOTS;
	u64 start = 0;
	irq_flags_t f1, f2;
	struct pending_irq *p;
	if (!vmm_monitor_enabled() || !from || !to || !from->is_normal || !to->is_normal ||
	    from->id >= CONFIG_MAX_VCPU_COUNT || to->id >= CONFIG_MAX_VCPU_COUNT ||
	    from->id == to->id || from->guest != to->guest) return;
	first = from->id < to->id ? from->id : to->id;
	second = from->id < to->id ? to->id : from->id;
	vmm_spin_lock_irqsave_lite(&pending[first].lock, f1);
	vmm_spin_lock_irqsave_lite(&pending[second].lock, f2);
	for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++)
		if (pending[from->id].irq[i].start && pending[from->id].irq[i].virq == virq) {
			start = pending[from->id].irq[i].start; pending[from->id].irq[i].start = 0; break;
		}
	if (!start) goto done;
	if (start < pending[to->id].epoch_ns) goto lost;
	p = pending[to->id].irq;
	for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++) {
		if (p[i].start && p[i].virq == virq) {
			if (start < p[i].start) p[i].start = start;
			goto done;
		}
		if (!p[i].start) free_slot = i;
	}
	if (free_slot < CONFIG_MONITOR_IRQ_SLOTS) {
		p[free_slot].virq = virq; p[free_slot].start = start; goto done;
	}
lost:
	arch_atomic64_inc(&untracked);
done:
	vmm_spin_unlock_irqrestore_lite(&pending[second].lock, f2);
	vmm_spin_unlock_irqrestore_lite(&pending[first].lock, f1);
}

static void irq_finish(struct vmm_vcpu *v, u32 virq, bool injected)
{
	u32 i;
	u64 start = 0, end;
	irq_flags_t flags;
	if (!vmm_monitor_enabled() || !v || !v->is_normal || v->id >= CONFIG_MAX_VCPU_COUNT)
		return;
	end = injected ? vmm_timer_timestamp() : 0;
	vmm_spin_lock_irqsave_lite(&pending[v->id].lock, flags);
	for (i = 0; i < CONFIG_MONITOR_IRQ_SLOTS; i++) {
		if (pending[v->id].irq[i].start && pending[v->id].irq[i].virq == virq) {
			start = pending[v->id].irq[i].start;
			pending[v->id].irq[i].start = 0;
			break;
		}
	}
	vmm_spin_unlock_irqrestore_lite(&pending[v->id].lock, flags);
	if (start && end)
		vmm_monitor_irq_sample(v, start, end);
}

void vmm_monitor_irq_injected(struct vmm_vcpu *v, u32 virq)
{
	irq_finish(v, virq, TRUE);
}

void vmm_monitor_irq_cancel(struct vmm_vcpu *v, u32 virq)
{
	irq_finish(v, virq, FALSE);
}

u64 vmm_monitor_irq_untracked(void)
{
	return arch_atomic64_read(&untracked);
}
VMM_EXPORT_SYMBOL(vmm_monitor_irq_pending);
VMM_EXPORT_SYMBOL(vmm_monitor_irq_pending_at);
VMM_EXPORT_SYMBOL(vmm_monitor_irq_move);
VMM_EXPORT_SYMBOL(vmm_monitor_irq_injected);
VMM_EXPORT_SYMBOL(vmm_monitor_irq_cancel);
