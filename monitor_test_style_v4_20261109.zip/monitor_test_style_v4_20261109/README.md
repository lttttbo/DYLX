# HOS monitor v4：其余测试文件编码风格修正版

日期：2026-11-09。交付目录：`D:\code\monitor_archive\v4\2026-11-09\04_test_style`。

这次整理当前 monitor 测试目录中尚未做 style 修正的文件。除排版外，为去掉 `goto`，将清理动作移到外层执行函数；原有测试场景、判定条件、错误返回及资源释放顺序保持一致。

## 基线与适用范围

核对基线为 `monitor_lock_retry_v4_20261109` 对应的完整源码树；本次涉及的测试文件沿用前面的 monitor 测试版本。`file_manifest.json` 给出每个文件修改前后的 SHA-256，私有工程有额外改动时请按函数合并。

本包不包含你已经调整过的 `commands/cmd_monitor.c`、`core/include/vmm_monitor.h`、`core/monitor/monitor_agent.c`、`libs/wboxtest/monitor/storm_runtime.c`，也不包含生产打点文件。本包不会回退近期采样取锁诊断或有界重试修改。

`objects.mk`、`openconf.cfg` 保持原样，仍使用同一个 `CONFIG_WBOXTEST_MONITOR` 开关。没有新增固件头文件、编译开关或测试场景。

## 文件范围

所有固件文件仍位于 `libs/wboxtest/monitor/`。

| 文件 | 本次整理 |
| --- | --- |
| common.h | 拆开结构成员；整理声明与宏；由 MT_REGISTER 生成统一的测试入口，负责 mt_begin/mt_end；MT_CHECK 失败直接返回 |
| support.c | 展开压缩的条件、循环和多条赋值；逐行声明；保留独立测试实例及全部符号重命名 |
| lifecycle.c | 整理 lifecycle_run、config_run；由注册入口负责测试环境加锁、复位与解锁 |
| scheduler.c | 整理 scheduler_run；保持原有 ready、dispatch 和状态切换断言 |
| memory.c | 整理内存后端和 memory_run；保留 vmm_shmem_reserve 等私有重命名，避免符号重复定义 |
| storm.c | 整理 prime、window、storm_run；保留阈值、连续窗口、去重、恢复及配置切换断言 |
| output.c | 整理 output_run；保留命令输出、日志回调、事件环和最大数值检查 |
| memory_runtime.c | 整理真实主机内存用例；统一 begin/end；拆出 shmem_check，外层 shmem_run 负责对象销毁 |
| guest_cases.c（可选） | 整理历史 Guest 辅助用例；统一 ml_begin/ml_end；拆出 schedule_check，外层 schedule_run 负责线程停止和销毁 |

前 8 个文件位于 `full_files/`，对应 `changes.patch`。最后一个文件位于 `optional_files/`，对应 `optional_guest_cases.patch`。`guest_cases.c` 在当前基线中未加入编译；如果你的目录没有它，无需添加，也无需应用可选补丁。

当前启用的测试名称和数量保持不变：六个隔离用例（config、lifecycle、scheduler、memory、storm、output），三个 host 内存用例，以及已有的 storm_runtime，共十项。

## 去掉 goto 后如何保证清理

### 隔离用例

原来的 `MT_CHECK` 跳到每个函数末尾的 `out`，那里调用 `mt_end()`。

现在 `MT_REGISTER` 生成外层入口：

```c
mt_begin();
rc = runfn(test, out, cpu);
mt_end();
return rc;
```

`MT_CHECK` 只返回测试结果，所有正常返回和断言失败返回都会回到外层，因此 `mt_end()` 仍只调用一次。`mt_begin()` 仍包含环境锁定和私有实例复位。测试函数内部主动调用的 `mt_reset()` 保留。

**common.h 与 lifecycle.c、scheduler.c、memory.c、storm.c、output.c 必须一起合入。** 不要把新宏与旧用例函数混用：旧函数自己调用 mt_begin/mt_end，可能造成重复加锁或重复解锁。

### 主机内存用例

`HOST_REGISTER` 生成入口，先 `begin()`，成功后运行检查，最终总是执行 `end()`。`begin()` 会先清零上下文，`end()` 根据 `locked` 判断是否释放锁，因此初始化部分失败时也能正确清理。

`shmem_run()` 负责创建和销毁共享内存对象，`shmem_check()` 负责原来的检查。检查失败返回后，仍先销毁对象，再回到注册入口释放测试锁。对象创建失败时直接返回，不销毁无效指针。

### 历史 Guest 辅助用例（可选）

`ML_REGISTER` 统一负责 `ml_begin()` / `ml_end()`。调度场景由 `schedule_check()` 执行，`schedule_run()` 保存工作线程句柄并负责停止、销毁；线程成功创建后的失败路径也会进入清理。停止失败时仍尝试销毁，沿用原有行为。

本包只是整理这一份保留源码，没有启用它，也没有把它的外部触发条件并入当前测试组。

## 统一编码约定

- 所有 if、else 和循环体使用花括号；else if 仍采用常规写法。
- 本次九个文件中没有 goto。
- 结构成员和普通变量声明逐行展开；同一行不堆叠多个语句。
- 多行函数、宏、条件和参数按层级缩进，长行按 100 列整理。
- 资源的创建与释放放在明确的外层函数，失败返回必须经过清理。
- 测试名称、阈值、超时、过滤条件和判断逻辑不随 style 修改。

根目录附 `.clang-format`（已用 clang-format 18.1.8 检查），可作为后续这些文件的排版规则参考。格式化工具不会自动保证资源清理或逻辑等价，仍需人工审查和验证。

## 合入方式

1. 优先阅读 `merge_locations.txt`，通过宏、函数及结构名称定位；行号仅供参考。
2. 这些新增文件若没有你自己的修改，可使用 `full_files/` 中的完整文件替换相同路径。若有私有改动，按 `changes.patch` 和定位说明手工合并。
3. 全量文件与补丁是两种合入方式，不必重复执行。不要重新覆盖前面四个已修改文件。
4. 可选的 `guest_cases.c` 单独处理，保留现有未编译状态。
5. 重新编译后，按原方法运行 `unittest run_groups 1 monitor`。真实运行用例仍要求 monitor 已启动及相应目标条件满足。

如采用 Git 辅助核对，可在工程根目录对主补丁执行：

```sh
git apply --check /path/to/changes.patch
```

补丁基线不匹配时不要强行覆盖；按函数手工合入即可。报错日志中的 `__LINE__`、断言表达式排版及部分函数名会随拆分变化，这是本次整理的预期差异。

## 验证记录与边界

- 九个文件通过 style 检查；clang-format 再次检查无差异。
- ARM64 freestanding 严格编译 40 个对象组合：原版 8 个 C 文件；新版 8 个 C 文件 × 两档优化（-Os/-O2）× 内部/外部执行模式。开启 -Wall、-Wextra、-Werror 及 2048 字节栈帧告警检查。
- 六个隔离用例，在内部、外部、自启动三种构建模型下各运行三次；修改前后各 54 次全部通过，输出结果一致。
- 六个隔离用例共有 212 个运行时断言位置。逐个强制失败并立即正常重跑；修改前后均验证错误返回和测试锁释放，没有改弱原断言。
- 主机内存模型 18 组场景：正常路径、采样/配置/状态异常，以及移除打点、替换错误码的反例。修改前后各运行一遍，判定结果一致；同时检查分配、共享对象、迭代器和测试锁未残留。反例中的用例失败是预期结果，说明测试仍能识别缺失或错误证据。
- 主补丁和可选补丁均验证可正向应用、反向还原，并核对完整文件字节一致。

上述是开发机模型与 ARM64 交叉编译结果，不是单板运行结果。本次未使用你的 HOS GCC 12 工程进行整机链接，也未在真实 Guest 中执行可选 guest_cases.c。它完成了严格编译和清理路径代码审查，不能据此宣称真实 Guest 场景已验收。

参考编译配置下，本次 7 个在编译路径内的 C 文件静态可写区总计仍为 **18,805 字节，增量 0**；该数不包含未改动的 storm_runtime.o、生产监控对象或测试框架。它们的对象加载区合计增加 **307 字节**（包括代码、只读数据和已初始化数据），不是新增静态 RAM，也不是最终固件 ROM 增量结论。可选 guest_cases.c 静态可写区仍为 1,840 字节，当前未编译时不计入固件。

结构体布局、静态数组容量和动态资源数量未因本次整理增加。最终镜像对齐、栈实际水位及 vapool 剩余量仍应以目标工程为准。

`validation/report.json` 保存编译和比较记录，`validation/` 下的日志均为开发机验证输出；日志落盘内容仍按此前约定在单板人工核对。
