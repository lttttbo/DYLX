/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef MONITOR_WBOX_COMMON_H
#define MONITOR_WBOX_COMMON_H
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/wboxtest.h>

#define MT_COUNT 4
#define MT_HOST 2
#define MT_IDLE 3
#define MT_UNKNOWN MT_COUNT

struct mt_latency {
	u64 count;
	u64 sum;
	u64 max;
};

struct mt_snapshot {
	struct mt_latency ready;
	struct mt_latency dispatch;
	u64 ready_since;
	u64 exits;
	u64 count;
	u64 interval;
	u64 sustained;
	u32 epoch;
	u32 guest;
	u32 kind;
	u32 windows;
	bool present;
	bool waiting;
	bool active;
	bool valid;
};

struct mt_event {
	u64 seq;
	u64 time;
	u64 last;
	u64 value;
	u64 address;
	u64 detail;
	u32 type;
	u32 guest;
	u32 vcpu;
	u32 epoch;
	u32 code;
	u32 config_seq;
	u32 sustain_s;
};

struct mt_global {
	u64 head;
	u64 cursor;
	u64 lost;
	u32 epoch;
	u32 enabled;
	u32 skipped;
	u32 logs;
	u32 config_seq;
	u32 config[VMM_MONITOR_CONFIG_KEYS];
};

/* All functions below operate only on the namespaced test instance.
 * The fixture mutex must be held from mt_begin() through mt_end(). */
void mt_begin(void);
void mt_end(void);
void mt_reset(void);
u64 mt_now(void);
void mt_time(u64 ns);
struct vmm_vcpu *mt_vcpu(u32 id);
void mt_cpu(u32 cpu);
int mt_enable(bool on);
int mt_config(u32 key, u32 value);
void mt_record(u32 id, u32 hook, u64 a, u64 b);
void mt_fault(struct vmm_vcpu *v, u32 kind, u64 address, u64 detail);
void mt_exits(u32 id, u32 count, u32 reason);
void mt_sample(u64 now);
void mt_sample_skip(u32 id, u64 now);
void mt_drain(void);
void mt_snapshot(u32 id, struct mt_snapshot *s);
void mt_global(struct mt_global *g);
bool mt_event(u64 seq, struct mt_event *e);
int mt_command(const char *verb, const char *key, const char *value);
const char *mt_output(void);
const char *mt_log(void);
bool mt_overflow(void);

/* Checks return to the registration wrapper, which always releases the fixture. */
#define MT_CHECK(expr)                                                               \
	do {                                                                         \
		if (!(expr)) {                                                       \
			vmm_cprintf(cdev, "%s:%u: %s\n", __func__, __LINE__, #expr); \
			return VMM_EFAIL;                                            \
		}                                                                    \
	} while (0)

/* Each iteration owns the fixture from begin through every return path. */
#define MT_REGISTER(test_name, runfn)                                                       \
	static int test_name##_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu) \
	{                                                                                   \
		int rc;                                                                     \
		mt_begin();                                                                 \
		rc = runfn(test, out, cpu);                                                 \
		mt_end();                                                                   \
		return rc;                                                                  \
	}                                                                                   \
	static struct wboxtest test_name = {                                                \
		.name = #test_name,    /* Stable framework identity. */                     \
		.run = test_name##_run /* Owns per-iteration cleanup. */                    \
	};                                                                                  \
	static int __init test_name##_init(void)                                            \
	{                                                                                   \
		return wboxtest_register("monitor", &test_name);                            \
	}                                                                                   \
	static void __exit test_name##_exit(void)                                           \
	{                                                                                   \
		wboxtest_unregister(&test_name);                                            \
	}                                                                                   \
	VMM_DECLARE_MODULE2(test_name, #test_name, "Monitor maintainers", "GPL",            \
			    WBOXTEST_IPRIORITY + 1, test_name##_init, test_name##_exit)
#endif
