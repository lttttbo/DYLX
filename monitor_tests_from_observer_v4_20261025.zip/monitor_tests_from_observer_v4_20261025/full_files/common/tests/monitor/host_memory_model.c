/* Included after actual monitor, command guards, shmem accessors and cases. */
int fake_irq_context, fail_next_trylock;
u64 fake_time;
u32 fake_cpu;
struct vmm_vcpu *fake_idle[CONFIG_CPU_COUNT];
struct vmm_resource vmm_hostmem_resource;
static struct vmm_vcpu runner={.id=2,.is_normal=FALSE};
static struct vmm_guest guest={.id=1};
static struct vmm_region region={.flags=VMM_REGION_REAL|VMM_REGION_MEMORY|VMM_REGION_ISRAM};
static struct vmm_shmem private_shmem;
static u8 backing[4096];
static unsigned allocations, manager_depth, backend_calls, logger_calls;
static bool allocation_failure, guest_absent, sampler_stopped, sampler_skips, shmem_live;
static u64 next_sample;
static struct wboxtest *cases[3];
static unsigned case_count;
int vmm_cprintf(struct vmm_chardev *out,const char *fmt,...) {
    va_list ap;int rc;(void)out;va_start(ap,fmt);rc=vprintf(fmt,ap);va_end(ap);return rc;
}
int vmm_printf(const char *fmt,...) { (void)fmt;return 0; }
int vmm_lprintf(unsigned level,const char *prefix,const char *fmt,...) {
    (void)level;(void)prefix;(void)fmt;logger_calls++;return 0;
}
struct vmm_vcpu *vmm_scheduler_current_vcpu(void) { return &runner; }
u32 vmm_host_ram_bank_count(void) { return 2; }
physical_addr_t vmm_host_ram_bank_start(u32 i) { assert(i<2);return i?0x8000:0x1000; }
physical_size_t vmm_host_ram_bank_size(u32 i) { assert(i<2);return i?0x1000:0x3000; }
void *vmm_zalloc(size_t n) {
    void *p;if(allocation_failure)return NULL;p=calloc(1,n);assert(p);allocations++;return p;
}
void vmm_free(void *p) { if(p){assert(allocations);allocations--;free(p);} }
int vmm_manager_guest_iterate(int (*fn)(struct vmm_guest *,void *),void *arg) {
    int rc=0;assert(!manager_depth);manager_depth++;
    if(!guest_absent)rc=fn(&guest,arg);
    manager_depth--;return rc;
}
void vmm_guest_iterate_region(struct vmm_guest *g,u32 flags,
    void (*fn)(struct vmm_guest *,struct vmm_region *,void *),void *arg) {
    assert(g==&guest);if((region.flags&flags)==flags)fn(g,&region,arg);
}
void vmm_guest_iterate_mapping(struct vmm_guest *g,struct vmm_region *r,
    void (*fn)(struct vmm_guest *,struct vmm_region *,u64,u64,u64,void *),void *arg) {
    assert(g==&guest&&r==&region);fn(g,r,0x40000000,0x2000,0x1000,arg);
}
int vmm_walk_tree_res(struct vmm_resource *r,void *arg,
    int (*fn)(const char *,u64,u64,unsigned long,int,void *)) {
    assert(r==&vmm_hostmem_resource);
    fn("System RAM",0x1000,0x3fff,0,0,arg);
    return fn("device",0xf000,0xffff,0,0,arg);
}
struct vmm_shmem *vmm_shmem_create(const char *name,u64 size,u32 align,void *priv) {
    assert(!shmem_live&&!strcmp(name,"monitor-host-test")&&size==4096&&align==12&&!priv);
    memset(backing,0,sizeof(backing));private_shmem=(struct vmm_shmem){0x8000,4096};shmem_live=TRUE;
    return &private_shmem;
}
void vmm_shmem_destroy(struct vmm_shmem *p) { assert(shmem_live&&p==&private_shmem);shmem_live=FALSE; }
static u8 *memory_at(u64 addr,u32 n) {
    assert(shmem_live&&addr>=0x8000&&addr-0x8000<=sizeof(backing)&&n<=sizeof(backing)-(addr-0x8000));
    backend_calls++;return backing+(addr-0x8000);
}
u32 vmm_host_memory_read(u64 a,void *out,u32 n,bool cache) { (void)cache;memcpy(out,memory_at(a,n),n);return n; }
u32 vmm_host_memory_write(u64 a,void *in,u32 n,bool cache) { (void)cache;memcpy(memory_at(a,n),in,n);return n; }
u32 vmm_host_memory_set(u64 a,u8 v,u32 n,bool cache) { (void)cache;memset(memory_at(a,n),v,n);return n; }
void vmm_msleep(unsigned long ms) {
    fake_time+=(u64)ms*1000000;
    if(!sampler_stopped&&fake_time>=next_sample) {
        fake_irq_context=1;
        if(sampler_skips) fail_next_trylock=1;
        vmm_monitor_sample(fake_time);fake_irq_context=0;
        next_sample=fake_time+VMM_MONITOR_NS;
    }
}
int wboxtest_register(const char *group,struct wboxtest *t) {
    assert(!strcmp(group,"monitor")&&case_count<3);cases[case_count++]=t;return 0;
}
void wboxtest_unregister(struct wboxtest *t) { (void)t; }

static void compare_original_policy(void) {
    const u64 addresses[]={0,0x1000,0x1fff,0x2000,0x2fff,0x3fff,0x8000,0xf000,0xffff,~0ULL-1};
    unsigned count=0;
    for(unsigned enabled_state=0;enabled_state<2;enabled_state++) {
        assert(!vmm_monitor_enable(enabled_state));
        for(unsigned oom=0;oom<2;oom++)for(unsigned w=1;w<=4;w*=2)for(unsigned a=0;a<10;a++) {
            allocation_failure=oom;
            assert(original_check_read_memory(NULL,addresses[a],w,FALSE)==check_read_memory(NULL,addresses[a],w,FALSE));count++;
            assert(original_check_read_memory(NULL,addresses[a],w,TRUE)==check_read_memory(NULL,addresses[a],w,TRUE));count++;
            bool old_io=FALSE,new_io=FALSE;
            assert(original_check_write_memory(NULL,addresses[a],w,&old_io)==check_write_memory(NULL,addresses[a],w,&new_io));
            assert(old_io==new_io);count++;
            assert(!allocations&&!manager_depth&&!backend_calls);
        }
    }
    printf("POLICY PASS: %u return/type comparisons; zero physical accesses\n",count);
}
int main(int argc,char **argv) {
    unsigned failures=0;
    const char *mode=argc>1?argv[1]:"normal";
    assert(!vmm_monitor_init());assert(!vmm_monitor_enable(TRUE));
    next_sample=VMM_MONITOR_NS;
    if(!strcmp(mode,"policy")){compare_original_policy();return 0;}
    guest_absent=!strcmp(mode,"no_guest");sampler_stopped=!strcmp(mode,"no_sampler");
    sampler_skips=!strcmp(mode,"skipped_sample");
    if(!strcmp(mode,"disabled"))assert(!vmm_monitor_enable(FALSE));
    assert(!monitor_host_range_init_host());assert(!monitor_host_guest_guard_init_host());
    assert(!monitor_host_shmem_init_host());assert(case_count==3);
    for(unsigned i=0;i<case_count;i++) {
        int rc=cases[i]->run(cases[i],NULL,0);bool expected_failure=FALSE;
#ifdef MODEL_MISSING_PROBES
        expected_failure=TRUE;
#elif defined(MODEL_WRONG_CODE)
        expected_failure=i==0;
#else
        expected_failure=sampler_stopped||sampler_skips||!strcmp(mode,"disabled")||(guest_absent&&i==1);
#endif
        printf("CASE %s rc=%d expected=%s\n",cases[i]->name,rc,expected_failure?"failure":"pass");
        if((rc!=0)!=expected_failure)failures++;
        assert(!allocations&&!manager_depth&&!shmem_live);
    }
    /* No logging callback was required for an automatic PASS. */
    assert(!logger_calls);
    printf("MODEL %s %s; logging callbacks=%u\n",mode,failures?"FAIL":"PASS",logger_calls);
    return failures?1:0;
}
