#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <limits.h>
#include <errno.h>
#include "vhost_round5.h"
#define likely(x) (x)
#define unlikely(x) (x)
#define MSG_DONTWAIT 0x40
#define MSG_MORE 0x8000
#define VHOST_NET_VQ_TX 1
#define VHOST_NET_BATCH 64
#define VHOST_GOODCOPY_LEN 256
#define UIO_MAXIOV 1024
#define VHOST_DMA_IN_PROGRESS 1
#define VHOST_DMA_DONE_LEN 2
#define SKBFL_ZEROCOPY_FRAG 1
#define TUN_MSG_UBUF 1
#define vq_err(...) ((void)0)
#define pr_debug(...) ((void)0)
#define cpu_to_vhost32(vq, val) (val)
#define min_t(t,a,b) ((a)<(b)?(a):(b))
struct vhost_work { int dummy; };
struct vhost_poll { int dummy; };
struct vhost_dev { int dummy; };
struct velem { unsigned id,len; };
struct vhost_virtqueue { int num; struct vhost_poll poll; struct velem heads[1024]; int last_avail_idx; struct vhost_dev *dev; };
struct vhost_net_ubuf_ref { int refcount; };
struct ubuf_info { void (*callback)(void); void *ctx; int desc,flags,refcnt; };
struct iter { int dummy; };
struct msghdr { void *msg_name; int msg_namelen; void *msg_control; int msg_controllen,msg_flags; struct iter msg_iter; };
struct tun_msg_ctl { int type; void *ptr; };
struct sock { int sk_sndbuf; };
struct socket;
struct sock_ops { int (*sendmsg)(struct socket *,struct msghdr *,size_t); };
struct socket { struct sock *sk; struct sock_ops *ops; };
struct vhost_net_virtqueue { struct vhost_virtqueue vq; int done_idx,upend_idx; struct ubuf_info ubuf_info[1024]; struct vhost_net_ubuf_ref *ubufs; };
struct vhost_net { struct vhost_dev dev; struct vhost_net_virtqueue vqs[2]; struct vhost_n5_tx n5_tx; };
static int scenario, packets, fetched, xdp_result, send_result, tail_state, recheck_remaining, budget, get_count, busy_intr;
static void logop(const char *op,int a){ printf("%s=%d;",op,a); }
static int get_tx_bufs(struct vhost_net *n,struct vhost_net_virtqueue *v,struct msghdr *m,unsigned *o,unsigned *i,size_t *len,bool *intr){
    (void)n;(void)m;*o=1;*i=0;*len=1400;*intr=busy_intr;get_count++;
    if(scenario==7){logop("get",-EFAULT);return -EFAULT;}
    if(fetched>=packets){logop("get",v->vq.num);return v->vq.num;}
    v->vq.last_avail_idx++; logop("get",fetched);return fetched++;
}
static int sendmock(struct socket *s,struct msghdr *m,size_t l){(void)s; logop("send_flags",m->msg_flags);logop("send",(int)l);return send_result==INT_MAX?(int)l:send_result;}
static void vhost_tx_batch(struct vhost_net *n,struct vhost_net_virtqueue *v,struct socket *s,struct msghdr *m){(void)n;(void)s;(void)m;logop("flush",v->done_idx);v->done_idx=0;}
static int vhost_net_build_xdp(struct vhost_net_virtqueue *v,struct iter *i){(void)v;(void)i;logop("build",xdp_result);return xdp_result;}
static void vhost_discard_vq_desc(struct vhost_virtqueue *v,int n){v->last_avail_idx-=n;logop("discard",n);}
static int vhost_net_enable_vq(struct vhost_net *n,struct vhost_virtqueue *v){(void)n;(void)v;logop("enable_backend",1);return 0;}
static bool tx_can_batch(struct vhost_virtqueue *v,size_t bytes){(void)v;(void)bytes;return false;}
static void vhost_poll_queue(struct vhost_poll *p){(void)p;logop("queue",1);}
void vhost_poll_queue_reason(struct vhost_poll *p,enum n5_source s){(void)s;vhost_poll_queue(p);}
static bool vhost_exceeds_weight(struct vhost_virtqueue *v,int pkts,int bytes){(void)bytes;logop("budget_check",pkts);if(pkts>=budget){vhost_poll_queue(&v->poll);return true;}return false;}
static bool vhost_vq_avail_empty(struct vhost_dev *d,struct vhost_virtqueue *v){(void)d;(void)v;logop("tail_avail",tail_state);return tail_state!=1;}
static bool vhost_enable_notify(struct vhost_dev *d,struct vhost_virtqueue *v){(void)d;(void)v;logop("enable_notify",1);if(recheck_remaining>0){recheck_remaining--;return true;}return false;}
static void vhost_disable_notify(struct vhost_dev *d,struct vhost_virtqueue *v){(void)d;(void)v;logop("disable_notify",1);}
static void vhost_zerocopy_signal_used(struct vhost_net *n,struct vhost_virtqueue *v){(void)n;(void)v;logop("zcopy_used",1);}
static bool vhost_exceeds_maxpend(struct vhost_net *n){(void)n;return false;}
static bool vhost_net_tx_select_zcopy(struct vhost_net *n){(void)n;return scenario!=2;}
static void vhost_zerocopy_callback(void){}
static void refcount_set(int *a,int n){*a=n;}
static void atomic_inc(int *a){(*a)++;}
static int vhost_net_ubuf_put(struct vhost_net_ubuf_ref *u){return --u->refcount;}
static void vhost_add_used_and_signal(struct vhost_dev *d,struct vhost_virtqueue *v,int h,int l){(void)d;(void)v;(void)l;logop("add_used",h);}
static void vhost_net_tx_packet(struct vhost_net *n){(void)n;logop("tx_packet",1);}

static void vhost_net_busy_poll_try_queue(struct vhost_net *net,
                                          struct vhost_virtqueue *vq)
{
        if (!vhost_vq_avail_empty(&net->dev, vq)) {
                vhost_poll_queue(&vq->poll);
        } else if (unlikely(vhost_enable_notify(&net->dev, vq))) {
                vhost_disable_notify(&net->dev, vq);
                vhost_poll_queue(&vq->poll);
        }
}
static void handle_tx_copy(struct vhost_net *net, struct socket *sock)
{
        struct vhost_net_virtqueue *nvq = &net->vqs[VHOST_NET_VQ_TX];
        struct vhost_virtqueue *vq = &nvq->vq;
        unsigned out, in;
        int head;
        struct msghdr msg = {
                .msg_name = NULL,
                .msg_namelen = 0,
                .msg_control = NULL,
                .msg_controllen = 0,
                .msg_flags = MSG_DONTWAIT,
        };
        size_t len, total_len = 0;
        int err;
        int sent_pkts = 0;
        bool sock_can_batch = (sock->sk->sk_sndbuf == INT_MAX);
        bool busyloop_intr;
        do {
                busyloop_intr = false;
                if (nvq->done_idx == VHOST_NET_BATCH)
                        vhost_tx_batch(net, nvq, sock, &msg);
                head = get_tx_bufs(net, nvq, &msg, &out, &in, &len,
                                   &busyloop_intr);
                /* On error, stop handling until the next kick. */
                if (unlikely(head < 0))
                        break;
                /* Nothing new?  Wait for eventfd to tell us they refilled. */
                if (head == vq->num) {
                        /* Kicks are disabled at this point, break loop and
                         * process any remaining batched packets. Queue will
                         * be re-enabled afterwards.
                         */
                        break;
                }
                total_len += len;
                /* For simplicity, TX batching is only enabled if
                 * sndbuf is unlimited.
                 */
                if (sock_can_batch) {
                        err = vhost_net_build_xdp(nvq, &msg.msg_iter);
                        if (!err) {
                                goto done;
                        } else if (unlikely(err != -ENOSPC)) {
                                vhost_tx_batch(net, nvq, sock, &msg);
                                vhost_discard_vq_desc(vq, 1);
                                vhost_net_enable_vq(net, vq);
                                break;
                        }
                        /* We can't build XDP buff, go for single
                         * packet path but let's flush batched
                         * packets.
                         */
                        vhost_tx_batch(net, nvq, sock, &msg);
                        msg.msg_control = NULL;
                } else {
                        if (tx_can_batch(vq, total_len))
                                msg.msg_flags |= MSG_MORE;
                        else
                                msg.msg_flags &= ~MSG_MORE;
                }
                err = sock->ops->sendmsg(sock, &msg, len);
                if (unlikely(err < 0)) {
                        if (err == -EAGAIN || err == -ENOMEM || err == -ENOBUFS) {
                                vhost_discard_vq_desc(vq, 1);
                                vhost_net_enable_vq(net, vq);
                                break;
                        }
                        pr_debug("Fail to send packet: err %d", err);
                } else if (unlikely(err != len))
                        pr_debug("Truncated TX packet: len %d != %zd\n",
                                 err, len);
done:
                vq->heads[nvq->done_idx].id = cpu_to_vhost32(vq, head);
                vq->heads[nvq->done_idx].len = 0;
                ++nvq->done_idx;
        } while (likely(!vhost_exceeds_weight(vq, ++sent_pkts, total_len)));
        /* Kicks are still disabled, dispatch any remaining batched msgs. */
        vhost_tx_batch(net, nvq, sock, &msg);
        if (unlikely(busyloop_intr))
                /* If interrupted while doing busy polling, requeue the
                 * handler to be fair handle_rx as well as other tasks
                 * waiting on cpu.
                 */
                vhost_poll_queue(&vq->poll);
        else
                /* All of our work has been completed; however, before
                 * leaving the TX handler, do one last check for work,
                 * and requeue handler if necessary. If there is no work,
                 * queue will be reenabled.
                 */
                vhost_net_busy_poll_try_queue(net, vq);
}
static void handle_tx_zerocopy(struct vhost_net *net, struct socket *sock)
{
        struct vhost_net_virtqueue *nvq = &net->vqs[VHOST_NET_VQ_TX];
        struct vhost_virtqueue *vq = &nvq->vq;
        unsigned out, in;
        int head;
        struct msghdr msg = {
                .msg_name = NULL,
                .msg_namelen = 0,
                .msg_control = NULL,
                .msg_controllen = 0,
                .msg_flags = MSG_DONTWAIT,
        };
        struct tun_msg_ctl ctl;
        size_t len, total_len = 0;
        int err;
        struct vhost_net_ubuf_ref *ubufs;
        struct ubuf_info *ubuf;
        bool zcopy_used;
        int sent_pkts = 0;
        do {
                bool busyloop_intr;
                /* Release DMAs done buffers first */
                vhost_zerocopy_signal_used(net, vq);
                busyloop_intr = false;
                head = get_tx_bufs(net, nvq, &msg, &out, &in, &len,
                                   &busyloop_intr);
                /* On error, stop handling until the next kick. */
                if (unlikely(head < 0))
                        break;
                /* Nothing new?  Wait for eventfd to tell us they refilled. */
                if (head == vq->num) {
                        if (unlikely(busyloop_intr)) {
                                vhost_poll_queue(&vq->poll);
                        } else if (unlikely(vhost_enable_notify(&net->dev, vq))) {
                                vhost_disable_notify(&net->dev, vq);
                                continue;
                        }
                        break;
                }
                zcopy_used = len >= VHOST_GOODCOPY_LEN
                             && !vhost_exceeds_maxpend(net)
                             && vhost_net_tx_select_zcopy(net);
                /* use msg_control to pass vhost zerocopy ubuf info to skb */
                if (zcopy_used) {
                        ubuf = nvq->ubuf_info + nvq->upend_idx;
                        vq->heads[nvq->upend_idx].id = cpu_to_vhost32(vq, head);
                        vq->heads[nvq->upend_idx].len = VHOST_DMA_IN_PROGRESS;
                        ubuf->callback = vhost_zerocopy_callback;
                        ubuf->ctx = nvq->ubufs;
                        ubuf->desc = nvq->upend_idx;
                        ubuf->flags = SKBFL_ZEROCOPY_FRAG;
                        refcount_set(&ubuf->refcnt, 1);
                        msg.msg_control = &ctl;
                        ctl.type = TUN_MSG_UBUF;
                        ctl.ptr = ubuf;
                        msg.msg_controllen = sizeof(ctl);
                        ubufs = nvq->ubufs;
                        atomic_inc(&ubufs->refcount);
                        nvq->upend_idx = (nvq->upend_idx + 1) % UIO_MAXIOV;
                } else {
                        msg.msg_control = NULL;
                        ubufs = NULL;
                }
                total_len += len;
                if (tx_can_batch(vq, total_len) &&
                    likely(!vhost_exceeds_maxpend(net))) {
                        msg.msg_flags |= MSG_MORE;
                } else {
                        msg.msg_flags &= ~MSG_MORE;
                }
                err = sock->ops->sendmsg(sock, &msg, len);
                if (unlikely(err < 0)) {
                        bool retry = err == -EAGAIN || err == -ENOMEM || err == -ENOBUFS;
                        if (zcopy_used) {
                                if (vq->heads[ubuf->desc].len == VHOST_DMA_IN_PROGRESS)
                                        vhost_net_ubuf_put(ubufs);
                                if (retry)
                                        nvq->upend_idx = ((unsigned)nvq->upend_idx - 1)
                                                % UIO_MAXIOV;
                                else
                                        vq->heads[ubuf->desc].len = VHOST_DMA_DONE_LEN;
                        }
                        if (retry) {
                                vhost_discard_vq_desc(vq, 1);
                                vhost_net_enable_vq(net, vq);
                                break;
                        }
                        pr_debug("Fail to send packet: err %d", err);
                } else if (unlikely(err != len))
                        pr_debug("Truncated TX packet: "
                                 " len %d != %zd\n", err, len);
                if (!zcopy_used)
                        vhost_add_used_and_signal(&net->dev, vq, head, 0);
                else
                        vhost_zerocopy_signal_used(net, vq);
                vhost_net_tx_packet(net);
        } while (likely(!vhost_exceeds_weight(vq, ++sent_pkts, total_len)));
}
int main(void){
 int mode,s;
 for(mode=0;mode<2;mode++)for(s=0;s<14;s++){
   struct vhost_net *n=calloc(1,sizeof(*n));struct vhost_net_ubuf_ref u={1};
   struct sock sk={0};struct sock_ops ops={sendmock};struct socket so={&sk,&ops};
   scenario=s;packets=3;fetched=0;xdp_result=0;send_result=INT_MAX;tail_state=0;recheck_remaining=0;budget=256;get_count=0;busy_intr=0;
   if(s==0)packets=0;
   if(s==1)packets=1;
   if(s==2){sk.sk_sndbuf=INT_MAX;packets=65;}
   if(s==3){sk.sk_sndbuf=INT_MAX;xdp_result=-ENOSPC;}
   if(s==4){sk.sk_sndbuf=INT_MAX;xdp_result=-ENOMEM;}
   if(s==5)send_result=-EAGAIN;
   if(s==6)send_result=-EINVAL;
   if(s==8)send_result=1399;
   if(s==9)budget=2;
   if(s==10)tail_state=1;
   if(s==11)recheck_remaining=1;
   if(s==12)busy_intr=1;
   if(s==13){packets=2;budget=1;tail_state=1;}
   n->n5_tx.active=true;
   n->vqs[1].vq.num=1024;n->vqs[1].vq.dev=&n->dev;n->vqs[1].ubufs=&u;
   printf("\nMODE=%d CASE=%d:",mode,s);
   if(mode==0)handle_tx_copy(n,&so);else handle_tx_zerocopy(n,&so);
   printf("last=%d,done=%d,upend=%d,getcalls=%d,ref=%d\n",n->vqs[1].vq.last_avail_idx,n->vqs[1].done_idx,n->vqs[1].upend_idx,get_count,u.refcount);
   free(n);
 }
 return 0;
}
