/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_monitor_guest.h>
#include <vmm_monitor_diag.h>
#include <vmm_smp.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <vmm_mutex.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <arch_barrier.h>
#include <libs/stringlib.h>
#include <libs/mathlib.h>
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
#include <vmm_threads.h>
#include <vmm_workqueue.h>
#include <vmm_delay.h>
#endif

/* No retained vCPU pointers, no allocation in any collection/report path. */
struct monitor_data {
	struct vmm_monitor_snapshot snap;
	struct vmm_monitor_hist ready, irq, dispatch;
	struct vmm_monitor_streak storm;
	u64 epoch_ns, ready_since, previous_ns, exits, faults;
	u64 notice_ns[3];
	bool waiting;
};
struct monitor_slot {
	vmm_spinlock_t lock;
	struct monitor_data data;
};
/* Extra slot records faults with no attributable Guest (e.g. host shmem API). */
static struct monitor_slot slots[CONFIG_MAX_VCPU_COUNT + 1];
static DEFINE_SPINLOCK(control_lock);
static DEFINE_SPINLOCK(sample_lock);
static struct vmm_mutex drain_lock;
static atomic_t initialized = { 0 }, enabled = { 0 };
static struct vmm_monitor_status status;
static struct vmm_monitor_event events[VMM_MONITOR_EVENTS];
static u64 report_sequence = 1;
extern void vmm_monitor_irq_init(void);
extern void vmm_monitor_irq_restart(u64 now);
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static struct vmm_workqueue *report_queue;
static struct vmm_work report_work;
static struct vmm_timer_event sample_timer;
static u64 next_sample;
static atomic_t executor_state = {0}, timer_start_result = {VMM_EINPROGRESS};
#endif

bool vmm_monitor_enabled(void)
{
	return arch_atomic_read(&enabled) != 0;
}

static struct monitor_slot *slot_for(struct vmm_vcpu *vcpu)
{
	if (!arch_atomic_read(&initialized) || !vcpu || !vcpu->is_normal ||
	    vcpu->id >= CONFIG_MAX_VCPU_COUNT)
		return NULL;
	return &slots[vcpu->id];
}

static void identify(struct monitor_data *d, struct vmm_vcpu *vcpu)
{
	d->snap.present = TRUE;
	d->snap.vcpu_id = vcpu ? vcpu->id : VMM_MONITOR_UNKNOWN;
	d->snap.guest_id = vcpu ? vcpu->guest->id : VMM_MONITOR_UNKNOWN;
}

static void reset_data(struct monitor_data *d, u64 now)
{
	u32 generation = d->snap.generation + 1;
	memset(d, 0, sizeof(*d));
	d->snap.generation = generation;
	d->epoch_ns = now;
}

void vmm_monitor_state(struct vmm_vcpu *vcpu, u32 state, u64 now)
{
	irq_flags_t flags;
	struct monitor_slot *s = slot_for(vcpu);
	struct monitor_data *d;
	if (!s)
		return;
	/* Lifecycle must invalidate cached data even while collection is off. */
	if (!vmm_monitor_enabled() && state != VMM_VCPU_STATE_RESET &&
	    state != VMM_VCPU_STATE_UNKNOWN)
		return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	d = &s->data;
	if (state == VMM_VCPU_STATE_RESET || state == VMM_VCPU_STATE_UNKNOWN)
		reset_data(d, now);
	identify(d, vcpu);
	d->snap.present = state != VMM_VCPU_STATE_UNKNOWN;
	d->snap.state = state;
	d->snap.hcpu = vcpu->hcpu;
	if (vmm_monitor_enabled()) {
		if (state == VMM_VCPU_STATE_READY && !d->waiting) {
			d->ready_since = now;
			d->waiting = TRUE;
		} else if (state != VMM_VCPU_STATE_READY) {
			if (state == VMM_VCPU_STATE_RUNNING && d->waiting &&
			    now >= d->ready_since)
				vmm_monitor_hist_add(&d->ready, now - d->ready_since);
			d->waiting = FALSE;
		}
	}
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
	if (state == VMM_VCPU_STATE_RESET || state == VMM_VCPU_STATE_UNKNOWN)
		vmm_monitor_irq_reset(vcpu);
	if (state == VMM_VCPU_STATE_RESET || state == VMM_VCPU_STATE_UNKNOWN)
		vmm_monitor_guest_reset(vcpu->guest->id);
}

void vmm_monitor_selected(struct vmm_vcpu *vcpu, u64 now)
{
	irq_flags_t flags;
	struct monitor_slot *s;
	if (!vmm_monitor_enabled() || !(s = slot_for(vcpu))) return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	if (vmm_monitor_enabled() && s->data.waiting) {
		if (now >= s->data.ready_since)
			vmm_monitor_hist_add(&s->data.ready, now - s->data.ready_since);
		s->data.waiting = FALSE;
	}
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
}

void vmm_monitor_dispatch(struct vmm_vcpu *vcpu, u64 begin, u64 end)
{
	irq_flags_t flags;
	struct monitor_slot *s;
	if (!vmm_monitor_enabled() || end < begin || !(s = slot_for(vcpu))) return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	if (vmm_monitor_enabled()) vmm_monitor_hist_add(&s->data.dispatch, end - begin);
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
}

void vmm_monitor_exit(struct vmm_vcpu *vcpu, u32 reason)
{
	irq_flags_t flags;
	struct monitor_slot *s;
	if (!vmm_monitor_enabled() || !(s = slot_for(vcpu)))
		return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	if (vmm_monitor_enabled()) {
		identify(&s->data, vcpu);
		s->data.exits++;
		s->data.snap.last_exit = reason;
	}
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
}

void vmm_monitor_mem_fault(struct vmm_vcpu *actor, u32 kind,
			   u64 address, u64 detail)
{
	irq_flags_t flags;
	struct monitor_slot *s;
	if (!vmm_monitor_enabled())
		return;
	s = actor ? slot_for(actor) : &slots[CONFIG_MAX_VCPU_COUNT];
	if (!s)
		return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	if (vmm_monitor_enabled()) {
		identify(&s->data, actor);
		s->data.faults++;
		s->data.snap.last_address = address;
		s->data.snap.last_detail = detail;
		s->data.snap.last_fault = kind;
	}
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
}

void vmm_monitor_irq_sample(struct vmm_vcpu *vcpu, u64 start_ns, u64 end_ns)
{
	irq_flags_t flags;
	struct monitor_slot *s;
	if (!vmm_monitor_enabled() || !(s = slot_for(vcpu)))
		return;
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	if (vmm_monitor_enabled() && start_ns >= s->data.epoch_ns &&
	    end_ns >= start_ns) {
		identify(&s->data, vcpu);
		vmm_monitor_hist_add(&s->data.irq, end_ns - start_ns);
	}
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
}

static void record_event(struct vmm_monitor_snapshot *s, u32 type,
			 u64 value, u64 detail, u32 code)
{
	irq_flags_t flags;
	struct vmm_monitor_event *e;
	vmm_spin_lock_irqsave_lite(&control_lock, flags);
	status.events++;
	if (status.events - report_sequence >= VMM_MONITOR_EVENTS) {
		report_sequence++;
		status.overwritten++;
	}
	e = &events[(status.events - 1) % VMM_MONITOR_EVENTS];
	e->sequence = status.events;
	e->timestamp_ns = s->timestamp_ns;
	e->guest_id = s->guest_id;
	e->vcpu_id = s->vcpu_id;
	e->generation = s->generation;
	e->type = type;
	e->value = value;
	e->detail = detail;
	e->code = code;
	vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
}

void vmm_monitor_guest_event(u32 guest, u64 now, u64 value, u32 limit)
{
	struct vmm_monitor_snapshot s = {0};
	s.guest_id = guest; s.vcpu_id = VMM_MONITOR_UNKNOWN; s.timestamp_ns = now;
	record_event(&s, VMM_MONITOR_GUEST_CPU_HIGH, value, limit, 0);
}

void vmm_monitor_status(struct vmm_monitor_status *out)
{
	irq_flags_t flags;
	vmm_spin_lock_irqsave_lite(&control_lock, flags);
	*out = status;
	out->enabled = vmm_monitor_enabled();
	out->irq_untracked = vmm_monitor_irq_untracked();
	vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
}

int vmm_monitor_snapshot(u32 id, struct vmm_monitor_snapshot *out)
{
	irq_flags_t flags;
	u64 now;
	struct monitor_slot *s;
	if (!out || id > CONFIG_MAX_VCPU_COUNT || !arch_atomic_read(&initialized))
		return VMM_EINVALID;
	s = &slots[id];
	vmm_spin_lock_irqsave_lite(&s->lock, flags);
	*out = s->data.snap;
	now = vmm_timer_timestamp();
	out->ready_age_ns = s->data.waiting && vmm_monitor_enabled() &&
		now >= s->data.ready_since ? now - s->data.ready_since : 0;
	vmm_spin_unlock_irqrestore_lite(&s->lock, flags);
	return out->present ? VMM_OK : VMM_ENOTAVAIL;
}

int vmm_monitor_event_get(u64 sequence, struct vmm_monitor_event *out)
{
	int rc = VMM_ENOTAVAIL;
	irq_flags_t flags;
	if (!sequence || !out)
		return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&control_lock, flags);
	if (sequence <= status.events && status.events - sequence < VMM_MONITOR_EVENTS) {
		*out = events[(sequence - 1) % VMM_MONITOR_EVENTS];
		rc = VMM_OK;
	}
	vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
	return rc;
}

int vmm_monitor_enable(bool on)
{
	u32 i;
	u64 now;
	irq_flags_t flags, sample_flags;
	if (!arch_atomic_read(&initialized))
		return VMM_ENOTAVAIL;
	vmm_spin_lock_irqsave_lite(&sample_lock, sample_flags);
	if (on == vmm_monitor_enabled())
		goto done;
	arch_atomic_write(&enabled, 0);
	if (on) {
		now = vmm_timer_timestamp();
		vmm_monitor_irq_restart(now);
		for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
			vmm_spin_lock_irqsave_lite(&slots[i].lock, flags);
			reset_data(&slots[i].data, now);
			vmm_spin_unlock_irqrestore_lite(&slots[i].lock, flags);
		}
		for (i = 0; i < CONFIG_MAX_GUEST_COUNT; i++) vmm_monitor_guest_reset(i);
		arch_wmb();
		arch_atomic_write(&enabled, 1);
	}
done:
	vmm_spin_unlock_irqrestore_lite(&sample_lock, sample_flags);
	return VMM_OK;
}

int vmm_monitor_configure(const struct vmm_monitor_config *c)
{
	u32 i;
	irq_flags_t flags, sample_flags;
	if (!c || !c->exit_rate || c->exit_rate > 1000000000 ||
	    !c->sustain_seconds || c->sustain_seconds > 60 || c->guest_cpu_limit_bp > 10000 ||
	    !arch_atomic_read(&initialized))
		return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&sample_lock, sample_flags);
	vmm_spin_lock_irqsave_lite(&control_lock, flags);
	status.config = *c;
	vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
		vmm_spin_lock_irqsave_lite(&slots[i].lock, flags);
		memset(&slots[i].data.storm, 0, sizeof(slots[i].data.storm));
		slots[i].data.previous_ns = 0;
		vmm_spin_unlock_irqrestore_lite(&slots[i].lock, flags);
	}
	vmm_spin_unlock_irqrestore_lite(&sample_lock, sample_flags);
	return VMM_OK;
}

void vmm_monitor_sample(u64 now)
{
	u32 i, alarms;
	int storm;
	u64 start = vmm_timer_timestamp(), dt;
	irq_flags_t flags, sample_flags;
	struct monitor_data *d;
	struct vmm_monitor_snapshot snap;
	struct vmm_monitor_status config;
	if (!vmm_monitor_enabled())
		return;
	if (!vmm_spin_trylock_irqsave(&sample_lock, sample_flags)) {
		vmm_spin_lock_irqsave_lite(&control_lock, flags);
		status.busy_snapshots++;
		vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
		return;
	}
	if (!vmm_monitor_enabled())
		goto done;
	vmm_monitor_status(&config);
	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
		/* Never let a contended/stuck producer stall the periodic sampler. */
		if (!vmm_spin_trylock_irqsave(&slots[i].lock, flags)) {
			vmm_spin_lock_irqsave_lite(&control_lock, flags);
			status.busy_snapshots++;
			vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
			continue;
		}
		d = &slots[i].data;
		if (!d->snap.present) {
			vmm_spin_unlock_irqrestore(&slots[i].lock, flags);
			continue;
		}
		dt = now >= d->previous_ns ? now - d->previous_ns : 0;
		d->snap.valid = d->previous_ns && dt >= VMM_MONITOR_NS * 3 / 4 &&
			dt <= VMM_MONITOR_NS * 5 / 4;
		d->snap.interval_ns = d->previous_ns ? dt : 0;
		d->previous_ns = now;
		d->snap.timestamp_ns = now;
		d->snap.ready_age_ns = d->waiting && now >= d->ready_since ? now - d->ready_since : 0;
		d->snap.exits = d->exits;
		/* Divide first for absurd long gaps to keep multiplication bounded. */
		d->snap.exit_rate = dt && d->exits <= (~0ULL / VMM_MONITOR_NS) ?
			udiv64(d->exits * VMM_MONITOR_NS, dt) : 0;
		d->snap.faults = d->faults;
		vmm_monitor_hist_read(&d->ready, &d->snap.ready);
		vmm_monitor_hist_read(&d->irq, &d->snap.irq);
		vmm_monitor_hist_read(&d->dispatch, &d->snap.dispatch);
		storm = vmm_monitor_storm_step(&d->storm, d->exits, dt,
			config.config.exit_rate, config.config.sustain_seconds, d->snap.valid);
		alarms = 0;
		if (d->faults && (!d->notice_ns[0] || now - d->notice_ns[0] >= 10 * VMM_MONITOR_NS))
			alarms |= 1;
		if (config.config.ready_limit_ns &&
		    ((d->snap.ready.count && d->snap.ready.p99_upper_ns > config.config.ready_limit_ns) ||
		     d->snap.ready_age_ns > config.config.ready_limit_ns) &&
		    (!d->notice_ns[1] || now - d->notice_ns[1] >= 10 * VMM_MONITOR_NS))
			alarms |= 2;
		if (config.config.irq_limit_ns && d->snap.irq.count &&
		    d->snap.irq.p99_upper_ns > config.config.irq_limit_ns &&
		    (!d->notice_ns[2] || now - d->notice_ns[2] >= 10 * VMM_MONITOR_NS))
			alarms |= 4;
		if (alarms & 1) { d->notice_ns[0] = now; d->faults = 0; }
		if (alarms & 2) d->notice_ns[1] = now;
		if (alarms & 4) d->notice_ns[2] = now;
		d->exits = 0;
		memset(&d->ready, 0, sizeof(d->ready));
		memset(&d->irq, 0, sizeof(d->irq));
		memset(&d->dispatch, 0, sizeof(d->dispatch));
		snap = d->snap;
		vmm_spin_unlock_irqrestore(&slots[i].lock, flags);
		if (storm)
			record_event(&snap, storm > 0 ? VMM_MONITOR_EXIT_STORM :
				VMM_MONITOR_EXIT_RECOVER, snap.exit_rate, config.config.exit_rate, snap.last_exit);
		if (alarms & 1)
			record_event(&snap, VMM_MONITOR_MEMORY, snap.faults, snap.last_address, snap.last_fault);
		if (alarms & 2)
			record_event(&snap, VMM_MONITOR_READY_SLOW,
				snap.ready_age_ns > snap.ready.p99_upper_ns ? snap.ready_age_ns : snap.ready.p99_upper_ns,
				config.config.ready_limit_ns, snap.ready_age_ns > snap.ready.p99_upper_ns);
		if (alarms & 4)
			record_event(&snap, VMM_MONITOR_IRQ_SLOW, snap.irq.p99_upper_ns, config.config.irq_limit_ns, 0);
	}
	vmm_monitor_guest_sample(now, config.config.guest_cpu_limit_bp);
	vmm_monitor_platform_sample(now);
	dt = vmm_timer_timestamp() - start;
	vmm_spin_lock_irqsave_lite(&control_lock, flags);
	status.samples++;
	if (dt > status.sample_max_ns) status.sample_max_ns = dt;
	vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
done:
	vmm_spin_unlock_irqrestore_lite(&sample_lock, sample_flags);
}

int __weak vmm_monitor_platform_publish(const char *json, u32 length)
{
	return VMM_ENOTAVAIL;
}
void __weak vmm_monitor_platform_sample(u64 now) { }
int __weak vmm_monitor_platform_diagnose(struct vmm_chardev *cdev)
{
	return VMM_ENOTAVAIL;
}

/* Sole worker; all formatting and potentially slow output stays here. */
void vmm_monitor_drain(void)
{
	u32 n;
	int len, rc;
	irq_flags_t flags;
	char json[384];
	struct vmm_monitor_event e;
	struct vmm_monitor_status c;
	if (!arch_atomic_read(&initialized))
		return;
	vmm_mutex_lock(&drain_lock);
	vmm_monitor_status(&c);
	for (n = 0; n < VMM_MONITOR_BATCH; n++) {
		vmm_spin_lock_irqsave_lite(&control_lock, flags);
		if (report_sequence > status.events) {
			vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
			break;
		}
		e = events[(report_sequence++ - 1) % VMM_MONITOR_EVENTS];
		vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
		len = vmm_snprintf(json, sizeof(json),
			"{\"schema\":2,\"seq\":%llu,\"time_ns\":%llu,\"type\":%u,"
			"\"guest\":%u,\"vcpu\":%u,\"generation\":%u,\"value\":%llu,"
			"\"detail\":%llu,\"code\":%u}\n",
			(unsigned long long)e.sequence, (unsigned long long)e.timestamp_ns,
			e.type, e.guest_id, e.vcpu_id, e.generation,
			(unsigned long long)e.value, (unsigned long long)e.detail, e.code);
		if (len < 0 || len >= sizeof(json))
			continue;
		if (c.config.log)
			vmm_printf("%s", json);
		if (c.config.publish) {
			rc = vmm_monitor_platform_publish(json, len);
			if (rc) {
				vmm_spin_lock_irqsave_lite(&control_lock, flags);
				status.publish_errors++;
				vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
			}
		}
	}
	vmm_mutex_unlock(&drain_lock);
}

#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static void report_fn(struct vmm_work *work) { vmm_monitor_drain(); }
/* IRQ context: no mutex, allocation, formatting, or Guest calls. */
static void monitor_timer(struct vmm_timer_event *ev)
{
	u64 now = vmm_timer_timestamp();
	irq_flags_t flags;
	int rc;
	if (arch_atomic_read(&executor_state) != 1) {
		if (!arch_atomic_read(&executor_state))
			vmm_timer_event_start(ev, VMM_MONITOR_NS);
		return;
	}
	if (vmm_monitor_enabled() && now > next_sample && now - next_sample >= VMM_MONITOR_NS / 4) {
		vmm_spin_lock_irqsave_lite(&control_lock, flags);
		status.late_samples++;
		vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
	}
	vmm_monitor_sample(now);
	rc = vmm_workqueue_schedule_work(report_queue, &report_work);
	if (rc && rc != VMM_EALREADY) {
		vmm_spin_lock_irqsave_lite(&control_lock, flags);
		status.work_errors++;
		vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
	}
	now = vmm_timer_timestamp();
	next_sample += (udiv64(now >= next_sample ? now - next_sample : 0, VMM_MONITOR_NS) + 1) * VMM_MONITOR_NS;
	if (vmm_timer_event_start(ev, next_sample - now)) {
		vmm_spin_lock_irqsave_lite(&control_lock, flags);
		status.work_errors++;
		vmm_spin_unlock_irqrestore_lite(&control_lock, flags);
	}
}

static void monitor_timer_start(void *unused0, void *unused1, void *unused2)
{
	/* Static result avoids a stack pointer escaping a timed-out IPI call. */
	if (arch_atomic_read(&executor_state) < 0) return;
	next_sample = vmm_timer_timestamp() + VMM_MONITOR_NS;
	arch_atomic_write(&timer_start_result, vmm_timer_event_start(&sample_timer, VMM_MONITOR_NS));
}
#endif

int __init vmm_monitor_init(void)
{
	u32 i;
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	int rc;
	u64 init_deadline;
#endif
	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++)
		INIT_SPIN_LOCK(&slots[i].lock);
	vmm_monitor_irq_init();
	INIT_SPIN_LOCK(&sample_lock);
	vmm_monitor_guest_init();
	vmm_monitor_diag_init();
	INIT_MUTEX(&drain_lock);
	status.config.exit_rate = 50000;
	status.config.sustain_seconds = 5;
	status.config.log = TRUE;
	status.config.guest_cpu_limit_bp = 9000;
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	INIT_TIMER_EVENT(&sample_timer, monitor_timer, NULL);
	INIT_WORK(&report_work, report_fn);
	if (CONFIG_MONITOR_HCPU >= CONFIG_CPU_COUNT ||
	    !vmm_cpu_online(CONFIG_MONITOR_HCPU))
		return VMM_ENOTAVAIL;
	report_queue = vmm_workqueue_create("monitor_wq", CONFIG_MONITOR_PRIORITY);
	if (!report_queue)
		return VMM_ENOMEM;
	rc = vmm_threads_set_affinity(vmm_workqueue_get_thread(report_queue),
				      vmm_cpumask_of(CONFIG_MONITOR_HCPU));
	if (rc)
		goto fail_queue;
	/* Timer starts on the configured core, independently of vCPU priorities. */
	rc = vmm_smp_ipi_sync_call(vmm_cpumask_of(CONFIG_MONITOR_HCPU), 1000,
				   monitor_timer_start, NULL, NULL, NULL);
	if (rc) goto fail_queue;
	/* Upstream sync IPI waits for dequeue, not necessarily callback completion. */
	init_deadline = vmm_timer_timestamp() + VMM_MONITOR_NS;
	while (arch_atomic_read(&timer_start_result) == VMM_EINPROGRESS &&
	       vmm_timer_timestamp() < init_deadline)
		vmm_udelay(1);
	rc = arch_atomic_read(&timer_start_result);
	if (rc == VMM_EINPROGRESS) rc = VMM_ETIMEDOUT;
	if (rc) goto fail_queue;
#endif
	arch_wmb();
	arch_atomic_write(&initialized, 1);
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	arch_atomic_write(&executor_state, 1);
#endif
#ifdef CONFIG_MONITOR_START_ENABLED
	vmm_monitor_enable(TRUE);
#endif
	return VMM_OK;
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
fail_queue:
	arch_atomic_write(&executor_state, -1);
	vmm_workqueue_destroy(report_queue);
	return rc;
#endif
}

VMM_EXPORT_SYMBOL(vmm_monitor_enabled);
VMM_EXPORT_SYMBOL(vmm_monitor_irq_sample);
VMM_EXPORT_SYMBOL(vmm_monitor_mem_fault);
VMM_EXPORT_SYMBOL(vmm_monitor_exit);
