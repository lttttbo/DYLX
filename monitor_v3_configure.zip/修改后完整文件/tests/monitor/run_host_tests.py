"""Execute production monitor against deterministic host timing/IRQ APIs."""
import argparse, os, json, re, subprocess
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--cc',required=True); p.add_argument('--build-dir',required=True); a=p.parse_args()
root=Path(__file__).resolve().parents[2]; out=Path(a.build_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
shim=out/'include'
for name in ['vmm_types.h','vmm_manager.h','vmm_timer.h','vmm_stdio.h','vmm_modules.h','vmm_smp.h','vmm_cmdmgr.h','vmm_threads.h','vmm_workqueue.h','libs/stringlib.h','libs/mathlib.h','arch_barrier.h']:
    f=shim/name; f.parent.mkdir(parents=True,exist_ok=True); f.write_text('#include "host.h"\n')
(shim/'vmm_error.h').write_text('\n'.join(s for s in (root/'core/include/vmm_error.h').read_text().splitlines() if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',s))+'\n')
cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
flags=['-std=gnu11','-O2','-Wall','-Werror','-I'+str(shim),'-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
defs=['-DCONFIG_MONITOR_AGENT=1','-DCONFIG_CMD_MONITOR=1','-DCONFIG_MAX_VCPU_COUNT=4','-DCONFIG_CPU_COUNT=12','-DCONFIG_MONITOR_EXIT_RATE=50000','-DCONFIG_MONITOR_STORM_SECONDS=5','-DCONFIG_MONITOR_PRIORITY=3']
for mode in ['external','internal','external_boot','internal_boot']:
    exe=out/(mode+'.exe')
    cmd=cc+flags+defs+(['-DCONFIG_MONITOR_EXTERNAL_EXECUTOR=1'] if mode.startswith('external') else [])
    if mode.endswith('_boot'): cmd+=['-DCONFIG_MONITOR_START_ENABLED=1']
    subprocess.run(cmd+[str(root/'tests/monitor/test_monitor.c'),str(root/'commands/cmd_monitor.c'),'-o',str(exe)],check=True)
    for fault in (['normal'] if mode.startswith('external') or mode.endswith('_boot') else ['normal','queue-fail','affinity-fail','timer-fail']):
        r=subprocess.run([str(exe)]+([] if fault=='normal' else [fault]),capture_output=True,text=True)
        (out/(mode+'_'+fault+'.txt')).write_text(r.stdout+r.stderr)
        assert r.returncode==0, r.stdout+r.stderr
        records=[json.loads(s) for s in r.stdout.splitlines() if s.startswith('{')]
        if fault=='normal':
            assert records and all(x['schema']==3 for x in records)
            assert any('ready' in x for x in records) and any(x.get('type')==3 for x in records)
        print('PASS:',mode,fault,'JSON records:',len(records))
exe=out/'disabled.exe'
subprocess.run(cc+flags+[str(root/'tests/monitor/test_disabled.c'),'-o',str(exe)],check=True)
subprocess.run([str(exe)],check=True)
print('PASS: disabled hooks evaluate no arguments')
