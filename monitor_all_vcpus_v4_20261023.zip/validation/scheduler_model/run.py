"""Compile the delivered extracted-function model; not a firmware build."""
from pathlib import Path
import argparse, itertools, os, subprocess
p=argparse.ArgumentParser(); p.add_argument('--cc',required=True); p.add_argument('--build-dir',required=True); a=p.parse_args()
root=Path(__file__).resolve().parent; out=Path(a.build_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
CC=a.cc
for m,t,h,a in itertools.product([0,1],repeat=4):
    name=f'm{m}_t{t}_h{h}_a{a}'
    defs=[f'-D{k}=1' for k,v in [('CONFIG_MONITOR_AGENT',m),('CONFIG_CMD_LAT_CTX',t),('CONFIG_SCHED_HISTORY',h),('CONFIG_ADAPTIVE_HALT_TRAP',a)] if v]
    exe=out/(name+'.exe')
    subprocess.run([CC,'cc','-std=gnu2x','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter',*defs,'-I'+str(root/'include'),str(root/'test.c'),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
