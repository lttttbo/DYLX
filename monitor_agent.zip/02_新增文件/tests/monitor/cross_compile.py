"""Compile touched ARM64 units; no firmware link or hardware execution.
Use a portable Zig compiler: --cc /path/to/zig --build-dir /tmp/monitor-build
Optional --baseline-ref REF compares against that local Git revision.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True
from elf_budget import totals

p=argparse.ArgumentParser()
p.add_argument('--cc',required=True)
p.add_argument('--build-dir',required=True)
p.add_argument('--baseline-ref')
p.add_argument('--enforce-rom',action='store_true')
args=p.parse_args()
root=Path(__file__).resolve().parents[2]
out=Path(args.build_dir).resolve()
out.mkdir(parents=True,exist_ok=True)
defines=dict(CONFIG_64BIT=1,CONFIG_ARM64=1,CONFIG_ARM=1,CONFIG_ARMV8=1,
    CONFIG_SMP=1,CONFIG_CPU_COUNT=12,CONFIG_MAX_VCPU_COUNT=64,
    CONFIG_MAX_GUEST_COUNT=16,CONFIG_TSLICE_MS=10,CONFIG_ARM_MMU_LPAE=1,
    CONFIG_ARM_GENERIC_TIMER=1,CONFIG_HOST_IRQ_COUNT=1024,
    CONFIG_IRQ_STACK_SIZE=4096,CONFIG_THREAD_STACK_SIZE=8192,
    CONFIG_IDLE_PERIOD_SECS=2,CONFIG_IDLE_TSLICE_SECS=1,
    CONFIG_VGPA2REG_CACHE_SIZE=8,CONFIG_SCHEDALGO_PRR=1,
    CONFIG_LOG_LEVEL=6,CONFIG_MONITOR_AGENT=1,CONFIG_MONITOR_PRIORITY=6,
    CONFIG_MONITOR_HCPU=0,CONFIG_MONITOR_IRQ_SLOTS=16,
    CONFIG_MAJOR=0,CONFIG_MINOR=3,CONFIG_RELEASE=0,
    CONFIG_MAX_RAM_BANK_COUNT=16,CONFIG_MODULES=1,CONFIG_ARM_VGIC=1)
includes=['arch/arm/cpu/arm64/include','arch/arm/cpu/common/include',
    'arch/arm/board/generic/include','arch/arm/include','arch/include',
    'arch/common/include','core/include','drivers/include','libs/include']
new=['core/monitor/monitor_stats.c','core/monitor/monitor_agent.c',
    'core/monitor/monitor_irq.c','commands/cmd_monitor.c']
changed=['core/vmm_scheduler.c','core/vmm_shmem.c','core/vmm_main.c',
    'core/vmm_host_irq.c','arch/arm/cpu/arm64/cpu_interrupts.c',
    'arch/arm/cpu/arm64/cpu_vcpu_excep.c','arch/arm/cpu/common/vgic.c']
results={}
modes=['on','off','external']+(['baseline'] if args.baseline_ref else [])
for mode in modes:
    config=defines.copy()
    if mode=='off': config.pop('CONFIG_MONITOR_AGENT')
    if mode=='external': config['CONFIG_MONITOR_EXTERNAL_EXECUTOR']=1
    flags=[args.cc,'cc','-target','aarch64-freestanding-none','-std=gnu11',
        '-Os','-ffreestanding','-fno-builtin','-fno-stack-protector',
        '-mgeneral-regs-only','-D__VMM__','-Wall','-Werror',
        '-ffile-prefix-map='+str(root)+'=xvisor',
        '-ffile-prefix-map='+str(out/'baseline')+'=xvisor',
        # These two warnings occur in unmodified upstream ARM headers.
        '-Wno-duplicate-decl-specifier','-Wno-asm-operand-widths',
        '-include',str(root/'core/include/vmm_openconf.h')]
    flags += [f'-D{k}={v}' for k,v in config.items()]
    flags += ['-I'+str(root/path) for path in includes]
    results[mode]={}
    for name in (changed if mode in ['off','baseline'] else new+changed):
        source=root/name
        if mode=='baseline':
            source=out/'baseline'/name
            source.parent.mkdir(parents=True,exist_ok=True)
            source.write_bytes(subprocess.check_output(
                ['git','show',args.baseline_ref+':'+name],cwd=root))
        dest=out/(mode+'_'+Path(name).stem+'.o')
        run=subprocess.run(flags+['-DVMM_MODNAME='+Path(name).stem,
            '-c',str(source),'-o',str(dest)],capture_output=True,text=True)
        (out/(dest.stem+'.log')).write_text(run.stdout+run.stderr)
        if run.returncode:
            print(run.stdout+run.stderr)
            raise SystemExit(run.returncode)
        rom,bss=totals(dest)
        results[mode][name]=dict(rom=rom,bss=bss)
    print(f'PASS: {mode}: {len(results[mode])} ARM64 translation units')

rom=sum(results['on'][f]['rom'] for f in new)
bss=sum(results['on'][f]['bss'] for f in new)
delta=None
if 'baseline' in results:
    delta=sum(results['on'][f]['rom']-results['baseline'][f]['rom'] for f in changed)
report=dict(configuration=defines,objects=results,new_rom=rom,new_bss=bss,
    hook_rom_delta=delta,total_rom_estimate=rom+(delta or 0),rom_limit=5120,
    limitation='Object section estimate; product link and hardware performance not tested')
(out/'report.json').write_text(json.dumps(report,indent=2))
print(f'New ROM: {rom} bytes; static BSS: {bss} bytes; hook ROM delta: {delta}')
print('ROM budget: '+('PASS' if report['total_rom_estimate']<=5120 else 'FAIL'))
if args.enforce_rom and report['total_rom_estimate']>5120: raise SystemExit(1)
