/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef R6_MATH_H
#define R6_MATH_H
/* The includer supplies u64, in either the kernel or the host selftest. */
#define R6_HBINS 24
struct r6_dist { u64 n, sum, min, max, bins[R6_HBINS]; };
/* Bin0=[0,64)ns; bin1=[64,128)ns; last is open ended. */
static inline unsigned int r6_bin(u64 v)
{
        unsigned int b = 0;
        while (v >= 64 && b < R6_HBINS - 1) { v >>= 1; ++b; }
        return b;
}
static inline void r6_add(struct r6_dist *d, u64 v)
{
        if (!d->n || v < d->min) d->min = v;
        if (v > d->max) d->max = v;
        ++d->n; d->sum += v; ++d->bins[r6_bin(v)];
}
/* One matched wake cycle, not a packet. Sender RETURN is deliberately absent. */
static inline int r6_partition(u64 w, u64 q, u64 d, u64 a, u64 r,
                               int queued, u64 out[6])
{
        if (!w || !a || !r || w > a || a > r) return -1;
        out[0] = a-w; out[1] = r-a; out[2] = r-w;
        out[3] = out[4] = out[5] = 0;
        if (queued) {
                if (!q || !d || w > q || q > d || d > a) return -1;
                out[3] = q-w; out[4] = d-q; out[5] = a-d;
                if (out[3]+out[4]+out[5] != out[0]) return -1;
        }
        return out[0]+out[1] == out[2] ? 0 : -1;
}
#endif
