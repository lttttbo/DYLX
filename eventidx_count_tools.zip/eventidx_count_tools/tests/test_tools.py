#!/usr/bin/env python3
"""Synthetic tests only: no target-board or guest performance validation."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("report",ROOT/"eventidx_report.py")
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

def bits(state):
    a=list('0'*64);a[29]=str(state);a[32]='1';return ''.join(a)+'\n'

def net(pkts):
    # received data is control traffic only for this synthetic upstream test.
    a=[100,1,0,0,0,0,0,0,pkts*1442,pkts,0,0,0,0,0,0]
    b=[pkts*1442,pkts,0,0,0,0,0,0,100,1,0,0,0,0,0,0]
    return 'Inter-| Receive | Transmit\n face | bytes packets ...\n eth0: '+' '.join(map(str,a))+'\n tap1: '+' '.join(map(str,b))+'\n'

def interrupts(role,n):
    if role=='server':
        return f'           CPU0 CPU1\n131: {n} 0 GICv3 480 Level eth0\nIPI0: 4 2 Rescheduling interrupts\nIPI1: {n*2} {n*3} Function call interrupts\n'
    return f'           CPU0 CPU1\n40: {n} 0 PCI-MSI virtio0-config\n41: {n*2} 0 PCI-MSI virtio0-input.0\n42: 0 {n*3} PCI-MSI virtio0-output.0\n43: 0 {n*9} PCI-MSI virtio01-output.0\nIPI1: 0 {n} Function call interrupts\n'

def kernel(state,route,worker=1053,dev='abcd',fd=12):
    return (f'[3.0] IOEM_CFG vmid=1 route={route} action=assign addr=0x6020003004 len=2 fd={fd} ret=0\n'
            f'[3.001] VQMAP bind tgid=172 tid=631 dev={dev} q=1 worker={worker} kickfd={fd} kick_fn=handle_tx_kick\n'
            f'[3.002] VQCFG dev={dev} q=1 worker={worker} event_idx={state} packed=0 busyloop_us=0 size=1024\n')

def capture(root,role,state):
    d=root/f'{role}_{state}';d.mkdir()
    ids='131' if role=='server' else '40 41 42'
    (d/'meta.env').write_text(f'role={role}\nstate_declared={state}\nroute_declared=client\nnet_if=eth0\ntap_if=tap1\ndirection=up\npayload_bytes=1400\nirq_ids={ids}\nirq_method=action_name\nkernel=test\nvirtio=virtio0\n')
    (d/'status.env').write_text('status=OK\n')
    for side,tm,pkts,ic in [('before',100,1000,200),('after',130,11000,1200 if state=='off' else 700)]:
        if role=='android':tm+=10000
        for counter in ('netdev','interrupts','stat'):
            for edge in ('begin','end'):(d/f'{side}.{counter}.{edge}').write_text(str(tm))
        (d/f'{side}.netdev').write_text(net(pkts))
        (d/f'{side}.interrupts').write_text(interrupts(role,ic))
        c=100 if side=='before' else 300
        (d/f'{side}.stat').write_text(f'cpu {c} 0 {c} {c*3} 0 0 {c} 0 0 0\ncpu0 {c//2} 0 {c//2} {c*3//2} 0 0 {c//2} 0 0 0\ncpu1 {c//2} 0 {c//2} {c*3//2} 0 0 {c//2} 0 0 0\n')
        (d/f'context.{side}.env').write_text('boot_id=x\ndevice=virtio0\nifindex=2\nmac=x\nonline=0-1\nirq_131_effective_affinity_list=0\n')
        (d/f'threads.{side}.tsv').write_text('1053\tvhost-631\t367\t0\n')
        (d/f'features.{side}').write_text(bits(int(state=='on')))
        (d/f'kernel_map.{side}.txt').write_text(kernel(int(state=='on'),'client'))
    return d

class Tests(unittest.TestCase):
    def test_features_low_bit_first(self):
        self.assertEqual(r.feature(bits(1)),1);self.assertEqual(r.feature(bits(0)),0)
        self.assertIsNone(r.feature('0x20000000'))
    def test_large_counter_exact(self):
        n=2**55+123
        self.assertEqual(r.parse_net(net(n))['eth0'][9],n)
        self.assertEqual(r.subtract([n+4],[n],'x'),[4])
    def test_negative_rejected(self):
        with self.assertRaises(ValueError):r.subtract([3],[9],'x')
    def test_interrupt_not_hwirq(self):
        cp,rows=r.parse_interrupts(interrupts('server',44))
        self.assertEqual(rows['131']['counts'],[44,0]);self.assertIn('480',rows['131']['desc'])
    def test_unbind_does_not_reactivate_on_vqcfg(self):
        s=kernel(1,'client')+'[5.0] VQMAP unbind dev=abcd q=1 worker=1053\n[5.1] VQCFG dev=abcd q=1 worker=1053 event_idx=1\n'
        self.assertFalse(r.kernel_config(s)['verified'])
    def test_latest_binding(self):
        s=kernel(0,'client')+'[5.0] VQMAP unbind dev=abcd q=1 worker=1053\n'+kernel(1,'asyncio',2139,'efgh',16)
        c=r.kernel_config(s);self.assertEqual(c['worker'],'2139');self.assertEqual(c['route'],'asyncio')
    def test_ambiguous_no_guess(self):
        c=r.kernel_config(kernel(0,'client')+kernel(1,'client',2139,'efgh',16))
        self.assertFalse(c['verified'])
    def test_route_deassign_invalidates(self):
        c=r.kernel_config(kernel(1,'client')+'[9] IOEM_CFG vmid=1 route=client action=deassign addr=0x6020003004 fd=12\n')
        self.assertFalse(c['verified'])
    def test_guest_feature_mismatch(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'android','off');(d/'features.after').write_text(bits(1))
            self.assertEqual(r.summarize(d)['status'],'ERROR')
    def test_host_route_mismatch(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'server','on');(d/'meta.env').write_text((d/'meta.env').read_text().replace('route_declared=client','route_declared=asyncio'))
            self.assertIn('Network IOEM route does not match declared client/asyncio',r.summarize(d)['errors'])
    def test_shared_not_invent_tx(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'android','on')
            for side in ('before','after'):
                f=d/f'{side}.interrupts';f.write_text(f.read_text().replace('virtio0-output.0','virtio0-virtqueues'))
            s=r.summarize(d);self.assertIsNone(s['irq']['tx']);self.assertIsNotNone(s['irq']['shared_or_unknown'])
    def test_compare_and_independent_clocks(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);paths={role+'_'+state:capture(p,role,state) for role in ('server','android') for state in ('off','on')}
            out=p/'report';r.compare(paths,out)
            j=json.loads((out/'comparison.json').read_text());self.assertFalse(j['comparison_issues'])
            rr=[x for x in j['rows'] if x['kind']=='tx'][0];self.assertAlmostEqual(rr['reduction_percent'],50)
    def test_label_swap_rejected_comparison(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);paths={role+'_'+state:capture(p,role,state) for role in ('server','android') for state in ('off','on')}
            paths['server_off'],paths['server_on']=paths['server_on'],paths['server_off']
            out=p/'report';r.compare(paths,out)
            self.assertTrue(json.loads((out/'comparison.json').read_text())['comparison_issues'])
    def test_missing_ipi_is_none(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'server','off')
            for side in ('before','after'):
                f=d/f'{side}.interrupts';f.write_text('\n'.join(l for l in f.read_text().splitlines() if not l.startswith('IPI')))
            self.assertIsNone(r.summarize(d)['function_call_ipi'])
    def test_clock_reversal(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'server','off');(d/'after.netdev.end').write_text('99')
            with self.assertRaises(ValueError):r.summarize(d)
    def test_collector_inspect_and_capture_mock_sysfs(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);proc=p/'proc';sys=p/'sys';proc.mkdir();sys.mkdir();(proc/'net').mkdir()
            (sys/'class/net/eth0').mkdir(parents=True);vd=sys/'devices/pci0000/0000:00:00.0/virtio0';vd.mkdir(parents=True)
            (sys/'class/net/eth0/device').symlink_to(vd)
            (vd/'features').write_text(bits(1))
            (vd.parent/'msi_irqs').mkdir()
            for n in [40,41,42]:(vd.parent/'msi_irqs'/str(n)).write_text('msix')
            (proc/'interrupts').write_text(interrupts('android',100));(proc/'net/dev').write_text(net(1000))
            (proc/'uptime').write_text('100.00 40.00\n');(proc/'stat').write_text('cpu 100 0 100 300 0 0 100 0 0 0\n')
            (proc/'softirqs').write_text(' CPU0 CPU1\n NET_TX: 20 20\n')
            b=p/'bin';b.mkdir();sl=b/'sleep'
            # Fast, deterministic fake kernel updates on the requested 1s sleep.
            sl.write_text('#!/bin/sh\nif [ "$1" = 1 ]; then\n echo "101.00 40.00" > "$EIC_PROC_ROOT/uptime"\n cp "$FIXTURE_ROOT/net_after" "$EIC_PROC_ROOT/net/dev"\n cp "$FIXTURE_ROOT/int_after" "$EIC_PROC_ROOT/interrupts"\nfi\n')
            sl.chmod(0o755);(p/'net_after').write_text(net(11000));(p/'int_after').write_text(interrupts('android',200))
            env=dict(os.environ,EIC_PROC_ROOT=str(proc),EIC_SYS_ROOT=str(sys),OUT_DIR=str(p/'capture'),
                     PATH=str(b)+':'+os.environ['PATH'],WAIT_MODE='manual',WARMUP='0',FIXTURE_ROOT=str(p))
            q=subprocess.run(['sh',str(ROOT/'eventidx_count.sh'),'inspect','android'],env=env,capture_output=True,text=True)
            self.assertEqual(q.returncode,0,q.stderr);self.assertIn('irq_ids=40 41 42',q.stdout)
            self.assertNotIn('43:',q.stdout)
            q=subprocess.run(['busybox','sh',str(ROOT/'eventidx_count.sh'),'capture','android','on','client','1'],env=env,capture_output=True,text=True)
            self.assertEqual(q.returncode,0,q.stderr)
            s=r.summarize(p/'capture');self.assertEqual(s['net']['main_packets'],10000);self.assertEqual(s['irq']['tx']['delta'],300)
    def test_kicks_counted_not_inferred(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'android','on')
            for side,tm,count in [('before',10100,2**55+100),('after',10130,2**55+400)]:
                for edge in ('begin','end'):(d/f'{side}.ethtool.{edge}').write_text(str(tm))
                (d/f'{side}.ethtool.rc').write_text('0')
                (d/f'{side}.ethtool').write_text(f'NIC statistics:\n tx_queue_0_kicks: {count}\n rx_queue_0_kicks: 9\n physical_tx_irqs: 666\n')
            s=r.summarize(d)
            self.assertEqual(s['kicks']['tx']['delta'],300)
            self.assertEqual(s['kicks']['rx']['delta'],0)
            self.assertNotIn('guest_to_backend_kick_count',s['not_measured'])
    def test_ethtool_failure_is_na(self):
        with tempfile.TemporaryDirectory() as t:
            d=capture(Path(t),'android','on')
            for side in ('before','after'):
                (d/f'{side}.ethtool.rc').write_text('1')
                (d/f'{side}.ethtool').write_text('tx_queue_0_kicks: 0')
            s=r.summarize(d);self.assertIsNone(s['kicks']['tx'])

    def test_collector_no_traffic_timeout(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);proc=p/'proc';sys=p/'sys';(proc/'net').mkdir(parents=True);(sys/'class/net/eth0').mkdir(parents=True)
            (proc/'interrupts').write_text(interrupts('server',0));(proc/'net/dev').write_text(net(1));(proc/'uptime').write_text('1.0 0\n')
            env=dict(os.environ,EIC_PROC_ROOT=str(proc),EIC_SYS_ROOT=str(sys),OUT_DIR=str(p/'cap'),WAIT_TIMEOUT='0',WARMUP='0')
            q=subprocess.run(['sh',str(ROOT/'eventidx_count.sh'),'capture','server','off','client','1'],env=env,capture_output=True,text=True,timeout=5)
            self.assertNotEqual(q.returncode,0);self.assertIn('Traffic wait timeout',q.stderr)
            self.assertEqual(r.envfile(p/'cap/status.env')['status'],'ERROR')

if __name__=='__main__':unittest.main()
