# HOS 中断优先级诊断 v4（2026-11-10）

本包定位 `irq_priority` 第一个用例的 107/108 超时。新增一个独立的
`irq_priority_debug` 用例，仍归属 `interrupt` 测试组，沿用现有中断测试编译开关。
只新增一个 C 文件及一条对象编译项，不改 HOS/GIC 生产代码、Guest 内核、设备树或 monitor。
这是诊断版本，不是已确认根因后的修复版本。

## 1. 依据现有材料能确定什么

### 优先级 0 和 1 是逻辑等级

你提供的 `gic_irq_set_priority()` 先执行 `pri = priority << irq_pri_bits`，
再写入对应中断的优先级字节。因此不能把测试参数 0、1 直接视为两个原始寄存器值，
也不能据此认定它们都被硬件舍入为零。本诊断保留逻辑等级 0、1，检查设置返回值和读回值。
不要直接把参数改成 0x40、0xa0；这些值可能超出该接口允许的逻辑等级范围。

仍需确认 `get_reg_base()`、优先级读回和 PMR 实现是否正确；本次尚无这些私有实现。

### 同时置 pending 的位运算适用于这对 IRQ

当前 IRQ 与 HWIRQ 都是 107、108。两者在同一个 32 位寄存器中：

```text
107 / 32 = 3
107 % 32 = 11
108 % 32 = 12
写地址 = GICD_ISPENDR 基址 + 3 * 4
写入值 = (1U << 11) | (1U << 12) = 0x00001800
```

这只能证明代码选择的 pending 位正确。`trigger_two()` 返回 0 只代表函数完成写操作，
没有检查 CPU 是否接收、Host 分发函数是否运行、测试回调是否被调用。
通用接口还存在 HIRQ/HWIRQ 映射边界检查不一致的问题；对于当前相等的 107/108，
它不是已经成立的故障原因。诊断会验证两个 descriptor 的相邻 HWIRQ、同一 bank 和同一 chip。

### irq stats 是累计计数

107 的 CPU0=2、108 的 CPU0=1 表示此前有分发记录，不能直接证明失败用例期间两个回调都执行了。
原 `irq_base` 还调用过 `vmm_host_generic_irq_exec(SPI_ID1)`；参考核心实现也会为这种软件分发增加计数。
所以 107 多一次可能来自后续 base 测试，需要运行顺序确认。

表中名称为 `test_irq_1/2` 不等于 IRQ 一定空闲或一定专供测试。参考实现的名称字段也不能代替 action 链表检查。

### 现有测试已经存在会污染后续测试的路径

原 priority 用例超时直接返回，没有 unregister；base 用例又假定 108 未注册。
这能解释“先 priority 失败，随后 base 的第一次 unregister 成功却被判失败”的可能链路，
但仍需确认两张截图是否来自同次启动、相同顺序。

参考上游 register() 会自动 unmask；原用例在注册之后才清完成标志，
回调又会 mask，因此需记录正式触发之前是否已有回调。原代码随后还有显式 unmask，
所以单凭这一时序不能直接认定它就是超时根因。

Guest 内核升级目前只是时间上的关联，不能据此确定是 Linux 6.12 的特定新特性导致。

## 2. 手动合入

新增完整文件：

```text
libs/wboxtest/interrupt/test_irq_priority_debug.c
```

从本包 `full_files/` 复制。`changes.patch` 只新增这个文件，无生产文件覆盖。

然后找到工程中编译 `wboxtest/interrupt/test_irq_priority.o` 的 objects.mk 条目，
复制该条目，只把对象文件名替换成 `test_irq_priority_debug.o`，保持左侧变量、编译条件、路径前缀不变。
也可以在原条件对应的对象列表中追加：

```text
wboxtest/interrupt/test_irq_priority_debug.o
```

不能只复制 C 文件而遗漏对象条目。由于未提供当前私有 objects.mk，本包没有猜测开关名或修改该文件。
不增加 Kconfig 项。现有 `test_irq.h` 和其 SPI_ID1/SPI_ID2 定义继续使用。

测试需要已有接口：register/unregister、mask/unmask、get/set_priority、priority_level、trigger_two、
get/set_routed_state、get_count，以及 descriptor 的 action_list/action_lock。
`get_priority()` 应返回与 `set_priority()` 参数一致的逻辑等级。
若它返回原始寄存器字节，需要先提供该函数实现进行适配，不能直接修改诊断中的范围检查绕过。

参考上游 get_routed_state() 虽带 routed 字样，也可读取普通 SPI 的 pending/active/masked 状态，
并不需要把 IRQ 设置成 Guest routed。若 HOS 修改了该语义或未实现回调，本例会拒绝运行；
不要为了通过测试修改 IRQ 的归属或 routed 标志。

## 3. 单板运行

先确认板级配置中的 SPI_ID1/SPI_ID2（当前 107/108）确实专供测试，
没有真实设备使用，也未分配给 Guest。无已注册 action 只是必要检查，不能替代板级资源确认。
不要与其他 IRQ 配置或中断用例并发运行。按现有方式静态编入 wboxtest。

建议重新启动 HOS，在旧的 irq_priority/irq_base 之前单独执行：

```text
hos irq stats
unittest run_tests 1 irq_priority_debug
hos irq stats
```

请保留从 `IRQDBG begin` 到 `IRQDBG result` 的完整输出，包括 result=0 的情况。
不要先运行整个 interrupt group；旧 priority 的失败路径会遗留 action，且其 case2/case3
还未重置 exec_order 下标，可能产生越界写入，影响诊断环境。

如果出现 `actions` 非零或 routed/per_cpu/ipi/chained 等不符合前置条件，本例拒绝注册。
它不会用 `unregister(irq, NULL)` 强行删除其他处理函数。先查清已有 owner，
如果是旧测试残留，重启后单独重试；不要自动释放未知 owner。

## 4. 收集流程及函数

| 函数 | 作用 |
|---|---|
| ipd_run | 串行化本例，准备、执行、采集结束快照、清理，输出诊断与结果 |
| ipd_prepare | 检查空闲专用 SPI、已有 action、路由标志、逻辑优先级、pending/active 和 mask 状态，保存原值 |
| ipd_actions | 按 CPU 在 action 读锁保护下统计全部或本例拥有的处理函数；统计数不是设备个数 |
| ipd_phase | 更新当前测试阶段，供异步回调记录 |
| ipd_snapshot | 记录 API 返回值、硬件状态、软件 mask、逻辑优先级、PMR 等级和各核计数 |
| ipd_exercise | 保留原 case1 的注册→设优先级→unmask→trigger_two 顺序；检查返回值；等候最多 1 秒 |
| ipd_handler | 记录时间、IRQ、CPU、所在阶段；更新受锁保护的完成计数；mask 本 IRQ；返回 IRQ_HANDLED |
| ipd_cleanup | 注销唯一 dev 指针对应的本例 action，等待 active 结束，清本例测试 pending，恢复原优先级、名称和 mask |
| ipd_dump | 在测量结束后输出阶段快照和回调记录 |
| ipd_init / ipd_exit | 按原有模块机制注册/注销 interrupt 组中的 irq_priority_debug |

结构体 ipd_source 保存两个 IRQ 的原始值和修改进度；ipd_frame_irq 保存单个 IRQ 的一次状态；
ipd_frame 保存某阶段两路 IRQ 的快照；ipd_trace 保存单次回调；ipd_data 是静态诊断存储。
固定上限为 12 帧、16 条回调记录，超出回调上限记 dropped，不越界写入。

回调内不打印，避免原处理函数的串口输出直接延长 ISR 执行。
诊断不强制改 affinity，也不改触发类型；这样能看到原配置是否导致送达不同 CPU。
寄存器读取通过已有 get_routed_state，未读取会应答中断的 IAR，也不会强行清 active。

失败也走清理；register 部分成功时，检查实际遗留的 action 并尝试只注销本例。
若 active 不退、注销不完整或状态恢复失败，本例报错并禁止再次复用静态回调存储，提示重启。
这不意味着硬件问题被自动修好；需保留 cleanup 记录继续分析。

## 5. 日志解读

阶段顺序：

```text
before → register0 → register1 → priority0 → priority1 → arm
       → unmask0 → unmask1 → trigger → wait → finish → cleanup
```

`wait` 是回调可记录的阶段；本例不每轮打印/保存 wait 帧。
在写 pending 的函数调用过程中就进入回调时，stage=trigger 是正常的。

| 字段 | 含义 |
|---|---|
| step / rc | 此步骤及对应操作返回值，0 表示 API 成功；before/arm 为无操作快照 |
| time_ns / cpu / irq_off | 采集时间、执行采集的 CPU、当时本地 IRQ 是否关闭 |
| hw_rc / hw | 状态查询返回值与硬件状态位；仅 hw_rc=0 时解析 hw |
| sw_mask | 当前读取 CPU 视角的软件 mask 标志，与硬件状态不同来源 |
| prio_rc / prio | 读优先级返回值和逻辑等级；设置后期望 107=0、108=1 |
| level_rc / levels / pmr_level | 优先级能力查询结果、逻辑等级总数、现有接口读出的 PMR 逻辑门限 |
| calls / fired | 总回调次数 / 在 trigger 或 wait 阶段发生的回调次数 |
| cpu_count_delta=0:1, | 从 before 基线起 CPU0 的 Host IRQ 计数增加 1；不打印零增量 CPU |
| callback / stage / cpu | 单次实际进入本例回调的序号、阶段、CPU |
| order_high / order_low | 触发后两路第一次回调的记录顺序，期望 1、2 |
| outside_trigger_wait | 正式 trigger/wait 之外的回调数，包含提前和清理阶段回调 |
| cleanup_rc / result | 清理结果 / 本例最终结果；0 成功，非零结合此前步骤定位 |
| dropped | 回调记录容量不足的次数，非零时证据不完整，本例不判通过 |

PMR 值由你当前的 gic_read_pmr() 决定读取语义。如果读取的是本地 CPU 接口，
这里对应快照 CPU，不能代表其他目标 CPU 的 PMR。affinity 是软件请求掩码，
不能等同于已读到 GICD_IROUTER 的实际硬件目标；本例尚不直接读 IROUTER。

硬件状态位：pending=bit0，active=bit1，masked=bit2。组合例子：

| finish 阶段状态及回调 | 下一步判断 |
|---|---|
| hw=0x1，fired=0 | pending 还在且 enable 未被 mask；检查 PMR、目标 CPU、Group enable、路由和 CPU 接口条件 |
| hw=0x5，fired=0 | pending 且 masked；对照各步骤看何时被屏蔽，并查有无正式触发前回调 |
| hw 含 bit1 且久久不退 | 检查 handler/EOI/deactivate 生命周期；不能仅凭一帧瞬间 active 判异常 |
| 计数增量>0，calls=0 | 分发有记录但本例回调没有进入，或计数来自别处；检查 action 注册和 irq flow handler |
| calls>fired，trace 在 register/unmask | 已证实触发前回调；结合后续 unmask 和 pending 状态判断是否造成超时 |
| fired 两者均为1，但 cpu_high!=cpu_low | 不能用这次跨核回调顺序证明同核优先级仲裁，本例判证据不满足 |
| fired 两者均为1，同核且顺序1/2 | 本次诊断观察到预期送达顺序，仍要检查读回、提前回调及 cleanup |

判断超时现场看 **finish** 帧；cleanup 会按设计 mask、清 pending 和恢复状态，
不要拿 cleanup 的 masked 值倒推超时发生前是否被屏蔽。
所有字段不是硬件原子快照，读取各项期间中断仍可能发生；需结合相邻帧和回调时间看趋势。
before 起算的增量还包括注册期间的回调；可对比 unmask1 和 finish 帧进一步区分正式触发段。

## 6. 判定边界与下一步资料

本例 PASS 只说明本次专用 SPI 诊断满足读回、同核回调顺序、次数和恢复条件。
它不是全部 interrupt 需求验收，也不能证明“升级内核导致的问题已修复”。
相较原例，诊断采用唯一 dev、完成计数锁保护、IRQ_HANDLED 和回调后统一打印，
加上额外状态读取，都会改变时序。若原例失败而诊断通过，要继续检查原测试的竞态、
忽略 register 返回值、清理遗漏和回调内串口输出，不能直接归因于 Guest 驱动。

如仍超时，先提供完整 IRQDBG 日志。根据结果可能进一步需要：

- 当前 HOS 的 get_reg_base()、gic_read_pmr()、gic_irq_get_priority()。
- 当前 vmm_host_irq_register/unregister/unmask 及 GIC 的 mask/unmask 实现。
- 超时时的 GICD_IROUTER、Group enable、目标 CPU PMR/运行优先级等状态；
  这部分需按实际寄存器访问封装适配，不能使用未知地址直接读。
- 107/108 的板级资源归属，以及此次是否只换 Guest 内核，HOS/DTB/固件是否保持一致。

现有代码的其他明确问题（case2/3 数组下标、case4 忽略返回值及延迟统计起点、
affinity 的默认 ALL 假定、base 的名称比较和清理）尚未在本包修改。
先拿首个超时的证据，再集中修订原测试，避免一次改太多导致无法比较。

## 7. 本地验证与占用

通过：ARM64 freestanding 对象编译，4 核/12 核，-Os/-O2，-Wall -Wextra -Werror；
必要的参考头文件警告使用既有构建豁免。私有 IRQ 接口声明按已提供的调用形式补入验证环境，
没有将验证头文件加入交付源码。

通过 16 个接口模拟场景：正常、无送达、单路送达、提前回调、颠倒顺序、跨 CPU、
注册部分失败、设置优先级失败、读回不符、已有 action、初始 pending、查询不支持、
IRQ 关闭、active 不退、注销失败、回调 mask 失败。
断言验证拒绝路径不改状态、正常/超时路径清理与恢复，以及清理失败后禁止重用。
模拟接口不等于 GIC 硬件测试；没有执行 HOS 完整 GCC12 链接或单板验证。

参考 12 核 -Os 对象：静态可写空间 3440 字节（含模块元数据和测试结构），
可加载段合计 5821 字节（包含数据及元数据，不能直接当最终固件 ROM 增量）。
编译进来即存在这些静态数据；运行时 register 还会由 IRQ 框架分配 action，
正常与超时路径均尝试释放；测试没有自己创建线程。
这属于临时诊断测试，不属于 monitor 生产代理的 5KB 指标。
最终内存与链接大小以 HOS 工具链/配置/镜像为准。
