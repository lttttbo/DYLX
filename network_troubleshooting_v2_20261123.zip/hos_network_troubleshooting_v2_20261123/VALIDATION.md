# 验证记录

日期：2026-11-23。

## 已完成

- 主脚本通过 Git for Windows 的 sh 语法检查；33 项本地检查通过，其中一项包含15组无效参数输入。
- 用独立 proc/sys 夹具和命令替身验证所有阶段、缺工具/权限失败/PID消失/namespace差异、读取错误码、无超时拒绝主动操作、无超时跳过ethtool、输出目录含空格和不覆盖已有文件。
- 使用实际 awk 运行十进制字符串差值，覆盖大于2^53、接近u64上限、借位、计数下降、boot/ifindex变化和缺字段。
- 使用 marked 解析 Markdown：66个标题、21个表格、67个代码块；无UTF-8替换字符。已人工复核分层排查分支及脚本参数一致性。
- 两轮独立审阅检查链路边界、TAP方向、namespace、前后端证据、命令返回值与退出清理。

## 验证边界

本地没有连接HOS单板、没有产生真实网络流量。工具模拟仅检验控制逻辑和结果处理，不替代实际Linux/Android驱动、权限和工具兼容测试。

尚未执行：Android mksh/Toybox、BusyBox ash、真实pcap写入及解析、真实Linux timeout信号转发和Ctrl+C子进程退出、磁盘实际耗尽、真实板端网络回归。示例pcap夹具仅用于分支检查，没有作为交付抓包文件。

已增加有限清理观察；若无法确认子进程退出，打印CLEANUP_UNCONFIRMED并保留PID，不能宣称任何内核阻塞都被强制结束。

## 目标板首次验证建议

1. 将sh与awk放同目录，执行help和selfcheck，确认工具与timeout能力。
2. 在正确角色执行basic，核对接口/namespace，确认网络配置未被改变。
3. sample观察静态计数和实际测试流量，结合原始uptime而非名义seconds计算速率。
4. 明确允许发包后执行短probe；检查ping输出，不把采集rc0当作网络通过。
5. 执行短capture，检查pcap可被tcpdump/Wireshark读取；测试自然到期、无流量和Ctrl+C，核对没有残留本次子进程。
6. 按文档定位到的区间运行对应阶段，正常/异常现场各留一份。权限/工具缺失时保留PARTIAL而非误报通过。

## 本地检查项

- shell syntax
- UTF8 and balanced code fences
- chapters 1 to 15
- old chapter14 deleted
- help works
- 15 invalid argument combinations
- basic and path with spaces
- basic never pings or captures
- no basic config mutations
- missing optional command
- permission failure retained
- DM disappeared
- namespace mismatch
- cmdline read failure rc retained
- unguarded ethtool skipped
- missing interface
- sample integration
- Android compat no DM
- no capture without verified timeout
- explicit probe
- probe failure retained
- capture rc124 and empty warning
- unknown capture timeout incomplete
- other stages executed
- invalid output preserved
- exact above 2^53
- exact near u64 max
- decrease not negative loss
- boot change rejected
- ifindex change rejected
- missing counter rejected
- identity missing rejected
- decimal borrow exact

工具环境：Windows Git sh/awk; mocked tools and isolated proc/sys。
