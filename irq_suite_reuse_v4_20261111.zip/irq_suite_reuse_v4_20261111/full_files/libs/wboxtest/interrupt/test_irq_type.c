/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright (c) 2024 ZTE Authors. All rights reserved. */
#include "test_irq.h"

#define MODULE_DESC "test_irq_type test"
#define MODULE_AUTHOR "ZTE Authors"
#define MODULE_LICENSE "GPL"
#define MODULE_IPRIORITY (WBOXTEST_IPRIORITY + 3)

static int type_cases(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq;
	u32 state;
	int rc;

	vmm_cprintf(out, "TEST1: irq=%u get type/state\n", test_irq_id(0));
	rc = vmm_host_irq_get_type(test_irq_id(0));
	if (rc < 0) {
		return rc;
	}
	vmm_cprintf(out, "TEST2: set level/edge trigger and reject SGI type change\n");
	rc = test_irq_set_trigger(1, VMM_IRQ_TYPE_LEVEL_HIGH);
	if (!rc && !vmm_host_irq_set_type(SGI_ID1, VMM_IRQ_TYPE_LEVEL_HIGH)) {
		rc = VMM_EFAIL;
	}
	if (!rc) {
		rc = test_irq_set_trigger(2, VMM_IRQ_TYPE_EDGE_RISING);
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST3: set level trigger and check LEVEL state\n");
	rc = test_irq_set_trigger(3, VMM_IRQ_TYPE_LEVEL_HIGH);
	irq = vmm_host_irq_get(test_irq_id(3));
	if (!rc && !vmm_host_irq_is_level_type(irq)) {
		rc = VMM_EFAIL;
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST4: masked/active state and software handler dispatch\n");
	rc = test_irq_register(0, "test_irq_type");
	if (!rc) {
		rc = vmm_host_irq_get_routed_state(test_irq_id(0), &state, TEST_IRQ_HW_STATE);
		if (!rc && state != VMM_ROUTED_IRQ_STATE_MASKED) {
			rc = VMM_EFAIL;
		}
	}
	if (!rc) {
		rc = test_irq_software(0, TRUE);
	}
	return rc;
}

static int test_irq_type_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
	int rc = test_irq_begin(out, cpu, 0);

	(void)test;
	if (rc) {
		return rc;
	}
	rc = type_cases(out);
	return test_irq_end(out, rc);
}

static struct wboxtest test_irq_type = {
	.name = "irq_type",
	.run = test_irq_type_run,
};

static int __init test_irq_type_init(void)
{
	return wboxtest_register("interrupt", &test_irq_type);
}

static void __exit test_irq_type_exit(void)
{
	wboxtest_unregister(&test_irq_type);
}

VMM_DECLARE_MODULE(MODULE_DESC, MODULE_AUTHOR, MODULE_LICENSE, MODULE_IPRIORITY, test_irq_type_init,
		   test_irq_type_exit);
