# Monitor v4：从记录版直接合入统一测试集

日期：2026-10-25。唯一升级基线：`monitor_observer_from_20261023_v4_20261025` 已合入后的工程。

## 1. 合入关系

本包直接包含从上述记录版到“单一测试开关 + Hypervisor 测试”的全部差异。无需先合入 unified、hv_tests 或 one_option 等中间包，也不要叠加它们的旧补丁。

只有两份补丁，均以 Hypervisor 根目录为路径起点：

1. `from_observer.patch`：以记录版交付结果为基线，包含核心测试支持、code=8 定义、测试归组与目录迁移、9 项用例的单一配置、模型工具和说明。
2. `cmd_memory_from_uploaded.patch`：记录版没有修改该文件，因此以你上传的带检查版本 `cmd_memory.c.txt` 为基线，追加三个原失败分支的记录及测试适配函数。它不是从原始开源 cmd_memory.c 整体替换的补丁。

两份都要合入；差异较多的私有工程按 `merge_locations.txt` 中的函数、上下文和原行号操作。`full_files` 提供全部新增/修改后的完整参考文件；保留你自己的其他改动。

既有 cpu_hcall.c、vmm_u_ioreq.c、vmm_shmem.c 和调度器沿用已合入的记录版，不重复修改。无 Linux/Android 内核或 CCM 驱动修改，无新 ioctl。保留原访问策略、错误返回及 VM 生命周期行为。

## 2. 配置和运行

monitor 测试侧只保留：

```text
CONFIG_WBOXTEST_MONITOR=y
```

已有框架/产品功能仍需启用：`CONFIG_WBOXTEST=y`、`CONFIG_MONITOR_AGENT=y`、`CONFIG_CMD_MONITOR=y`。测试选项自动选择 `CONFIG_CMD_WBOXTEST`、`CONFIG_CMD_MEMORY`，不再提供 HOST/LIVE 子开关。

合入后重新生成配置，清理旧测试对象并重新构建。旧 `CONFIG_WBOXTEST_MONITOR_LIVE` 不再生效；不要保留旧 monitor_live/objects.mk 的编译行。只删除补丁列出的七份旧文件，不删除用户其他文件。

```text
monitor start
wboxtest group_list
wboxtest run_groups 1 monitor
```

也可以逐项运行新增用例：

```text
wboxtest run_tests 1 monitor_host_range
wboxtest run_tests 1 monitor_host_guest_guard
wboxtest run_tests 1 monitor_host_shmem
```

共 9 项，统一属于 monitor 组。Guest 现场用例的 5 份 C/H 文件迁移到 monitor/live 保留，但当前不构建、不注册；不是跳过后算 PASS。旧 protocol.h/专用 Guest 测试资料不参与本阶段流程。

不需要 Guest 用户态程序或新 Guest。Guest 写保护用例需要现有符合原检查条件的 Guest RAM/ROM 映射，但 Guest 不必运行。缺少条件会明确失败，不作为通过。保持 monitor 启停、配置及 VM 生命周期、映射稳定；新增用例的每次采样等待上限为 8 秒。

## 3. 用例与需求覆盖

| 用例 | 主要检查 | 层级与边界 |
|---|---|---|
| monitor_lifecycle | 启停、epoch、状态重置及旧状态隔离 | 隔离实例 |
| monitor_config | 配置命令、参数和阈值更新行为 | 隔离实例 |
| monitor_scheduler | READY 等待、dispatch 统计及边界 | 模拟时间/调度输入；不代替真实调度器打点验收 |
| monitor_memory | 内存事件及共享内存错误处理 | 隔离实例和替身平台 |
| monitor_storm | 陷入阈值、持续窗口、去重和恢复 | 模拟 exit 输入；不代替 Guest 实际 HVC 负载 |
| monitor_output | JSON/输出及日志调用行为 | 隔离实例；不证明落盘 |
| monitor_host_range | 原命令地址检查拒绝后，真实 monitor 记录事件 | 调用原检查；不读写非法物理地址 |
| monitor_host_guest_guard | 原禁止写 Guest 地址的分支拒绝后，真实 monitor 记录事件 | 使用已有映射；不写 Guest 内存 |
| monitor_host_shmem | 真实共享内存 API 合法读写/填充，以及三类普通越界 | 使用测试专用对象，核对事件及数据未破坏 |

新三个用例不直接调用 monitor 事件注入、sample 或 drain 来制造成功。操作前读取事件游标和真实采样完成序号，操作后等待两个采样完成，再匹配 code、地址、detail、主体、epoch、时间和次数。采样停滞、lost/skipped/errors 增加或证据混入时不会算作通过。

这些测试证明的是实际覆盖的检查与记录路径，不代表所有域、所有访存方式都已验收。任意 Hypervisor 裸指针越界、Guest 自行发起的越权访存、实际调度/exit 链路仍需各自现场证据。ROM ≤5KB、CPU <0.5%、高优先级上下文及日志持久化不能由这 9 项全部证明。测试自身申请共享内存，不属于 monitor 生产采集路径的资源计量。

## 4. 内存事件与人工日志

schema=3，type=3，旧 code=1..7 不变，新增 code=8。

| 来源 | code | address | detail | 记录主体 |
|---|---|---|---|---|
| 原 mem 地址范围/分类检查拒绝 | 8 | 检查的 HPA | 高 32 位：读 0/写 1；低 32 位：宽度 | 当前 host vCPU |
| 原 mem 禁止写 Guest 内存分支 | 3 | 检查的 HPA | 同上 | 当前 host vCPU，而非被保护的 Guest |
| shmem 普通越界 | 1 | 对象内 offset | 请求长度 | 原接口 actor=NULL，guest/vcpu=4294967295 |

code=8 表示原命令范围/分类检查拒绝；原写入分类函数可能合并其他下层错误，不能把所有 code=8 都断言为物理越界。本包不改变这个原行为。

三个记录点分别位于 check_read_memory 的原 VMM_ERANGE 结果，以及 check_write_memory 的原分类失败、禁止写 Guest 分支。测试适配函数只在统一测试开关启用时存在：probe 只探测候选条件，guard 调用实际检查；二者不映射或访问目标物理地址。适配器的参数约束只作用于测试入口，不改变原 mem 命令规则。

自动测试输出 `monitor_host EVENT seq=... epoch=... ...; log=manual`。根据这些标识人工检查原日志后端中的 JSON；自动用例不等待落盘，不新增存储实现。事件输出尚未完成时等待正常后台日志任务。

## 5. 验证与交付

本次重新核对发布的记录版文件哈希，并从已发布的 23 日版与记录版补丁重建基线。直接应用本包两份补丁后，核对所有修改结果、撤销还原，以及与已验证单开关源码的一致性。没有靠先应用中间测试包来完成本次检查。

代码与上一轮已验证的单开关实现相同，本次只改变升级基线和说明。相同源码的既有验证报告保存在 validation/previous_identical_source：11 次 ARM64 单文件编译、开/关测试接口隔离、重复全局符号检查、54 次隔离执行、360 组命令行为对照、新用例的平台模型及漏记/错误类型/采样异常反例。此次没有重复运行这些编译/功能测试。

本次专门的基线、直接应用、结果、反向还原及源码一致性报告在 validation。尚未进行私有完整固件链接或 QEMU/板卡运行。

上传的 cmd_memory 文本首行缺少注释开头斜杠，完整文件补齐为 /*。工程中头注释完整时跳过该注释修正。其余函数按上下文合入，勿覆盖私有策略。
