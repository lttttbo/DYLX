/* Guest telemetry arithmetic, independent from Hypervisor scheduling. */
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include "../../tools/monitor_guest/monitor_parse.h"
static FILE *input(const char *s) { FILE *f=tmpfile(); assert(f); fputs(s,f); rewind(f); return f; }
int main(void)
{
    struct xm_cpu a,b; uint64_t bp,total,available,free_bytes; FILE *f;
    f=input("cpu 10 0 10 80 0 0 0 0 9999 9999\n"); assert(!xm_cpu_read(f,&a)); fclose(f);
    f=input("cpu 60 0 10 130 0 0 0 0 19999 19999\n"); assert(!xm_cpu_read(f,&b)); fclose(f);
    assert(!xm_cpu_usage(&a,&b,&bp) && bp==5000); /* guest/guest_nice not double-counted */
    assert(xm_cpu_usage(&a,&a,&bp));
    b.field[4]=1; a.field[4]=2; assert(xm_cpu_usage(&a,&b,&bp)); /* reset/decreasing iowait */
    f=input("MemTotal: 1000 kB\nMemFree: 100 kB\nMemAvailable: 400 kB\n");
    assert(!xm_mem_read(f,&total,&available,&free_bytes)); fclose(f);
    assert(total==1024000 && available==409600 && free_bytes==102400);
    f=input("MemTotal: 1000 kB\nMemFree: 100 kB\n"); assert(xm_mem_read(f,&total,&available,&free_bytes)); fclose(f);
    f=input("MemTotal: 1 kB\nMemFree: 2 kB\nMemAvailable: 1 kB\n"); assert(xm_mem_read(f,&total,&available,&free_bytes)); fclose(f);
    f=input("MemTotal: 18446744073709551615 kB\n"); assert(xm_mem_read(f,&total,&available,&free_bytes)); fclose(f);
    puts("PASS: Guest CPU deltas, no double-count, rollback/zero windows, memory units/missing/overflow");
    return 0;
}
