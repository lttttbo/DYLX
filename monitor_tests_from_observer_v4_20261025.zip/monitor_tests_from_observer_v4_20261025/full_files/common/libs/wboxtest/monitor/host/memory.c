/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor_test.h>
#include <vmm_monitor_host_test.h>
#include <vmm_manager.h>
#include <vmm_scheduler.h>
#include <vmm_guest_aspace.h>
#include <vmm_host_ram.h>
#include <vmm_host_aspace.h>
#include <vmm_shmem.h>
#include <vmm_mutex.h>
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/wboxtest.h>

#define H_U(x) ((unsigned long long)(x))
#define H_TIMEOUT (8ULL * VMM_MONITOR_NS)
#define H_UNKNOWN (~0U)
static DEFINE_MUTEX(host_test_lock);
struct host_case {
    struct vmm_chardev *out;
    struct vmm_monitor_test_state initial;
    u32 actor;
    bool locked;
};
struct checkpoint {
    u64 head, serial, started;
};
#define H_CHECK(x) do { if (!(x)) { \
    vmm_cprintf(out, "monitor_host FAIL %s:%u: %s\n", __func__, __LINE__, #x); \
    rc = VMM_EFAIL; goto done; } } while (0)

static int stable(struct host_case *c, struct vmm_monitor_test_state *s)
{
    if (vmm_monitor_test_state(s) || !s->enabled ||
        s->enabled != c->initial.enabled || s->epoch != c->initial.epoch ||
        s->config_seq != c->initial.config_seq || s->lost != c->initial.lost ||
        s->errors != c->initial.errors || s->skipped != c->initial.skipped) return VMM_EFAIL;
    return VMM_OK;
}
static int checkpoint(struct host_case *c, struct checkpoint *p)
{
    struct vmm_monitor_test_state s;
    if (stable(c, &s) || vmm_monitor_test_sample_serial(&p->serial) ||
        p->serial > ~0ULL - 2) return VMM_EFAIL;
    p->head = s.head;
    p->started = vmm_timer_timestamp();
    return VMM_OK;
}
static int sampled(struct host_case *c, u64 before)
{
    struct vmm_monitor_test_state s;
    u64 serial, deadline = vmm_timer_timestamp() + H_TIMEOUT;
    do {
        if (stable(c, &s) || vmm_monitor_test_sample_serial(&serial)) return VMM_EFAIL;
        /* Two completions cover a pass already in flight at the checkpoint. */
        if (serial >= before + 2) return VMM_OK;
        vmm_msleep(20);
    } while (vmm_timer_timestamp() < deadline);
    vmm_cprintf(c->out, "monitor_host: sampler did not complete two passes\n");
    return VMM_ETIMEDOUT;
}
static int begin(struct host_case *c, struct vmm_chardev *out)
{
    struct vmm_vcpu *v;
    u64 serial;
    memset(c, 0, sizeof(*c)); c->out = out;
    if (!vmm_mutex_trylock(&host_test_lock)) return VMM_EBUSY;
    c->locked = TRUE;
    v = vmm_scheduler_current_vcpu();
    if (!v || v->is_normal || v->id >= CONFIG_MAX_VCPU_COUNT) return VMM_ENOTAVAIL;
    c->actor = v->id;
    if (vmm_monitor_test_state(&c->initial) || !c->initial.enabled) {
        vmm_cprintf(out, "monitor_host: run monitor start before this test\n");
        return VMM_ENOTAVAIL;
    }
    if (vmm_monitor_test_sample_serial(&serial) || serial > ~0ULL - 2) return VMM_EFAIL;
    return sampled(c, serial); /* Flush earlier pending events, without forcing sample(). */
}
static int end(struct host_case *c, int rc)
{
    if (c->locked) vmm_mutex_unlock(&host_test_lock);
    return rc;
}
static int observed(struct host_case *c, const struct checkpoint *p, u32 actor,
                    u32 code, u64 address, u64 detail, bool expected)
{
    struct vmm_monitor_test_state s;
    struct vmm_monitor_test_event e;
    u64 seq;
    u32 found = 0;
    if (sampled(c, p->serial) || stable(c, &s) || s.head < p->head ||
        s.head - p->head > VMM_MONITOR_EVENTS) return VMM_EFAIL;
    for (seq = p->head + 1; seq <= s.head; seq++) {
        if (vmm_monitor_test_event(seq, &e)) return VMM_EFAIL;
        if (e.type != 3 || e.vcpu != actor) continue;
        /* Do not accept an unrelated/aggregated failure as our evidence. */
        if (!expected || e.guest != H_UNKNOWN || e.epoch != c->initial.epoch ||
            e.code != code || e.address != address || e.detail != detail ||
            e.value != 1 || e.time_ns < p->started || e.last_ns < e.time_ns)
            return VMM_EFAIL;
        found++;
        vmm_cprintf(c->out, "monitor_host EVENT seq=%llu epoch=%u vcpu=%u code=%u address=%llu detail=%llu; log=manual\n",
            H_U(e.seq), e.epoch, e.vcpu, e.code, H_U(e.address), H_U(e.detail));
    }
    return found == (expected ? 1U : 0U) ? VMM_OK : VMM_EFAIL;
}

static bool rejected_candidate(physical_addr_t a, physical_addr_t *out)
{
    u32 kind;
    /* Fixed safe arithmetic; the probe never maps or dereferences a. */
    if (a > ~(physical_addr_t)0 - 4) return FALSE;
    if (vmm_monitor_host_probe(a, 1, &kind) == VMM_EFAIL) {
        *out = a; return TRUE;
    }
    return FALSE;
}
static bool find_rejected(physical_addr_t *out)
{
    u32 i;
    physical_addr_t start, last;
    physical_size_t size;
    if (rejected_candidate(0, out)) return TRUE;
    for (i = 0; i < vmm_host_ram_bank_count(); i++) {
        start = vmm_host_ram_bank_start(i); size = vmm_host_ram_bank_size(i);
        if (start && rejected_candidate(start - 1, out)) return TRUE;
        if (size <= ~(physical_addr_t)0 - start) {
            last = start + size;
            if (rejected_candidate(last, out)) return TRUE;
        }
    }
    return rejected_candidate((~(physical_addr_t)0) & ~((physical_addr_t)VMM_PAGE_MASK), out);
}
static int range_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    physical_addr_t bad;
    int rc = begin(&c, out);
    (void)test; (void)cpu;
    if (rc) goto done;
    if (!find_rejected(&bad)) {
        vmm_cprintf(out, "monitor_host: no address rejected by existing command policy\n");
        rc = VMM_ENOTAVAIL; goto done;
    }
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(vmm_monitor_host_guard(out, bad, 1, FALSE) == VMM_ERANGE);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_HOST_RANGE_REJECT, bad, 1, TRUE));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(vmm_monitor_host_guard(out, bad, 1, TRUE) == VMM_EFAIL);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_HOST_RANGE_REJECT, bad, (1ULL << 32) | 1, TRUE));
done:
    return end(&c, rc);
}

struct candidates {
    physical_addr_t address[64];
    u32 guest[64], count;
};
static void collect_mapping(struct vmm_guest *g, struct vmm_region *r,
                            physical_addr_t gpa, physical_addr_t hpa,
                            physical_size_t size, void *arg)
{
    struct candidates *list = arg;
    u32 i;
    physical_addr_t start, candidate;
    physical_size_t bank_size;
    (void)r; (void)gpa;
    if (!size || list->count == 64) return;
    for (i = 0; i < vmm_host_ram_bank_count(); i++) {
        start = vmm_host_ram_bank_start(i); bank_size = vmm_host_ram_bank_size(i);
        candidate = hpa > start ? hpa : start;
        if (candidate - hpa < size && candidate - start < bank_size &&
            candidate < ~(physical_addr_t)0) {
            list->address[list->count] = candidate;
            list->guest[list->count++] = g->id;
            break;
        }
    }
}
static void collect_region(struct vmm_guest *g, struct vmm_region *r, void *arg)
{
    vmm_guest_iterate_mapping(g, r, collect_mapping, arg);
}
static int collect_guest(struct vmm_guest *g, void *arg)
{
    vmm_guest_iterate_region(g, VMM_REGION_REAL | VMM_REGION_MEMORY | VMM_REGION_ISRAM,
                             collect_region, arg);
    vmm_guest_iterate_region(g, VMM_REGION_ISROM, collect_region, arg);
    return VMM_OK;
}
static int guest_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    struct candidates list = {0};
    u32 i, kind;
    int rc = begin(&c, out);
    (void)test; (void)cpu;
    if (rc) goto done;
    H_CHECK(!vmm_manager_guest_iterate(collect_guest, &list));
    /* Probe AFTER leaving the manager iterator: probe itself iterates Guests. */
    for (i = 0; i < list.count; i++)
        if (!vmm_monitor_host_probe(list.address[i], 1, &kind) && kind == VMM_MONITOR_HOST_GUEST) break;
    if (i == list.count) {
        vmm_cprintf(out, "monitor_host: no existing Guest mapping reaches the command write-denial branch\n");
        rc = VMM_ENOTAVAIL; goto done;
    }
    vmm_cprintf(out, "monitor_host: candidate guest=%u hpa=%llu; policy check only, no write\n",
                list.guest[i], H_U(list.address[i]));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(vmm_monitor_host_guard(out, list.address[i], 1, TRUE) == VMM_EFAIL);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_ACCESS_DENIED,
                     list.address[i], (1ULL << 32) | 1, TRUE));
done:
    return end(&c, rc);
}
static int shmem_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    struct vmm_shmem *shm = NULL;
    u8 input[16], first[16], last[16], data[16];
    u32 kind;
    int rc = begin(&c, out);
    (void)test; (void)cpu;
    if (rc) goto done;
    shm = vmm_shmem_create("monitor-host-test", VMM_PAGE_SIZE, VMM_PAGE_SHIFT, NULL);
    if (VMM_IS_ERR_OR_NULL(shm)) { shm = NULL; rc = VMM_ENOMEM; goto done; }
    H_CHECK(shm->size >= sizeof(input) * 2);
    memset(input, 0x5a, sizeof(input));
    /* Positive command checks use ONLY our allocated page and access nothing. */
    H_CHECK(!vmm_monitor_host_probe(shm->addr, 1, &kind) && kind == VMM_MONITOR_HOST_RAM);
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(!vmm_monitor_host_guard(out, shm->addr, 1, FALSE));
    H_CHECK(!vmm_monitor_host_guard(out, shm->addr, 1, TRUE));
    H_CHECK(!observed(&c, &p, c.actor, 0, 0, 0, FALSE));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(vmm_shmem_write(shm, 0, input, sizeof(input), TRUE) == sizeof(input));
    H_CHECK(vmm_shmem_write(shm, shm->size - sizeof(input), input, sizeof(input), TRUE) == sizeof(input));
    H_CHECK(vmm_shmem_set(shm, shm->size - 8, 0xa5, 8, TRUE) == 8);
    H_CHECK(vmm_shmem_read(shm, 0, first, sizeof(first), TRUE) == sizeof(first));
    H_CHECK(!memcmp(first, input, sizeof(first)));
    H_CHECK(vmm_shmem_read(shm, shm->size - sizeof(last), last, sizeof(last), TRUE) == sizeof(last));
    H_CHECK(last[7] == 0x5a && last[8] == 0xa5 && last[15] == 0xa5);
    H_CHECK(!observed(&c, &p, H_UNKNOWN, 0, 0, 0, FALSE));
    memset(data, 0xcc, sizeof(data));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(!vmm_shmem_read(shm, shm->size, data, 1, TRUE) && data[0] == 0xcc);
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size, 1, TRUE));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(!vmm_shmem_write(shm, shm->size - 1, input, 2, TRUE));
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size - 1, 2, TRUE));
    H_CHECK(!checkpoint(&c, &p));
    H_CHECK(!vmm_shmem_set(shm, shm->size, 0, 1, TRUE));
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size, 1, TRUE));
    H_CHECK(vmm_shmem_read(shm, 0, data, sizeof(data), TRUE) == sizeof(data));
    H_CHECK(!memcmp(data, first, sizeof(data)));
    H_CHECK(vmm_shmem_read(shm, shm->size - sizeof(data), data, sizeof(data), TRUE) == sizeof(data));
    H_CHECK(!memcmp(data, last, sizeof(data)));
done:
    if (shm) vmm_shmem_destroy(shm);
    return end(&c, rc);
}

#define HOST_REGISTER(test_name, fn) \
static struct wboxtest test_name = {.name = #test_name, .run = fn}; \
static int __init test_name##_init(void) { return wboxtest_register("monitor", &test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name, #test_name, "Monitor maintainers", "GPL", WBOXTEST_IPRIORITY + 1, test_name##_init, test_name##_exit)
HOST_REGISTER(monitor_host_range, range_run);
HOST_REGISTER(monitor_host_guest_guard, guest_run);
HOST_REGISTER(monitor_host_shmem, shmem_run);
