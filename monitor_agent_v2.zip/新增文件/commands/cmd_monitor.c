/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_monitor_guest.h>
#include <vmm_monitor_diag.h>
#include <vmm_manager.h>
#include <vmm_delay.h>
#include <vmm_mutex.h>
#include <libs/mathlib.h>
#include <vmm_cmdmgr.h>
#include <vmm_modules.h>
#include <vmm_stdio.h>
#include <vmm_timer.h>
#include <libs/stringlib.h>

#define MON_ULL(x) ((unsigned long long)(x))
static DEFINE_MUTEX(diagnose_lock);

static void monitor_usage(struct vmm_chardev *cdev)
{
	vmm_cprintf(cdev, "monitor start|stop|status|collect|cpu|irq|events|guest\n"
		"monitor diagnose [1..5000 ms] (default 1000)\n"
		"monitor mem <guest_name>\n"
		"monitor config <exit_rate|sustain_seconds|ready_ns|irq_ns|cpu_bp|log|publish> <decimal>\n"
		"cpu/irq/collect: cached JSON; cpu affinity: vcpu normal_list\n");
}

static int number(const char *s, u64 *n)
{
	*n = 0;
	if (!*s) return VMM_EINVALID;
	while (*s) {
		if (*s < '0' || *s > '9' || *n > (~0ULL - (*s - '0')) / 10)
			return VMM_EINVALID;
		*n = *n * 10 + (*s++ - '0');
	}
	return VMM_OK;
}

static void latency(struct vmm_chardev *cdev, const char *name,
		    const struct vmm_monitor_latency *s)
{
	vmm_cprintf(cdev, "\"%s\":{\"count\":%llu,\"mean_ns\":%llu,"
		"\"p99_upper_ns\":%llu,\"max_ns\":%llu,\"jitter_range_ns\":%llu}",
		name, MON_ULL(s->count), MON_ULL(s->mean_ns), MON_ULL(s->p99_upper_ns),
		MON_ULL(s->max_ns), MON_ULL(s->max_ns - s->min_ns));
}

static void guest_status(struct vmm_chardev *cdev, u32 id)
{
	struct vmm_monitor_guest r;
	u64 now = vmm_timer_timestamp();
	if (vmm_monitor_guest_get(id, &r)) {
		vmm_cprintf(cdev, "{\"schema\":2,\"kind\":\"guest_os\",\"guest\":%u,\"quality\":\"missing\"}\n", id);
		return;
	}
	vmm_cprintf(cdev, "{\"schema\":2,\"kind\":\"guest_os\",\"guest\":%u,\"session\":%llu,\"seq\":%llu,"
		"\"received_ns\":%llu,\"age_ns\":%llu,\"quality\":\"%s\",\"valid\":%u,\"cpu_bp\":%u,"
		"\"total_bytes\":%llu,\"available_bytes\":%llu,\"free_bytes\":%llu,\"used_estimate_bytes\":%llu}\n",
		id, MON_ULL(r.session), MON_ULL(r.sequence), MON_ULL(r.received_ns),
		MON_ULL(now >= r.received_ns ? now - r.received_ns : 0), !vmm_monitor_enabled() ? "disabled" :
		now < r.received_ns || now - r.received_ns > 3 * VMM_MONITOR_NS ? "stale" : "valid",
		r.valid, r.cpu_bp, MON_ULL(r.total_bytes), MON_ULL(r.available_bytes), MON_ULL(r.free_bytes),
		MON_ULL(r.total_bytes - r.available_bytes));
}

static int diagnose(struct vmm_chardev *cdev, u32 ms)
{
	u32 i, ec, suspect;
	int rc;
	struct vmm_monitor_diag_record r;
	vmm_mutex_lock(&diagnose_lock);
	rc = vmm_monitor_diag_start(ms);
	if (rc) goto done;
	vmm_msleep(ms);
	vmm_monitor_diag_stop();
	for (i = 0; i < VMM_MONITOR_DIAG_SLOTS; i++) {
		if (vmm_monitor_diag_get(i, &r)) continue;
		ec = (r.esr >> 26) & 63;
		/* WFI/WFE is excluded from repetition/latency suspicion. */
		suspect = r.errors ? 4 : 0;
		if (ec != 1) {
			if (r.count * 1000 > (u64)1000 * ms) suspect |= 1;
			if (r.max_ns > 1000000) suspect |= 2;
		}
		vmm_cprintf(cdev, "{\"schema\":2,\"kind\":\"trap_diagnostic\",\"guest\":%u,\"vcpu\":%u,"
			"\"elr\":%llu,\"esr\":%llu,\"ec\":%u,\"count\":%llu,\"mean_service_ns\":%llu,"
			"\"max_service_ns\":%llu,\"last_ns\":%llu,\"errors\":%u,\"suspect\":%u}\n",
			r.guest, r.vcpu, MON_ULL(r.pc), MON_ULL(r.esr), ec, MON_ULL(r.count),
			MON_ULL(udiv64(r.sum_ns, r.count)), MON_ULL(r.max_ns), MON_ULL(r.last_ns), r.errors, suspect);
	}
	vmm_cprintf(cdev, "{\"schema\":2,\"kind\":\"diagnostic_summary\",\"window_ms\":%u,"
		"\"untracked\":%llu,\"pmu_cycles\":\"not_collected\"}\n", ms, MON_ULL(vmm_monitor_diag_overflow()));
	/* Preserve the product's optional diagnostic extension after built-in data. */
	rc = vmm_monitor_platform_diagnose(cdev);
	if (rc == VMM_ENOTAVAIL) rc = VMM_OK;
done:
	vmm_mutex_unlock(&diagnose_lock);
	return rc;
}

static int monitor_exec(struct vmm_chardev *cdev, int argc, char **argv)
{
	u32 i;
	u64 value, seq, now;
	int rc;
	struct vmm_monitor_status st;
	struct vmm_monitor_snapshot s;
	struct vmm_monitor_event e;
	if (argc < 2) goto usage;
	if (argc == 2 && !strcmp(argv[1], "start")) return vmm_monitor_enable(TRUE);
	if (argc == 2 && !strcmp(argv[1], "stop")) return vmm_monitor_enable(FALSE);
	if ((argc == 2 || argc == 3) && !strcmp(argv[1], "diagnose")) {
		value = 1000;
		if (argc == 3 && number(argv[2], &value)) return VMM_EINVALID;
		return value && value <= 5000 ? diagnose(cdev, value) : VMM_EINVALID;
	}
	vmm_monitor_status(&st);
	if (argc == 4 && !strcmp(argv[1], "config")) {
		if (number(argv[3], &value)) return VMM_EINVALID;
		if (!strcmp(argv[2], "ready_ns")) st.config.ready_limit_ns = value;
		else if (!strcmp(argv[2], "irq_ns")) st.config.irq_limit_ns = value;
		else if (!strcmp(argv[2], "exit_rate") && value <= 1000000000) st.config.exit_rate = value;
		else if (!strcmp(argv[2], "sustain_seconds") && value <= 60) st.config.sustain_seconds = value;
		else if (!strcmp(argv[2], "log") && value <= 1) st.config.log = value;
		else if (!strcmp(argv[2], "publish") && value <= 1) st.config.publish = value;
		else if (!strcmp(argv[2], "cpu_bp") && value <= 10000) st.config.guest_cpu_limit_bp = value;
		else return VMM_EINVALID;
		return vmm_monitor_configure(&st.config);
	}
	if (argc == 3 && !strcmp(argv[1], "mem")) {
		struct vmm_guest *guest = vmm_manager_guest_find(argv[2]);
		char *args[] = { "guest", "region_list", argv[2] };
		if (!guest) return VMM_ENOTAVAIL;
		guest_status(cdev, guest->id);
		return vmm_cmdmgr_execute_cmd(cdev, 3, args);
	}
	if (argc != 2) goto usage;
	if (!strcmp(argv[1], "guest") || !strcmp(argv[1], "cpu")) {
		for (i = 0; i < CONFIG_MAX_GUEST_COUNT; i++)
			if (vmm_manager_guest(i)) guest_status(cdev, i);
		if (!strcmp(argv[1], "guest")) return VMM_OK;
	}
	if (!strcmp(argv[1], "status")) {
		vmm_cprintf(cdev, "{\"schema\":2,\"enabled\":%u,\"samples\":%llu,"
			"\"late_samples\":%llu,\"sample_max_ns\":%llu,\"events\":%llu,"
			"\"overwritten\":%llu,\"publish_errors\":%llu,\"work_errors\":%llu,"
			"\"irq_untracked\":%llu,\"exit_rate\":%u,\"sustain_seconds\":%u,"
			"\"ready_ns\":%llu,\"irq_ns\":%llu,\"log\":%u,\"publish\":%u,\"busy_snapshots\":%llu,\"cpu_bp\":%u}\n",
			st.enabled, MON_ULL(st.samples), MON_ULL(st.late_samples), MON_ULL(st.sample_max_ns),
			MON_ULL(st.events), MON_ULL(st.overwritten), MON_ULL(st.publish_errors), MON_ULL(st.work_errors),
			MON_ULL(st.irq_untracked), st.config.exit_rate, st.config.sustain_seconds,
			MON_ULL(st.config.ready_limit_ns), MON_ULL(st.config.irq_limit_ns), st.config.log, st.config.publish,
			MON_ULL(st.busy_snapshots), st.config.guest_cpu_limit_bp);
		return VMM_OK;
	}
	if (!strcmp(argv[1], "events")) {
		seq = st.events > VMM_MONITOR_EVENTS ? st.events - VMM_MONITOR_EVENTS + 1 : 1;
		for (; seq <= st.events; seq++) {
			if (vmm_monitor_event_get(seq, &e)) continue;
			vmm_cprintf(cdev, "{\"schema\":2,\"seq\":%llu,\"time_ns\":%llu,\"type\":%u,"
				"\"guest\":%u,\"vcpu\":%u,\"generation\":%u,\"value\":%llu,\"detail\":%llu,\"code\":%u}\n",
				MON_ULL(e.sequence), MON_ULL(e.timestamp_ns), e.type, e.guest_id,
				e.vcpu_id, e.generation, MON_ULL(e.value), MON_ULL(e.detail), e.code);
		}
		return VMM_OK;
	}
	if (!strcmp(argv[1], "cpu") || !strcmp(argv[1], "irq") || !strcmp(argv[1], "collect")) {
		now = vmm_timer_timestamp();
		for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
			if (vmm_monitor_snapshot(i, &s)) continue;
			vmm_cprintf(cdev, "{\"schema\":2,\"guest\":%u,\"vcpu\":%u,\"generation\":%u,"
				"\"hcpu\":%u,\"state\":%u,\"quality\":\"%s\",\"time_ns\":%llu,\"interval_ns\":%llu,"
				"\"ready_age_ns\":%llu,\"exits\":%llu,\"exit_rate\":%llu,\"last_exit\":%u,",
				s.guest_id, s.vcpu_id, s.generation, s.hcpu, s.state,
				!st.enabled ? "disabled" : !s.timestamp_ns ? "warmup" :
				now - s.timestamp_ns > 2 * VMM_MONITOR_NS ? "stale" : s.valid ? "valid" : "warmup_or_gap",
				MON_ULL(s.timestamp_ns), MON_ULL(s.interval_ns), MON_ULL(s.ready_age_ns),
				MON_ULL(s.exits), MON_ULL(s.exit_rate), s.last_exit);
			latency(cdev, "ready", &s.ready);
			vmm_cprintf(cdev, ",");
			latency(cdev, "host_irq_to_lr", &s.irq);
			vmm_cprintf(cdev, ",");
			latency(cdev, "dispatch", &s.dispatch);
			vmm_cprintf(cdev, ",\"faults_pending_summary\":%llu,\"last_address\":%llu,"
				"\"last_fault\":%u,\"last_detail\":%llu}\n", MON_ULL(s.faults),
				MON_ULL(s.last_address), s.last_fault, MON_ULL(s.last_detail));
		}
		if (!strcmp(argv[1], "collect")) {
			rc = diagnose(cdev, 1000);
			if (rc) return rc;
		}
		return VMM_OK;
	}
usage:
	monitor_usage(cdev);
	return argc == 2 && !strcmp(argv[1], "help") ? VMM_OK : VMM_EINVALID;
}

static struct vmm_cmd monitor_cmd = {
	.name = "monitor", .desc = "Lightweight hypervisor monitoring",
	.usage = monitor_usage, .exec = monitor_exec,
};
static int __init monitor_cmd_init(void) { return vmm_cmdmgr_register_cmd(&monitor_cmd); }
static void __exit monitor_cmd_exit(void) { vmm_cmdmgr_unregister_cmd(&monitor_cmd); }
VMM_DECLARE_MODULE("Monitor command", "Xvisor contributors", "GPL", 0,
		   monitor_cmd_init, monitor_cmd_exit);
