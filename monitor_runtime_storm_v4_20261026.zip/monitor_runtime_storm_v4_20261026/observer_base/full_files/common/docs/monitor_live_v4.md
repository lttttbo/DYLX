# Monitor 测试入口

当前共十项：六项隔离测试、三项 Hypervisor 内存测试、一个 monitor_storm_runtime 真实风暴用例。
继续使用 CONFIG_WBOXTEST_MONITOR，一个选项；旧 guest_cases.c 仍不编译。
新用例自动选择现有运行中的 Guest，并临时修改、恢复门限；不需要旧 monitor_live target 命令。
完整说明见 [统一测试说明](monitor_tests_flat_v4.md)。
