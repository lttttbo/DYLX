#include <vmm_error.h>
#include <vmm_monitor.h>
#include <vmm_stdio.h>
#include <vmm_u_ioreq.h>
#include <vmm_guest_aspace.h>
#include <vmm_host_aspace.h>
#include <vmm_devemu.h>
#include <cpu_hcall.h>
#include <cpu_vcpu_helper.h>
#include <generic_mmu.h>
#include <cpu_vcpu_excep.h>
#include <arch_regs.h>
#include <vmm_host_io.h>
#include <vmm_main.h>
#include <vmm_threads.h>
#include <vmm_manager.h>
#include <vmm_completion.h>
#include <vmm_heap.h>
#include <vmm_spinlocks.h>
#if defined(CONFIG_ANDROID_BOOTLOADER)
#include <boot/vmm_android_bootloader.h>
#endif
#include <vmm_percpu.h>
static u32 ccm_irq = 0;
static void hand_reset();
s32 dispatch_hcall(struct vmm_vcpu *vcpu, arch_regs_t *regs) {
        s32 ret = VMM_OK;
        struct vmm_guest *target_vm = NULL;
        u64 func_id = regs->gpr[0];// x0
        u64 guest_vmid = regs->gpr[1];
        u64 param1 = regs->gpr[2];
        u64 param2 = regs->gpr[3];
        switch (func_id) {
        case HC_CREATE_VM:
                vmm_manager_hcall_createvm_lock();
                ret = hcall_create_vm(vcpu, param2);
                if(ret < 0) {
                        vmm_printf("Failed to create a Guest VM !!\n");
                        vmm_manager_hcall_createvm_unlock();
                        break;
                }
                /* TODO:
                 * We don't need to init ccm irq each time HC_CREATE_VM
                 * is called.
                 */
                ret = init_ccm_irq();
                if(ret < 0) {
                        vmm_printf("Failed to init ccm irq !!\n");
                }
                vmm_manager_hcall_createvm_unlock();
                break;
        case HC_FTRACE:
                hcall_ftrace(vcpu, param1, param2);
                break;
        case HC_DESTROY_VM:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_destroy_vm(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to desdroy the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_START_VM:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_start_vm(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to start the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_PAUSE_VM:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_pause_vm(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to pause the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_GET_VM_STATE:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_get_vm_state(target_vm, param2);
                if(ret < 0) {
                        vmm_printf("Failed to get vm state !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_RESET_VM:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_reset_vm(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to reset the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_SUSPEND_VM:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_suspend_vm(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to suspend the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_SUSPEND_SYSTEM:
                target_vm = vmm_manager_guest((u32)SERVERVM_ID);
                ret = hcall_suspend_system(target_vm);
                if(ret < 0) {
                        vmm_printf("Failed to suspend system !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_SHUTDOWN_SYSTEM:
                ret = hcall_shutdown_system();
                if(ret < 0) {
                        vmm_printf("Failed to shutdown system !!\n");
                }
                break;
    case HC_REBOOT_VM:
        vmm_printf("hos restart board, linux node addr=%lu\n", guest_vmid);
#ifdef CONFIG_BOARD_A1000
        if ((u32)guest_vmid == 1800U) {
#else
        if ((u32)guest_vmid == 1100U) {
#endif
                hand_reset();
        }
        break;
        case HC_SET_VCPU_REGS:
        target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_set_vcpu_regs(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to set the target VM's vcpu regs !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_INJECT_MSI:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_inject_msi(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to inject msi for the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_VM_INTR_MONITOR:
                /* Using 'target_vm' without calling 'vmm_manager_guest'? */
                ret = hcall_vm_intr_monitor(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to set a shared page for the target VM interrupt statistics!!\n");
                }
                break;
        case HC_SET_IRQLINE:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_set_irqline(target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to set or clear an interrupt line for the target VM !!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_SET_IOREQ_BUFFER:
                ret = hcall_set_ioreq_buffer(vcpu, (u32)guest_vmid, param2);
                if(ret < 0) {
                        vmm_printf("Failed to set up the ioreq buffer for the target VM's I/O Requests!!\n");
                }
                break;
        case HC_NOTIFY_REQUEST_FINISH:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_notify_ioreq_finish(target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to notify the target VM I/O request completion!!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_ASYNCIO_ASSIGN:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_asyncio_assign(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to assign asyncio requests for the target VM!!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_ASYNCIO_DEASSIGN:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_asyncio_deassign(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to deassign asyncio requests for the target VM!!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case (u64)HC_DEASSERT_IOREQ_INTR:
                ret = hcall_deassert_ioreq_intr();
                if(ret < 0) {
                        vmm_printf("Failed to deassert ioreq intr!!\n");
                }
                break;
        case HC_VM_SET_MEMORY_REGIONS:
                ret = hcall_set_vm_memory_regions(vcpu, param1, 0);
                if(ret < 0) {
                        vmm_printf("Failed to Inform the target VM to set up EPT mappings!!\n");
                }
                break;
        case HC_SET_SBUF:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                ret = hcall_set_sbuf(vcpu, target_vm, param1);
                if(ret < 0) {
                        vmm_printf("Failed to set up the shared buffer for the target VM!!\n");
                }
                if (target_vm) {
                        vmm_manager_guest_put(target_vm);
                }
                break;
        case HC_GET_MEMINFO:
                target_vm = vmm_manager_guest((u32)guest_vmid);
                if (!target_vm) {
                        vmm_printf("target vm get failed\n");
                        ret = -1;
                        break;
                }
                ret = hcall_get_meminfo(target_vm, param2);
                if(ret < 0) {
                        vmm_printf("Failed to get VM's meminfo !!\n");
                        break;
                }
                vmm_manager_guest_put(target_vm);
                break;
        case HC_PM_GET_CPU_STATE:
                ret = hcall_get_cpu_pm_state(vcpu, target_vm, param1, param2);
                if(ret < 0) {
                        vmm_printf("Failed to Get P-states and C-states info from the target VM!!\n");
                }
                break;
        default:
                        vmm_printf("not support function id=%ld\n", func_id);
                        break;
        }
        cpu_vcpu_reg64_write(vcpu, regs, 0, (u64)ret);
        /*
         * Guest should handle the fault according to 'ret' saved in
         * gpr[0]. In hypervisor, we don't need to raise a 'panic'.
         */
#if 0
        if(ret == VMM_DUPLICATE_GUEST || ret == VMM_MAX_GUEST_REACHED) {
                return VMM_OK;
        }
#endif
        return VMM_OK;
}
/* Started by AICoder, pid:ya7d17e849k3993146c80a3f1091721fc5a88227 */
static int reset_board_force(void *unused)
{
    unused = NULL;
    board_reset();
    return VMM_OK;
}
static void hand_reset()
{
    struct vmm_thread *pReset = vmm_threads_create("ResetBoard", reset_board_force, NULL,
                                                    (u8)VMM_VCPU_MAX_PRIORITY,
                                                    (u64)VMM_THREAD_DEF_DEADLINE);
    if (!pReset) {
        vmm_printf("failed to create ResetBoard thread\n");
        return;
    }
    vmm_threads_start(pReset);
}

extern int vfs_guest_fdt_load(const char *name, const char *path,
                              u32 count, int aliasc, char **aliasv);
s32 hcall_create_vm(struct vmm_vcpu *vcpu, u64 gpa_vm_creation) {
        u32 res;
        struct vm_creation vmc;
        struct vmm_devtree_node *pnode = NULL, *node = NULL;
        struct vmm_guest *guest = NULL;
        /* Started by AICoder, pid:05b5638160jd54914c490a01104de40ecdd4f8f5 */
        // 检查虚拟机管理器中已经创建的虚拟机数量是否达到最大限制。
        /* Dom0架构改造后，userVM并不由serverVM创建，此处不应当检查Guest数量。
        if (vmm_manager_guest_count() == (u32)CONFIG_MAX_GUEST_COUNT) {
                return VMM_MAX_GUEST_REACHED;
        }
        */
        /* Ended by AICoder, pid:05b5638160jd54914c490a01104de40ecdd4f8f5 */
        res = vmm_guest_memory_read(vcpu->guest, gpa_vm_creation, &vmc, (u32)sizeof(vmc), TRUE);
        if (res != sizeof(vmc)) {
                return VMM_EIO;
        }
        // liyinggang hypervisor已经启动好了user-linux1
        // guest = vmm_manager_guest_find(vmc.name);
        // if (guest != NULL) {
        //      vmm_printf("guest:%s has been created by hypervisor, just get the vm's information\n", vmc.name);
        //      vmc.vcpu_num = (u16)guest->vcpu_count;
        //      vmc.vmid = (u16)guest->id;
        //      res = vmm_guest_memory_write(vcpu->guest, gpa_vm_creation, &vmc, sizeof(vmc), TRUE);
        //      vmm_manager_guest_put(guest);
        //      if (res != sizeof(vmc)) {
        //              return VMM_EIO;
        //      }
        //      return VMM_OK;
        // }
        // liyinggang hypervisor已经加载好了dtb
        // load device tree
        // if (VMM_OK != vfs_guest_fdt_load(vmc.name, NULL, (u32)vmc.vcpu_num,  0, NULL)) {
        //      vmm_printf("Failed to load dtb of Guest %s !!\n", vmc.name);
        //      return VMM_EFAIL;
        // }
        // vm_creation.name exist or not
        pnode = vmm_devtree_getnode(VMM_DEVTREE_PATH_SEPARATOR_STRING
                                                                VMM_DEVTREE_GUESTINFO_NODE_NAME);
        node = vmm_devtree_getchild(pnode, vmc.name);
        vmm_devtree_dref_node(pnode);
        if (!node) {
                vmm_printf("Error: failed to find %s node under %s\n",
                                        vmc.name, VMM_DEVTREE_PATH_SEPARATOR_STRING
                                        VMM_DEVTREE_GUESTINFO_NODE_NAME);
                return VMM_EFAIL;
        }
        // liyinggang userV是由hypervisor创建的
        //guest = vmm_manager_guest_create(node);
        guest = vmm_manager_guest_find(vmc.name);
        vmm_devtree_dref_node(node);
        if (!guest) {
                vmm_printf("Failed to create Guest %s !!\n", vmc.name);
                return VMM_EFAIL;
        }
        vmc.vcpu_num = (u16)guest->vcpu_count;
        vmc.vmid = (u16)guest->id;
        res = vmm_guest_memory_write(vcpu->guest, gpa_vm_creation, &vmc, (u32)sizeof(vmc), TRUE);
        if (res != sizeof(vmc)) {
                vmm_manager_guest_put(guest);
                return VMM_EIO;
        }
        //guest->state=RESET;
        vmm_linfo(NULL, "success to create Guest %s, vmid=%d !!\n", vmc.name, vmc.vmid);
        vmm_manager_guest_put(guest);
        return VMM_OK;
}
/* Ended by AICoder, pid:d249e1b6f4h58ef14af00848b02a7b669f16e0d5 */
s32 hcall_start_vm(struct vmm_guest *target_vm) {
        s32 ret;
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        ret = vmm_u_ioreq_register_backend(target_vm->id);
        if (WARN_ON(ret != VMM_OK && ret != VMM_ENOENT)) {
                vmm_printf("Failed to wakeup clients, target_vmid: %u\n", target_vm->id);
                return ret;
        }
        if (target_vm->state != RESET) {
                return VMM_OK;
        }
        if(target_vm->load_list_path[0] != '\0') {
                if ((ret = vmm_manager_guest_load_list(target_vm))) {
                        vmm_lerror(NULL, "%s: Failed to load_list\n", target_vm->name);
                        return ret;
                } else {
                        vmm_linfo(NULL, "%s: load_list done\n", target_vm->name);
                }
        }
#if defined(CONFIG_ANDROID_BOOTLOADER)
    /* Started by AICoder, pid:27c86pd7d29074414ab10beea0c46a0df2c7e4e5 */
    if(target_vm->android_boot_info) {
        ret = vmm_android_bootloader_boot_flow(target_vm, target_vm->android_boot_info);
        if(ret != VMM_OK) {
            vmm_printf("Failed to boot android guest: %s\n", target_vm->name);
            return ret;
        }
    }
    /* Ended by AICoder, pid:27c86pd7d29074414ab10beea0c46a0df2c7e4e5 */
#endif
        if ((ret = vmm_manager_guest_kick(target_vm))) {
                vmm_lerror(NULL, "%s: Failed to kick\n", target_vm->name);
                return ret;
        } else {
                vmm_linfo(NULL, "%s: Kicked\n", target_vm->name);
        }
        return VMM_OK;
}
s32 hcall_pause_vm(struct vmm_guest *target_vm) {
        s32 ret = -1;
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        // The "vm pause" operation in Xvisor relies on the preceding VM state being either ready or running.
        /*
         * So if the upper software requests us to pause a VM which is
         * not ready or running, we should refuse the request instead
         * of tolerating it and trying to make things 'normal'.
         *
         * It is the upper software's duty not to change the state of
         * VM improperly. However, when taking 'cmd_guest' into
         * consideration, the upper software may not know the exact
         * state of the VM since it maybe changed manually. To address
         * this problem, there should be better ways such as limiting
         * the power of 'cmd_guest' that targeting userVMs.
         */
        if ((ret = vmm_manager_guest_pause(target_vm))) {
                vmm_printf("%s: Failed to pause\n", target_vm->name);
        } else {
                target_vm->state=PAUSED;
                vmm_printf( "%s: Paused\n", target_vm->name);
        }
        return ret;
}
/* Started by AICoder, pid:gfe8cic4ffx639414ad20af0c0c2ce2e17d31aec */
/* 该hcall用于获取usevm的虚拟机状态 */
s32 hcall_get_vm_state(struct vmm_guest *target_vm, u64 gpa_vm_state) {
        u32 res;
        int vm_state;
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        struct vmm_guest *serverVM = vmm_manager_guest((u32)SERVERVM_ID);
        if (!serverVM) {
                return VMM_EFAIL;
        }
        vm_state = target_vm->state;
        res = vmm_guest_memory_write(serverVM, gpa_vm_state, &vm_state, (u32)sizeof(vm_state), TRUE);
        vmm_manager_guest_put(serverVM);
        if (res != sizeof(int)) {
                return VMM_EIO;
        }
        return VMM_OK;
}
/* Ended by AICoder, pid:gfe8cic4ffx639414ad20af0c0c2ce2e17d31aec */
/* Started by AICoder, pid:35d9138a88z769b14b8b0bd9b0dba114a5b798ec */
/* uservm关机的线程函数 */
static s32 guest_shutdown_thread_main(void* data)
{
        s32 ret = VMM_OK;
        struct vmm_guest *guest = (struct vmm_guest *)data;
        if ((ret = (s32)wait_guest_powerff(guest, guest->poweroff_timeout_secs))) {
                vmm_lerror(NULL, "%s poweroff failed, ret = %d! \n", guest->name, ret);
        }
        if ((ret = (s32)vmm_manager_guest_reset(guest))) {
                vmm_lerror(NULL, "%s: Failed to reset\n", guest->name);
        } else {
                vmm_linfo(NULL, "%s: Reset\n", guest->name);
        }
        return ret;
}
/* Ended by AICoder, pid:35d9138a88z769b14b8b0bd9b0dba114a5b798ec */
/* Started by AICoder, pid:20025q9cf4bb1ed14fd20a3c90e1e44b67a0667c */
/* 创建线程去关闭uservm */
s32 hcall_reset_vm(struct vmm_guest *target_vm) {
        s32 ret;
        struct vmm_thread *guest_poweroff_thread;
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        /* Started by AICoder, pid:rfe085c4a915bd3147e80b82402aba32d2d1150e */
        guest_poweroff_thread = target_vm->guest_poweroff_thread;
        if (guest_poweroff_thread) {
                ret = vmm_threads_stop(guest_poweroff_thread);
                if (ret) {
                        return ret;
                }
        } else {
                target_vm->guest_poweroff_thread = guest_poweroff_thread =
                                vmm_threads_create(target_vm->name,
                                                   guest_shutdown_thread_main,
                                                   (void *)target_vm,
                                                   (u8)VMM_THREAD_DEF_PRIORITY,
                                                   (u64)VMM_THREAD_DEF_TIME_SLICE);
        }
        if (guest_poweroff_thread != NULL) {
                if (vmm_threads_start(guest_poweroff_thread)) {
                        vmm_threads_destroy(guest_poweroff_thread);
                        target_vm->guest_poweroff_thread = NULL;
                } else {
                        return VMM_OK;
                }
        }
        /* Ended by AICoder, pid:rfe085c4a915bd3147e80b82402aba32d2d1150e */
        if ((ret = (s32)vmm_manager_guest_reset(target_vm))) {
                vmm_printf("%s: Failed to reset\n", target_vm->name);
        } else {
                vmm_printf("%s: Reset\n", target_vm->name);
        }
        return ret;
}
/* Ended by AICoder, pid:20025q9cf4bb1ed14fd20a3c90e1e44b67a0667c */
static s32 guest_suspend_thread_main(void* data)
{
        s32 ret = VMM_OK;
        struct vmm_guest *guest = (struct vmm_guest *)data;
        if ((ret = (s32)wait_guest_suspend(guest))) {
                vmm_printf("%s suspend failed, ret = %d! \n", guest->name, ret);
        }
        return ret;
}
static s32 system_suspend_thread_main(void* data)
{
        s32 ret = VMM_OK;
        struct vmm_guest *guest = (struct vmm_guest *)data;
        if ((ret = (s32)vmm_manager_system_suspend(guest))) {
                vmm_printf("%s suspend failed, ret = %d! \n", guest->name, ret);
        }
        return ret;
}
/* Started by AICoder, pid:g6619bb029gf24b146d00889207a4d0dd2c80328 */
static int system_shutdown_thread_main(void* data)
{
        (void)data;
        vmm_shutdown();
        return VMM_OK;
}
/* Ended by AICoder, pid:g6619bb029gf24b146d00889207a4d0dd2c80328 */
/* Started by AICoder, pid:ec839sd1aeq322114a720915007b9641c002db70 */
static s32 _hcall_suspend(struct vmm_guest *target_vm,
                                                int (*thread_fn) (void *udata),
                                                const struct vmm_cpumask *cpu_mask)
{
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        if (target_vm->guest_suspend_thread != NULL) {
                vmm_printf("%s: guest_suspend_thread exist\n", target_vm->name);
                if (vmm_threads_get_state(target_vm->guest_suspend_thread) != VMM_THREAD_STATE_CREATED) {
                        vmm_threads_stop(target_vm->guest_suspend_thread);
                }
                if (vmm_threads_start(target_vm->guest_suspend_thread)) {
                        vmm_printf("%s: guest_suspend_thread exec failed\n", target_vm->name);
                        return VMM_EFAIL;
                }
                return VMM_OK;
        }
        char thread_name[VMM_FIELD_NAME_SIZE];
        vmm_snprintf(thread_name, (u32)sizeof(thread_name), "%s-str", target_vm->name);
        struct vmm_thread *guest_suspend_thread = vmm_threads_create(thread_name,
                                                                        thread_fn, (void *)target_vm,
                                                                        (u8)VMM_THREAD_DEF_PRIORITY,
                                                                        (u64)VMM_THREAD_DEF_TIME_SLICE);
        if (guest_suspend_thread != NULL) {
                if (cpu_mask) {
                        if (vmm_threads_set_affinity(guest_suspend_thread, cpu_mask)) {
                                vmm_printf("%s: failed to set thread affinity\n", target_vm->name);
                                vmm_threads_destroy(guest_suspend_thread);
                                return VMM_EFAIL;
                        }
                }
                if (vmm_threads_start(guest_suspend_thread)) {
                        vmm_printf("%s: guest_suspend_thread exec failed\n", target_vm->name);
                        vmm_threads_destroy(guest_suspend_thread);
                        return VMM_EFAIL;
                } else {
                        target_vm->guest_suspend_thread = guest_suspend_thread;
                        return VMM_OK;
                }
    }
        return VMM_EFAIL;
}

s32 hcall_suspend_vm(struct vmm_guest *target_vm)
{
        return _hcall_suspend(target_vm, guest_suspend_thread_main, NULL);
}
/* Started by AICoder, pid:5d90dk5fb00ba7314af00930206a7e0321649e4d */
s32 hcall_suspend_system(struct vmm_guest *target_vm)
{
        return _hcall_suspend(target_vm, system_suspend_thread_main, vmm_cpumask_of((u32)0));
}
/* Ended by AICoder, pid:5d90dk5fb00ba7314af00930206a7e0321649e4d */
/* Started by AICoder, pid:jfd5b7e2e9t357d14a4f0879f0a28a28ad96a0c2 */
s32 hcall_shutdown_system()
{
        s32 ret = VMM_OK;
        struct vmm_thread *system_shutdown_thread = vmm_threads_create("system-shutdown",
                                                                        system_shutdown_thread_main, NULL,
                                                                        (u8)VMM_THREAD_DEF_PRIORITY,
                                                                        (u64)VMM_THREAD_DEF_TIME_SLICE);
        if (!system_shutdown_thread) {
                vmm_printf("Failed to create thread\n");
                return VMM_EFAIL;
        }
        ret = (s32)vmm_threads_start(system_shutdown_thread);
        if (ret != VMM_OK) {
                vmm_printf("Thread system_shutdown_thread exec failed\n");
                vmm_threads_destroy(system_shutdown_thread);
        }
        return ret;
}
/* Ended by AICoder, pid:jfd5b7e2e9t357d14a4f0879f0a28a28ad96a0c2 */
s32 hcall_destroy_vm(struct vmm_guest *target_vm) {
#if 0
        s32 ret;
        char vm_name[VMM_FIELD_NAME_SIZE];
#endif
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
        /* TODO:
         * We should unregister backend before resetting userVM.
         */
        return vmm_u_ioreq_unregister_backend(target_vm->id);
#if 0
        strcpy(vm_name, target_vm->name);
        if ((ret = vmm_manager_guest_destroy(target_vm))) {
                vmm_printf("%s: Failed to destroy\n", vm_name);
        } else {
                vmm_printf("%s: Destroyed\n", vm_name);
        }
        return ret;
#endif
}
s32 hcall_set_irqline(struct vmm_guest *target_vm, u64 irq_para) {
        struct irq_para irq_info;
        irq_info.irq = (u32)irq_para;
        irq_info.mode = (u32)(irq_para >> 32);
        if (!target_vm) {
                vmm_printf("Failed to find guest\n");
                return VMM_ENOTAVAIL;
        }
//TODO: dsm 完成virtio后端数据处理后，会调用两次hcall，来完成一次中断通知，需要优化。
        return vmm_devemu_emulate_irq(target_vm, irq_info.irq, irq_info.mode);
}
s32 hcall_set_vcpu_regs(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_vcpu_regs) {
        u32 res;
        struct vcpu_regs vcpu_registers;
        res = vmm_guest_memory_read(vcpu->guest, gpa_vcpu_regs,
                                    &vcpu_registers, (u32)sizeof(vcpu_registers), TRUE);
        if (res != sizeof(vcpu_registers)) {
                return VMM_EIO;
        }
        vmm_printf("vcpu regs: pc=0x%lx\n", vcpu_registers.regs.pc);
        return vmm_manager_guest_reset_regs(target_vm, &vcpu_registers.regs);
}
/* Started by AICoder, pid:i55d272cadoeec914662083f101d48153627a157 */
s32 hcall_inject_msi(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_msi_entry) {
    struct msi_entry msi;
    s32 ret = VMM_EFAIL;
    u16 i;
    if (!vcpu || !target_vm) {
        return ret;
    }
    i = (u16)vmm_guest_memory_read(vcpu->guest, gpa_msi_entry, &msi, (u32)sizeof(msi), TRUE);
    if (i != sizeof(msi)) {
        return VMM_EIO;
    }
    list_for_each_entry(vcpu, &target_vm->vcpu_list, head) {
        ret = vmm_devemu_emulate_write(vcpu, msi.msi_addr, &msi.msi_data, (u32)sizeof(msi.msi_data), 2);
        if (ret == VMM_OK) {
                        return ret;
                }
    }
    return ret;
}
/* Ended by AICoder, pid:i55d272cadoeec914662083f101d48153627a157 */
/* Started by AICoder, pid:996a7ae631284bd18b6f8e38f2489ec1 */
s32 hcall_vm_intr_monitor(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 param1) {
        (void)vcpu;
        (void)target_vm;
        (void)param1;
        return VMM_OK;
}
/* Ended by AICoder, pid:996a7ae631284bd18b6f8e38f2489ec1 */
/* Started by AICoder, pid:67377daf04a24c2d81f9b62bb7f771fb */
s32 hcall_asyncio_assign(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_asyncio_info) {
        struct asyncio_info asyncio_info;
        s32 ret = VMM_EFAIL;
        if (!vcpu || !target_vm) {
                return ret;
        }
        if (vmm_guest_memory_read(vcpu->guest, gpa_asyncio_info, &asyncio_info, sizeof(asyncio_info), TRUE) == sizeof(asyncio_info)) {
                add_asyncio(target_vm, asyncio_info.type, asyncio_info.addr, asyncio_info.fd);
                ret = VMM_OK;
        }
        return ret;
}
/* Ended by AICoder, pid:67377daf04a24c2d81f9b62bb7f771fb */
/* Started by AICoder, pid:523afb4497ba43ff9ed917bac3cdd25b */
s32 hcall_asyncio_deassign(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_asyncio_info) {
        struct asyncio_info asyncio_info;
        s32 ret = VMM_EFAIL;
        if (!vcpu || !target_vm) {
                return ret;
        }
        if (vmm_guest_memory_read(vcpu->guest, gpa_asyncio_info, &asyncio_info, sizeof(asyncio_info), TRUE) == sizeof(asyncio_info)) {
                remove_asyncio(target_vm, asyncio_info.type, asyncio_info.addr, asyncio_info.fd);
                ret = VMM_OK;
        }
        return ret;
}
/* Ended by AICoder, pid:523afb4497ba43ff9ed917bac3cdd25b */
s32 hcall_deassert_ioreq_intr(void) {
        s32 ret;
        struct vmm_guest *target_vm;
        target_vm = vmm_manager_guest((u32)SERVERVM_ID);
        if (!target_vm) {
                return VMM_EFAIL;
        }
        ret = vmm_devemu_emulate_irq(target_vm, ccm_irq, 0);
        vmm_manager_guest_put(target_vm);
        return ret;
}
s32 hcall_notify_ioreq_finish(struct vmm_guest *target_vm, u64 param1) {
        u16 vcpu_id = (u16)param1;
        return wakeup_io_req(target_vm, vcpu_id);
}
s32 hcall_set_ioreq_buffer(struct vmm_vcpu *vcpu, u32 target_vmid, u64 gpa_ioreq_buffer) {
        // struct ioreq_buffer ioreqbuf;
        // u16 i;
        // s32 ret = VMM_OK;
        // (void)target_vm;
        virtual_addr_t ioreqbuf_mem_start = 0;
        struct vmm_region *servervm_mem0_reg = NULL;
        struct vmm_guest *server_vm = vmm_manager_guest(SERVERVM_ID);
        struct ioreq_buffer ioreqbuf;
        void *buffer_addr = vmm_ioreq_buffer_get(target_vmid);
        u32 ret;
        if (!vcpu || !server_vm) {
                return VMM_EINVALID;
        }
        if (!buffer_addr) {
                vmm_manager_guest_put(server_vm);
                return VMM_ENOMEM;
        }
        /* Started by AICoder, pid:r77364c77e11791143070b1900f56b27fe33e51d */
        ret = vmm_guest_memory_read(vcpu->guest, gpa_ioreq_buffer,
                                                                &ioreqbuf, sizeof(ioreqbuf), TRUE);
        if (ret != sizeof(ioreqbuf)) {
                vmm_manager_guest_put(server_vm);
                return VMM_EIO;
        }
        // target_vm->sw.io_shared_page = (void*)vmm_host_memmap(ioreqbuf.ioreq_buf, 0x1000, VMM_MEMORY_FLAGS_NORMAL);
        // for (i = 0; i < IO_REQUEST_MAX; i++) {
        //              set_io_req_state(target_vm, (u32)i, IOREQ_STATE_FREE);
        // }
        servervm_mem0_reg = vmm_guest_find_region_by_name(server_vm, "mem0", (u32)0);
        if(!servervm_mem0_reg) {
                vmm_printf("find serverVM mem0 region failed\n");
                vmm_manager_guest_put(server_vm);
                return VMM_EFAIL;
        }
        // 获取uservm的ioreq buff信息：总的ioreq buff的起始GPA、size以及当前uservm的ioreq buff的page offset.
        ioreqbuf_mem_start = vmm_ioreq_buffer_mem_start();
        ioreqbuf.gpa_start = (u64)IO_REQUEST_BUFF_BASE;
        ioreqbuf.size = vmm_ioreq_buffer_mem_size();
        ioreqbuf.pgoff = (u16)(((virtual_addr_t)buffer_addr - ioreqbuf_mem_start) >> VMM_PAGE_SHIFT);
        ret = vmm_guest_memory_write(vcpu->guest, gpa_ioreq_buffer, &ioreqbuf, (u32)sizeof(ioreqbuf), TRUE);
        if (ret != sizeof(ioreqbuf)) {
                vmm_printf("===qcc test hcall_set_ioreq_buffer 555===\n");
                vmm_manager_guest_put(server_vm);
                return VMM_EIO;
        }
        /* Ended by AICoder, pid:r77364c77e11791143070b1900f56b27fe33e51d */
        vmm_manager_guest_put(server_vm);
        return VMM_OK;
}
/* Started by AICoder, pid:b6f7ed93efe24bddac9915d12e8aea21 */
s32 hcall_get_cpu_pm_state(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 param1, u64 param2) {
        (void)vcpu;
        (void)target_vm;
        (void)param1;
        (void)param2;
        return VMM_OK;
}
/* Ended by AICoder, pid:b6f7ed93efe24bddac9915d12e8aea21 */
// liyinggang
s32 hcall_get_meminfo(struct vmm_guest *target_vm, u64 gpa_meminfo) {
        s32 res;
        irq_flags_t flags;
        struct vmm_region *uservm_reg = NULL;
        struct vmm_guest *server_vm = vmm_manager_guest(SERVERVM_ID);
        struct vm_mem_info meminfo;
        if (!server_vm) {
                return VMM_ENOTAVAIL;
        }
        /* Started by AICoder, pid:x79b5z707d42a7014d8e0ac1b07e483412471caf */
        // 获取uservm的主存region
        uservm_reg = vmm_guest_find_region_by_name(target_vm, "mem0", (u32)0);
        if(!uservm_reg) {
                vmm_printf("find mem0 region failed\n");
                vmm_manager_guest_put(server_vm);
                return VMM_ENOTAVAIL;
        }
        // serverVM gpa布局: | serverVM ram gpa | userVMs' gpa |...|ioreq buffer gpa|
        physical_addr_t uservm_gphys_addr = uservm_reg->maps[0].hphys_addr; // servervm_reg->gphys_addr + servervm_reg->phys_size;
        physical_size_t phys_size = uservm_reg->phys_size;
        physical_addr_t hphys_addr = uservm_reg->maps[0].hphys_addr;
        vmm_spin_lock_irqsave(&server_vm->user_region_added_lock, flags);
        if (!server_vm->user_region_added[target_vm->id]) {
                res = (s32)vmm_u_add_region(server_vm, uservm_gphys_addr, hphys_addr, (u64)phys_size);
                if (res) {
                        vmm_spin_unlock_irqrestore(&server_vm->user_region_added_lock, flags);
                        vmm_printf("Add uservm's ram region to servervm ram region failed.\n");
                        vmm_manager_guest_put(server_vm);
                        return res;
                }
                server_vm->user_region_added[target_vm->id] = TRUE;
        }
        vmm_spin_unlock_irqrestore(&server_vm->user_region_added_lock, flags);
        meminfo.gpa_start = uservm_gphys_addr;
        meminfo.size = phys_size;
        res = (s32)vmm_guest_memory_write(server_vm, (physical_addr_t)gpa_meminfo,
                                          &meminfo, (u32)sizeof(meminfo), TRUE);
        vmm_manager_guest_put(server_vm);
        if (res != (s32)sizeof(meminfo)) {
                return VMM_EIO;
        }
        vmm_linfo(NULL, "Added memory region gpa:0x%lx ~ 0x%lx to servervm\n", meminfo.gpa_start, meminfo.gpa_start + meminfo.size);
        return VMM_OK;
        /* Ended by AICoder, pid:x79b5z707d42a7014d8e0ac1b07e483412471caf */
}

s32 hcall_set_sbuf(struct vmm_vcpu *vcpu, struct vmm_guest *target_vm, u64 gpa_sbuf_param) {
        struct sbuf_param sp;
    physical_addr_t hpa;
        virtual_addr_t hva;
        physical_size_t hpa_size;
        u32 reg_flags = 0x0;
        u32 res;
        int ret = -1;
        if (!vcpu || !target_vm) {
                return VMM_EINVALID;
        }
        res = vmm_guest_memory_read(vcpu->guest, gpa_sbuf_param, &sp, sizeof(sp), TRUE);
        if (res != sizeof(sp)){
                vmm_monitor_mem_fault(vcpu, VMM_MONITOR_CCM_READ_FAILED,
                                      gpa_sbuf_param, sizeof(sp));
                return VMM_EIO;
        }
        // GPA convert to HPA
        ret = vmm_guest_physical_map(vcpu->guest, sp.gpa, sizeof(sp), &hpa, &hpa_size, &reg_flags);
        if (hpa) {
                hva = vmm_host_memmap(hpa, VMM_PAGE_SIZE, VMM_MEMORY_FLAGS_NORMAL);
                ret = sbuf_setup_common(target_vm, sp.cpu_id, sp.sbuf_id, (u64*)hva, hpa);
        } else {
                ret = VMM_EINVALID;
        }
    if (ret != VMM_OK)
        vmm_monitor_mem_fault(vcpu, VMM_MONITOR_CCM_REGISTER_FAILED,
                              sp.gpa, (u64)(s64)ret);
    return ret;
}
s32 hcall_set_vm_memory_regions(struct vmm_vcpu *vcpu, u64 gpa_regions, u64 param2) {
        struct set_regions regions;
        struct vm_memory_region mr;
        u32 idx = 0;
        u32 res;
        s32 ret = VMM_OK;
        (void)param2;
        res = vmm_guest_memory_read(vcpu->guest, (physical_addr_t)gpa_regions,
                                                                &regions, sizeof(regions), TRUE);
        if (res != sizeof(regions)) {
                return VMM_EIO;
        }
        struct vmm_guest *target_vm = vmm_manager_guest(regions.vmid);
        if (!target_vm) {
                return VMM_EINVALID;
        }
        u32 len = sizeof(mr);
        while (idx < regions.mr_num) {
                if (vmm_guest_memory_read(vcpu->guest, regions.regions_gpa + idx * len, &mr, len, TRUE) != len) {
                        vmm_printf("Copy mr entry fail from vm\n");
                        break;
                }
                ret = vmm_u_add_region(target_vm, mr.gpa, mr.service_vm_gpa, (u64)mr.size);
                if (ret != VMM_OK) {
                        vmm_printf(" map_hugepage failed, gpa=0x%lx, hpa=0x%lx\n",  mr.gpa, mr.service_vm_gpa);
                        break;
                }
                idx++;
        }
        vmm_manager_guest_put(target_vm);
        return ret;
}
s32 init_ccm_irq() {
        struct vmm_devtree_node *node = NULL;
        struct vmm_devtree_attr *attr = NULL;
        u32 *intspec = NULL;
        if (ccm_irq) {
                return VMM_OK;
        }
        struct vmm_guest *target_vm = vmm_manager_guest((u32)SERVERVM_ID);
        if (!target_vm) {
                return VMM_EFAIL;
        }
        // Obtain device nodes of "/ccm" through the device tree.
        node = vmm_devtree_getchild(target_vm->node, "/ccm");
        vmm_devtree_dref_node(node);
        if (!node) {
                vmm_printf("Error: /ccm node not found!! \n");
                vmm_manager_guest_put(target_vm);
                return VMM_EINVALID;
        }
        // Obtain device node interrupt number.
        attr = vmm_devtree_getattr(node, "interrupts");
        if (NULL == attr) {
                vmm_manager_guest_put(target_vm);
                return VMM_EINVALID;
        }
        intspec = attr->value;
        ccm_irq = vmm_be32_to_cpu(*intspec);
        vmm_manager_guest_put(target_vm);
        return VMM_OK;
}
struct vmm_guest* servervm;
s32 ccm_upcall() {
        s32 ret;
        // struct vmm_guest *target_vm = vmm_manager_guest((u32)SERVERVM_ID);
        if (!servervm) {
                return VMM_EFAIL;
        }
        /* TODO：
         * 目前拉高电平后，依赖于serverVM借助hypercall进行的通知，以拉低电平。
         * CCM中断注入应当在hypervisor内部完成闭环，不应当跨OS完成中断注入流程。
         */
        ret = vmm_devemu_emulate_irq2(servervm, ccm_irq, 0, 1);
        // vmm_manager_guest_put(target_vm);
        return ret;
}
#define MACHINE_64  // comments it for 32bit
#define FTRACE_CMD_START   1
#define FTRACE_CMD_END     2
#define FTRACE_CMD_READY   3
#define FTRACE_CMD_PRINT   4
#define FTRACE_CMD_UNREADY 9
#ifdef MACHINE_64
#define TRACE_PER_ITEM     4
#else
#define TRACE_PER_ITEM     2
#endif
#define ITEMS_PER_PAGE     (4096 / (TRACE_PER_ITEM * 8))
#define TRACE_TOTAL_SIZE   (1024*1024*2)
#define TRACE_BUF_SIZE     (TRACE_TOTAL_SIZE / (TRACE_PER_ITEM * 8))
static u32 old_ftracebuf_idx = 0;
volatile static u64 ftrace_start = 0, g_ftrace_sum = 0;
u8 ftrace_cpuid = 0, old_cpuid = 0;
DEFINE_PER_CPU(u64, ftrace_buf);
DEFINE_PER_CPU(u32, ftrace_cur_idx);
DEFINE_PER_CPU(u32, ftrace_sta_idx);
DEFINE_PER_CPU(u32, ftrace_end_idx);
int cmd_ftrace(const char *cmd, void *out_data)
{
    struct hos_ftrace_param_t *fdata_ptr;
    void *trace_buffer = NULL;
    u64 ftrace_sum = 0;
    u32 sta_buf_idx, end_buf_idx;
    u32 cpu;
    if (strcmp(cmd, "ready") == 0) {
        for_each_possible_cpu(cpu) {
            trace_buffer = vmm_zalloc(TRACE_TOTAL_SIZE);// 2M
            if (!trace_buffer) {
                vmm_printf("trace buffer alloc failed!\n");
            }
            per_cpu(ftrace_buf, cpu) = (u64)trace_buffer;
        }
    } else if (strcmp(cmd, "free") == 0) {
        for_each_possible_cpu(cpu) {
            trace_buffer = (void*)per_cpu(ftrace_buf, cpu);
            if (trace_buffer)
                vmm_free(trace_buffer);
        }
        trace_buffer = NULL;
    } else if (strcmp(cmd, "start") == 0) {
        for_each_possible_cpu(cpu) {
            per_cpu(ftrace_sta_idx, cpu) = per_cpu(ftrace_cur_idx, cpu);
        }
        g_ftrace_sum = 0;
        ftrace_start = true;
        arch_mb();
    } else if (strcmp(cmd, "stop") == 0) {
        ftrace_start = false;
        arch_mb();
        fdata_ptr = (struct hos_ftrace_param_t*)out_data;
        // vmm_printf("^*^--ftrace buffer info--^*^\n");
        for_each_possible_cpu(cpu) {
            per_cpu(ftrace_end_idx, cpu) = per_cpu(ftrace_cur_idx, cpu);
            sta_buf_idx = per_cpu(ftrace_sta_idx, cpu);
            end_buf_idx = per_cpu(ftrace_end_idx, cpu);
            if (fdata_ptr) {
                fdata_ptr->cpu_len[cpu] = (end_buf_idx >= sta_buf_idx)
                        ? (u32)(end_buf_idx - sta_buf_idx) : (u32)(end_buf_idx + TRACE_BUF_SIZE - sta_buf_idx);
                ftrace_sum += fdata_ptr->cpu_len[cpu];
            }
            //vmm_printf("cpu%d: ftrace_buf=0x%lx start_idx=%d end_idx=%d\n", cpu, per_cpu(ftrace_buf, cpu), sta_buf_idx, end_buf_idx);
        }
        if (ftrace_sum < g_ftrace_sum) {
            vmm_printf("ftrace buf overflow!! hypervisor has %ld ftraces, but only saved %ld.\n", g_ftrace_sum, ftrace_sum);
        }
    } else if (strcmp(cmd, "check") == 0) {
        for_each_possible_cpu(cpu) {
            per_cpu(ftrace_end_idx, cpu) = per_cpu(ftrace_cur_idx, cpu);
            sta_buf_idx = per_cpu(ftrace_sta_idx, cpu);
            end_buf_idx = per_cpu(ftrace_end_idx, cpu);
            vmm_printf("cpu%d: ftrace_buf=0x%lx start_idx=%d end_idx=%d\n", cpu, per_cpu(ftrace_buf, cpu), sta_buf_idx, end_buf_idx);
        }
        vmm_printf("g_ftrace_sum=%ld\n", g_ftrace_sum);
    } else if (strcmp(cmd, "print") == 0) {
    }
    return VMM_OK;
}
NO_INSTRUMENT void __cyg_profile_func_enter(void *this_fn, void *call_site)
{
    if (ftrace_start && vmm_init_done()) {
        if (per_cpu(ftrace_cur_idx, arch_smp_id()) >= TRACE_BUF_SIZE) {
            per_cpu(ftrace_cur_idx, arch_smp_id()) = 0;
        }
        u32 buf_idx = per_cpu(ftrace_cur_idx, arch_smp_id());
        u64 *trace_buf = (u64*)per_cpu(ftrace_buf, arch_smp_id());
        u64 *trace_save = &trace_buf[buf_idx * TRACE_PER_ITEM];// 2 items per idx
        per_cpu(ftrace_cur_idx, arch_smp_id())++;
#ifdef MACHINE_64
        *trace_save++ = arch_smp_id();
        *trace_save++ = (u64)this_fn;
        *trace_save++ = (u64)call_site;
        *trace_save++ = mrs(cntpct_el0);
#else
        *trace_save = (u64)this_fn | (((u64)call_site) << 32);
        *(trace_save + 1) = (mrs(cntpct_el0) << 8) | arch_smp_id();
#endif
        g_ftrace_sum++;
    }
}
NO_INSTRUMENT inline void __cyg_profile_func_exit(void *this_fn, void *call_site)
{
}
s32 hcall_ftrace(struct vmm_vcpu *vcpu, u64 param_pa, u64 buf_pa) {
    struct hos_ftrace_param_t fpara;
    s32 res, ret = VMM_OK;
    u64 cmd = 0;
    u32 sta_buf_idx, end_buf_idx, i;
    u64 *trace_buf, *data;
    res = vmm_guest_memory_read(vcpu->guest, param_pa, &fpara, (u32)sizeof(fpara), TRUE);
    if (res != sizeof(fpara)) {
        return VMM_EIO;
    }
    cmd = fpara.cmd & 0xff;
    // vmm_printf("hos_ftrace: hyper ftrace cmd=%ld flag=%ld vmm=%d\n", cmd, ftrace_start, vmm_init_done());
    if (cmd == FTRACE_CMD_READY) {
        cmd_ftrace("ready", NULL);
    } else if (cmd == FTRACE_CMD_END) {
        cmd_ftrace("stop", &fpara);
        //vcpu_trap_cnt_tmp(false);
        res = vmm_guest_memory_write(vcpu->guest, param_pa, &fpara, (u32)sizeof(fpara), TRUE);
        if (res != sizeof(fpara)) {
            return VMM_EIO;
        }
    } else if (cmd == FTRACE_CMD_UNREADY) {
            cmd_ftrace("free", NULL);
    } else if (cmd == FTRACE_CMD_START) {
            cmd_ftrace("start", NULL);
    } else if (cmd == FTRACE_CMD_PRINT) {
        old_cpuid = ftrace_cpuid;
        ftrace_cpuid = (fpara.cmd >> 8) & 0xff;
        // vmm_printf("hos_ftrace: cpuid=%d old_cpuid=%d\n", ftrace_cpuid, old_cpuid);
        sta_buf_idx = per_cpu(ftrace_sta_idx, ftrace_cpuid);
        end_buf_idx = per_cpu(ftrace_end_idx, ftrace_cpuid);
        trace_buf = (u64*)per_cpu(ftrace_buf, ftrace_cpuid);
        if (old_ftracebuf_idx && (old_cpuid == ftrace_cpuid)) {
                data = &trace_buf[old_ftracebuf_idx * TRACE_PER_ITEM];
        } else {
                data = &trace_buf[sta_buf_idx * TRACE_PER_ITEM];
                old_ftracebuf_idx = sta_buf_idx;
        }
        // vmm_printf("hos_ftrace: old idx=%d st=%d ed=%d\n", old_ftracebuf_idx, sta_buf_idx, end_buf_idx);
        if (end_buf_idx >= sta_buf_idx) {
            if (fpara.cpu_len[ftrace_cpuid] >= ITEMS_PER_PAGE) {// 4096/items
                for (i = 0; i < ITEMS_PER_PAGE; i++) {
                    //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                    vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                    data += TRACE_PER_ITEM;//item offset
                    buf_pa += TRACE_PER_ITEM * 8;
                }
                fpara.cpu_len[ftrace_cpuid] = ITEMS_PER_PAGE;
                old_ftracebuf_idx += ITEMS_PER_PAGE;
            } else {
                for (i = 0; i < fpara.cpu_len[ftrace_cpuid]; i++) {
                    //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                    vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                    data += TRACE_PER_ITEM;
                    buf_pa += TRACE_PER_ITEM * 8;
                }
                old_ftracebuf_idx = 0;
            }
        }
        else { //end < start
            if (fpara.cpu_len[ftrace_cpuid] >= ITEMS_PER_PAGE) {// 4096/items
                if (TRACE_BUF_SIZE - old_ftracebuf_idx >= ITEMS_PER_PAGE) {
                    for (i = 0; i < ITEMS_PER_PAGE; i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                    old_ftracebuf_idx += ITEMS_PER_PAGE;
                } else {
                    for (i = 0; i < TRACE_BUF_SIZE - old_ftracebuf_idx; i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                    for (i = 0; i < ITEMS_PER_PAGE - (TRACE_BUF_SIZE - old_ftracebuf_idx); i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                    old_ftracebuf_idx = ITEMS_PER_PAGE - (TRACE_BUF_SIZE - old_ftracebuf_idx);
                }
                fpara.cpu_len[ftrace_cpuid] = ITEMS_PER_PAGE;
            } else {// < ITEMS_PER_PAGE
                if (TRACE_BUF_SIZE - old_ftracebuf_idx >= fpara.cpu_len[ftrace_cpuid]) {
                    for (i = 0; i < fpara.cpu_len[ftrace_cpuid]; i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                } else {// < fpara.cpu_len[ftrace_cpuid]
                    for (i = 0; i < TRACE_BUF_SIZE - old_ftracebuf_idx; i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                    for (i = 0; i < fpara.cpu_len[ftrace_cpuid] - (TRACE_BUF_SIZE - old_ftracebuf_idx); i++) {
                        //("cpu%ld:func=0x%lx:parent=0x%lx:time=%ld\n");
                        vmm_guest_memory_write(vcpu->guest, buf_pa, data, TRACE_PER_ITEM * 8, TRUE);
                        data += TRACE_PER_ITEM;
                        buf_pa += TRACE_PER_ITEM * 8;
                    }
                }
                old_ftracebuf_idx = 0;
            }
        }
        res = vmm_guest_memory_write(vcpu->guest, param_pa, &fpara, (u32)sizeof(fpara), TRUE);
        if (res != sizeof(fpara)) {
            return VMM_EIO;
        }
    }
    return ret;
}

