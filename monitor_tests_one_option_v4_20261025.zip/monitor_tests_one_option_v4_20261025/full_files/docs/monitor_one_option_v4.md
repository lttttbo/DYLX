# Monitor v4：单一测试开关

日期：2026-10-25。依据当前“先测试 Hypervisor 能自行触发的场景”的范围整理。

## 配置和执行

测试侧只保留一个配置：

```text
CONFIG_WBOXTEST_MONITOR=y
```

它仍依赖已有的 wboxtest 框架及 monitor 产品功能（CONFIG_WBOXTEST=y、CONFIG_MONITOR_AGENT=y、CONFIG_CMD_MONITOR=y）。这些是框架/产品开关，不是新增的 monitor 测试子选项。测试选项自动选中内置的 memory 和 wboxtest 命令，不再要求分别设置 HOST、LIVE 或手动切换 memory 命令为内置。

执行：

```text
monitor start
wboxtest group_list
wboxtest run_groups 1 monitor
```

monitor 组固定包含 9 个用例：monitor_lifecycle、monitor_config、monitor_scheduler、monitor_memory、monitor_storm、monitor_output，以及 monitor_host_range、monitor_host_guest_guard、monitor_host_shmem。

不需要 monitor_live target 或 Guest 用户态程序。Guest 写保护用例仍需要至少一个已创建且符合原检查条件的 Guest 内存映射；Guest 不必运行。缺少条件时明确失败，不当成通过。日志人工检查。测试中保持 monitor 启停、配置和 VM 映射稳定。

## 本次合并的范围

- 删除 CONFIG_WBOXTEST_MONITOR_HOST、CONFIG_WBOXTEST_MONITOR_LIVE 的配置入口和有效代码引用。
- 核心只读观察接口、采样完成序号、命令测试适配接口统一由 CONFIG_WBOXTEST_MONITOR 控制。
- 隔离 monitor 副本在 include 实际实现前 undef 同一个测试开关，防止重复定义观察接口。
- 7 个测试编译单元集中列在 monitor/objects.mk，不再维护 host/live 两份对象列表。
- 当前 Guest 现场用例的 C 源码保留，但不参与此次构建、不注册到 monitor 组；这不是跳过后算 PASS。以后恢复真实 Guest 场景时再接入执行流程。
- 生产 monitor 的启停、优先级、判断策略及记录点不变；关闭测试选项会去掉全部测试和适配代码，但保留产品 monitor 原本的功能。

CONFIG_CMD_MEMORY=y 会由测试选项选择，因此必须已合入你的私有 cmd_memory 检查/记录适配版本。只有原始开源 cmd_memory.c 无法提供两个测试适配函数。

## 合入

已经合入 monitor_hv_tests_v4_20261025 包时，仅应用本包的 single_option.patch。
尚未合入该包时，先按之前包安装 Hypervisor 测试，再应用本包；本次是它的配置简化增量。

四个旧文件在补丁中删除：

```text
libs/wboxtest/monitor/host/openconf.cfg
libs/wboxtest/monitor/host/objects.mk
libs/wboxtest/monitor/live/openconf.cfg
libs/wboxtest/monitor/live/objects.mk
```

手工合入时不要保留旧 objects.mk 的编译行，否则工程自动扫描子目录时可能重复链接。不要删除对应目录中的 C/H 文件或你的其他改动。

重新生成配置后，旧 HOST/LIVE 项应不再出现。遗留配置里的旧值不再具有作用，也不需要将它们改成 y。量产关闭 CONFIG_WBOXTEST_MONITOR。

## 覆盖与验证

这次只简化构建配置和本阶段用例选择，不改变原 9 个用例的断言。实际 CPU/exit 场景仍按原白盒覆盖范围理解，不因为选项合并而宣称完成 Guest 现场验收。

Hypervisor 三项的自动断言检查原错误返回、真实 monitor 事件、采样推进和合法访问不误报；命令适配函数不实际访问非法物理地址，共享内存只操作测试专用对象。

本机验证报告位于 validation。编译及平台模型结果不代替你的完整私有固件链接或板卡运行；ROM/CPU 指标也不由此证明达标。
