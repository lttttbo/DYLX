/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef MONITOR_WBOX_COMMON_H
#define MONITOR_WBOX_COMMON_H
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/wboxtest.h>

#define MT_COUNT 4
#define MT_HOST 2
#define MT_IDLE 3
#define MT_UNKNOWN MT_COUNT
struct mt_latency { u64 count, sum, max; };
struct mt_snapshot {
	struct mt_latency ready, dispatch;
	u64 ready_since, exits, count, interval, sustained;
	u32 epoch, guest, kind, windows;
	bool present, waiting, active, valid;
};
struct mt_event {
	u64 seq, time, last, value, address, detail;
	u32 type, guest, vcpu, epoch, code, config_seq, sustain_s;
};
struct mt_global {
	u64 head, cursor, lost;
	u32 epoch, enabled, skipped, logs, config_seq;
	u32 config[VMM_MONITOR_CONFIG_KEYS];
};
/* All functions below operate only on the namespaced test instance.
 * The fixture mutex must be held from mt_begin() through mt_end(). */
void mt_begin(void);
void mt_end(void);
void mt_reset(void);
u64 mt_now(void);
void mt_time(u64 ns);
struct vmm_vcpu *mt_vcpu(u32 id);
void mt_cpu(u32 cpu);
int mt_enable(bool on);
int mt_config(u32 key, u32 value);
void mt_record(u32 id, u32 hook, u64 a, u64 b);
void mt_fault(struct vmm_vcpu *v, u32 kind, u64 address, u64 detail);
void mt_exits(u32 id, u32 count, u32 reason);
void mt_sample(u64 now);
void mt_sample_skip(u32 id, u64 now);
void mt_drain(void);
void mt_snapshot(u32 id, struct mt_snapshot *s);
void mt_global(struct mt_global *g);
bool mt_event(u64 seq, struct mt_event *e);
int mt_command(const char *verb, const char *key, const char *value);
const char *mt_output(void);
const char *mt_log(void);
bool mt_overflow(void);

#define MT_CHECK(expr) do { \
	if (!(expr)) { \
		vmm_cprintf(cdev, "%s:%u: %s\n", __func__, __LINE__, #expr); \
		rc = VMM_EFAIL; goto out; \
	} \
} while (0)

/* Each iteration initializes inside run(), not in the framework's setup(). */
#define MT_REGISTER(test_name, runfn) \
static struct wboxtest test_name = { .name = #test_name, .run = runfn }; \
static int __init test_name##_init(void) { return wboxtest_register("monitor", &test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name, #test_name, "Monitor maintainers", "GPL", WBOXTEST_IPRIORITY+1, \
		   test_name##_init, test_name##_exit)
#endif
