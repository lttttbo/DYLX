本目录仅用于从原记录版重新合入。当前已通过九项的工程使用上层 add_to_current.patch。
旧统一测试合入位置见 previous_merge_locations.txt；上次采样修正见 sampling_fix_locations.txt；
本次新增风暴测试见上层 merge_locations.txt。主说明以外层 README.txt 为准。
