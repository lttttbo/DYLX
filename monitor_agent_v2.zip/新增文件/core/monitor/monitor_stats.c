/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <libs/mathlib.h>

void vmm_monitor_hist_add(struct vmm_monitor_hist *h, u64 ns)
{
	u32 b = 0;
	u64 upper = 1000;
	while (b < VMM_MONITOR_BUCKETS - 1 && ns > upper) {
		upper <<= 1;
		b++;
	}
	if (!h->count || ns < h->min)
		h->min = ns;
	if (ns > h->max)
		h->max = ns;
	h->count++;
	h->sum += ns;
	h->bins[b]++;
}

void vmm_monitor_hist_read(const struct vmm_monitor_hist *h,
			   struct vmm_monitor_latency *out)
{
	u32 b;
	u64 n = 0, target = h->count - udiv64(h->count, 100);
	out->count = h->count;
	out->min_ns = h->min;
	out->max_ns = h->max;
	out->mean_ns = h->count ? udiv64(h->sum, h->count) : 0;
	out->p99_upper_ns = 0;
	if (!h->count)
		return;
	for (b = 0; b < VMM_MONITOR_BUCKETS; b++) {
		n += h->bins[b];
		if (n >= target) {
			/* Last bucket is unbounded; observed maximum is a safe bound. */
			out->p99_upper_ns = b == VMM_MONITOR_BUCKETS - 1 ?
				h->max : (1000ULL << b);
			return;
		}
	}
}

int vmm_monitor_storm_step(struct vmm_monitor_streak *s, u64 count,
			   u64 dt, u32 rate, u32 seconds, bool valid)
{
	/* dt is bounded before multiplying; do not credit missing windows. */
	if (!valid || dt < VMM_MONITOR_NS * 3 / 4 ||
	    dt > VMM_MONITOR_NS * 5 / 4) {
		s->elapsed = 0;
		s->windows = 0;
		return 0;
	}
	/* count > rate * dt / 1e9 implements strict 'greater than'. */
	if (count > udiv64((u64)rate * dt, VMM_MONITOR_NS)) {
		if (s->elapsed < (u64)seconds * VMM_MONITOR_NS)
			s->elapsed += dt;
		if (s->windows < seconds)
			s->windows++;
		if (!s->active && s->windows >= seconds &&
		    s->elapsed >= (u64)seconds * VMM_MONITOR_NS) {
			s->active = TRUE;
			return 1;
		}
	} else {
		bool was_active = s->active;
		s->elapsed = 0;
		s->windows = 0;
		s->active = FALSE;
		return was_active ? -1 : 0;
	}
	return 0;
}
