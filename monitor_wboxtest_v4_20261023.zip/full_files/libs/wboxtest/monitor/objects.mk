libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/support.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/lifecycle.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/scheduler.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/memory.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/storm.o
libs-objs-$(CONFIG_WBOXTEST_MONITOR) += wboxtest/monitor/output.o
