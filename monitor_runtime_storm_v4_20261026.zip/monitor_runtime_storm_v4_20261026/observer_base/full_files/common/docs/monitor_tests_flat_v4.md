# Monitor v4：统一测试及真实 exit 风暴用例

Monitor v4：利用现有 Guest 真实 exit 的风暴集成测试 / 2026-10-26

1. 你当前工程的合入方式
本次小补丁以已通过九项测试的 monitor_test_sampling_fix_v4_20261026 为基线。
使用根目录 add_to_current.patch，或按 merge_locations.txt 手工合入。
只增加 libs/wboxtest/monitor/storm_runtime.c，并修改同目录 objects.mk/openconf.cfg。
完整文件位于 full_files。私有工程按函数/构建行合并，不覆盖原有业务改动。
没有新增头文件、目录层级或编译开关；仍使用 CONFIG_WBOXTEST_MONITOR。
生产 monitor、scheduler、内存策略、CCM 和 Guest 内核均未修改。
本包不处理之前观察到的采样间隔异常或 JSON 输出截断。

2. 新增什么测试
用例名：monitor_storm_runtime；组名：monitor。
原六项隔离测试、三项真实内存测试保留，当前共十项。
新增用例直接读取生产 monitor 的只读测试快照，临时调用原有配置接口修改门限。
不会直接调用 vmm_monitor_record/exit/sample/drain，不伪造 exit，不重置监控状态。
不新增测试 Guest，不修改现有 Guest 的运行状态、优先级、CPU 绑定或内存映射。
不需要 Guest 用户态辅助程序，依靠已有运行中的 Guest 正常产生 exit。

3. 前置条件及运行
保持至少一个现有 Guest 运行，并产生持续 exit；只有静态映射而 Guest 未运行不够。
自动选择最近连续两个新鲜有效窗口中有实际 exit 的 Guest vCPU，基线平均速率至少 4 次/秒。
多个候选同时满足时优先选基线速率较高的，打印实际 guest/vcpu 编号。
测试期间串行运行，保持 VM 生命周期、monitor 启停与配置稳定，不要并行运行其他 monitor 用例。
编译仍只需 CONFIG_WBOXTEST_MONITOR=y，依赖沿用已有 WBOXTEST/MONITOR_AGENT/CMD_MONITOR 等配置。
建议先单独执行新用例：
  monitor start
  monitor config
  unittest run_tests 1 monitor_storm_runtime
  monitor config
  monitor events
然后可运行全部十项：
  unittest run_groups 1 monitor
上游命令名称为 wboxtest；以上按你项目已展示的 unittest 命名。
每次正常执行约 25～40 秒，取决于采样相位与间隔；不是原隔离测试约 1 毫秒的执行时间。
选目标时间预算 10 秒，后续五个阶段各最多 20 秒；无法获得充分证据时失败，不计为通过。
无 Guest/没有足够真实 exit 返回 ENOTAVAIL；超时返回 ETIMEDOUT，并打印失败阶段。

4. 自动执行流程
select：保存 enabled/epoch/config 等基线，观察实际采样，自动选择目标。
quiet：临时将全局 exit_limit 提高到 1000000000/s、sustain_s 设为 5；
       等目标出现两个有效未超限窗口，确认 active 已清除，排除之前风暴的去重状态干扰。
trigger：阈值降为 min(500, floor(基线速率/4))，下限为 1 次/秒；
         例如基线约 2420/s，则测试门限为 500/s。等待真实 exit 连续超过门限并产生首条事件。
dedup：阈值保持不变，再观察至少 5 秒且至少 5 个连续有效超限窗口，期间不能产生重复事件。
recover：再次提高阈值，等两个有效未超限窗口，确认检测器恢复到可再次触发状态。
retrigger：再次降低到相同门限，等待另一条符合条件的新风暴事件。
restore：恢复原 exit_limit 与 sustain_s 并读回校验，成功后才报告 PASS。

门限是现有全局配置，测试期间其他 Guest vCPU 也可能正常生成 type=1 事件；
用例只将选定 guest/vcpu 的事件计为自身证据，其他事件不会误算成通过。
修改配置会使跨配置窗口失效；测试等待新的有效窗口，不将其计入持续时间。
对于短时目标采样跳过，按后续真实窗口重新累计；不放宽有效窗口判据。
无关槽位 skipped 增长不直接失败；目标持续没有有效进度仍会超时。

5. 自动判定与输出
必须观察到 type=1，且 guest/vcpu/epoch/config_seq/detail/sustain_s 对应本次目标与配置。
事件时间必须等于产生事件的采样窗口结束时间，value 必须等于该窗口实际退出速率的整数值。
超限判定使用实际 interval_ns；不能把三秒累计次数当成每秒次数。
value 是截断取整的速率，不能简单用 value>limit 替代精确的窗口计数比较。
测试独立累计连续超限窗口数量及时间；不足五秒或不足五个有效窗口就告警会被检出。
应告警却无匹配事件、持续期间重复告警、恢复后不再告警均失败。
事件丢失、覆盖、执行器错误、启停或配置被外部修改也会明确失败。

典型通过输出（编号和序号以现场为准）：
  monitor_storm_runtime target guest=0 vcpu=70 baseline=2420/s
  monitor_storm_runtime test limit=500 sustain_s=5
  monitor_storm_runtime phase=quiet
  monitor_storm_runtime phase=trigger
  monitor_storm_runtime EVENT seq=... guest=0 vcpu=70 rate=.../s
  monitor_storm_runtime phase=dedup
  monitor_storm_runtime phase=recover
  monitor_storm_runtime phase=retrigger
  monitor_storm_runtime EVENT seq=... guest=0 vcpu=70 rate=.../s
  monitor_storm_runtime restored limit=50000 sustain_s=5
  monitor_storm_runtime PASS trigger/dedup/recovery/retrigger; logs=manual

config_seq 正常递增，不回滚；事件及原始统计历史保留，不为了测试通过而清空。
测试未改 enabled/epoch，不会为了测试自动 stop/start。正常失败/超时也恢复两项原配置。
若检测到其他操作者修改配置，则中止并提示 restore skipped，不覆盖对方的新设置；
此时按开头打印的 saved 值人工核对。恢复接口报错也会导致用例失败，不会宣称成功恢复。
当前框架把前置条件不足也显示为 failed，请结合 FAIL phase=... 原因区分。

6. 覆盖边界
板端运行本用例可验证：真实 Guest exit 统计、真实定时采样、连续超限判断、事件记录、去重与恢复。
它以正常退出流和降低门限测试功能，并没有人为制造硬件故障或 5 万次/秒实际高压退出流。
它不证明每一种退出原因都已打点，也不验证 ROM<=5KB、CPU<0.5%、日志落盘或串口 JSON 完整性。
日志按之前约定人工检查：用 EVENT seq/guest/vcpu/config_seq 与 monitor events、存储日志对应。
只有存在两个匹配事件及完整阶段证据，才计为这项真实链路测试通过。

7. 本次开发机验证
ARM64 严格编译：测试开启十个当前编译单元、关闭两个单元；另检查归档 Guest 源码。
无重复全局符号，生产监控源码与已交付版逐字节相同。
原六项隔离用例 54 次执行、三模式只读接口、8 项解析回归及 18 组内存模型场景通过。
新增风暴模型 24 组：正常、已处于告警状态、原门限很低、无关跳过、目标偶发跳过，
以及无 Guest/无退出/无采样/关闭监控/负载消失/持续跳过/无效窗口/丢失/执行器错误/配置或 epoch 变化。
另对故意漏记、重复告警、提前告警、错误速率/Guest/门限、不能重新使能的七种实现缺陷验证可检出。
上述 24 组包含这七种缺陷场景，并非额外增加 7 组。
模型检查成功/异常路径恢复配置，外部修改不被覆盖；模型 PASS 表示预期行为被验证。
开发机模型会模拟 exit 和时间，这与固件中的新用例分离；固件用例没有模拟注入。
尚未获得你的完整私有固件，没有代替你执行板卡/QEMU 测试。

8. 如需直接从原记录版重新合入
observer_base/from_observer.patch 直接基于 monitor_observer_from_20261023_v4_20261025，
包含统一测试、上次采样判据修正和本次真实风暴测试。
observer_base/cmd_memory_from_uploaded.patch 为原上传命令文件的既有打点/适配，内容不变。
当前已经通过九项测试的工程只用根目录 add_to_current.patch，不要叠加两条路线。
optional_verification 只包含开发机工具增量，不参与固件编译，无需为板端测试合入。
