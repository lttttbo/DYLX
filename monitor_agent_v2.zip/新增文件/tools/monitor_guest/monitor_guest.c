/* SPDX-License-Identifier: GPL-2.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include "monitor_uapi.h"
#include "monitor_parse.h"

static volatile sig_atomic_t stopping;
static void stop_handler(int signal_number) { (void)signal_number; stopping = 1; }
static FILE *open_proc(const char *root, const char *name)
{
	char path[1024];
	int n = snprintf(path, sizeof(path), "%s/%s", root, name);
	return n < 0 || (size_t)n >= sizeof(path) ? NULL : fopen(path, "r");
}
static int number(const char *s, unsigned *value)
{
	char *end; unsigned long n;
	if (!*s || *s == '-') return -1;
	errno = 0; n = strtoul(s, &end, 10);
	if (errno || *end || n > UINT_MAX) return -1;
	*value = (unsigned)n; return 0;
}
int main(int argc, char **argv)
{
	const char *root = "/proc", *device = "/dev/xvisor_monitor";
	unsigned interval_ms = 1000, limit = 9000;
	int once = 0, stdout_only = 0, fd = -1, i, baseline = 0, cpu_ok;
	struct xm_cpu previous = {{0}}, current;
	struct xm_report report;
	struct timespec next, stamp;
	uint64_t cpu = 0, total, available, free_bytes;
	FILE *f;
	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "--once")) once = 1;
		else if (!strcmp(argv[i], "--stdout-only")) stdout_only = 1;
		else if (i + 1 < argc && !strcmp(argv[i], "--device")) device = argv[++i];
		else if (i + 1 < argc && !strcmp(argv[i], "--proc-root")) root = argv[++i];
		else if (i + 1 < argc && !strcmp(argv[i], "--interval-ms")) { if (number(argv[++i], &interval_ms)) return 2; }
		else if (i + 1 < argc && !strcmp(argv[i], "--cpu-limit-bp")) { if (number(argv[++i], &limit)) return 2; }
		else { fprintf(stderr, "monitor_guest [--once] [--stdout-only] [--device PATH] [--proc-root PATH] [--interval-ms 100..2000] [--cpu-limit-bp 0..10000]\n"); return 2; }
	}
	if (interval_ms < 100 || interval_ms > 2000 || limit > 10000) return 2;
	if (!stdout_only && (fd = open(device, O_WRONLY | O_CLOEXEC)) < 0) { perror(device); return 1; }
	signal(SIGINT, stop_handler); signal(SIGTERM, stop_handler);
	f = open_proc(root, "stat");
	if (f) { baseline = !xm_cpu_read(f, &previous); fclose(f); }
	if (clock_gettime(CLOCK_MONOTONIC, &next)) return 1;
	while (!stopping) {
		next.tv_nsec += (long)interval_ms * 1000000L;
		next.tv_sec += next.tv_nsec / 1000000000L; next.tv_nsec %= 1000000000L;
		while (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL) == EINTR && !stopping) { }
		if (stopping) break;
		memset(&report, 0, sizeof(report)); cpu_ok = 0;
		f = open_proc(root, "stat");
		if (f) { if (!xm_cpu_read(f, &current)) { cpu_ok = baseline && !xm_cpu_usage(&previous, &current, &cpu); previous = current; baseline = 1; } else baseline = 0; fclose(f); } else baseline = 0;
		if (cpu_ok) { report.cpu_bp = cpu; report.valid |= 1; }
		f = open_proc(root, "meminfo");
		if (f) { if (!xm_mem_read(f, &total, &available, &free_bytes)) { report.total_bytes = total; report.available_bytes = available; report.free_bytes = free_bytes; report.valid |= 2; } fclose(f); }
		if (clock_gettime(CLOCK_MONOTONIC, &stamp)) break;
		printf("{\"schema\":1,\"kind\":\"guest_sample\",\"time_ns\":%"PRIu64",\"valid\":%"PRIu64",\"cpu_bp\":%"PRIu64",\"cpu_high\":%u,\"total_bytes\":%"PRIu64",\"available_bytes\":%"PRIu64",\"used_estimate_bytes\":%"PRIu64"}\n",
			(uint64_t)stamp.tv_sec * 1000000000 + (uint64_t)stamp.tv_nsec, (uint64_t)report.valid,
			(uint64_t)report.cpu_bp, (unsigned)(cpu_ok && limit && cpu > limit),
			(uint64_t)report.total_bytes, (uint64_t)report.available_bytes,
			(uint64_t)(report.total_bytes - report.available_bytes));
		fflush(stdout);
		if (fd >= 0 && report.valid && write(fd, &report, sizeof(report)) != sizeof(report)) perror("monitor report");
		if (once) break;
		/* Skip missed periods, do not burst old measurements after a stall. */
		if (stamp.tv_sec > next.tv_sec || (stamp.tv_sec == next.tv_sec && stamp.tv_nsec > next.tv_nsec)) next = stamp;
	}
	if (fd >= 0) close(fd);
	return 0;
}
