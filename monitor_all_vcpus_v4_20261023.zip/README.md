# 性能监控 v4 全调度对象监控增量包

交付版本：v4；整理日期：2026-10-23。
本次仅重新标注交付版本并规范交付文件命名，功能代码与 2026-10-22 的全调度对象版本完全一致。
JSON 协议仍为 schema=3，不因交付版本号改变。已经合入该功能版本的工程不必重复应用补丁。
交付文件及压缩包内目录、文件名采用纯英文和数字，保留 v4 版本号及标准扩展名；工程内原有文件路径、源码文件名及依赖include名保留，便于直接合入与复现测试。

增量补丁基线仍是“输出精简”版本。

本次修改：Guest vCPU、auth/mterm、ipi/syswq、monitor 和其他 orphan 线程均可记录 READY 等待与 dispatch 耗时。idle 单独分类；exit 风暴仍只统计 Guest。
monitor 日志线程优先级保持 3，auth/mterm 和 CPU 分配不调整。已有私有 scheduler 的打点可直接复用，本包不替换 scheduler。

## 关于 monitor=3、ipi=7

调度数据在调度器路径直接记录，周期汇总在 HV timer IRQ 中执行；不需要 priority=3 的 monitor 线程抢占 priority=7 的 ipi。
priority=3 只影响后台日志何时输出。IPI 长期占用采样核时，日志/mterm 可能延迟；长期屏蔽 HV IRQ 时采样本身也可能延迟。硬锁死仍需 watchdog 等独立机制，不能保证任何情况下都实时告警。
本版没有宿主线程利用率、IPI 硬中断次数/耗时或 READY 时延阈值告警；调度时延通过 status 观察，exit 异常通过 events/后台日志观察。

## 手工合入

1. main.patch：monitor_agent.c 核心修改和 openconf.cfg 帮助文字，共 2 个文件。
2. full_files/：上述文件以及测试、详细文档的完整内容。
3. merge_locations.txt：各改动所在函数及原/新参考行号，适合已有私有改动的工程手工合入。
4. tests_and_docs.patch：测试模型与文档，共 4 个文件；不影响目标固件功能。
5. design.md：新增第 9 节解释线程覆盖、已有打点依据、优先级边界及验收步骤。
6. file_manifest.json / SHA256SUMS.txt：版本与交付完整性校验。

先在工程副本执行 git apply --check。若旧版本不同，按函数/上下文手工合入；不能把本增量直接套到未集成 v3 的原始上游。
公共 vmm_monitor.h、cmd_monitor.c 和 scheduler 本次不需要修改。若私有 vmm_scheduler.h 缺少 idle_vcpu 声明，按函数定位说明补声明；getter 保持无锁。

## 输出与简要验证

monitor start
运行 Guest、唤醒 ipi/syswq、完成 auth/mterm 交互后执行 monitor status。
每对象 JSON 新增 kind=guest/host/idle。host/idle 的 guest=4294967295，vcpu 是实际系统 ID，可与 vcpu list 对照名称。
ready/dispatch 为 [累计次数,平均纳秒,最大纳秒]；host/idle 的 exits=0 表示不适用。
只有 start 后发生新打点的对象才进入本 epoch；始终 Paused/Reset 的对象可能尚未显示。idle 长时间 READY 通常是正常现象。
monitor config 仍为简洁文本回显；后台每个事件仍只调用一次 vmm_lwarning，由产品后端完成落盘和串口镜像。

建议先用默认优先级观察宿主时延，再在测试环境使用 exit_limit=100、sustain_s=2 验证 Guest 风暴去重。参数变更后的首个混合窗口会丢弃，需要等待随后完整的持续窗口。
priority=7 宿主线程即使调用 exit 打点，也不会被计作 Guest 风暴。

## 已有验证及限制

以下行为测试和编译记录来自 2026-10-22 的同一份代码。本次重新核对代码一致性、补丁应用结果和交付校验，不重复运行未改动代码的功能测试。

主机模型的内部/外部执行、开机启用、初始化失败、关闭宏、宿主与 idle、ID 复用、空 Guest 指针、单次日志、运行时配置均通过。
基于用户已适配 scheduler 实际函数及本版记录器，16 组 monitor/history/trace/adaptive 配置回归通过，覆盖 priority=7 host 与 idle，保留原 history/trace 时间戳。
ARM64 开启、开机启用、关闭、外部执行和基线翻译单元编译通过。两份补丁实际应用后的文件与完整交付文件一致，反向检查通过。
ROM 对象段增量估算 6553 B，开机自动启用 6561 B，仍超出 5120 B；静态 BSS 16264 B（MAX_VCPU_COUNT=64）。CPU<0.5% 和板端时序尚未实测，未运行私有固件/QEMU。
更多目标板验收步骤见设计书 8、9 节；16 组私有 scheduler 模型可用 validation/scheduler_model/run.py --cc <zig> --build-dir <目录> 复现。
