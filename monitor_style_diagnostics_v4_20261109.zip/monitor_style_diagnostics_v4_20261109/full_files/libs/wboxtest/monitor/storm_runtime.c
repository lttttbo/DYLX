/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * Observe the production monitor and existing Guest exits. Never inject exits,
 * call sample/drain, or change Guest scheduling/lifetime. Run tests serially.
 */
#include <vmm_monitor.h>
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_mutex.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/mathlib.h>
#include <libs/wboxtest.h>

#define SR_U(x) ((unsigned long long)(x))
#define SR_HIGH 1000000000U
#define SR_LOW 1U
#define SR_SECONDS 5U
#define SR_SELECT_NS (10ULL * VMM_MONITOR_NS)
#define SR_PHASE_NS (20ULL * VMM_MONITOR_NS)
#define SR_HISTORY 8U

static DEFINE_MUTEX(sr_lock);

/* Test-only static scratch; no additional production or test config option. */
struct sr_candidate {
	u64 previous;
	u64 rate;
	u32 good;
	u32 guest;
};

static struct sr_candidate sr_candidates[CONFIG_MAX_VCPU_COUNT];

struct sr_context {
	struct vmm_chardev *out;
	struct vmm_monitor_test_state saved;
	struct vmm_monitor_test_state expected;
	const char *phase;
	u64 cursor;
	u32 id;
	u32 guest;
	u32 low;
	bool locked;
	bool changed;
	bool foreign;
};

enum sr_phase {
	SR_QUIET,
	SR_TRIGGER,
	SR_HOLD,
	SR_RECOVER,
	SR_RETRIGGER
};

enum sr_observation {
	SR_OBS_LOW,
	SR_OBS_HIGH,
	SR_OBS_CONFIG,
	SR_OBS_INVALID,
	SR_OBS_EMPTY,
	SR_OBS_CLOCK,
	SR_OBS_BEFORE_PHASE,
	SR_OBS_OVERFLOW,
	SR_OBS_COUNT
};

struct sr_observation_record {
	u64 read_ns;
	u64 sample_ns;
	u64 interval;
	u64 exits;
	u32 config_seq;
	u32 reason;
	bool valid;
	bool active;
};

struct sr_diagnostics {
	struct sr_observation_record history[SR_HISTORY];
	struct vmm_monitor_test_state initial;
	u64 serial;
	u64 actor;
	u32 polls;
	u32 retries;
	u32 stale;
	u32 samples;
	u32 max_low;
	u32 reasons[SR_OBS_COUNT];
	bool state_ok;
	bool serial_ok;
	bool actor_ok;
};

/* Local phase state, shared by the polling loop and its single-step helper. */
struct sr_phase_state {
	struct sr_diagnostics diag;
	u64 start;
	u64 previous;
	u64 high_ns;
	u32 windows;
	u32 low_windows;
};

static int sr_fail(struct sr_context *c, int rc, const char *reason)
{
	vmm_cprintf(c->out, "monitor_storm_runtime FAIL phase=%s: %s\n",
		    c->phase, reason);
	return rc;
}

static bool sr_same_config(const struct vmm_monitor_test_state *a,
			   const struct vmm_monitor_test_state *b)
{
	return a->config_seq == b->config_seq &&
	       !memcmp(a->config, b->config, sizeof(a->config));
}

static int sr_state(struct sr_context *c, struct vmm_monitor_test_state *s)
{
	int rc = vmm_monitor_test_state(s);

	if (rc) {
		return sr_fail(c, rc, "cannot read monitor state");
	}
	if (!sr_same_config(s, &c->expected)) {
		c->foreign = TRUE;
		return sr_fail(c, VMM_EBUSY,
			       "monitor configuration changed outside this test");
	}
	if (!s->enabled || s->enabled != c->saved.enabled ||
	    s->epoch != c->saved.epoch) {
		return sr_fail(c, VMM_EFAIL, "monitor enable/epoch changed");
	}
	if (s->lost != c->saved.lost || s->errors != c->saved.errors) {
		return sr_fail(c, VMM_EFAIL, "event loss or monitor executor error");
	}
	/* Global skipped is not a failure: target windows are checked below. */
	return VMM_OK;
}

static int sr_set(struct sr_context *c, u32 key, u32 value)
{
	struct vmm_monitor_test_state s;
	int rc = sr_state(c, &s);

	if (rc || c->expected.config[key] == value) {
		return rc;
	}
	rc = vmm_monitor_configure(key, value);
	if (rc) {
		return sr_fail(c, rc, "cannot set temporary configuration");
	}
	c->changed = TRUE;
	c->expected.config[key] = value;
	if (!++c->expected.config_seq) {
		++c->expected.config_seq;
	}
	return sr_state(c, &s);
}

static int sr_restore(struct sr_context *c)
{
	struct vmm_monitor_test_state s;
	int a;
	int b;

	if (!c->changed) {
		return VMM_OK;
	}
	if (vmm_monitor_test_state(&s)) {
		return sr_fail(c, VMM_EFAIL,
			       "restore: cannot read current configuration");
	}
	if (c->foreign || !sr_same_config(&s, &c->expected)) {
		return sr_fail(c, VMM_EBUSY,
			       "restore skipped: external configuration must not be overwritten");
	}
	/*
	 * Always try both owned keys, even if restoring the first one fails.
	 * Sampling windows, enabled state, VM state and history are never reset.
	 */
	a = vmm_monitor_configure(VMM_MONITOR_EXIT_LIMIT,
				  c->saved.config[VMM_MONITOR_EXIT_LIMIT]);
	b = vmm_monitor_configure(VMM_MONITOR_SUSTAIN_S,
				  c->saved.config[VMM_MONITOR_SUSTAIN_S]);
	if (a || b || vmm_monitor_test_state(&s) ||
	    memcmp(s.config, c->saved.config, sizeof(s.config))) {
		return sr_fail(c, VMM_EFAIL, "restore failed; check monitor config");
	}
	vmm_cprintf(c->out,
		    "monitor_storm_runtime restored limit=%u sustain_s=%u\n",
		    s.config[VMM_MONITOR_EXIT_LIMIT],
		    s.config[VMM_MONITOR_SUSTAIN_S]);
	return VMM_OK;
}

static bool sr_full_window(const struct vmm_monitor_test_slot *s, u64 start)
{
	return s->valid && s->interval && s->previous >= s->interval &&
	       s->previous - s->interval >= start &&
	       s->exits <= ~0ULL / VMM_MONITOR_NS;
}

static int sr_select(struct sr_context *c)
{
	struct vmm_monitor_test_state g;
	struct vmm_monitor_test_slot s;
	u64 start = vmm_timer_timestamp();
	u64 best;
	u64 rate;
	u32 i;
	u32 selected;
	int rc;

	memset(sr_candidates, 0, sizeof(sr_candidates));
	do {
		rc = sr_state(c, &g);
		if (rc) {
			return rc;
		}
		best = 0;
		selected = ~0U;
		for (i = 0; i < CONFIG_MAX_VCPU_COUNT; i++) {
			struct sr_candidate *p = &sr_candidates[i];

			rc = vmm_monitor_test_slot(i, &s);
			if (rc) {
				return sr_fail(c, rc, "cannot inspect candidate slot");
			}
			if (!s.present || s.kind != 0 || s.epoch != c->saved.epoch ||
			    s.config_seq != c->expected.config_seq || s.guest == ~0U) {
				p->good = 0;
				continue;
			}
			if (s.previous != p->previous) {
				if (!sr_full_window(&s, start)) {
					p->good = 0;
				} else {
					rate = udiv64(s.exits * VMM_MONITOR_NS, s.interval);
					if (rate < 4 || (p->good &&
					    (p->guest != s.guest ||
					     s.previous - s.interval != p->previous))) {
						p->good = 0;
					}
					if (rate >= 4) {
						if (!p->good || rate < p->rate) {
							p->rate = rate;
						}
						p->good++;
						p->guest = s.guest;
					}
				}
				p->previous = s.previous;
			}
			if (p->good >= 2 && p->rate > best &&
			    vmm_timer_timestamp() >= p->previous &&
			    vmm_timer_timestamp() - p->previous < 2 * VMM_MONITOR_NS) {
				best = p->rate;
				selected = i;
			}
		}
		if (selected != ~0U) {
			c->id = selected;
			c->guest = sr_candidates[selected].guest;
			/*
			 * A boot-time peak is not a sustained workload guarantee.
			 * Use the lowest supported threshold for this functional path
			 * test, then restore the original policy. Real exits must
			 * still exceed it.
			 */
			c->low = SR_LOW;
			vmm_cprintf(c->out,
				    "monitor_storm_runtime target guest=%u vcpu=%u "
				    "baseline=%llu/s\n",
				    c->guest, c->id, SR_U(best));
			vmm_cprintf(c->out,
				    "monitor_storm_runtime test limit=%u sustain_s=%u\n",
				    c->low, SR_SECONDS);
			return VMM_OK;
		}
		vmm_msleep(20);
	} while (vmm_timer_timestamp() - start < SR_SELECT_NS);
	return sr_fail(c, VMM_ENOTAVAIL,
		       "need a running Guest with two fresh valid exit windows");
}

/*
 * Read slot -> ring -> slot, committing cursor only if the sample is unchanged.
 * A concurrent sampler may publish the slot and event between separate APIs.
 */
static int sr_frame(struct sr_context *c, struct vmm_monitor_test_slot *s,
		    struct vmm_monitor_test_event *found, u32 *count)
{
	struct vmm_monitor_test_slot after;
	struct vmm_monitor_test_state g;
	struct vmm_monitor_test_event e;
	u64 seq;
	int rc = sr_state(c, &g);

	if (rc) {
		return rc;
	}
	if (vmm_monitor_test_slot(c->id, s) || vmm_monitor_test_state(&g)) {
		return sr_fail(c, VMM_EFAIL, "cannot read sample/event boundary");
	}
	if (!s->present || s->kind != 0 || s->guest != c->guest ||
	    s->epoch != c->saved.epoch) {
		return sr_fail(c, VMM_EFAIL, "selected Guest slot changed");
	}
	if (g.head < c->cursor || g.head - c->cursor > VMM_MONITOR_EVENTS) {
		return sr_fail(c, VMM_EFAIL, "event evidence overwritten");
	}
	*count = 0;
	for (seq = c->cursor + 1; seq <= g.head; seq++) {
		if (vmm_monitor_test_event(seq, &e)) {
			return sr_fail(c, VMM_EFAIL, "event evidence no longer available");
		}
		if (e.type != 1 || e.vcpu != c->id) {
			continue;
		}
		if (e.guest != c->guest || e.epoch != c->saved.epoch ||
		    e.config_seq != c->expected.config_seq ||
		    e.detail != c->expected.config[VMM_MONITOR_EXIT_LIMIT] ||
		    e.sustain_s != SR_SECONDS || e.address || e.last_ns != e.time_ns) {
			return sr_fail(c, VMM_EFAIL,
				       "storm event identity/configuration mismatch");
		}
		*found = e;
		(*count)++;
	}
	if (vmm_monitor_test_slot(c->id, &after)) {
		return sr_fail(c, VMM_EFAIL, "cannot confirm sample boundary");
	}
	if (after.previous != s->previous || after.config_seq != s->config_seq ||
	    after.guest != s->guest || after.epoch != s->epoch ||
	    after.present != s->present) {
		return VMM_EAGAIN;
	}
	rc = sr_state(c, &g);
	if (rc) {
		return rc;
	}
	/* Advance only to the head scanned above, not a newly published head. */
	c->cursor = seq - 1;
	return VMM_OK;
}

/*
 * Diagnostics retain only distinct, coherent observations. No per-poll UART
 * output. These local fixed-size records are dumped only after phase timeout.
 */
static u32 sr_reject_reason(const struct sr_context *c,
			   const struct vmm_monitor_test_slot *s, u64 start)
{
	/* First matching rejection, in the same order as the existing predicate. */
	if (s->config_seq != c->expected.config_seq) {
		return SR_OBS_CONFIG;
	}
	if (!s->valid) {
		return SR_OBS_INVALID;
	}
	if (!s->interval) {
		return SR_OBS_EMPTY;
	}
	if (s->previous < s->interval) {
		return SR_OBS_CLOCK;
	}
	if (s->previous - s->interval < start) {
		return SR_OBS_BEFORE_PHASE;
	}
	return SR_OBS_OVERFLOW;
}

static void sr_note(struct sr_diagnostics *d,
		    const struct vmm_monitor_test_slot *s, u32 reason)
{
	struct sr_observation_record *r = &d->history[d->samples % SR_HISTORY];

	r->read_ns = vmm_timer_timestamp();
	r->sample_ns = s->previous;
	r->interval = s->interval;
	r->exits = s->exits;
	r->config_seq = s->config_seq;
	r->valid = s->valid;
	r->active = s->active;
	r->reason = reason;
	d->samples++;
	d->reasons[reason]++;
}

static void sr_diagnostic_dump(struct sr_context *c,
			       const struct sr_diagnostics *d, u64 start,
			       u32 high, u32 low, u64 high_ns)
{
	static const char *const reasons[] = {
		"low",
		"high",
		"config",
		"invalid",
		"empty",
		"clock",
		"before_phase",
		"overflow"
	};
	struct vmm_monitor_test_state g = {0};
	u64 serial = 0;
	u64 actor = 0;
	u64 now = vmm_timer_timestamp();
	u32 i;
	u32 first = d->samples > SR_HISTORY ? d->samples - SR_HISTORY : 0;
	int state_rc = vmm_monitor_test_state(&g);
	int serial_rc = vmm_monitor_test_sample_serial(&serial);
	int actor_rc = vmm_monitor_test_sample_actor(c->id, &actor);

	/*
	 * Capture counters before printing. The three read-only APIs are separate
	 * snapshots, so their differences are diagnostic, not atomic invariants.
	 */
	vmm_cprintf(c->out,
		    "monitor_storm_diag phase=%s guest=%u vcpu=%u epoch=%u\n",
		    c->phase, c->guest, c->id, c->saved.epoch);
	vmm_cprintf(c->out, "monitor_storm_diag start_ns=%llu end_ns=%llu\n",
		    SR_U(start), SR_U(now));
	vmm_cprintf(c->out,
		    "monitor_storm_diag expected_seq=%u limit=%u/s sustain_s=%u\n",
		    c->expected.config_seq,
		    c->expected.config[VMM_MONITOR_EXIT_LIMIT],
		    c->expected.config[VMM_MONITOR_SUSTAIN_S]);
	vmm_cprintf(c->out,
		    "monitor_storm_diag window_min_ms=%u window_max_ms=%u\n",
		    c->expected.config[VMM_MONITOR_WINDOW_MIN_MS],
		    c->expected.config[VMM_MONITOR_WINDOW_MAX_MS]);
	vmm_cprintf(c->out,
		    "monitor_storm_diag polls=%u frame_retries=%u same_sample=%u new_samples=%u\n",
		    d->polls, d->retries, d->stale, d->samples);
	vmm_cprintf(c->out,
		    "monitor_storm_diag consecutive_low=%u max_low=%u consecutive_high=%u\n",
		    low, d->max_low, high);
	vmm_cprintf(c->out,
		    "monitor_storm_diag high_ns=%llu low_total=%u high_total=%u\n",
		    SR_U(high_ns), d->reasons[SR_OBS_LOW], d->reasons[SR_OBS_HIGH]);
	for (i = SR_OBS_CONFIG; i < SR_OBS_COUNT; i++) {
		vmm_cprintf(c->out, "monitor_storm_diag rejected=%s count=%u\n",
			    reasons[i], d->reasons[i]);
	}
	if (!state_rc && d->state_ok) {
		vmm_cprintf(c->out,
			    "monitor_storm_diag global_skipped=%u->%u actual_seq=%u enabled=%u\n",
			    d->initial.skipped, g.skipped, g.config_seq, g.enabled);
		vmm_cprintf(c->out,
			    "monitor_storm_diag errors=%u->%u lost=%llu->%llu\n",
			    d->initial.errors, g.errors, SR_U(d->initial.lost), SR_U(g.lost));
	} else {
		vmm_cprintf(c->out,
			    "monitor_storm_diag state_read start_ok=%u end_rc=%d\n",
			    (u32)d->state_ok, state_rc);
	}
	if (!serial_rc && d->serial_ok) {
		vmm_cprintf(c->out, "monitor_storm_diag sampler_passes=%llu->%llu\n",
			    SR_U(d->serial), SR_U(serial));
	} else {
		vmm_cprintf(c->out,
			    "monitor_storm_diag sampler_read start_ok=%u end_rc=%d\n",
			    (u32)d->serial_ok, serial_rc);
	}
	if (!actor_rc && d->actor_ok) {
		vmm_cprintf(c->out, "monitor_storm_diag target_passes=%llu->%llu\n",
			    SR_U(d->actor), SR_U(actor));
	} else {
		vmm_cprintf(c->out,
			    "monitor_storm_diag target_read start_ok=%u end_rc=%d\n",
			    (u32)d->actor_ok, actor_rc);
	}
	if (d->samples) {
		const struct sr_observation_record *r =
			&d->history[(d->samples - 1) % SR_HISTORY];

		vmm_cprintf(c->out,
			    "monitor_storm_diag last_observed_age_ns=%llu future_stamp=%u\n",
			    SR_U(now >= r->sample_ns ? now - r->sample_ns : 0),
			    (u32)(now < r->sample_ns));
	}
	for (i = first; i < d->samples; i++) {
		const struct sr_observation_record *r = &d->history[i % SR_HISTORY];

		vmm_cprintf(c->out,
			    "monitor_storm_diag win=%u result=%s valid=%u active=%u "
			    "config_seq=%u\n",
			    i + 1, reasons[r->reason], (u32)r->valid, (u32)r->active,
			    r->config_seq);
		vmm_cprintf(c->out,
			    "monitor_storm_diag win=%u read_ns=%llu sample_ns=%llu\n",
			    i + 1, SR_U(r->read_ns), SR_U(r->sample_ns));
		vmm_cprintf(c->out,
			    "monitor_storm_diag win=%u interval_ns=%llu exits=%llu\n",
			    i + 1, SR_U(r->interval), SR_U(r->exits));
	}
}

/*
 * One observation step. EAGAIN means keep waiting, OK means the phase passed;
 * other errors end the phase. The caller owns the sleep and timeout checks.
 */
static int sr_poll(struct sr_context *c, enum sr_phase phase,
		   struct sr_phase_state *p)
{
	struct vmm_monitor_test_slot s;
	struct vmm_monitor_test_event e = {0};
	u32 events = 0;
	bool high;
	bool eligible;
	int rc;

	p->diag.polls++;
	rc = sr_frame(c, &s, &e, &events);
	if (rc == VMM_EAGAIN) {
		p->diag.retries++;
		return VMM_EAGAIN;
	}
	if (rc) {
		return rc;
	}
	if (s.previous == p->previous) {
		p->diag.stale++;
		if (events) {
			return sr_fail(c, VMM_EFAIL,
				       "event without a new sampling window");
		}
		return VMM_EAGAIN;
	}
	if (p->previous && s.interval && s.previous >= s.interval &&
	    s.previous - s.interval != p->previous) {
		return sr_fail(c, VMM_EFAIL, "observer missed sampling windows");
	}
	p->previous = s.previous;
	if (s.config_seq != c->expected.config_seq || !sr_full_window(&s, p->start)) {
		sr_note(&p->diag, &s, sr_reject_reason(c, &s, p->start));
		p->windows = 0;
		p->low_windows = 0;
		p->high_ns = 0;
		if (events) {
			return sr_fail(c, VMM_EFAIL,
				       "storm event in invalid/transition window");
		}
		return VMM_EAGAIN;
	}
	high = s.exits > udiv64((u64)c->expected.config[VMM_MONITOR_EXIT_LIMIT] *
				s.interval, VMM_MONITOR_NS);
	sr_note(&p->diag, &s, high ? SR_OBS_HIGH : SR_OBS_LOW);
	if (high) {
		p->windows++;
		p->high_ns += s.interval;
		p->low_windows = 0;
	} else {
		p->windows = 0;
		p->high_ns = 0;
		p->low_windows++;
	}
	if (p->low_windows > p->diag.max_low) {
		p->diag.max_low = p->low_windows;
	}
	eligible = p->windows >= SR_SECONDS &&
		   p->high_ns >= SR_SECONDS * VMM_MONITOR_NS;
	if (phase == SR_QUIET || phase == SR_RECOVER) {
		if (events) {
			return sr_fail(c, VMM_EFAIL,
				       "unexpected event with recovery threshold");
		}
		if (!high && s.active) {
			return sr_fail(c, VMM_EFAIL, "low-rate window did not rearm detector");
		}
		if (p->low_windows >= 2) {
			return VMM_OK;
		}
	} else if (phase == SR_HOLD) {
		if (events) {
			return sr_fail(c, VMM_EFAIL, "duplicate event during the same episode");
		}
		if (!high) {
			vmm_cprintf(c->out,
				    "monitor_storm_runtime load dropped: exits=%llu "
				    "interval_ns=%llu limit=%u/s\n",
				    SR_U(s.exits), SR_U(s.interval), c->low);
			return sr_fail(c, VMM_ENOTAVAIL,
				       "Guest exit rate dropped during dedup observation");
		}
		if (!s.active) {
			return sr_fail(c, VMM_EFAIL, "episode lost its active state");
		}
		if (eligible) {
			return VMM_OK;
		}
	} else {
		if (events > 1) {
			return sr_fail(c, VMM_EFAIL,
				       "multiple events for one threshold crossing");
		}
		if (events && (!eligible || !s.active || e.time_ns != s.previous ||
		    e.value != udiv64(s.exits * VMM_MONITOR_NS, s.interval))) {
			return sr_fail(c, VMM_EFAIL,
				       "early storm event or inconsistent rate/timestamp");
		}
		if (!events && (eligible || s.active)) {
			return sr_fail(c, VMM_EFAIL,
				       "threshold met but matching storm event missing");
		}
		if (events) {
			vmm_cprintf(c->out,
				    "monitor_storm_runtime EVENT seq=%llu guest=%u vcpu=%u "
				    "rate=%llu/s\n",
				    SR_U(e.seq), e.guest, e.vcpu, SR_U(e.value));
			vmm_cprintf(c->out,
				    "monitor_storm_runtime evidence config_seq=%u "
				    "limit=%llu; log=manual\n",
				    e.config_seq, SR_U(e.detail));
			return VMM_OK;
		}
	}
	return VMM_EAGAIN;
}

static int sr_phase(struct sr_context *c, enum sr_phase phase)
{
	static const char *const names[] = {
		"quiet",
		"trigger",
		"dedup",
		"recover",
		"retrigger"
	};
	struct sr_phase_state p = {0};
	int rc;

	p.start = vmm_timer_timestamp();
	c->phase = names[phase];
	vmm_cprintf(c->out, "monitor_storm_runtime phase=%s limit=%u/s\n",
		    c->phase, c->expected.config[VMM_MONITOR_EXIT_LIMIT]);
	p.diag.state_ok = !vmm_monitor_test_state(&p.diag.initial);
	p.diag.serial_ok = !vmm_monitor_test_sample_serial(&p.diag.serial);
	p.diag.actor_ok = !vmm_monitor_test_sample_actor(c->id, &p.diag.actor);
	do {
		rc = sr_poll(c, phase, &p);
		if (rc != VMM_EAGAIN) {
			return rc;
		}
		vmm_msleep(20);
	} while (vmm_timer_timestamp() - p.start < SR_PHASE_NS);
	sr_diagnostic_dump(c, &p.diag, p.start, p.windows, p.low_windows, p.high_ns);
	if (phase == SR_QUIET || phase == SR_RECOVER) {
		return sr_fail(c, VMM_ETIMEDOUT,
			       "need two consecutive fresh valid low-rate windows");
	}
	return sr_fail(c, VMM_ETIMEDOUT,
		       "insufficient fresh valid windows or sustained Guest exits");
}

/* Run the phases; sr_run always handles configuration restoration and unlock. */
static int sr_execute(struct sr_context *c)
{
	struct vmm_monitor_test_state g;
	int rc = vmm_monitor_test_state(&c->saved);

	if (rc || !c->saved.enabled) {
		return sr_fail(c, VMM_ENOTAVAIL, "run monitor start before this test");
	}
	c->expected = c->saved;
	c->phase = "select";
	rc = sr_select(c);
	if (rc) {
		return rc;
	}
	vmm_cprintf(c->out, "monitor_storm_runtime saved limit=%u sustain_s=%u\n",
		    c->saved.config[VMM_MONITOR_EXIT_LIMIT],
		    c->saved.config[VMM_MONITOR_SUSTAIN_S]);
	rc = sr_set(c, VMM_MONITOR_EXIT_LIMIT, SR_HIGH);
	if (!rc) {
		rc = sr_set(c, VMM_MONITOR_SUSTAIN_S, SR_SECONDS);
	}
	if (rc) {
		return rc;
	}
	rc = sr_state(c, &g);
	if (rc) {
		return rc;
	}
	/* Earlier episodes cannot count as this test's evidence. */
	c->cursor = g.head;
	rc = sr_phase(c, SR_QUIET);
	if (!rc) {
		rc = sr_set(c, VMM_MONITOR_EXIT_LIMIT, c->low);
	}
	if (!rc) {
		rc = sr_phase(c, SR_TRIGGER);
	}
	if (!rc) {
		rc = sr_phase(c, SR_HOLD);
	}
	if (!rc) {
		rc = sr_set(c, VMM_MONITOR_EXIT_LIMIT, SR_HIGH);
	}
	if (!rc) {
		rc = sr_phase(c, SR_RECOVER);
	}
	if (!rc) {
		rc = sr_set(c, VMM_MONITOR_EXIT_LIMIT, c->low);
	}
	if (!rc) {
		rc = sr_phase(c, SR_RETRIGGER);
	}
	return rc;
}

static int sr_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
	struct sr_context c = {0};
	int rc;
	int restore;

	(void)test;
	(void)cpu;
	c.out = out;
	c.phase = "begin";
	if (!vmm_mutex_trylock(&sr_lock)) {
		return sr_fail(&c, VMM_EBUSY, "another runtime storm test is running");
	}
	c.locked = TRUE;
	rc = sr_execute(&c);
	restore = sr_restore(&c);
	if (restore) {
		rc = restore;
	}
	if (!rc) {
		vmm_cprintf(out,
			    "monitor_storm_runtime PASS trigger/dedup/recovery/retrigger; "
			    "logs=manual\n");
	}
	if (c.locked) {
		vmm_mutex_unlock(&sr_lock);
	}
	return rc;
}

static struct wboxtest monitor_storm_runtime = {
	.name = "monitor_storm_runtime",
	.run = sr_run
};

static int __init monitor_storm_runtime_init(void)
{
	return wboxtest_register("monitor", &monitor_storm_runtime);
}

static void __exit monitor_storm_runtime_exit(void)
{
	wboxtest_unregister(&monitor_storm_runtime);
}

VMM_DECLARE_MODULE2(monitor_storm_runtime, "monitor_storm_runtime",
		    "Monitor maintainers", "GPL", WBOXTEST_IPRIORITY + 1,
		    monitor_storm_runtime_init, monitor_storm_runtime_exit);
