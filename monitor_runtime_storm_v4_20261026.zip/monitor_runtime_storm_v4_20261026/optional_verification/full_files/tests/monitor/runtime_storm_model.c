/* Included after the actual monitor, its platform model and runtime testcase.
 * Only this developer model supplies synthetic exits/time. Firmware testcase
 * storm_runtime.c must never call the record/sample/drain entry points. */
static struct wboxtest *runtime_case;
static const char *scenario;
static u64 next_tick;
static u32 low_ticks, old_sequence;
static unsigned dropped_once;
static bool changed_once;
int wboxtest_register(const char *group, struct wboxtest *t)
{
    assert(!strcmp(group,"monitor") && !runtime_case);
    runtime_case=t;return 0;
}
void wboxtest_unregister(struct wboxtest *t) { (void)t; }
void vmm_msleep(unsigned long ms)
{
    bool low, busy=FALSE;
    u32 n=2420;
    fake_time+=(u64)ms*1000000;
    if(fake_time<next_tick) return;
    next_tick=fake_time+VMM_MONITOR_NS;
    low=config.value[VMM_MONITOR_EXIT_LIMIT]<=500 && config.seq!=old_sequence;
    if(low) low_ticks++;
    if(!strcmp(scenario,"no_exits") || (!strcmp(scenario,"load_stops") && low)) n=0;
    if(!strcmp(scenario,"no_guest")) {
        for(u32 i=0;i<n;i++) vmm_monitor_exit(&v[2],1);
    } else {
        for(u32 i=0;i<n;i++) vmm_monitor_exit(&v[0],0x100);
        if(strcmp(scenario,"no_exits"))
            for(u32 i=0;i<124;i++) vmm_monitor_exit(&v[1],1);
    }
    if(!strcmp(scenario,"no_sampler")) return;
    if(!strcmp(scenario,"target_starved") && low) busy=TRUE;
    if(!strcmp(scenario,"target_skip_once") && low && low_ticks==3 && !dropped_once) {
        busy=TRUE;dropped_once++;
    }
    if(!strcmp(scenario,"invalid_windows") && low && low_ticks%2) busy=TRUE;
    if(!strcmp(scenario,"unrelated_skip")) slots[2].lock.held=1;
    if(busy) slots[0].lock.held=1;
    fake_irq_context=1;vmm_monitor_sample(fake_time);fake_irq_context=0;
    if(busy) slots[0].lock.held=0;
    if(!strcmp(scenario,"unrelated_skip")) slots[2].lock.held=0;
    if(low && low_ticks==2 && !changed_once) {
        changed_once=TRUE;
        if(!strcmp(scenario,"lost")) lost++;
        if(!strcmp(scenario,"errors")) arch_atomic_inc(&errors);
        if(!strcmp(scenario,"external_config")) assert(!vmm_monitor_configure(VMM_MONITOR_EXIT_LIMIT,333));
        if(!strcmp(scenario,"epoch")) {
            assert(!vmm_monitor_enable(FALSE));assert(!vmm_monitor_enable(TRUE));
        }
        if(!strcmp(scenario,"stop")) assert(!vmm_monitor_enable(FALSE));
    }
}
int main(int argc,char **argv)
{
    struct monitor_config original;
    int rc;
    bool expected_failure;
    scenario=argc>1?argv[1]:"normal";
    assert(!vmm_monitor_init());assert(!vmm_monitor_enable(TRUE));
    assert(!vmm_monitor_configure(VMM_MONITOR_SUSTAIN_S,7));
    if(!strcmp(scenario,"original_low")) {
        assert(!vmm_monitor_configure(VMM_MONITOR_EXIT_LIMIT,1));
        assert(!vmm_monitor_configure(VMM_MONITOR_SUSTAIN_S,1));
    }
    original=config;old_sequence=config.seq;
    if(strcmp(scenario,"no_guest")) {
        vmm_monitor_state(&v[0],VMM_VCPU_STATE_RESET,fake_time);
        vmm_monitor_state(&v[1],VMM_VCPU_STATE_RESET,fake_time);
    }
    if(!strcmp(scenario,"preactive")) slots[0].d.active=TRUE;
    if(!strcmp(scenario,"disabled")) assert(!vmm_monitor_enable(FALSE));
    next_tick=fake_time+VMM_MONITOR_NS;
    assert(!monitor_storm_runtime_init_host());assert(runtime_case);
    rc=runtime_case->run(runtime_case,NULL,0);
    expected_failure=strcmp(scenario,"normal") && strcmp(scenario,"preactive") &&
        strcmp(scenario,"original_low") && strcmp(scenario,"unrelated_skip") &&
        strcmp(scenario,"target_skip_once");
#ifdef MODEL_BAD_MONITOR
    expected_failure=TRUE;
#endif
    assert(!sr_lock.held);
    if(!strcmp(scenario,"external_config")) {
        assert(config.value[VMM_MONITOR_EXIT_LIMIT]==333);
        assert(strstr(output,"restore skipped"));
    } else assert(!memcmp(config.value,original.value,sizeof(original.value)));
    if(!strcmp(scenario,"stop") || !strcmp(scenario,"disabled")) assert(!arch_atomic_read(&enabled));
    else assert(arch_atomic_read(&enabled));
    if(!rc) {
        assert(strstr(output,"phase=dedup") && strstr(output,"phase=retrigger"));
        unsigned events=0;char *p=output;
        while((p=strstr(p,"monitor_storm_runtime EVENT"))) {events++;p++;}
        assert(events==2 && strstr(output,"restored"));
    }
    assert(!log_calls); /* Storage is deliberately outside automatic PASS. */
    puts(output);
    printf("MODEL %s rc=%d expected=%s restoration_checked=1\n",scenario,rc,expected_failure?"failure":"pass");
    return ((rc!=0)!=expected_failure)?1:0;
}
