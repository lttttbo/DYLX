/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_cmdmgr.h>
#include <vmm_stdio.h>
#include <libs/stringlib.h>
static void monitor_usage(struct vmm_chardev *cdev)
{
	vmm_cprintf(cdev, "monitor start|stop|status|events\n");
}
static int monitor_exec(struct vmm_chardev *cdev, int argc, char **argv)
{
	if (argc == 2) {
		if (!strcmp(argv[1], "start")) return vmm_monitor_enable(TRUE);
		if (!strcmp(argv[1], "stop")) return vmm_monitor_enable(FALSE);
		if (!strcmp(argv[1], "status")) return vmm_monitor_dump(cdev, FALSE);
		if (!strcmp(argv[1], "events")) return vmm_monitor_dump(cdev, TRUE);
	}
	monitor_usage(cdev);
	return VMM_EINVALID;
}
static struct vmm_cmd monitor_cmd;
/* Built-in bool command: register directly, without a loadable-module table. */
int __init vmm_monitor_cmd_init(void)
{
	strcpy(monitor_cmd.name, "monitor");
	strcpy(monitor_cmd.desc, "HV monitor");
	monitor_cmd.usage = monitor_usage;
	monitor_cmd.exec = monitor_exec;
	return vmm_cmdmgr_register_cmd(&monitor_cmd);
}
