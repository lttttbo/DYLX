/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
#include <vmm_shmem.h>
#include <vmm_guest_aspace.h>
#include <vmm_host_aspace.h>
#include <vmm_host_ram.h>
#include <vmm_heap.h>
#include <vmm_mutex.h>

#define TEST_HPA 0x100000ULL
#define TEST_GPA 0x200000ULL
static struct vmm_region region;
static struct vmm_shmem object;
static u8 backing[32];
static u32 accesses;
static bool short_map, failed_map, invalid_backend;

static struct vmm_region *find_region(struct vmm_guest *guest, physical_addr_t gpa,
				     u32 flags, bool aliases)
{
	(void)guest; (void)flags; (void)aliases;
	return gpa >= TEST_GPA && gpa < TEST_GPA+sizeof(backing) ? &region : NULL;
}
static int map_region(struct vmm_guest *guest, physical_addr_t gpa,
	physical_size_t len, physical_addr_t *hpa, physical_size_t *available, u32 *flags)
{
	(void)len;
	if (failed_map) return VMM_EFAIL;
	*hpa=TEST_HPA + gpa-TEST_GPA + (guest->id ? 0x1000 : 0);
	*available=short_map ? 1 : TEST_GPA+sizeof(backing)-gpa;
	*flags=region.flags;
	return VMM_OK;
}
static bool backend_range(physical_addr_t address, u32 len)
{
	if (address < TEST_HPA || !vmm_monitor_range_valid(sizeof(backing),address-TEST_HPA,len)) {
		invalid_backend=TRUE; return FALSE;
	}
	accesses++; return TRUE;
}
static u32 read_memory(physical_addr_t addr, void *buf, u32 len, bool cacheable)
{
	(void)cacheable;
	if (!backend_range(addr,len)) return 0;
	memcpy(buf,backing+(addr-TEST_HPA),len); return len;
}
static u32 write_memory(physical_addr_t addr, void *buf, u32 len, bool cacheable)
{
	(void)cacheable;
	if (!backend_range(addr,len)) return 0;
	memcpy(backing+(addr-TEST_HPA),buf,len); return len;
}
static u32 set_memory(physical_addr_t addr, u8 byte, u32 len, bool cacheable)
{
	(void)cacheable;
	if (!backend_range(addr,len)) return 0;
	memset(backing+(addr-TEST_HPA),byte,len); return len;
}

/* Include the actual shared-memory implementation, with a private registry and
 * private entry points. Only its access APIs are exercised. Never call this
 * copy's create/ref/dref/init functions; fixtures are static objects. */
#define vmm_shmem_guest_access wb_shmem_guest_access
#define vmm_shmem_read wb_shmem_read
#define vmm_shmem_write wb_shmem_write
#define vmm_shmem_set wb_shmem_set
#define vmm_shmem_iterate wb_shmem_iterate
#define vmm_shmem_count wb_shmem_count
#define vmm_shmem_find_byname wb_shmem_find_byname
#define vmm_shmem_ref wb_shmem_ref
#define vmm_shmem_dref wb_shmem_dref
#define vmm_shmem_create wb_shmem_create
#define vmm_shmem_init wb_shmem_init
void wb_shmem_ref(struct vmm_shmem *shm);
#define vmm_guest_find_region find_region
#define vmm_guest_physical_map map_region
#define vmm_host_memory_read read_memory
#define vmm_host_memory_write write_memory
#define vmm_host_memory_set set_memory
#undef vmm_monitor_mem_fault
#define vmm_monitor_mem_fault(v,k,a,d) mt_fault(v,k,a,d)
#include "../../../core/vmm_shmem.c"

static int memory_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	int rc=VMM_OK;
	u8 data[32], saved[32];
	u32 prior;
	struct mt_event e;
	(void)test; (void)cpu;
	mt_begin(); MT_CHECK(mt_enable(TRUE)==VMM_OK);
	memset(&object,0,sizeof(object)); object.addr=TEST_HPA; object.size=sizeof(backing);
	memset(&region,0,sizeof(region));
	region.flags=VMM_REGION_REAL|VMM_REGION_MEMORY|VMM_REGION_ISSHARED;
	memset(backing,0,sizeof(backing)); memset(data,0x5a,sizeof(data));
	accesses=0; short_map=failed_map=invalid_backend=FALSE;
	MT_CHECK(vmm_shmem_guest_write(mt_vcpu(0),&object,TEST_GPA+28,28,data,4,FALSE)==4);
	MT_CHECK(backing[28]==0x5a && accesses==1);
	memset(data,0,sizeof(data));
	MT_CHECK(vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA+28,28,data,4,FALSE)==4);
	MT_CHECK(data[0]==0x5a && accesses==2);
	mt_sample(mt_now()+VMM_MONITOR_NS); MT_CHECK(!mt_event(1,&e));
	memcpy(saved,backing,sizeof(saved)); prior=accesses;
	MT_CHECK(!vmm_shmem_guest_write(mt_vcpu(0),&object,TEST_GPA+31,31,data,2,FALSE));
	mt_sample(mt_now()+VMM_MONITOR_NS);
	MT_CHECK(mt_event(1,&e) && e.code==VMM_MONITOR_SHMEM_BOUNDS && e.address==TEST_GPA+31);
	MT_CHECK(!vmm_shmem_guest_write(mt_vcpu(1),&object,TEST_GPA+28,28,data,4,FALSE));
	mt_sample(mt_now()+VMM_MONITOR_NS);
	MT_CHECK(mt_event(2,&e) && e.code==VMM_MONITOR_ACCESS_DENIED && e.guest==1);
	region.flags|=VMM_REGION_READONLY;
	MT_CHECK(!vmm_shmem_guest_write(mt_vcpu(0),&object,TEST_GPA,0,data,4,FALSE));
	MT_CHECK(accesses==prior && !memcmp(saved,backing,sizeof(saved)));
	MT_CHECK(vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA,0,data,4,FALSE)==4);
	prior=accesses; region.flags|=VMM_REGION_ALIAS;
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA,0,data,4,FALSE));
	region.flags=VMM_REGION_REAL|VMM_REGION_MEMORY|VMM_REGION_ISSHARED;
	short_map=TRUE;
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA,0,data,4,FALSE));
	short_map=FALSE; failed_map=TRUE;
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA,0,data,4,FALSE));
	failed_map=FALSE;
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(0),&object,TEST_GPA+64,0,data,4,FALSE));
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(0),&object,~0ULL-1,0,data,4,FALSE));
	MT_CHECK(!vmm_shmem_guest_read(mt_vcpu(MT_HOST),&object,TEST_GPA,0,data,4,FALSE));
	MT_CHECK(!vmm_shmem_write(&object,~0ULL-1,data,4,FALSE));
	object.addr=~0ULL-1;
	MT_CHECK(!vmm_shmem_set(&object,1,0,4,FALSE));
	object.addr=TEST_HPA;
	MT_CHECK(accesses==prior && !invalid_backend && !memcmp(saved,backing,sizeof(saved)));
	mt_sample(mt_now()+VMM_MONITOR_NS);
	MT_CHECK(mt_event(3,&e) && e.type==3 && e.value>=5); /* aggregated Guest failures */
	MT_CHECK(vmm_monitor_range_valid(32,32,0));
	MT_CHECK(!vmm_monitor_range_valid(32,33,0));
	MT_CHECK(!vmm_monitor_range_valid(32,31,2));
	MT_CHECK(!mt_overflow());
out:
	mt_end(); return rc;
}
MT_REGISTER(monitor_memory, memory_run);
