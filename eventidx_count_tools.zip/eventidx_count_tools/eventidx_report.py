#!/usr/bin/env python3
"""Offline analysis of eventidx_count.sh captures. Python >=3.8, standard library only.
No directory from one OS is time-aligned to another OS. Never equate Guest IRQs,
vhost signals, EVENT_IDX false decisions, physical eth0 IRQs and Function-call IPIs.
"""
import argparse
import csv
import json
import re
import sys
from decimal import Decimal
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

VERSION = "1.0"

def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace") if p.is_file() else ""

def envfile(p: Path) -> Dict[str, str]:
    return dict(line.split("=", 1) for line in read_text(p).splitlines()
                if "=" in line and not line.startswith("#"))

def ns(p: Path) -> int:
    s = read_text(p).strip()
    if not s:
        raise ValueError("Missing timestamp: " + str(p))
    return int(Decimal(s) * Decimal(10**9))

def window(d: Path, counter: str) -> Dict[str, float]:
    b0, b1, a0, a1 = [ns(d / f"{side}.{counter}.{edge}")
                       for side, edge in (("before", "begin"), ("before", "end"),
                                          ("after", "begin"), ("after", "end"))]
    if not (b0 <= b1 < a0 <= a1):
        raise ValueError(f"Invalid {counter} timestamps; stopped/reversed clock or malformed capture")
    return {"start_s": (b0+b1)/2e9, "end_s": (a0+a1)/2e9,
            "seconds": ((a0+a1)-(b0+b1))/2e9,
            "max_read_span_s": max(b1-b0, a1-a0)/1e9}

def parse_net(s: str) -> Dict[str, List[int]]:
    out = {}
    for line in s.splitlines():
        if ":" not in line:
            continue
        key, values = line.rsplit(":", 1)
        v = values.split()
        if len(v) >= 16 and all(x.isdecimal() for x in v[:16]):
            out[key.strip()] = [int(x) for x in v[:16]]
    return out

def parse_interrupts(s: str) -> Tuple[List[str], Dict[str, Any]]:
    cpus, out = [], {}
    for line in s.splitlines():
        if not cpus:
            cpus = re.findall(r"\bCPU\d+\b", line)
            if cpus:
                continue
        if ":" not in line or not cpus:
            continue
        key, values = line.split(":", 1)
        v = values.split()
        if len(v) < len(cpus) or not all(x.isdecimal() for x in v[:len(cpus)]):
            continue
        out[key.strip()] = {"counts": [int(x) for x in v[:len(cpus)]],
                            "desc": " ".join(v[len(cpus):])}
    if not cpus:
        raise ValueError("/proc/interrupts has no readable CPU header")
    return cpus, out

def subtract(a: List[int], b: List[int], name: str) -> List[int]:
    if len(a) != len(b):
        raise ValueError(f"{name}: counter layout changed")
    v = [x-y for x, y in zip(a, b)]
    if any(x < 0 for x in v):
        raise ValueError(f"{name}: counter reset/wrap; refusing subtraction")
    return v

def feature(s: str) -> Optional[int]:
    s = s.strip()
    # Linux virtio features_show prints bit 0 FIRST, not a big-endian binary number.
    return int(s[29]) if len(s) > 29 and re.fullmatch(r"[01]+", s) else None

def thread_rows(p: Path) -> Dict[int, Dict[str, str]]:
    out = {}
    for line in read_text(p).splitlines():
        v = line.split("\t")
        if len(v) == 4 and v[0].isdigit():
            out[int(v[0])] = dict(zip(("comm", "starttime", "affinity"), v[1:]))
    return out

def kernel_config(s: str, hint: str = "") -> Dict[str, Any]:
    """Reconstruct active vhost-net queue bindings, excluding explicit unbinds.
    Associate IOEM_CFG only when the last such registration matches the bind FD,
    within 1s if timestamps are available. Return unknown rather than guessing.
    """
    devs: Dict[str, Any] = {}
    active_io: Dict[Tuple[str, str], Any] = {}
    last_io = None
    for line in s.splitlines():
        kv = dict(re.findall(r"([A-Za-z_][A-Za-z_0-9]*)=([^\s]+)", line))
        tm = re.search(r"\[\s*([0-9]+\.[0-9]+)\]", line)
        ts = float(tm.group(1)) if tm else None
        if "IOEM_CFG " in line:
            k = (kv.get("vmid", "?"), kv.get("addr", "?"))
            if kv.get("action") == "assign":
                active_io[k] = kv
            elif kv.get("action") == "deassign":
                active_io.pop(k, None)
            last_io = (kv, ts)
        elif "VQMAP " in line and "dev" in kv and "q" in kv:
            dev = devs.setdefault(kv["dev"], {})
            q = kv["q"]
            if "VQMAP unbind" in line:
                if q in dev:
                    dev[q]["active"] = False
            elif "VQMAP bind" in line:
                v = dict(kv, active=True)
                if last_io:
                    io, its = last_io
                    recent = ts is None or its is None or 0 <= ts-its <= 1.0
                    if io.get("action") == "assign" and io.get("fd") == kv.get("kickfd") and recent:
                        v["io_key"] = (io.get("vmid", "?"), io.get("addr", "?"))
                        v["io_at_bind"] = dict(io)
                dev[q] = v
        elif "VQCFG " in line and "dev" in kv and "q" in kv:
            qv = devs.setdefault(kv["dev"], {}).setdefault(kv["q"], {"active": False})
            qv["cfg"] = kv
    candidates = []
    for dev_id, queues in devs.items():
        for q, v in queues.items():
            if not v.get("active") or v.get("kick_fn") != "handle_tx_kick":
                continue
            if hint and v.get("worker") != hint:
                continue
            candidates.append((dev_id, queues, q, v))
    if len(candidates) != 1:
        return {"verified": False, "reason": "No unique active vhost-net TX binding in captured logs",
                "candidate_count": len(candidates)}
    dev_id, qs, txq, v = candidates[0]
    cfg = v.get("cfg", {})
    io = active_io.get(v.get("io_key", ()), {})
    route = io.get("route") if io.get("fd") == v.get("kickfd") else None
    def num(k: str):
        try:
            return int(cfg[k], 0)
        except (KeyError, ValueError):
            return None
    return {"verified": route in ("client", "asyncio") and num("event_idx") is not None,
            "dev": dev_id, "worker": v.get("worker"), "tgid": v.get("tgid"),
            "route": route, "tx_addr": io.get("addr"), "tx_kickfd": v.get("kickfd"),
            "event_idx": num("event_idx"), "busyloop_us": num("busyloop_us"),
            "packed": num("packed"), "ring_size": num("size"),
            "active_queues": [{"q": q, "kickfd": x.get("kickfd"),
                               "kick_fn": x.get("kick_fn"), "cfg": x.get("cfg", {})}
                              for q, x in qs.items() if x.get("active")]}

def irq_kind(desc: str, role: str) -> str:
    if role == "server":
        return "physical"
    d = desc.lower()
    if "output." in d:
        return "tx"
    if "input." in d:
        return "rx"
    if "config" in d:
        return "config"
    return "shared_or_unknown"

def parse_ethtool(s: str) -> Dict[str, int]:
    out = {}
    for line in s.splitlines():
        m = re.fullmatch(r"\s*((?:tx|rx)_queue_[0-9]+_kicks):\s*([0-9]+)\s*", line)
        if m:
            out[m.group(1)] = int(m.group(2))
    return out

def parse_cpu(s: str) -> Dict[str, List[int]]:
    return {v[0]: [int(x) for x in v[1:9]] for v in (l.split() for l in s.splitlines())
            if v and re.fullmatch(r"cpu\d*", v[0]) and len(v) >= 9}

def summarize(d: Path) -> Dict[str, Any]:
    if not d.is_dir():
        raise ValueError("Not a capture directory: " + str(d))
    m, st = envfile(d / "meta.env"), envfile(d / "status.env")
    if st.get("status") != "OK":
        raise ValueError(f"{d}: capture status {st}; no valid measurement")
    role = m.get("role")
    if role not in ("server", "android"):
        raise ValueError("Missing/invalid role")
    expected = {"off": 0, "on": 1}.get(m.get("state_declared", ""))
    if expected is None:
        raise ValueError("Missing/invalid off/on state")
    errors: List[str] = []
    warnings: List[str] = []
    nw, iw, cw = (window(d, k) for k in ("netdev", "interrupts", "stat"))
    if nw["seconds"] < 10:
        warnings.append("Measurement shorter than 10 seconds; use at least 30s for the real test")
    skew = max(abs(iw["start_s"]-nw["start_s"]), abs(iw["end_s"]-nw["end_s"])) + max(nw["max_read_span_s"], iw["max_read_span_s"])
    if skew > max(0.1, 0.01*nw["seconds"]):
        warnings.append("Interrupt/network snapshot boundaries differ appreciably")
    before, after = (parse_net(read_text(d / f"{s}.netdev")) for s in ("before", "after"))
    name = m["net_if"]
    if name not in before or name not in after:
        raise ValueError("Selected interface missing at a measurement endpoint")
    dv = subtract(after[name], before[name], name)
    main_idx = 9 if m["direction"] == "up" else 1
    main_pkts = dv[main_idx]
    if main_pkts <= 0:
        raise ValueError("No traffic in selected direction")
    pps = main_pkts/nw["seconds"]
    net = {"seconds": nw["seconds"], "main_packets": main_pkts, "main_pps": pps,
           "payload_mbps_est": pps*int(m["payload_bytes"])*8/1e6,
           "tx_packets": dv[9], "rx_packets": dv[1], "tx_bytes": dv[8], "rx_bytes": dv[0],
           "tx_errors": dv[10], "rx_errors": dv[2], "tx_dropped": dv[11], "rx_dropped": dv[3],
           "tx_interface_mbps": dv[8]*8/nw["seconds"]/1e6,
           "rx_interface_mbps": dv[0]*8/nw["seconds"]/1e6}
    if any(net[x] for x in ("tx_errors", "rx_errors", "tx_dropped", "rx_dropped")):
        warnings.append("Interface error/drop counters increased; inspect peer iperf loss as well")
    if pps < 5000:
        warnings.append("Low main traffic; background activity may dominate")
    if min(dv[1], dv[9]) > 0.1*max(dv[1], dv[9]):
        warnings.append("Significant reverse traffic: not a clean unidirectional UDP test")
    tap = m.get("tap_if", "tap1")
    if role == "server" and tap in before and tap in after:
        td = subtract(after[tap], before[tap], tap)
        mirror = td[1] if m["direction"] == "up" else td[9]
        net["tap_matching_packets"] = mirror
        if abs(mirror-main_pkts) > max(100, main_pkts*0.02):
            warnings.append("TAP/eth0 packet mismatch >2%; possible other traffic or drops")
    cp0, int0 = parse_interrupts(read_text(d / "before.interrupts"))
    cp1, int1 = parse_interrupts(read_text(d / "after.interrupts"))
    if cp0 != cp1:
        raise ValueError("CPU layout changed during capture")
    irq_rows, ipi_rows = [], []
    selected = m.get("irq_ids", "").split()
    if not selected:
        raise ValueError("No selected NIC IRQ IDs")
    def mkrow(k: str) -> Dict[str, Any]:
        if k not in int0 or k not in int1:
            raise ValueError(f"IRQ/IPI {k} disappeared during capture")
        if int0[k]["desc"] != int1[k]["desc"]:
            raise ValueError(f"IRQ/IPI {k} identity changed during capture")
        dd = subtract(int1[k]["counts"], int0[k]["counts"], "IRQ "+k)
        count = sum(dd)
        return {"id": k, "description": int1[k]["desc"], "delta": count,
                "per_cpu": dict(zip(cp0, dd)), "per_second": count/iw["seconds"],
                "per_10k_main_packets": (count/iw["seconds"])/pps*10000}
    for k in selected:
        row = mkrow(k)
        row["kind"] = irq_kind(row["description"], role)
        if "," in row["description"]:
            warnings.append("Selected IRQ may contain shared handlers; inspect IRQ description")
        irq_rows.append(row)
    for k in int0:
        if re.fullmatch(r"IPI\d+", k):
            ipi_rows.append(mkrow(k))
    def total(rows: List[Dict[str, Any]]) -> Optional[Dict[str, float]]:
        if not rows:
            return None
        return {k: sum(x[k] for x in rows) for k in ("delta", "per_second", "per_10k_main_packets")}
    kinds = ("physical",) if role == "server" else ("tx", "rx", "config", "shared_or_unknown")
    irq = {k: total([x for x in irq_rows if x["kind"] == k]) for k in kinds}
    irq["all_selected"] = total(irq_rows)
    call_ipi = total([x for x in ipi_rows if "function call" in x["description"].lower()])
    if call_ipi is None:
        warnings.append("No Function call IPI row; value is unavailable, NOT zero")
    if role == "android" and irq.get("tx") is None:
        warnings.append("No separate virtio TX vector name; only combined/shared NIC IRQ is measurable")
    c0, c1 = (parse_cpu(read_text(d / f"{s}.stat")) for s in ("before", "after"))
    cpu = {}
    for k in c0:
        if k not in c1:
            raise ValueError("CPU stat layout changed")
        dd = subtract(c1[k], c0[k], k)
        tt = sum(dd)
        if tt:
            cpu[k] = {"busy_percent": (tt-dd[3]-dd[4]-dd[7])/tt*100,
                      "irq_percent": dd[5]/tt*100, "softirq_percent": dd[6]/tt*100,
                      "steal_percent": dd[7]/tt*100}
    ctx0, ctx1 = (envfile(d / f"context.{s}.env") for s in ("before", "after"))
    for k in ("boot_id", "device", "ifindex", "online", "mac"):
        if ctx0.get(k) != ctx1.get(k):
            errors.append("Context identity/layout changed: "+k)
    for k, v in ctx0.items():
        if k.startswith("irq_") and ctx1.get(k) != v:
            errors.append("IRQ affinity changed: "+k)
    threads0, threads1 = (thread_rows(d / f"threads.{s}.tsv") for s in ("before", "after"))
    if role == "server":
        for tid, t in threads0.items():
            if t["comm"].startswith(("vhost-", "VM")):
                if threads1.get(tid) != t:
                    errors.append(f"Relevant thread identity/affinity changed: {tid} {t['comm']}")
    if role == "android":
        f0, f1 = (feature(read_text(d / f"features.{s}")) for s in ("before", "after"))
        config = {"event_idx": f0, "feature_before": read_text(d / "features.before").strip(),
                  "feature_after": read_text(d / "features.after").strip(),
                  "virtio": m.get("virtio")}
        if f0 is None or f1 is None:
            warnings.append("Cannot read negotiated virtio features; confirm EVENT_IDX using initialization logs")
        elif f0 != f1 or f0 != expected:
            errors.append("Guest EVENT_IDX state mismatch/changed")
        iperfs = {tid:t for tid,t in threads1.items() if t["comm"] == "iperf3"}
        config["iperf_threads_after"] = iperfs
    else:
        configs = [kernel_config(read_text(d / f"kernel_map.{s}.txt"), m.get("vhost_tid_hint", ""))
                   for s in ("before", "after")]
        config = configs[0]
        if not all(c.get("verified") for c in configs):
            warnings.append("Server route/EVENT_IDX not fully verified from active VQMAP/VQCFG; initialization logs needed")
        else:
            for c in configs:
                if c["event_idx"] != expected:
                    errors.append("Kernel VQCFG EVENT_IDX does not match off/on label")
                if c["route"] != m["route_declared"]:
                    errors.append("Network IOEM route does not match declared client/asyncio")
            for k in ("dev", "worker", "tgid", "tx_addr", "route", "event_idx", "busyloop_us", "ring_size", "packed"):
                if configs[0].get(k) != configs[1].get(k):
                    errors.append("vhost queue/config changed during capture: "+k)
            worker = int(config["worker"])
            config["worker_before"] = threads0.get(worker)
            config["worker_after"] = threads1.get(worker)
            if not config["worker_before"] or config["worker_before"] != config["worker_after"]:
                errors.append("vhost worker in log not confirmed alive/unchanged in /proc snapshots")
        config["after"] = configs[1]
    kicks: Dict[str, Any] = {"tx": None, "rx": None}
    if role == "android":
        rc0, rc1 = (read_text(d / f"{side}.ethtool.rc").strip() for side in ("before", "after"))
        ks0, ks1 = (parse_ethtool(read_text(d / f"{side}.ethtool")) for side in ("before", "after"))
        if rc0 == "0" and rc1 == "0" and ks0 and ks1:
            kw = window(d, "ethtool")
            kicks["window"] = kw
            for way in ("tx", "rx"):
                keys0 = {k for k in ks0 if k.startswith(way + "_")}
                keys1 = {k for k in ks1 if k.startswith(way + "_")}
                if keys0 != keys1:
                    errors.append("Virtio ethtool kick counter layout changed: " + way)
                    continue
                if keys0:
                    dd = subtract([ks1[k] for k in sorted(keys0)], [ks0[k] for k in sorted(keys0)], way + " kicks")
                    val = sum(dd)
                    kicks[way] = {"delta": val, "per_second": val/kw["seconds"],
                                  "per_10k_main_packets": val/kw["seconds"]/pps*10000,
                                  "per_queue_delta": dict(zip(sorted(keys0), dd))}
            kskew = max(abs(kw["start_s"]-nw["start_s"]), abs(kw["end_s"]-nw["end_s"])) + kw["max_read_span_s"]
            if kskew > max(0.1, 0.01*nw["seconds"]):
                warnings.append("Ethtool/network snapshot skew appreciable; inspect ioctl duration")
        if kicks["tx"] is None:
            warnings.append("Guest TX kick counter unavailable: missing ethtool/helper/driver field; not inferred from IPI")
    if m.get("irq_method") == "manual":
        warnings.append("IRQ identity selected manually; verify irq_selection.txt belongs only to the tested NIC")
    return {"tool_version": VERSION, "directory": str(d.resolve()), "meta": m,
            "status": "ERROR" if errors else ("REVIEW" if warnings else "OK"),
            "errors": sorted(set(errors)), "warnings": sorted(set(warnings)),
            "net": net, "irq": irq, "irq_rows": irq_rows, "ipi_rows": ipi_rows,
            "function_call_ipi": call_ipi, "kicks": kicks, "cpu": cpu, "configuration": config,
            "network_window": nw, "interrupt_window": iw, "cpu_window": cw,
            "boundary_skew_s": skew, "context": ctx0, "threads_before": threads0,
            "not_measured": ([] if kicks.get("tx") is not None else ["guest_to_backend_kick_count"]) + ["vhost_notify_false_count",
                             "vhost_eventfd_signal_count", "hypervisor_physical_IPI_count",
                             "PC_receiver_bitrate_and_loss"]}

def fmt(v: Any, digits: int = 3) -> str:
    return "N/A" if v is None else f"{v:.{digits}f}"

def reduction(a: Optional[float], b: Optional[float]) -> Optional[float]:
    return None if a is None or b is None or a == 0 else (a-b)/a*100

def metric(s: Dict[str, Any], group: str, k: str) -> Optional[float]:
    if group == "function_call_ipi":
        v = s.get(group)
    elif group.startswith("kick_"):
        v = s.get("kicks", {}).get(group[5:])
    else:
        v = s["irq"].get(group)
    return None if v is None else v.get(k)

def compare(paths: Dict[str, Path], out: Path) -> None:
    results = {k:summarize(p) for k,p in paths.items()}
    issues, findings = [], []
    for k,s in results.items():
        wanted_role, wanted_state = k.split("_")
        if s["meta"]["role"] != wanted_role or s["meta"]["state_declared"] != wanted_state:
            issues.append(k+": role/state label does not match argument")
        issues += [k+": "+e for e in s["errors"]]
    for role in ("server", "android"):
        a,b = (results[role+"_"+x] for x in ("off","on"))
        for k in ("net_if", "direction", "payload_bytes", "route_declared", "kernel"):
            if a["meta"].get(k) != b["meta"].get(k):
                issues.append(f"{role}: OFF/ON differ in {k}")
        ratio = b["net"]["main_pps"]/a["net"]["main_pps"]
        if abs(ratio-1) > 0.05:
            issues.append(f"{role}: offered/achieved PPS differs >5%; normalize counts and repeat at a common lower load")
        aa = sorted(v for k,v in a["context"].items() if k.startswith("irq_") and k.endswith("effective_affinity_list"))
        bb = sorted(v for k,v in b["context"].items() if k.startswith("irq_") and k.endswith("effective_affinity_list"))
        if aa != bb:
            issues.append(f"{role}: OFF/ON IRQ affinity layout differs")
    a,b = results["server_off"],results["server_on"]
    for k in ("route", "busyloop_us", "packed", "ring_size"):
        if a["configuration"].get(k) != b["configuration"].get(k):
            issues.append("server: OFF/ON active vhost config differs in "+k)
    wa,wb = (s["configuration"].get("worker_before") for s in (a,b))
    if wa and wb and wa.get("affinity") != wb.get("affinity"):
        issues.append("server: OFF/ON vhost affinity differs")
    def ioe_affinities(s):
        return sorted((t["comm"], t["affinity"]) for t in s["threads_before"].values()
                      if t["comm"].startswith("VM") and "-ioeventfd-" in t["comm"])
    if ioe_affinities(a) != ioe_affinities(b):
        issues.append("server: OFF/ON ioeventfd affinity layout differs")
    # Ensure paired captures claim the same route, direction and payload.
    for state in ("off", "on"):
        s,g = results["server_"+state],results["android_"+state]
        for k in ("route_declared", "direction", "payload_bytes"):
            if s["meta"].get(k) != g["meta"].get(k):
                issues.append(state+": Android/Server declarations differ in "+k)
    lines = ["# EVENT_IDX 开／关对照结果", "", "## 采集与配置", "",
             "| 项目 | Server OFF | Server ON | Android OFF | Android ON |",
             "|---|---:|---:|---:|---:|"]
    order = ["server_off","server_on","android_off","android_on"]
    for label,func in [
        ("质量标记", lambda s:s["status"]),
        ("实际EVENT_IDX", lambda s:str(s["configuration"].get("event_idx", "unknown"))),
        ("声明通知路由", lambda s:s["meta"]["route_declared"]),
        ("实测秒数", lambda s:fmt(s["net"]["seconds"])),
        ("主方向PPS", lambda s:fmt(s["net"]["main_pps"])),
        ("固定UDP长度折算Mbps（非接收端结果）", lambda s:fmt(s["net"]["payload_mbps_est"])),
        ("CPU busy %（本OS全核平均，含其他业务）", lambda s:fmt(s["cpu"].get("cpu",{}).get("busy_percent"))),
    ]:
        lines.append("| "+label+" | "+" | ".join(func(results[k]) for k in order)+" |")
    lines += ["", "## 按相同报文数归一化", "",
              "减少率=(OFF每万包次数−ON每万包次数)/OFF每万包次数×100%。",
              "负值表示增加；OFF为0时不计算百分比；N/A不表示0。", "",
              "| 指标 | OFF 次/秒 | ON 次/秒 | OFF 次/万包 | ON 次/万包 | 每万包减少率 |",
              "|---|---:|---:|---:|---:|---:|"]
    rows = []
    for label,role,kind in [
        ("Android TX kick（驱动计数）", "android", "kick_tx"),
        ("Android RX补充kick（驱动计数）", "android", "kick_rx"),
        ("Android virtio TX虚拟IRQ", "android","tx"),
        ("Android virtio RX虚拟IRQ", "android","rx"),
        ("Android virtio配置IRQ", "android","config"),
        ("Android共享/未分类网卡IRQ", "android","shared_or_unknown"),
        ("Android所选网卡IRQ合计", "android","all_selected"),
        ("ServerVM Function-call IPI（间接指标）", "server","function_call_ipi"),
        ("ServerVM eth0 IRQ（辅助指标）", "server","all_selected"),
    ]:
        a,b = results[role+"_off"],results[role+"_on"]
        vals = [metric(a,kind,"per_second"),metric(b,kind,"per_second"),
                metric(a,kind,"per_10k_main_packets"),metric(b,kind,"per_10k_main_packets")]
        red = reduction(vals[2], vals[3])
        rows.append({"name":label,"role":role,"kind":kind,"off_per_s":vals[0],"on_per_s":vals[1],
                     "off_per_10k":vals[2],"on_per_10k":vals[3],"reduction_percent":red})
        lines.append("| "+label+" | "+" | ".join(fmt(v) for v in vals)+" | "+fmt(red)+"% |")
    lines += ["", "## IRQ身份与通知路由", ""]
    for k in order:
        s=results[k]
        lines += ["### "+k, "", "```text",
                  f"interface={s['meta']['net_if']} irq_method={s['meta'].get('irq_method')}",
                  f"route_observed={s['configuration'].get('route','N/A')} event_idx={s['configuration'].get('event_idx','N/A')}"]
        for row in s["irq_rows"]:
            lines.append(f"IRQ {row['id']} kind={row['kind']} delta={row['delta']} {row['description']}")
        for e in s["errors"]:
            lines.append("ERROR: "+e)
        for w in s["warnings"]:
            lines.append("REVIEW: "+w)
        lines += ["```", ""]
    lines += ["## 对照有效性检查", ""]
    if issues:
        lines += ["**存在以下可比性问题，不能直接给出EVENT_IDX独立收益结论：**", ""]
        lines += ["- "+x for x in sorted(set(issues))]
    else:
        lines += ["已采字段未发现标签、路由、主要亲和性或PPS的明显不一致。仍需核对相同iperf参数、PC接收带宽/丢包，以及业务负载和CPU频率。"]
    lines += ["", "## 结果边界", "",
              "1. Android统计的是实际到达Guest的虚拟网卡IRQ入口；不是ServerVM物理eth0 IRQ。独立TX/RX向量不可识别时，只能比较合计或共享IRQ。",
              "2. ServerVM的Function-call IPI是系统级间接指标，不能冒充Guest kick数。",
              "3. 若Android驱动提供ethtool的tx/rx_queue_N_kicks，本工具直接比较驱动记录的成功通知计数；没有接口时标N/A。不是根据IPI猜测kick数。仍不统计vring_need_event返回false次数或vhost eventfd signal次数。",
              "4. OFF和ON都可能已有其他通知抑制、NAPI和中断合并机制。因此观察到的差异是这组条件下的实际效果，不是EVENT_IDX的理论抑制百分比。",
              "5. TX kick/万包下降可直接支持本轮Guest→后端通知变少，IPI同向下降则进一步支持原跨核交接负担减轻；只有Android虚拟IRQ下降，则收益主要显示在完成通知侧，不能代替kick计数。IPI仍需排除CPU/其他负载变化。",
              "6. 单次无明显差异不代表未开启，也不代表所有流量模式都无效。建议相同负载各重复2～3次。",
              "7. 两OS独立开始稳定窗口，不把跨系统时间戳相减。metadata上下文不作为计数时间边界。",
              "", "## 反馈", "", "提供本文件（feedback.txt）和OFF/ON两次PC iperf日志即可。若有ERROR/REVIEW涉及配置或IRQ匹配，再附对应目录的irq_selection.txt和初始化网络日志。"]
    out.mkdir(parents=True, exist_ok=True)
    text="\n".join(lines)+"\n"
    (out/"feedback.txt").write_text(text,encoding="utf-8")
    (out/"comparison.md").write_text(text,encoding="utf-8")
    (out/"comparison.json").write_text(json.dumps({"results":results,"rows":rows,"comparison_issues":issues},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(text)
    print("OUTPUT_DIR="+str(out.resolve()))

def main() -> None:
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="cmd",required=True)
    one=sub.add_parser("summarize");one.add_argument("directory",type=Path)
    c=sub.add_parser("compare")
    for role in ("server","android"):
        for state in ("off","on"):
            c.add_argument("--"+role+"-"+state,type=Path,required=True)
    c.add_argument("--out",type=Path,default=Path("eventidx_result"))
    args=p.parse_args()
    try:
        if args.cmd=="summarize":
            print(json.dumps(summarize(args.directory),ensure_ascii=False,indent=2))
        else:
            compare({role+"_"+state:getattr(args,role+"_"+state) for role in ("server","android") for state in ("off","on")},args.out)
    except (ValueError, OSError, KeyError, ArithmeticError) as e:
        print("ERROR: "+str(e),file=sys.stderr);sys.exit(2)

if __name__=="__main__":
    main()
