/* Host fault-injection tests compile the production implementation unchanged.
 * Inclusion permits inspecting fixed queues and forcing a contended slot. */
#include "host.h"
#include <vmm_monitor.h>
#include "../../core/monitor/monitor_agent.c"

u64 fake_time = 100 * VMM_MONITOR_NS;
u32 fake_cpu;
int fail_next_trylock, fake_irq_context;
static struct vmm_cmd *cmd;
static struct vmm_guest guests[2] = {{0},{1}};
static struct vmm_vcpu v[4] = {{0,0,TRUE,&guests[0]}, {1,1,TRUE,&guests[1]},
    {2,2,FALSE,&guests[0]}, {3,3,TRUE,&guests[1]}};
static char output[65536]; static size_t used;
int vmm_cprintf(struct vmm_chardev *c, const char *fmt, ...) {
    int n; va_list ap; (void)c; assert(!fake_irq_context);
    va_start(ap,fmt); n=vsnprintf(output+used,sizeof(output)-used,fmt,ap); va_end(ap);
    assert(n>=0 && used+(size_t)n<sizeof(output)); used+=n; return n;
}
int vmm_cmdmgr_register_cmd(struct vmm_cmd *p) { cmd=p; return 0; }
static int command(const char *s) { char *args[]={(char *)"monitor",(char *)s}; return cmd->exec(NULL,2,args); }
static void begin(void) {
    assert(!vmm_monitor_enable(FALSE)); fake_time+=VMM_MONITOR_NS;
    assert(!vmm_monitor_enable(TRUE)); vmm_monitor_state(&v[0],VMM_VCPU_STATE_RESET,fake_time);
}
static void period(u64 dt, unsigned n) {
    unsigned i; for(i=0;i<n;i++) vmm_monitor_exit(&v[0],1);
    fake_time+=dt; fake_irq_context=1; vmm_monitor_sample(fake_time); fake_irq_context=0;
}
static void test_timing(void) {
    begin();
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=2000; vmm_monitor_state(&v[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=3000; vmm_monitor_selected(&v[0],fake_time);
    vmm_monitor_dispatch(&v[0],fake_time-1000,fake_time+1000);
    assert(slots[0].d.ready.count==1 && slots[0].d.ready.max==5000);
    assert(slots[0].d.dispatch.count==1 && slots[0].d.dispatch.max==2000);
    vmm_monitor_selected(&v[0],fake_time); assert(slots[0].d.ready.count==1);
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_READY,fake_time);
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_PAUSED,fake_time+10);
    vmm_monitor_selected(&v[0],fake_time+20); assert(slots[0].d.ready.count==1);
    vmm_monitor_dispatch(&v[0],20,10); assert(slots[0].d.dispatch.count==1);
    period(VMM_MONITOR_NS,7); assert(slots[0].d.valid && slots[0].d.count==7);
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_READY,fake_time); fake_time+=40;
    assert(!command("status"));
    assert(strstr(output,"\"ready\":[1,5000,5000]") && strstr(output,"\"dispatch\":[1,2000,2000]"));
    assert(strstr(output,"\"ready_age_ns\":40"));
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_UNKNOWN,fake_time); assert(!slots[0].d.present);
    vmm_monitor_exit(&v[2],1); assert(!slots[2].d.present);
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_RESET,fake_time); assert(!slots[0].d.ready.count);
    puts("PASS: READY boundaries, cancellation, separate dispatch, live ready age, lifecycle, orphan exclusion");
}
static void test_storm(void) {
    u64 n; unsigned i;
    begin(); n=head;
    for(i=0;i<6;i++) period(VMM_MONITOR_NS,50000); assert(head==n);
    for(i=0;i<4;i++) period(VMM_MONITOR_NS,50001); assert(head==n);
    period(VMM_MONITOR_NS,50001); assert(head==n+1 && ring[(head-1)%16].type==1);
    assert(ring[(head-1)%16].time==fake_time && ring[(head-1)%16].value==50001);
    period(VMM_MONITOR_NS,60000); assert(head==n+1);
    period(VMM_MONITOR_NS,0);
    for(i=0;i<5;i++) period(VMM_MONITOR_NS,50001); assert(head==n+2);
    begin(); n=head;
    for(i=0;i<6;i++) period(800000000,40001); assert(head==n);
    period(800000000,40001); assert(head==n+1); /* >=5 windows AND >=5 real seconds */
    begin(); n=head;
    for(i=0;i<4;i++) period(VMM_MONITOR_NS,50001);
    period(2*VMM_MONITOR_NS,100001); assert(!slots[0].d.valid && head==n);
    for(i=0;i<4;i++) period(VMM_MONITOR_NS,50001); assert(head==n);
    period(VMM_MONITOR_NS,50001); assert(head==n+1);
    begin(); n=head; fail_next_trylock=1;
    period(VMM_MONITOR_NS,50001); assert(arch_atomic_read(&skipped));
    period(VMM_MONITOR_NS,50001); assert(!slots[0].d.valid && head==n);
    puts("PASS: strict rate boundary, five-second duration, duplicate suppression, retrigger, delayed/missed windows");
}
static void test_memory_and_switches(void) {
    struct event e; u64 n,t,old_epoch; unsigned i;
    begin(); n=head; t=fake_time;
    vmm_monitor_mem_fault(&v[1],VMM_MONITOR_MAP_REJECT,0x1000,7);
    fake_time+=50; vmm_monitor_mem_fault(&v[1],VMM_MONITOR_ACCESS_DENIED,0x2000,1);
    assert(head==n); period(VMM_MONITOR_NS,0); assert(event_get(n+1,&e));
    assert(e.type==3 && e.guest==1 && e.vcpu==1 && e.value==2 && e.time==t && e.last==t+50);
    assert(e.code==3 && e.address==0x2000 && e.detail==1);
    vmm_monitor_mem_fault(&v[0],VMM_MONITOR_PERMISSION,0x3000,0x400);
    n=head; assert(!command("stop")); period(VMM_MONITOR_NS,100);
    assert(head==n+1 && slots[0].d.exits==0); /* stop drains faults, rejects new counters */
    n=head; vmm_monitor_mem_fault(&v[0],1,1,1); period(VMM_MONITOR_NS,0); assert(head==n);
    assert(!command("start")); old_epoch=epoch; assert(!command("start") && epoch==old_epoch);
    vmm_monitor_mem_fault(&v[0],1,10,1); n=head;
    vmm_monitor_state(&v[0],VMM_VCPU_STATE_UNKNOWN,fake_time); assert(head==n+1);
    assert(!slots[0].d.present);
    vmm_monitor_mem_fault(&v[0],1,20,1); old_epoch=epoch; n=head;
    command("stop"); command("start"); vmm_monitor_exit(&v[0],1);
    assert(head==n+1 && event_get(head,&e) && e.epoch==old_epoch);
    assert(slots[0].d.epoch==epoch && slots[0].d.ready.count==0);
    vmm_monitor_mem_fault(NULL,VMM_MONITOR_SHMEM_BOUNDS,99,2); period(VMM_MONITOR_NS,0);
    assert(event_get(head,&e) && e.vcpu==~0U && e.guest==~0U);
    vmm_monitor_drain(); vmm_monitor_drain();
    n=lost;
    for(i=0;i<20;i++) { vmm_monitor_mem_fault(&v[0],1,i,1); period(VMM_MONITOR_NS,0); }
    assert(lost==n+4 && head-cursor+1==16 && !event_get(head-16,&e));
    n=cursor; vmm_monitor_drain(); assert(cursor==n+8);
    command("events"); command("status");
    assert(command("cpu")==VMM_EINVALID && command("diagnose")==VMM_EINVALID);
    puts("PASS: fault timestamps/identity/aggregation, stop/reset/restart preservation, bounded ring/loss, removed commands");
}
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static struct vmm_workqueue q;
static struct vmm_timer_event *ev;
static struct vmm_work *pending;
static int fail_queue,fail_affinity,fail_timer,fail_schedule,destroyed,scheduled;
struct vmm_workqueue *vmm_workqueue_create(const char *name,u32 priority) {
    (void)name; assert(!fake_irq_context && priority==3); return fail_queue?NULL:&q;
}
struct vmm_thread *vmm_workqueue_get_thread(struct vmm_workqueue *p) { return &p->thread; }
int vmm_threads_set_affinity(struct vmm_thread *t,const void *mask) {
    (void)t; assert(mask==vmm_cpumask_of(fake_cpu)); return fail_affinity?VMM_EFAIL:0;
}
int vmm_workqueue_destroy(struct vmm_workqueue *p) { assert(p==&q); destroyed++; return 0; }
int vmm_workqueue_schedule_work(struct vmm_workqueue *p,struct vmm_work *w) {
    assert(p==&q && fake_irq_context); scheduled++;
    if(fail_schedule) return VMM_EFAIL;
    if(pending) return VMM_EALREADY;
    pending=w; return 0;
}
int vmm_timer_event_start(struct vmm_timer_event *e,u64 dt) {
    if(fail_timer) return VMM_EFAIL;
    ev=e; e->active=1; e->expiry=fake_time+dt; assert(dt>0 && dt<=VMM_MONITOR_NS); return 0;
}
static void fire(void) {
    fake_time=ev->expiry; ev->active=0;
    fake_irq_context=1; ev->handler(ev); fake_irq_context=0;
}
static void test_timer(void) {
    command("stop"); while(cursor<=head) vmm_monitor_drain();
    scheduled=0; fire(); assert(scheduled==0); /* no foreground competition while idle */
    command("start"); vmm_monitor_mem_fault(&v[0],1,1,1); fire();
    assert(scheduled==1 && pending); pending->func(pending); pending=NULL;
    fail_schedule=1; vmm_monitor_mem_fault(&v[0],1,2,1); fire(); assert(arch_atomic_read(&errors)==1);
    fail_schedule=0; fire(); assert(pending); pending->func(pending); pending=NULL;
    fail_timer=1; fire(); assert(arch_atomic_read(&errors)==2 && !ev->active);
    puts("PASS: IRQ-safe timer, background priority, disabled idle, scheduling failure, timer rearm failure visibility");
}
#endif
int main(int argc,char **argv) {
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
    if(argc>1) {
        fail_queue=!strcmp(argv[1],"queue-fail"); fail_affinity=!strcmp(argv[1],"affinity-fail");
        fail_timer=!strcmp(argv[1],"timer-fail");
        assert(vmm_monitor_init()!=0 && !arch_atomic_read(&initialized));
        assert(destroyed==!fail_queue && vmm_monitor_enable(TRUE)==VMM_ENOTAVAIL);
        puts("PASS: init failure cleanup, collection unavailable"); return 0;
    }
#else
    (void)argc; (void)argv;
#endif
    assert(!vmm_monitor_init()); assert(!vmm_monitor_cmd_init());
    assert(!arch_atomic_read(&enabled));
    test_timing(); test_storm(); test_memory_and_switches();
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
    test_timer();
#endif
    puts(output); puts("PASS: monitor v3 production model"); return 0;
}
