/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Observe the production monitor and existing Guest exits. Never inject exits,
 * call sample/drain, or change Guest scheduling/lifetime. Run tests serially. */
#include <vmm_monitor.h>
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_mutex.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/mathlib.h>
#include <libs/wboxtest.h>

#define SR_U(x) ((unsigned long long)(x))
#define SR_HIGH 1000000000U
#define SR_LOW 1U
#define SR_SECONDS 5U
#define SR_SELECT_NS (10ULL * VMM_MONITOR_NS)
#define SR_PHASE_NS (20ULL * VMM_MONITOR_NS)
static DEFINE_MUTEX(sr_lock);
/* Test-only static scratch; no additional production or test config option. */
static struct sr_candidate { u64 previous, rate; u32 good, guest; }
    sr_candidates[CONFIG_MAX_VCPU_COUNT];
struct sr_context {
    struct vmm_chardev *out;
    struct vmm_monitor_test_state saved, expected;
    const char *phase;
    u64 cursor;
    u32 id, guest, low;
    bool locked, changed, foreign;
};
enum sr_phase { SR_QUIET, SR_TRIGGER, SR_HOLD, SR_RECOVER, SR_RETRIGGER };

static int sr_fail(struct sr_context *c, int rc, const char *reason)
{
    vmm_cprintf(c->out, "monitor_storm_runtime FAIL phase=%s: %s\n", c->phase, reason);
    return rc;
}
static bool sr_same_config(const struct vmm_monitor_test_state *a,
                           const struct vmm_monitor_test_state *b)
{
    return a->config_seq == b->config_seq &&
           !memcmp(a->config, b->config, sizeof(a->config));
}
static int sr_state(struct sr_context *c, struct vmm_monitor_test_state *s)
{
    int rc = vmm_monitor_test_state(s);
    if (rc) return sr_fail(c, rc, "cannot read monitor state");
    if (!sr_same_config(s, &c->expected)) {
        c->foreign = TRUE;
        return sr_fail(c, VMM_EBUSY, "monitor configuration changed outside this test");
    }
    if (!s->enabled || s->enabled != c->saved.enabled || s->epoch != c->saved.epoch)
        return sr_fail(c, VMM_EFAIL, "monitor enable/epoch changed");
    if (s->lost != c->saved.lost || s->errors != c->saved.errors)
        return sr_fail(c, VMM_EFAIL, "event loss or monitor executor error");
    /* Global skipped is not a failure: target windows are checked below. */
    return VMM_OK;
}
static int sr_set(struct sr_context *c, u32 key, u32 value)
{
    struct vmm_monitor_test_state s;
    int rc = sr_state(c, &s);
    if (rc || c->expected.config[key] == value) return rc;
    rc = vmm_monitor_configure(key, value);
    if (rc) return sr_fail(c, rc, "cannot set temporary configuration");
    c->changed = TRUE;
    c->expected.config[key] = value;
    if (!++c->expected.config_seq) ++c->expected.config_seq;
    return sr_state(c, &s);
}
static int sr_restore(struct sr_context *c)
{
    struct vmm_monitor_test_state s;
    int a, b;
    if (!c->changed) return VMM_OK;
    if (vmm_monitor_test_state(&s))
        return sr_fail(c, VMM_EFAIL, "restore: cannot read current configuration");
    if (c->foreign || !sr_same_config(&s, &c->expected))
        return sr_fail(c, VMM_EBUSY, "restore skipped: external configuration must not be overwritten");
    /* Always try both owned keys, even if restoring the first one fails.
     * Sampling windows, enabled state, VM state and history are never reset. */
    a = vmm_monitor_configure(VMM_MONITOR_EXIT_LIMIT, c->saved.config[VMM_MONITOR_EXIT_LIMIT]);
    b = vmm_monitor_configure(VMM_MONITOR_SUSTAIN_S, c->saved.config[VMM_MONITOR_SUSTAIN_S]);
    if (a || b || vmm_monitor_test_state(&s) ||
        memcmp(s.config, c->saved.config, sizeof(s.config)))
        return sr_fail(c, VMM_EFAIL, "restore failed; check monitor config");
    vmm_cprintf(c->out, "monitor_storm_runtime restored limit=%u sustain_s=%u\n",
        s.config[VMM_MONITOR_EXIT_LIMIT], s.config[VMM_MONITOR_SUSTAIN_S]);
    return VMM_OK;
}
static bool sr_full_window(const struct vmm_monitor_test_slot *s, u64 start)
{
    return s->valid && s->interval && s->previous >= s->interval &&
           s->previous - s->interval >= start && s->exits <= ~0ULL / VMM_MONITOR_NS;
}
static int sr_select(struct sr_context *c)
{
    struct vmm_monitor_test_state g;
    struct vmm_monitor_test_slot s;
    u64 start = vmm_timer_timestamp(), best, rate;
    u32 i, selected;
    int rc;
    memset(sr_candidates, 0, sizeof(sr_candidates));
    do {
        rc = sr_state(c, &g);
        if (rc) return rc;
        best = 0; selected = ~0U;
        for (i = 0; i < CONFIG_MAX_VCPU_COUNT; i++) {
            struct sr_candidate *p = &sr_candidates[i];
            rc = vmm_monitor_test_slot(i, &s);
            if (rc) return sr_fail(c, rc, "cannot inspect candidate slot");
            if (!s.present || s.kind != 0 || s.epoch != c->saved.epoch ||
                s.config_seq != c->expected.config_seq || s.guest == ~0U) {
                p->good = 0; continue;
            }
            if (s.previous != p->previous) {
                if (!sr_full_window(&s, start)) p->good = 0;
                else {
                    rate = udiv64(s.exits * VMM_MONITOR_NS, s.interval);
                    if (rate < 4 || (p->good && (p->guest != s.guest ||
                        s.previous - s.interval != p->previous))) p->good = 0;
                    if (rate >= 4) {
                        if (!p->good || rate < p->rate) p->rate = rate;
                        p->good++; p->guest = s.guest;
                    }
                }
                p->previous = s.previous;
            }
            if (p->good >= 2 && p->rate > best &&
                vmm_timer_timestamp() >= p->previous &&
                vmm_timer_timestamp() - p->previous < 2 * VMM_MONITOR_NS) {
                best = p->rate; selected = i;
            }
        }
        if (selected != ~0U) {
            c->id = selected; c->guest = sr_candidates[selected].guest;
            /* A boot-time peak is not a sustained workload guarantee. Use the
             * lowest supported threshold for this functional path test, then
             * restore the original policy. Real exits must still exceed it. */
            c->low = SR_LOW;
            vmm_cprintf(c->out, "monitor_storm_runtime target guest=%u vcpu=%u baseline=%llu/s\n",
                        c->guest, c->id, SR_U(best));
            vmm_cprintf(c->out, "monitor_storm_runtime test limit=%u sustain_s=%u\n", c->low, SR_SECONDS);
            return VMM_OK;
        }
        vmm_msleep(20);
    } while (vmm_timer_timestamp() - start < SR_SELECT_NS);
    return sr_fail(c, VMM_ENOTAVAIL, "need a running Guest with two fresh valid exit windows");
}
/* Read slot -> ring -> slot, committing cursor only if the sample is unchanged.
 * A concurrent sampler may publish the slot and event between separate APIs. */
static int sr_frame(struct sr_context *c, struct vmm_monitor_test_slot *s,
                    struct vmm_monitor_test_event *found, u32 *count)
{
    struct vmm_monitor_test_slot after;
    struct vmm_monitor_test_state g;
    struct vmm_monitor_test_event e;
    u64 seq;
    int rc = sr_state(c, &g);
    if (rc) return rc;
    if (vmm_monitor_test_slot(c->id, s) || vmm_monitor_test_state(&g))
        return sr_fail(c, VMM_EFAIL, "cannot read sample/event boundary");
    if (!s->present || s->kind != 0 || s->guest != c->guest || s->epoch != c->saved.epoch)
        return sr_fail(c, VMM_EFAIL, "selected Guest slot changed");
    if (g.head < c->cursor || g.head - c->cursor > VMM_MONITOR_EVENTS)
        return sr_fail(c, VMM_EFAIL, "event evidence overwritten");
    *count = 0;
    for (seq = c->cursor + 1; seq <= g.head; seq++) {
        if (vmm_monitor_test_event(seq, &e))
            return sr_fail(c, VMM_EFAIL, "event evidence no longer available");
        if (e.type != 1 || e.vcpu != c->id) continue;
        if (e.guest != c->guest || e.epoch != c->saved.epoch ||
            e.config_seq != c->expected.config_seq ||
            e.detail != c->expected.config[VMM_MONITOR_EXIT_LIMIT] ||
            e.sustain_s != SR_SECONDS || e.address || e.last_ns != e.time_ns)
            return sr_fail(c, VMM_EFAIL, "storm event identity/configuration mismatch");
        *found = e; (*count)++;
    }
    if (vmm_monitor_test_slot(c->id, &after))
        return sr_fail(c, VMM_EFAIL, "cannot confirm sample boundary");
    if (after.previous != s->previous || after.config_seq != s->config_seq ||
        after.guest != s->guest || after.epoch != s->epoch || after.present != s->present)
        return VMM_EAGAIN;
    rc = sr_state(c, &g);
    if (rc) return rc;
    /* Advance only to the head scanned above, not a newly published head. */
    c->cursor = seq - 1;
    return VMM_OK;
}
static int sr_phase(struct sr_context *c, enum sr_phase phase)
{
    static const char *const names[] = {"quiet", "trigger", "dedup", "recover", "retrigger"};
    struct vmm_monitor_test_slot s;
    struct vmm_monitor_test_event e = {0};
    struct vmm_monitor_test_state g;
    u64 start = vmm_timer_timestamp(), previous = 0, high_ns = 0;
    u32 windows = 0, low_windows = 0, events = 0;
    bool high, eligible;
    int rc;
    c->phase = names[phase];
    vmm_cprintf(c->out, "monitor_storm_runtime phase=%s\n", c->phase);
    do {
        rc = sr_frame(c, &s, &e, &events);
        if (rc == VMM_EAGAIN) goto wait;
        if (rc) return rc;
        if (s.previous == previous) {
            if (events) return sr_fail(c, VMM_EFAIL, "event without a new sampling window");
            goto wait;
        }
        if (previous && s.interval && s.previous >= s.interval &&
            s.previous - s.interval != previous)
            return sr_fail(c, VMM_EFAIL, "observer missed sampling windows");
        previous = s.previous;
        if (s.config_seq != c->expected.config_seq || !sr_full_window(&s, start)) {
            windows = low_windows = 0; high_ns = 0;
            if (events) return sr_fail(c, VMM_EFAIL, "storm event in invalid/transition window");
            goto wait;
        }
        high = s.exits > udiv64((u64)c->expected.config[VMM_MONITOR_EXIT_LIMIT] * s.interval, VMM_MONITOR_NS);
        if (high) { windows++; high_ns += s.interval; low_windows = 0; }
        else { windows = 0; high_ns = 0; low_windows++; }
        eligible = windows >= SR_SECONDS && high_ns >= SR_SECONDS * VMM_MONITOR_NS;
        if (phase == SR_QUIET || phase == SR_RECOVER) {
            if (events) return sr_fail(c, VMM_EFAIL, "unexpected event with recovery threshold");
            if (!high && s.active) return sr_fail(c, VMM_EFAIL, "low-rate window did not rearm detector");
            if (low_windows >= 2) return VMM_OK;
        } else if (phase == SR_HOLD) {
            if (events) return sr_fail(c, VMM_EFAIL, "duplicate event during the same episode");
            if (!high) {
                vmm_cprintf(c->out, "monitor_storm_runtime load dropped: exits=%llu interval_ns=%llu limit=%u/s\n",
                            SR_U(s.exits), SR_U(s.interval), c->low);
                return sr_fail(c, VMM_ENOTAVAIL, "Guest exit rate dropped during dedup observation");
            }
            if (!s.active) return sr_fail(c, VMM_EFAIL, "episode lost its active state");
            if (eligible) return VMM_OK;
        } else {
            if (events > 1) return sr_fail(c, VMM_EFAIL, "multiple events for one threshold crossing");
            if (events && (!eligible || !s.active || e.time_ns != s.previous ||
                e.value != udiv64(s.exits * VMM_MONITOR_NS, s.interval)))
                return sr_fail(c, VMM_EFAIL, "early storm event or inconsistent rate/timestamp");
            if (!events && (eligible || s.active))
                return sr_fail(c, VMM_EFAIL, "threshold met but matching storm event missing");
            if (events) {
                vmm_cprintf(c->out, "monitor_storm_runtime EVENT seq=%llu guest=%u vcpu=%u rate=%llu/s\n",
                            SR_U(e.seq), e.guest, e.vcpu, SR_U(e.value));
                vmm_cprintf(c->out, "monitor_storm_runtime evidence config_seq=%u limit=%llu; log=manual\n",
                            e.config_seq, SR_U(e.detail));
                return VMM_OK;
            }
        }
wait:
        vmm_msleep(20);
    } while (vmm_timer_timestamp() - start < SR_PHASE_NS);
    if (!vmm_monitor_test_state(&g))
        vmm_cprintf(c->out, "monitor_storm_runtime timeout valid_high=%u high_ns=%llu skipped=%u->%u\n",
                    windows, SR_U(high_ns), c->saved.skipped, g.skipped);
    return sr_fail(c, VMM_ETIMEDOUT, "insufficient fresh valid windows or sustained Guest exits");
}
static int sr_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct sr_context c;
    struct vmm_monitor_test_state g;
    int rc, restore;
    (void)test; (void)cpu;
    memset(&c, 0, sizeof(c)); c.out = out; c.phase = "begin";
    if (!vmm_mutex_trylock(&sr_lock)) return sr_fail(&c, VMM_EBUSY, "another runtime storm test is running");
    c.locked = TRUE;
    rc = vmm_monitor_test_state(&c.saved);
    if (rc || !c.saved.enabled) {
        rc = sr_fail(&c, VMM_ENOTAVAIL, "run monitor start before this test"); goto done;
    }
    c.expected = c.saved; c.phase = "select";
    rc = sr_select(&c);
    if (rc) goto done;
    vmm_cprintf(out, "monitor_storm_runtime saved limit=%u sustain_s=%u\n",
                c.saved.config[VMM_MONITOR_EXIT_LIMIT], c.saved.config[VMM_MONITOR_SUSTAIN_S]);
    rc = sr_set(&c, VMM_MONITOR_EXIT_LIMIT, SR_HIGH);
    if (!rc) rc = sr_set(&c, VMM_MONITOR_SUSTAIN_S, SR_SECONDS);
    if (rc) goto done;
    rc = sr_state(&c, &g);
    if (rc) goto done;
    c.cursor = g.head; /* Earlier episodes cannot count as this test's evidence. */
    rc = sr_phase(&c, SR_QUIET);
    if (!rc) rc = sr_set(&c, VMM_MONITOR_EXIT_LIMIT, c.low);
    if (!rc) rc = sr_phase(&c, SR_TRIGGER);
    if (!rc) rc = sr_phase(&c, SR_HOLD);
    if (!rc) rc = sr_set(&c, VMM_MONITOR_EXIT_LIMIT, SR_HIGH);
    if (!rc) rc = sr_phase(&c, SR_RECOVER);
    if (!rc) rc = sr_set(&c, VMM_MONITOR_EXIT_LIMIT, c.low);
    if (!rc) rc = sr_phase(&c, SR_RETRIGGER);
done:
    restore = sr_restore(&c);
    if (restore) rc = restore;
    if (!rc) vmm_cprintf(out, "monitor_storm_runtime PASS trigger/dedup/recovery/retrigger; logs=manual\n");
    if (c.locked) vmm_mutex_unlock(&sr_lock);
    return rc;
}
#define SR_REGISTER(test_name, fn) \
static struct wboxtest test_name = {.name = #test_name, .run = fn}; \
static int __init test_name##_init(void) { return wboxtest_register("monitor", &test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name, #test_name, "Monitor maintainers", "GPL", WBOXTEST_IPRIORITY+1, test_name##_init, test_name##_exit)
SR_REGISTER(monitor_storm_runtime, sr_run);
