# Monitor v4 白盒测试说明

日期：2026-10-23。适用基线：已合入 v4 全调度对象监控的参考树。

## 1. 本次交付及覆盖边界

新增 `libs/wboxtest/monitor/` 和 `CONFIG_WBOXTEST_MONITOR`，在 `monitor` 组注册六个用例。
测试直接包含当前工程的监控、命令和共享内存实现，编译为独立命名的测试实例；不复制一套判定算法。
功能代码没有修改；已有 scheduler、认证、前台线程优先级及生产 monitor 实例不改变。

这是运行于 Hypervisor 内的确定性白盒回归，不是全部需求的最终验收：

- 时间、Guest 映射、内存后端、CPU/idle 查询与日志输出为受控测试输入；使用真实 C 实现和真实内核锁。
- 不执行真实 Guest 指令，不切换真实 vCPU，不读取 EL2 故障寄存器，不触发真实硬件越权。
- 不运行生产 timer/日志工作队列；不测试工作线程优先级、实际采样 IRQ 延迟、QEMU 时序、日志落盘与串口后端。
- 不验证 ROM <=5KB、运行期间全调用链分配情况或 CPU <0.5%。测试关闭后的产品代码仍需按原验收矩阵测试，既有 ROM 超限问题不因此消失。

## 2. 编译开关

```text
CONFIG_MONITOR_AGENT=y
CONFIG_CMD_MONITOR=y
CONFIG_WBOXTEST=y
CONFIG_CMD_WBOXTEST=y
CONFIG_WBOXTEST_MONITOR=y
```

新开关默认关闭，要求 WBOXTEST 内建为 y，不支持以 m 单独加载该组。
`CONFIG_MONITOR_PRIORITY` 保持原值 3；生产 monitor 可以处于 start 或 stop，不影响本组用例的隔离状态。
`CONFIG_MONITOR_EXTERNAL_EXECUTOR`、`CONFIG_MONITOR_START_ENABLED` 可以保持产品配置。测试副本始终采用手动执行、默认停止的方式，每轮自行初始化；这不改变生产实例的执行方式。

配置入口位于 White-box testing library 下的 Monitor regression group。
已有 Makefile 会扫描各子目录的 `objects.mk`；只需在 `libs/wboxtest/openconf.cfg` 增加一个 source 行，不修改总 Makefile。
产品性能/容量验收应关闭 `CONFIG_WBOXTEST_MONITOR`；量产不需要整个白盒框架时，也关闭 `CONFIG_WBOXTEST`。

## 3. 执行命令及通过条件

通过产品原有认证及命令白名单进入允许执行 wboxtest 的终端，然后运行：

```text
wboxtest group_list
wboxtest test_list
wboxtest run_groups 1 monitor
wboxtest run_groups 10 monitor

wboxtest run_tests 1 monitor_lifecycle
wboxtest run_tests 1 monitor_config
wboxtest run_tests 1 monitor_scheduler
wboxtest run_tests 1 monitor_memory
wboxtest run_tests 1 monitor_storm
wboxtest run_tests 1 monitor_output
```

先确认列表中有 monitor 组和全部六个用例，再运行。六个用例每轮均应显示 `passed`，每个汇总均为 `failures 0 out of N`，N 必须大于零。
失败会额外打印用例函数、源码行号和失败的表达式，便于定位私有接口差异。
时间采用虚拟输入，无须实际等待两秒或五秒。测试中的风暴与内存事件进入私有缓冲，不应在业务 `monitor events` 或真实日志文件中出现。

当前上游 wboxtest 命令会在执行用例后返回命令成功，不能仅凭 shell 返回值判断测试成功；应解析每个用例的结果和汇总。
不要用 `iterations=0` 作为验收结果，该框架会跳过实际执行。本包不修改公共 wboxtest 行为。
本组所有初始化在 run 内完成，不使用 setup，因此避开框架 setup 失败后仍执行 run 的既有问题。
框架的全局空闲内存前后差异仍仅是辅助诊断：运行中的其他模块也可能改变内存使用，不能据此证明监控从未分配内存。

## 4. 各用例详细设计

| 用例 | 输入与操作 | 主要断言 |
|---|---|---|
| `monitor_lifecycle` | 默认停止、重复 start、stop 后继续送入打点、停止后排出旧摘要、重新 start、UNKNOWN/RESET、同 ID 从 Guest 变为宿主 | 默认不采集；start 幂等；停止拒绝新样本；旧异常保留；新 epoch 不混用旧数据；ID 复用清理；异常 ID/空 Guest 安全拒绝 |
| `monitor_config` | 命令写入、空字符串/负数/带符号/小数/十六进制/溢出/未知参数；四个键的上下边界 | 合法值生效；非法输入和同值写入不改变配置版本；写入成功简单文本回显；查询无 JSON |
| `monitor_scheduler` | Guest、host、idle 分别输入 READY、重复 READY、selected、dispatch、暂停、逆序时间、远程通知 | 等待起点不被刷新；次数/和/最大值正确；暂停不算等待；无 READY 不补样本；查询年龄正确；host/idle 分类与归属正确；宿主 exit 不计数 |
| `monitor_memory` | 实际共享内存访问实现＋受控映射；边界内读写、末尾越界、其他 Guest backing、只读写入、alias、映射失败/长度不足、无映射、地址回绕、宿主对象参数 | 合法访问到达测试后端且数据正确；拒绝请求不触达后端、不改 backing；事件类型和 Guest 归属正确；整数边界不绕过检查 |
| `monitor_storm` | 100/s 门限、2s 持续门限；精确一秒与 0.8s 窗口、100/101 次边界、有效恢复、改参、延迟采样、槽竞争、两个 Guest | 严格大于才超限；满足窗口数及实际持续时间；同一轮只告警一次；改参首窗丢弃且保持已告警状态；恢复后重报；延迟/跳过不能伪造连续窗口；Guest 独立触发 |
| `monitor_output` | 多次内存异常合并、events 查询、后台排空、最大地址字段、20 次独立事件填入16条环 | 首末时间及最后代表信息正确；查询不消费后台游标、不重复记日志；每事件只调用一次捕获日志；每批最多8条；覆盖4条时 lost=4；关键输出字段及缓冲区边界正确 |

调度确定性例子：READY=100、重复 READY=150、selected=300，应记录等待200，而不是150。用例对每一种对象分类均执行等价检查。
本组没有运行真实优先级7线程；分类和过滤由输入对象类型决定，不能据此宣称硬件调度抢占已验证。
风暴用例的2s门限只是隔离实例的测试配置，不会修改产品门限。产品是否实现真实50000/s持续5s检测，还需真实 Guest 与时序测试。
输出用例检查关键字段和有界输出；完整 JSON 解析、落盘完成时刻及串口是否与产品后端一致，继续由外部验收脚本检查。

## 5. 隔离方式及源码组织

```text
libs/wboxtest/monitor/
    openconf.cfg
    objects.mk
    common.h
    support.c
    lifecycle.c
    scheduler.c
    memory.c
    storm.c
    output.c
```

`support.c` 在读取平台头文件后，重命名监控公开入口，再包含 `core/monitor/monitor_agent.c` 和 `commands/cmd_monitor.c`。
它拥有自己的静态 slots/ring/config/epoch，最多4个模拟调度对象和一个无归属内存槽。虚拟时间由测试输入推进，不调用生产的 `vmm_monitor_sample()`。
测试副本不创建 timer、工作队列或命令注册项。其 init 被保留在普通代码段，可在每轮运行时调用，不依赖已释放的启动代码段。
日志接口被捕获到固定缓冲中；assert 失败才通过 wboxtest 的终端输出原因。

`memory.c` 对 `core/vmm_shmem.c` 的入口命名隔离，替换查找映射、物理映射和内存读写为测试后端；所有实际读写仅针对32字节静态 backing。
包含该文件是为了复用当前访问检查实现，其测试副本的共享内存注册、创建、引用和销毁接口不被调用。对象由用例静态构造，不加入业务共享内存列表。

所有用例以一个测试互斥锁保护整个 run；每轮先重置私有状态，再执行断言，任何失败都经过统一 out 分支解锁。生产中其他CPU和timer继续独立运行。
不会临时清空业务统计、占用真实 vCPU ID，也不依赖 monitor stop 关闭 timer。

## 6. 手工合入位置与私有工程适配

现有文件只改 `libs/wboxtest/openconf.cfg`：在已有 stdio/threads/nested_mmu 的 source 附近增加：

```text
source libs/wboxtest/monitor/openconf.cfg
```

新增上述9个文件。`core/monitor/monitor_agent.c`、`commands/cmd_monitor.c`、`core/vmm_shmem.c`、scheduler 和公共 monitor 头文件均不修改。
测试支持代码依赖 v4 内部结构和函数；如果私有实现调整过结构字段、函数名或文件路径，编译会指出对应适配位置。
特别是共享内存文件若新增了其他全局入口，包含测试副本时需要一并为这些入口改名，避免重复符号；不要为消除编译错误而让测试调用真实物理内存后端。
`__vmm_snprintf`、mutex、wboxtest 注册和 `VMM_DECLARE_MODULE2` 使用上游现有接口。每个测试使用唯一模块名，确保同一文件中的生命周期和配置用例都注册。

包内额外提供主机复现文件：

```text
tests/monitor/wboxtest_host.h
tests/monitor/test_wboxtest.c
tests/monitor/run_wboxtests.py
```

它们依赖之前交付的 `tests/monitor/host.h`，不编入目标固件。
在带 Python/Zig 的开发机执行：

```text
python tests/monitor/run_wboxtests.py --cc <zig-path> --build-dir <output-directory>
```

## 7. 本地验证和仍需执行的验收

本轮验证：

- ARM64 使用真实工程头文件编译6个新增 C 文件；生产配置分别为内部执行、外部执行、开机启用，均通过。
- 主机模型编译并执行本次交付的六个 wboxtest 用例，每种配置3轮，共54次用例执行，通过。
- 核对测试对象符号：没有调用生产监控、生产 timer/工作队列、Guest 映射或物理内存访问入口；测试 init 保留在普通代码段。
- 编译比较开启/关闭白盒开关时的生产 monitor_agent 对象，应字节一致。
- 使用独立副本故意引入三种错误：重复 READY 覆盖起点、速率门限误写为大于等于、绕过共享内存只读检查；对应测试应报失败。
- 补丁应用后文件与完整文件逐一核对，执行反向应用检查和交付哈希校验。

以上结果不包含完整产品链接、实际 QEMU 启动、板端 wboxtest 命令执行或实机多核验证。最终请在产品上运行第3节命令，并保留六个用例的完整输出。
后续验收还包括真实 scheduler 打点、Guest stage-2异常、实际exit风暴、产品日志后端、auth/mterm交互、12核负载下时序和CPU开销、最终固件容量。
