/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"

static int output_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	struct mt_global a;
	struct mt_global b;
	struct mt_event e;
	u32 i;
	u64 first;
	(void)test;
	(void)cpu;
	MT_CHECK(mt_enable(TRUE) == VMM_OK);
	first = mt_now();
	mt_fault(mt_vcpu(0), VMM_MONITOR_MAP_REJECT, 0x1000, 1);
	mt_time(first + 50);
	mt_fault(mt_vcpu(0), VMM_MONITOR_PERMISSION, 0x2000, 7);
	mt_sample(first + VMM_MONITOR_NS);
	MT_CHECK(mt_event(1, &e) && e.time == first && e.last == first + 50 && e.value == 2);
	MT_CHECK(e.code == VMM_MONITOR_PERMISSION && e.address == 0x2000);
	mt_global(&a);
	MT_CHECK(a.head == 1 && !a.logs);
	MT_CHECK(mt_command("events", NULL, NULL) == VMM_OK);
	MT_CHECK(strstr(mt_output(), "\"schema\":3") && strstr(mt_output(), "\"seq\":1"));
	mt_global(&b);
	MT_CHECK(b.cursor == a.cursor && !b.logs);
	mt_drain();
	mt_global(&b);
	MT_CHECK(b.logs == 1 && b.cursor == 2);
	MT_CHECK(strstr(mt_log(), "\"type\":3") && strchr(mt_log(), '\n'));
	mt_drain();
	mt_global(&b);
	MT_CHECK(b.logs == 1);
	MT_CHECK(mt_command("events", NULL, NULL) == VMM_OK);
	mt_global(&b);
	MT_CHECK(b.logs == 1 && b.cursor == 2);
	MT_CHECK(mt_command("config", "exit_limit", "100") == VMM_OK);
	MT_CHECK(!strcmp(mt_output(), "OK: exit_limit=100\n"));
	MT_CHECK(mt_command("config", NULL, NULL) == VMM_OK && !strchr(mt_output(), '{'));
	/* Maximum numeric payload must fit the production fixed line buffer. */
	mt_time(~0ULL - 1);
	mt_fault(mt_vcpu(0), VMM_MONITOR_PERMISSION, ~0ULL, ~0ULL);
	mt_sample(~0ULL);
	mt_drain();
	MT_CHECK(strstr(mt_log(), "18446744073709551615") && !mt_overflow());
	mt_reset();
	MT_CHECK(mt_enable(TRUE) == VMM_OK);
	for (i = 0; i < VMM_MONITOR_EVENTS + 4; i++) {
		mt_fault(NULL, VMM_MONITOR_SHMEM_BOUNDS, i, 1);
		mt_sample(mt_now() + VMM_MONITOR_NS);
	}
	mt_global(&a);
	MT_CHECK(a.head == 20 && a.lost == 4 && a.cursor == 5);
	MT_CHECK(!mt_event(4, &e) && mt_event(5, &e));
	MT_CHECK(e.guest == ~0U && e.vcpu == ~0U);
	MT_CHECK(mt_command("events", NULL, NULL) == VMM_OK && !mt_overflow());
	mt_global(&b);
	MT_CHECK(a.cursor == b.cursor);
	mt_drain();
	mt_global(&b);
	MT_CHECK(b.logs == 8 && b.cursor == 13);
	mt_drain();
	mt_global(&b);
	MT_CHECK(b.logs == 16 && b.cursor == 21);
	mt_drain();
	mt_global(&b);
	MT_CHECK(b.logs == 16);
	return VMM_OK;
}

MT_REGISTER(monitor_output, output_run);
