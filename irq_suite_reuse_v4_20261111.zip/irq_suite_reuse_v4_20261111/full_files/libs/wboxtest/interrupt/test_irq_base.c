/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright (c) 2024 ZTE Authors. All rights reserved. */
#include "test_irq.h"

#define MODULE_DESC "test_irq_base test"
#define MODULE_AUTHOR "ZTE Authors"
#define MODULE_LICENSE "GPL"
#define MODULE_IPRIORITY (WBOXTEST_IPRIORITY + 4)

static int base_cases(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq;
	const char *name;
	u32 count;
	int rc;

	vmm_cprintf(out, "TEST1: get descriptor\n");
	irq = vmm_host_irq_get(test_irq_id(0));
	if (!irq || irq->num != test_irq_id(0) || irq->hwirq < 32U) {
		return VMM_EFAIL;
	}
	vmm_cprintf(out, "TEST2: register and get name\n");
	rc = test_irq_register(0, "test_irq_1");
	name = vmm_host_irq_get_name(irq);
	if (!rc && (!name || strcmp(name, "test_irq_1"))) {
		rc = VMM_EFAIL;
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST3: SGI count including invalid CPU query\n");
	irq = vmm_host_irq_get(test_irq_id(TEST_IRQ_SGI1));
	if (vmm_host_irq_get_count(irq, CONFIG_CPU_COUNT) != 0U) {
		return VMM_EFAIL;
	}
	count = vmm_host_irq_get_count(irq, test_irq_cpu());
	rc = test_irq_set_priority(TEST_IRQ_SGI1, 0);
	if (!rc) {
		rc = test_irq_register(TEST_IRQ_SGI1, "test_irq_sgi");
	}
	if (!rc) {
		rc = test_irq_sgi(TEST_IRQ_SGI1);
	}
	if (!rc && (u32)(vmm_host_irq_get_count(irq, test_irq_cpu()) - count) != 1U) {
		rc = VMM_EFAIL;
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST4: raise SGI again and software-dispatch SPI\n");
	rc = test_irq_sgi(TEST_IRQ_SGI1);
	if (!rc) {
		rc = test_irq_software(0, FALSE);
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST5: disable/enable state\n");
	irq = vmm_host_irq_get(test_irq_id(0));
	rc = test_irq_mask(0);
	if (!rc && !vmm_host_irq_is_disabled(irq)) {
		rc = VMM_EFAIL;
	}
	if (!rc) {
		rc = test_irq_unmask(0);
	}
	if (!rc && vmm_host_irq_is_disabled(irq)) {
		rc = VMM_EFAIL;
	}
	if (!rc) {
		rc = test_irq_mask(0);
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST6: unregister absent own action, then register/unregister\n");
	if (!test_irq_unregister(1)) {
		return VMM_EFAIL;
	}
	rc = test_irq_register(1, "test_irq_register");
	if (!rc) {
		rc = test_irq_unregister(1);
	}
	if (rc) {
		return rc;
	}
	vmm_cprintf(out, "TEST7: CPU PMR set/get and immediate restore\n");
	return test_irq_pmr(0);
}

static int test_irq_base_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
	int rc = test_irq_begin(out, cpu, 1);

	(void)test;
	if (rc) {
		return rc;
	}
	rc = base_cases(out);
	return test_irq_end(out, rc);
}

static struct wboxtest test_irq_base = {
	.name = "irq_base",
	.run = test_irq_base_run,
};

static int __init test_irq_base_init(void)
{
	return wboxtest_register("interrupt", &test_irq_base);
}

static void __exit test_irq_base_exit(void)
{
	wboxtest_unregister(&test_irq_base);
}

VMM_DECLARE_MODULE(MODULE_DESC, MODULE_AUTHOR, MODULE_LICENSE, MODULE_IPRIORITY, test_irq_base_init,
		   test_irq_base_exit);
