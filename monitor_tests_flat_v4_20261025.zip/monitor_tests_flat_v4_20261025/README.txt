Monitor v4：平铺测试目录，直接基于记录版 / 2026-10-25

唯一基线：monitor_observer_from_20261023_v4_20261025 已合入后的工程。
无需先合入中间测试包；本包替代之前提供的测试整理包，不能叠加旧增量。

板端只合入根目录的两份补丁：
1. from_observer.patch：核心测试支持、统一测试目录、九项用例及单一开关。
2. cmd_memory_from_uploaded.patch：基于你上传的原 cmd_memory.c，追加原拒绝分支记录及检查适配。
完整文件在 full_files；手工定位见 merge_locations.txt；板端清单见 board_file_manifest.json。
保留你的其他私有改动；上传命令的头注释缺斜杠已补齐，实际文件正确时跳过该注释差异。

结构：
- libs/wboxtest/monitor 下平铺所有用例，不再有 host/live 子目录。
- 四个测试查询函数并入 monitor_agent.c，删除 monitor_test.inc。
- 声明和结构合并到 vmm_monitor.h，删除旧 vmm_monitor_test.h；不新增头文件。
- 新增 memory_runtime.c 承载真实内存测试，原 memory.c 保留隔离测试。
- 原 Guest 配合用例保存为 guest_cases.c，本阶段不编译；当前仍为九项。

测试侧唯一选项：CONFIG_WBOXTEST_MONITOR=y。
已有 WBOXTEST、MONITOR_AGENT、CMD_MONITOR 仍需为 y；CMD_MEMORY、CMD_WBOXTEST 自动选择。
执行：monitor start，然后 wboxtest run_groups 1 monitor。
Guest 写保护用例需已有符合原策略的映射；无需运行新 Guest 或用户态测试程序。日志人工检查。

optional_verification 中是可选的开发机工具补丁/文件，不属于板端必需合入内容。
生成的模型替代头文件不放入正式源码，不参与固件构建。

已完成 11 次当前构建/关闭配置 ARM64 编译，以及保留 Guest 文件的单独编译；
原隔离/只读回归、内存模型和 360 组策略行为对照、补丁应用/反向还原通过。
尚未进行私有完整固件链接或板卡/QEMU运行，不代表资源与实时性约束已经验收。
