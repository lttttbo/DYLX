#include <vmm_error.h>
#include <vmm_monitor.h>
#include <vmm_stdio.h>
#include <vmm_smp.h>
#include <vmm_mutex.h>
#include <vmm_u_ioreq.h>
#include <arch_barrier.h>
#include <vmm_guest_aspace.h>
#include <vmm_host_aspace.h>
#include <arch_barrier.h>
#include <vmm_completion.h>
#include <cpu_hcall.h>
#include <arch_atomic.h>
#include <vmm_waitqueue.h>
#define IOREQ_DIR_READ             0U
#define IOREQ_DIR_WRITE            1U
#define IOREQ_WAITQ_NUM            IO_REQUEST_MAX
enum vm_exitcode {
        VM_EXITCODE_INOUT = 0,
        VM_EXITCODE_MMIO_EMUL,
        VM_EXITCODE_PCI_CFG,
        VM_EXITCODE_MAX
};
#ifdef DEBUG
s32 sbuf_share_setup(u16 pcpu_id, u32 sbuf_id, u64 *hva)
{
    if ((pcpu_id >= get_pcpu_nums()) || (sbuf_id >= ACRN_SBUF_PER_PCPU_ID_MAX)) {
            return -EINVAL;
    }
    per_cpu(sbuf, pcpu_id)[sbuf_id] = (struct shared_buf *) hva;
    pr_info("%s share sbuf for pCPU[%u] with sbuf_id[%u] setup successfully",
                    __func__, pcpu_id, sbuf_id);
    return 0;
}
#else
s32 sbuf_share_setup(__unused u16 pcpu_id,
                __unused u32 sbuf_id, __unused u64 *hva)
{
        return VMM_ENOTAVAIL;
}
#endif
void set_io_req_state(struct vmm_guest *vm, u32 vcpu_id, u32 state) {
        struct io_request_buffer *req_buf = NULL;
        struct io_request *io_req;
        req_buf = (struct io_request_buffer *)vm->sw.io_shared_page;
        if (req_buf != NULL) {
                /* Started by AICoder, pid:b89eac43b7q7f6f145120a8ef01d6506a7d4b566 */
                if (vcpu_id >= IO_REQUEST_MAX) {
                        vmm_printf("vcpu_id is out of range when set_io_req_state!\n");
                        return;
                }
                /* Ended by AICoder, pid:b89eac43b7q7f6f145120a8ef01d6506a7d4b566 */
                io_req = &req_buf->req_slot[vcpu_id];
                /*
                 * HV will only set processed to IOREQ_STATE_PENDING or IOREQ_STATE_FREE.
                 * we don't need to sfence here is that even if the Service-VM/DM sees the previous state,
                 * the only side effect is that it will defer the processing of the new IOReq.
                 * It won't lead wrong processing.
                 */
                io_req->processed = state;
        }
}
u32 get_io_req_state(struct vmm_guest *vm, u32 vcpu_id)
{
        u32 state;
        struct io_request_buffer *req_buf = NULL;
        struct io_request *io_req;
        req_buf = (struct io_request_buffer *)vm->sw.io_shared_page;
        if (req_buf == NULL || vcpu_id >= IO_REQUEST_MAX) {
                state =  0xffffffffU;
        } else {
                io_req = &req_buf->req_slot[vcpu_id];
                state = io_req->processed;
        }
        return state;
}
s32 init_asyncio(struct vmm_guest *vm, u64 *hva, physical_addr_t hpa) {
        struct shared_buf *sbuf = (struct shared_buf *)hva;
        int ret = VMM_EINVALID;
        if (sbuf != NULL) {
                if (sbuf->magic == SBUF_MAGIC) {
                        vm->sw.asyncio_sbuf = sbuf;
                        vm->sw.asyncio_sbuf_hpa = hpa;
                        INIT_LIST_HEAD(&vm->aiodesc_queue);
                        INIT_SPIN_LOCK(&vm->asyncio_lock);
                        ret = VMM_OK;
                }
        }
        arch_smp_mb();
        return ret;
}
int add_asyncio(struct vmm_guest *vm, u32 type, u64 addr, u64 fd) {
        u32 i;
        int ret = VMM_EFAIL;
        if (addr != 0UL) {
                vmm_spin_lock(&vm->asyncio_lock);
                for (i = 0U; i < ASYNCIO_MAX; i++) {
                        if ((vm->aio_desc[i].addr == 0UL) && (vm->aio_desc[i].fd == 0UL)) {
                                vm->aio_desc[i].addr = addr;
                                vm->aio_desc[i].fd = fd;
                                INIT_LIST_HEAD(&vm->aio_desc[i].list);
                                list_add(&vm->aio_desc[i].list, &vm->aiodesc_queue);
                                ret = VMM_OK;
                                break;
                        }
                }
                vmm_spin_unlock(&vm->asyncio_lock);
                if (i == ASYNCIO_MAX) {
                        vmm_printf("too much fastio, would not support!\n");
                }
        } else {
                vmm_printf("%s: base = 0 is not supported!\n", __func__);
        }
        return ret;
}
int remove_asyncio(struct vmm_guest *vm, u32 type, u64 addr, u64 fd) {
        u32 i;
        int ret = VMM_EFAIL;
        if (addr != 0UL) {
                vmm_spin_lock(&vm->asyncio_lock);
                for (i = 0U; i < ASYNCIO_MAX; i++) {
                        if ((vm->aio_desc[i].addr == addr)
                                        && (vm->aio_desc[i].fd == fd)) {
                                vm->aio_desc[i].addr = 0U;
                                vm->aio_desc[i].fd = 0UL;
                                list_del_init(&vm->aio_desc[i].list);
                                ret = VMM_OK;
                                break;
                        }
                }
                vmm_spin_unlock(&vm->asyncio_lock);
                if (i == ASYNCIO_MAX) {
                        vmm_printf("Failed to find asyncio req on addr: %lx!\n", addr);
                }
        } else {
                vmm_printf("%s: base = 0 is not supported!\n", __func__);
        }
        return ret;
}
s32 init_vm_event(struct vmm_guest *vm, u64 *hva)
{
        struct shared_buf *sbuf = (struct shared_buf *)hva;
        s32 ret = -1;
        // stac();
        if (sbuf != NULL) {
                if (sbuf->magic == SBUF_MAGIC) {
                        vm->sw.vm_event_sbuf = sbuf;
                        INIT_SPIN_LOCK(&vm->vm_event_lock);
                        ret = 0;
                }
        }
        // clac();
        return ret;
}
s32 sbuf_setup_common(struct vmm_guest *vm, u16 cpu_id, u32 sbuf_id, u64 *hva, physical_addr_t hpa) {
        s32 ret = VMM_OK;
        switch (sbuf_id) {
                case VMMU_TRACE:
                case VMMU_HVLOG:
                case VMMU_SEP:
                case VMMU_SOCWATCH:
                        ret = sbuf_share_setup(cpu_id, sbuf_id, hva);
                        break;
                case VMMU_ASYNCIO:
                        ret = init_asyncio(vm, hva, hpa);
                        break;
                case VMMU_VM_EVENT:
                        ret = init_vm_event(vm, hva);
                        break;
                default:
                        pr_info("%s not support sbuf_id %d", __func__, sbuf_id);
                        ret = -1;
                        break;
        }
        return ret;
}
static struct asyncio_desc *get_asyncio_desc(struct vmm_guest *vm, const u64 addr) {
        struct list_head *pos;
        struct asyncio_desc *iter_desc;
        struct asyncio_desc *ret = NULL;
        struct shared_buf *sbuf =
                (struct shared_buf *)vm->sw.asyncio_sbuf;
        if (sbuf != NULL) {
                if (addr != 0UL) {
                        vmm_spin_lock(&vm->asyncio_lock);
                        list_for_each(pos, &vm->aiodesc_queue) {
                                iter_desc = container_of(pos, struct asyncio_desc, list);
                                if (iter_desc->addr == addr) {
                                        ret = iter_desc;
                                        break;
                                }
                        }
                        vmm_spin_unlock(&vm->asyncio_lock);
                }
        }
        return ret;
}

u32 sbuf_next_ptr(u32 pos_arg, u32 span, u32 scope) {
        u32 pos = pos_arg;
        pos += span;
        pos = (pos >= scope) ? (pos - scope) : pos;
        return pos;
}
/**
 * The high caller should guarantee each time there must have
 * sbuf->ele_size data can be write form data.
 *
 * As sbuf->ele_size is possibly setup by some sources outside of the
 * HV (e.g. the service VM), it is not meant to be trusted. So caller
 * should provide the max length of the data for safety reason.
 *
 * And this function should guarantee execution atomically.
 *
 * flag:
 * If OVERWRITE_EN set, buf can store (ele_num - 1) elements at most.
 * Should use lock to guarantee that only one read or write at
 * the same time.
 * if OVERWRITE_EN not set, buf can store (ele_num - 1) elements
 * at most. Shouldn't modify the sbuf->head.
 *
 * return:
 * ele_size:    write succeeded.
 * 0:           no write, buf is full
 * UINT32_MAX:  failed, sbuf corrupted.
 */
/* Started by AICoder, pid:sd83flcbb4w751114d17085c60808734b0257c57 */
u32 sbuf_put(struct shared_buf *sbuf, u8 *data, u32 max_len) {
        void *to;
        u32 next_tail;
        u32 ele_size, ret;
        bool trigger_overwrite = false;
        ele_size = sbuf->ele_size;
        next_tail = sbuf_next_ptr(sbuf->tail, ele_size, sbuf->size);
        if ((next_tail == sbuf->head) && ((sbuf->flags & OVERWRITE_EN) == 0U)) {
                /* 如果覆盖未启用，直接返回0 */
                ret = 0U;
        }
        else if (ele_size <= max_len) {
                if (next_tail == sbuf->head) {
                        /* 如果有必要，累积覆盖计数 */
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        trigger_overwrite = true;
                }
                to = (void *)sbuf + SBUF_HEAD_SIZE + sbuf->tail;
                memmove(to, data, (size_t)ele_size);
                /* 确保在更新头部之前写入数据 */
                arch_smp_mb();
                if (trigger_overwrite) {
                        sbuf->overrun_cnt += sbuf->flags & OVERRUN_CNT_EN;
                        sbuf->head = sbuf_next_ptr(sbuf->head, ele_size, sbuf->size);
                }
                sbuf->tail = next_tail;
                ret = ele_size;
        } else {
                vmm_monitor_mem_fault(NULL, VMM_MONITOR_CCM_ELEMENT_REJECTED,
                                      0, ((u64)ele_size << 32) | max_len);
                ret = U32_MAX;
        }
        return ret;
}
/* Ended by AICoder, pid:sd83flcbb4w751114d17085c60808734b0257c57 */
#if 1
static int insert_asyncio_request(struct vmm_vcpu *vcpu, const u64 asyncio_fd) {
        struct vmm_guest *vm = vcpu->guest;
        struct shared_buf *sbuf =
                (struct shared_buf *)vm->sw.asyncio_sbuf;
        int ret = -ENODEV;
        if (sbuf != NULL) {
                vmm_spin_lock(&vm->asyncio_lock);
                while (sbuf_put(sbuf, (u8 *)&asyncio_fd, (u32)sizeof(asyncio_fd)) == 0U) {
                        /* sbuf is full, try later.. */
                        vmm_spin_unlock(&vm->asyncio_lock);
                        arch_cpu_relax();//vmm_scheduler_yield()，需调度器修改 arm yield?；添加log指示sbuf已经满了
                        vmm_spin_lock(&vm->asyncio_lock);
                }
                vmm_spin_unlock(&vm->asyncio_lock);
                ccm_upcall();
                ret = 0;
        }
        return ret;
}
#endif

static atomic_t ioreq_backend_registered[CONFIG_MAX_GUEST_COUNT];
static struct vmm_waitqueue ioreq_backend_wq[CONFIG_MAX_GUEST_COUNT];
int vmm_u_ioreq_register_backend(u32 target_vmid)
{
        if (target_vmid >= (u32)CONFIG_MAX_GUEST_COUNT) {
                return VMM_EINVALID;
        }
        arch_atomic_write(&ioreq_backend_registered[target_vmid], 1);
        return vmm_waitqueue_wakeall(&ioreq_backend_wq[target_vmid]);
}
int vmm_u_ioreq_unregister_backend(u32 target_vmid)
{
        if (target_vmid >= (u32)CONFIG_MAX_GUEST_COUNT) {
                return VMM_EINVALID;
        }
        arch_atomic_write(&ioreq_backend_registered[target_vmid], 0);
        return VMM_OK;
}
void vmm_u_ioreq_unregister_backend_all(void)
{
        u32 i;
        for (i = 0U; i < (u32)CONFIG_MAX_GUEST_COUNT; i++) {
                arch_atomic_write(&ioreq_backend_registered[i], 0);
        }
}
static s32 insert_io_request(struct vmm_vcpu *vcpu, struct io_request *io_req_src){
        struct io_request_buffer *req_buf;
        int cur;
        struct io_request *io_req_dst;
        s32 ret = VMM_OK;
        u32 guest_id = vcpu->guest->id;
        u64 timeout_usecs;
        struct vmm_completion *vcpu_ioreq_completion = (struct vmm_completion *)vcpu->vmm_u_io_req_wait;
        /* Wait until the backend is registered. */
        while (!arch_atomic_read(&ioreq_backend_registered[guest_id])) {
                timeout_usecs = (u64)(10 * 1000);
                vmm_waitqueue_sleep_timeout(&ioreq_backend_wq[guest_id],
                                            &timeout_usecs);
        }
        if ((vcpu->guest->sw.io_shared_page != NULL)) {
                if (!(get_io_req_state(vcpu->guest, vcpu->subid) &
                      (IOREQ_STATE_FREE | IOREQ_STATE_COMPLETE))) {
                        vmm_linfo(NULL, "%s: Staled ioreq detected, vcpu subid: %u!!\n",
                                   __func__, vcpu->subid);
                        /* Clear staled ioreq. */
                        set_io_req_state(vcpu->guest, vcpu->subid, IOREQ_STATE_FREE);
                }
            req_buf = (struct io_request_buffer *)(vcpu->guest->sw.io_shared_page);
            cur = vcpu->subid;
            io_req_dst = &req_buf->req_slot[cur];
            /* insert request to HSM and inject upcall */
            memcpy(io_req_dst, io_req_src, sizeof(*io_req_dst));
            /* Must clear the signal before we mark req as pending
             * Once we mark it pending, HSM may process req and signal us
             * before we perform upcall.
             * because HSM can work in pulling mode without wait for upcall
             */
            set_io_req_state(vcpu->guest, vcpu->subid, IOREQ_STATE_PENDING);
            INIT_COMPLETION(vcpu_ioreq_completion);
            /* signal HSM */
            ccm_upcall();
            vmm_completion_wait(vcpu_ioreq_completion);
            if (io_req_dst->processed == IOREQ_STATE_COMPLETE) {
                io_req_src->reqs.mmio_req.value = io_req_dst->reqs.mmio_req.value;
                io_req_dst->processed = IOREQ_STATE_FREE; //TODO: why not sync
                arch_flush_dcache_range((u64)io_req_dst, (u64)io_req_dst + sizeof(*io_req_dst));
            } else {
                                vmm_printf("[Hypervisor] invalid io status current:%d\n", io_req_dst->processed);
                        }
        }       
        else {
                        vmm_printf(" io_shared_page is null!!\n");
                        ret = VMM_ENOTAVAIL;
        }
        return ret;
}
int wakeup_io_req(struct vmm_guest *target_vm, u16 id)
{
        int ret = VMM_EINVALID;
        if (id < IOREQ_WAITQ_NUM) {
                struct vmm_vcpu* vcpu = vmm_manager_guest_vcpu(target_vm, (u32)id);
                if (!vcpu) {
                    return ret;
                }
                struct vmm_completion *vcpu_ioreq_completion = vcpu->vmm_u_io_req_wait;
                ret = vmm_completion_complete(vcpu_ioreq_completion);
        }
        else {
                vmm_printf("%s: id=%u not exsit\n", __func__, id);
        }
        //TODO:多虚拟机并发与ServerVM注入io_req，在User-VM注入io_req的时候，会阻塞，然后等待该函数进行唤醒
        //vmm_completion和vCPU强行绑定，目前暂未知为什么没有vCPU阻塞在vmm_completion中
        return ret == VMM_ENOENT ? VMM_OK : ret;
}
int handle_io_request(struct vmm_vcpu *vcpu, physical_addr_t gphys_addr, void *dst, u32 dst_len, bool read) {
        int ret = VMM_OK;
        //struct vmm_guest *server_vm = NULL;
        struct asyncio_desc *aio_desc;
        struct io_request io_req;
        u64 value_tmp = (u64)0;
        /* Started by AICoder, pid:913e4qd455ec62c1460d0b591051ea154e774bf4 */
        switch ((int)dst_len) {
                case 8:
                        value_tmp = *(u64 *)dst;
                        break;
                case 4:
                        value_tmp = (u64)(*(u32 *)dst);
                        break;
                case 2:
                        value_tmp = (u64)(*(u16 *)dst);
                        break;
                case 1:
                        value_tmp = (u64)(*(u8 *)dst);
                        break;
                default:
                        vmm_printf("Invalid dst_len: %d\n", dst_len);
                        ret = VMM_EINVALID;
                        break;
        }
        /* Ended by AICoder, pid:913e4qd455ec62c1460d0b591051ea154e774bf4 */
        if (ret != VMM_OK) {
                return ret;
        }
        aio_desc = get_asyncio_desc(vcpu->guest, gphys_addr);
        if (aio_desc) {
                ret = insert_asyncio_request(vcpu, aio_desc->fd);
        } else {
                if (vcpu) {
            memset(&io_req, 0, sizeof(io_req));
            io_req.type = (u32)VM_EXITCODE_MMIO_EMUL;
            io_req.reqs.mmio_req.direction = read ? IOREQ_DIR_READ : IOREQ_DIR_WRITE;
            io_req.reqs.mmio_req.address = gphys_addr;
            io_req.reqs.mmio_req.size = dst_len;
            io_req.reqs.mmio_req.value = value_tmp;
            ret = insert_io_request(vcpu, &io_req);
                        if (ret == VMM_OK) {
                                value_tmp = io_req.reqs.mmio_req.value;
                                switch ((int)dst_len) {
                                        case 8:
                                                *(u64 *)dst = value_tmp;
                                                break;
                                        case 4:
                                                *(u32 *)dst = (u32)value_tmp;
                                                break;
                                        case 2:
                                                *(u16 *)dst = (u16)value_tmp;
                                                break;
                                        case 1:
                                                *(u8 *)dst = (u8)value_tmp;
                                                break;
                                        default:
                                                vmm_printf("Invalid dst_len: %d\n", dst_len);
                                                ret = VMM_EINVALID;
                                                break;
                                };
                        }
                } else {
                        vmm_printf("Error in %s: vcpu is null\n", __func__);
                        return VMM_EINVALID;
                }
                /* Ended by AICoder, pid:f1511j314f4386a1445108916073a1336e625a36 */
        }
        return ret;
}
int __init vmm_u_ioreq_init(void)
{
        int i;
        for (i = 0; i < CONFIG_MAX_GUEST_COUNT; i++) {
                ARCH_ATOMIC_INIT(&ioreq_backend_registered[i], 0);
                INIT_WAITQUEUE(&ioreq_backend_wq[i], NULL);
        }
        return VMM_OK;
}
