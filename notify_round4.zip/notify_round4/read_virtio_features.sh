#!/system/bin/sh
# Read-only. Run with: sh read_virtio_features.sh eth0
set -eu
IFACE=${1:-eth0}
DEV=$(readlink -f "/sys/class/net/$IFACE/device") || exit 1
[ -r "$DEV/features" ] || {
    echo "No virtio features file at $DEV/features; do not decode an unrelated device." >&2
    exit 1
}
echo "netdev=$IFACE"
echo "device_path=$DEV"
for x in device vendor status; do
    if [ -r "$DEV/$x" ]; then printf '%s=' "$x"; cat "$DEV/$x"; fi
done
printf 'driver='; readlink "$DEV/driver" || true
printf 'features_raw='; cat "$DEV/features"
awk '
{ gsub(/[ \t\r]/, ""); s=$0 }
END {
 if (length(s)<35 || s ~ /[^01]/) {
   print "ERROR: not the upstream low-bit-first binary sysfs format" > "/dev/stderr"; exit 2
 }
 print "# first character is bit0; not a conventional MSB-first binary number"
 printf "INDIRECT_DESC(bit28)=%s\n",substr(s,29,1)
 printf "EVENT_IDX(bit29)=%s\n",substr(s,30,1)
 printf "VERSION_1(bit32)=%s\n",substr(s,33,1)
 printf "ACCESS_PLATFORM(bit33)=%s\n",substr(s,34,1)
 printf "RING_PACKED(bit34)=%s\n",substr(s,35,1)
}' "$DEV/features"
