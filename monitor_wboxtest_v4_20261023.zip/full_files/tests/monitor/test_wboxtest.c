/* Host runner: every assertion resides in the delivered board test sources. */
#include "wboxtest_host.h"
int fake_irq_context, fail_next_trylock;
u64 fake_time;
u32 fake_cpu;
struct vmm_vcpu *fake_idle[CONFIG_CPU_COUNT];
static struct wboxtest *cases[16];
static unsigned count;
int vmm_cprintf(struct vmm_chardev *c,const char *fmt,...) {
    va_list ap; int n; (void)c;
    va_start(ap,fmt); n=vprintf(fmt,ap); va_end(ap); return n;
}
int wboxtest_register(const char *group,struct wboxtest *test) {
    assert(!strcmp(group,"monitor") && count<16); cases[count++]=test; return 0;
}
void wboxtest_unregister(struct wboxtest *test) { (void)test; }
int monitor_lifecycle_init_host(void);
int monitor_config_init_host(void);
int monitor_scheduler_init_host(void);
int monitor_memory_init_host(void);
int monitor_storm_init_host(void);
int monitor_output_init_host(void);
int main(void) {
    unsigned i,n; int failures=0;
    assert(!monitor_lifecycle_init_host()); assert(!monitor_config_init_host());
    assert(!monitor_scheduler_init_host()); assert(!monitor_memory_init_host());
    assert(!monitor_storm_init_host()); assert(!monitor_output_init_host());
    assert(count==6);
    for(n=0;n<3;n++) for(i=0;i<count;i++) {
        int rc=cases[i]->run(cases[i],NULL,n);
        printf("%s iteration=%u %s\n",cases[i]->name,n,rc?"FAIL":"PASS");
        if(rc) failures++;
    }
    return failures ? 1 : 0;
}
