#include "host.h"
#include <vmm_monitor.h>
static unsigned calls;
static u64 side_effect(void) { calls++; return 1; }
int main(void) {
    vmm_monitor_state(NULL,side_effect(),side_effect());
    vmm_monitor_selected(NULL,side_effect());
    vmm_monitor_dispatch(NULL,side_effect(),side_effect());
    vmm_monitor_exit(NULL,side_effect());
    vmm_monitor_mem_fault(NULL,side_effect(),side_effect(),side_effect());
    assert(!calls && !vmm_monitor_init()); (void)side_effect; return 0;
}
