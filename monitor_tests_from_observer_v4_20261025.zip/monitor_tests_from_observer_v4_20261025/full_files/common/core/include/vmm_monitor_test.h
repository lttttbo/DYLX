/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef VMM_MONITOR_TEST_H
#define VMM_MONITOR_TEST_H
#include <vmm_monitor.h>

/* Test-only read access. No reset, injection, sampler or drain entry points. */
struct vmm_monitor_test_latency { u64 count, sum, max; };
struct vmm_monitor_test_state {
	u32 epoch, enabled, config_seq, config[VMM_MONITOR_CONFIG_KEYS];
	u32 skipped, errors;
	u64 head, lost;
};
struct vmm_monitor_test_slot {
	u32 epoch, guest, kind, config_seq;
	bool present, waiting, valid, active;
	u64 ready_since, previous, interval, exits;
	struct vmm_monitor_test_latency ready, dispatch;
};
struct vmm_monitor_test_event {
	u64 seq, time_ns, last_ns, value, address, detail;
	u32 type, guest, vcpu, epoch, code, config_seq, sustain_s;
	bool log_returned;
	u32 log_calls;
};
#ifdef CONFIG_WBOXTEST_MONITOR
int vmm_monitor_test_sample_serial(u64 *out);
int vmm_monitor_test_state(struct vmm_monitor_test_state *out);
int vmm_monitor_test_slot(u32 id, struct vmm_monitor_test_slot *out);
int vmm_monitor_test_event(u64 seq, struct vmm_monitor_test_event *out);
#endif
#endif
