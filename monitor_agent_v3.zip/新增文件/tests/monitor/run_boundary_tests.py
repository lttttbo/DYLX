"""Compile production shmem access bodies against controlled mapping/backing APIs.
The test exercises actual upstream-facing wrapper bodies, not a reimplementation.
No target kernel module or board execution is claimed.
"""
import argparse, os, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--cc',required=True)
p.add_argument('--build-dir',required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
out=Path(a.build_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
cc=[a.cc,'cc'] if Path(a.cc).stem=='zig' else [a.cc]
flags=['-std=gnu11','-O2','-Wall','-Wextra','-Werror']
source=(root/'core/vmm_shmem.c').read_text()
body=source[source.index('static inline bool shmem_range'):source.index('int vmm_shmem_iterate')]
prefix=r'''
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef uint64_t u64;
typedef uint64_t physical_addr_t;
typedef uint64_t physical_size_t;
typedef unsigned bool;
#define TRUE 1
#define FALSE 0
#define VMM_REGION_REAL 1
#define VMM_REGION_VIRTUAL 2
#define VMM_REGION_ALIAS 4
#define VMM_REGION_MEMORY 8
#define VMM_REGION_READONLY 128
#define VMM_REGION_ISRAM 256
#define VMM_REGION_ISSHARED 16384
#define VMM_MONITOR_SHMEM_BOUNDS 1
#define VMM_MONITOR_ACCESS_DENIED 3
#define vmm_shmem_guest_read(v,s,g,o,b,n,c) vmm_shmem_guest_access(v,s,g,o,b,n,c,FALSE)
#define vmm_shmem_guest_write(v,s,g,o,b,n,c) vmm_shmem_guest_access(v,s,g,o,b,n,c,TRUE)
struct vmm_guest { unsigned id; };
struct vmm_vcpu { bool is_normal; struct vmm_guest *guest; };
struct vmm_region { u32 flags; };
struct vmm_shmem { u64 addr,size; };
static struct vmm_region reg={VMM_REGION_REAL|VMM_REGION_MEMORY|VMM_REGION_ISSHARED};
static unsigned accesses,faults,last_kind,actor_id;
static u64 last_address;
static bool vmm_monitor_range_valid(u64 size,u64 offset,u64 length) { return offset<=size && length<=size-offset; }
static void vmm_monitor_mem_fault(struct vmm_vcpu *v,u32 k,u64 address,u64 detail) { (void)detail; faults++; last_kind=k; actor_id=v?v->guest->id:~0U; last_address=address; }
static struct vmm_region *vmm_guest_find_region(struct vmm_guest *g,u64 gpa,u32 flags,bool aliases) { (void)g; (void)flags; (void)aliases; return gpa>=100 && gpa<132?&reg:NULL; }
static int vmm_guest_physical_map(struct vmm_guest *g,u64 gpa,u64 length,u64 *hpa,u64 *available,u32 *flags) { (void)length; *hpa=(g->id?2000:200)+gpa-100; *available=132-gpa; *flags=reg.flags; return 0; }
static u32 vmm_host_memory_read(u64 addr,void *data,u32 len,bool cacheable) { (void)addr; (void)data; (void)cacheable; accesses++; return len; }
static u32 vmm_host_memory_write(u64 addr,void *data,u32 len,bool cacheable) { return vmm_host_memory_read(addr,data,len,cacheable); }
static u32 vmm_host_memory_set(u64 addr,u8 value,u32 len,bool cacheable) { return vmm_host_memory_read(addr,&value,len,cacheable); }
u32 vmm_shmem_read(struct vmm_shmem *,u64,void *,u32,bool);
u32 vmm_shmem_write(struct vmm_shmem *,u64,void *,u32,bool);
'''
suffix=r'''
int main(void) {
    struct vmm_guest guest={0},other={1};
    struct vmm_vcpu v={TRUE,&guest},w={TRUE,&other};
    struct vmm_shmem shm={200,32}; unsigned char data[32]; unsigned before;
    assert(vmm_shmem_guest_read(&v,&shm,110,10,data,5,FALSE)==5 && accesses==1);
    assert(vmm_shmem_guest_write(&v,&shm,110,10,data,5,FALSE)==5 && accesses==2);
    before=accesses;
    assert(!vmm_shmem_guest_write(&w,&shm,110,10,data,5,FALSE));
    assert(accesses==before && actor_id==1 && last_kind==VMM_MONITOR_ACCESS_DENIED);
    assert(!vmm_shmem_guest_read(&v,&shm,131,31,data,2,FALSE));
    assert(last_kind==VMM_MONITOR_SHMEM_BOUNDS && last_address==131);
    reg.flags|=VMM_REGION_READONLY;
    assert(!vmm_shmem_guest_write(&v,&shm,110,10,data,5,FALSE));
    assert(vmm_shmem_guest_read(&v,&shm,110,10,data,5,FALSE)==5);
    reg.flags|=VMM_REGION_ALIAS;
    assert(!vmm_shmem_guest_read(&v,&shm,110,10,data,5,FALSE));
    reg.flags=VMM_REGION_VIRTUAL|VMM_REGION_MEMORY;
    assert(!vmm_shmem_guest_read(&v,&shm,110,10,data,5,FALSE));
    before=accesses;
    assert(!vmm_shmem_guest_read(NULL,&shm,110,10,data,5,FALSE));
    assert(!vmm_shmem_read(&shm,~0ULL-1,data,4,FALSE));
    assert(!vmm_shmem_write(&shm,32,data,1,FALSE));
    assert(!vmm_shmem_set(&shm,33,0,0,FALSE));
    shm.addr=~0ULL-1;
    assert(!vmm_shmem_read(&shm,1,data,3,FALSE));
    assert(accesses==before && faults>=7);
    puts("PASS: production shmem ranges, mapping ownership, read-only, aliases, overflow, no rejected backing access"); return 0;
}
'''
test=out/'shmem_test.c'; test.write_text(prefix+body+suffix)
exe=out/'shmem.exe'
subprocess.run(cc+flags+[str(test),'-o',str(exe)],check=True)
r=subprocess.run([str(exe)],capture_output=True,text=True,check=True)
print(r.stdout.strip()); (out/'shmem.txt').write_text(r.stdout)
