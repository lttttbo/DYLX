/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_scheduler.h>
#include <vmm_guest_aspace.h>
#include <vmm_host_ram.h>
#include <vmm_host_aspace.h>
#include <vmm_shmem.h>
#include <vmm_mutex.h>
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/stringlib.h>
#include <libs/wboxtest.h>

#define H_U(x) ((unsigned long long)(x))
#define H_TIMEOUT (8ULL * VMM_MONITOR_NS)
#define H_UNKNOWN (~0U)
static DEFINE_MUTEX(host_test_lock);
struct host_case {
    struct vmm_chardev *out;
    struct vmm_monitor_test_state initial;
    const char *name, *phase;
    u32 actor;
    bool locked, initialized;
};
struct checkpoint {
    u64 head, serial, started;
    u32 actor;
};
#define H_CHECK(x) do { if (!(x)) { \
    vmm_cprintf(out, "monitor_host FAIL test=%s %s:%u: %s\n", c.name, __func__, __LINE__, #x); \
    rc = VMM_EFAIL; goto done; } } while (0)

static int stable(struct host_case *c, struct vmm_monitor_test_state *s)
{
    int rc = vmm_monitor_test_state(s);
    if (rc) {
        vmm_cprintf(c->out, "monitor_host FAIL test=%s phase=%s: state read rc=%d\n", c->name, c->phase, rc);
        return rc;
    }
    /* skipped is global: contention on an unrelated slot is not our failure.
     * sampled() separately proves progress of the actor under test. */
    if (!s->enabled || s->enabled != c->initial.enabled ||
        s->epoch != c->initial.epoch || s->config_seq != c->initial.config_seq ||
        s->lost != c->initial.lost || s->errors != c->initial.errors) {
        vmm_cprintf(c->out, "monitor_host FAIL test=%s phase=%s: state changed "
            "enabled=%u->%u epoch=%u->%u config_seq=%u->%u lost=%llu->%llu "
            "errors=%u->%u skipped=%u->%u\n", c->name, c->phase,
            c->initial.enabled, s->enabled, c->initial.epoch, s->epoch,
            c->initial.config_seq, s->config_seq, H_U(c->initial.lost), H_U(s->lost),
            c->initial.errors, s->errors, c->initial.skipped, s->skipped);
        return VMM_EFAIL;
    }
    return VMM_OK;
}
static int actor_serial(struct host_case *c, u32 actor, u64 *serial)
{
    int rc = vmm_monitor_test_sample_actor(actor, serial);
    if (rc) vmm_cprintf(c->out, "monitor_host FAIL test=%s phase=%s: actor=%u progress read rc=%d\n",
                       c->name, c->phase, actor, rc);
    return rc;
}
static int checkpoint(struct host_case *c, struct checkpoint *p, u32 actor)
{
    struct vmm_monitor_test_state s;
    int rc;
    c->phase = "checkpoint";
    rc = stable(c, &s);
    if (rc) return rc;
    rc = actor_serial(c, actor, &p->serial);
    if (rc) return rc;
    p->head = s.head; p->actor = actor;
    p->started = vmm_timer_timestamp();
    return VMM_OK;
}
static int sampled(struct host_case *c, u32 actor, u64 before)
{
    struct vmm_monitor_test_state s;
    u64 serial = before, global = 0, start = vmm_timer_timestamp();
    int rc;
    for (;;) {
        rc = stable(c, &s);
        if (rc) return rc;
        rc = actor_serial(c, actor, &serial);
        if (rc) return rc;
        /* Two successful target flushes, including a possible in-flight pass.
         * Unsigned subtraction handles the counter's wraparound. */
        if (serial - before >= 2) return VMM_OK;
        if (vmm_timer_timestamp() - start >= H_TIMEOUT) break;
        vmm_msleep(20);
    }
    vmm_monitor_test_sample_serial(&global);
    vmm_cprintf(c->out, "monitor_host FAIL test=%s phase=%s: target sampling timeout "
        "actor=%u completed=%llu need=2 global_passes=%llu skipped=%u->%u wait_ns=%llu\n",
        c->name, c->phase, actor, H_U(serial - before), H_U(global),
        c->initial.skipped, s.skipped, H_U(vmm_timer_timestamp() - start));
    return VMM_ETIMEDOUT;
}
static int flush_actor(struct host_case *c, u32 actor)
{
    u64 serial;
    int rc;
    c->phase = "baseline";
    rc = actor_serial(c, actor, &serial);
    return rc ? rc : sampled(c, actor, serial);
}
static int begin(struct host_case *c, struct vmm_chardev *out, const char *name)
{
    struct vmm_vcpu *v;
    int rc;
    memset(c, 0, sizeof(*c)); c->out = out; c->name = name; c->phase = "begin";
    if (!vmm_mutex_trylock(&host_test_lock)) {
        vmm_cprintf(out, "monitor_host FAIL test=%s: another host test is running\n", name);
        return VMM_EBUSY;
    }
    c->locked = TRUE;
    v = vmm_scheduler_current_vcpu();
    if (!v || v->is_normal || v->id >= CONFIG_MAX_VCPU_COUNT) {
        vmm_cprintf(out, "monitor_host FAIL test=%s: runner must be a valid host vCPU\n", name);
        return VMM_ENOTAVAIL;
    }
    c->actor = v->id;
    rc = vmm_monitor_test_state(&c->initial);
    if (rc || !c->initial.enabled) {
        vmm_cprintf(out, "monitor_host FAIL test=%s: run monitor start before this test (state_rc=%d enabled=%u)\n",
                    name, rc, c->initial.enabled);
        return rc ? rc : VMM_ENOTAVAIL;
    }
    c->initialized = TRUE;
    return flush_actor(c, c->actor); /* Wait; never force sample() or drain(). */
}
static int end(struct host_case *c, int rc)
{
    struct vmm_monitor_test_state s;
    if (c->initialized && !vmm_monitor_test_state(&s) && s.skipped != c->initial.skipped)
        vmm_cprintf(c->out, "monitor_host INFO test=%s: global skipped=%u->%u; target progress checked separately\n",
                    c->name, c->initial.skipped, s.skipped);
    if (c->locked) vmm_mutex_unlock(&host_test_lock);
    return rc;
}
static int observed(struct host_case *c, const struct checkpoint *p, u32 actor,
                    u32 code, u64 address, u64 detail, bool expected)
{
    struct vmm_monitor_test_state s;
    struct vmm_monitor_test_event e;
    u64 seq;
    u32 found = 0;
    int rc;
    c->phase = "event";
    if (p->actor != actor) {
        vmm_cprintf(c->out, "monitor_host FAIL test=%s: checkpoint actor=%u expected=%u\n", c->name, p->actor, actor);
        return VMM_EINVALID;
    }
    rc = sampled(c, actor, p->serial);
    if (rc) return rc;
    rc = stable(c, &s);
    if (rc) return rc;
    if (s.head < p->head || s.head - p->head > VMM_MONITOR_EVENTS) {
        vmm_cprintf(c->out, "monitor_host FAIL test=%s: event window overwritten head=%llu->%llu\n",
                    c->name, H_U(p->head), H_U(s.head));
        return VMM_EFAIL;
    }
    for (seq = p->head + 1; seq <= s.head; seq++) {
        rc = vmm_monitor_test_event(seq, &e);
        if (rc) {
            vmm_cprintf(c->out, "monitor_host FAIL test=%s: event seq=%llu unavailable rc=%d\n", c->name, H_U(seq), rc);
            return rc;
        }
        if (e.type != 3 || e.vcpu != actor) continue;
        /* Do not accept an unrelated/aggregated failure as our evidence. */
        if (!expected || e.guest != H_UNKNOWN || e.epoch != c->initial.epoch ||
            e.code != code || e.address != address || e.detail != detail ||
            e.value != 1 || e.time_ns < p->started || e.last_ns < e.time_ns) {
            vmm_cprintf(c->out, "monitor_host FAIL test=%s: event mismatch seq=%llu "
                "actor=%u guest=%u epoch=%u value=%llu time_ns=%llu last_ns=%llu "
                "actual(code,address,detail)=(%u,%llu,%llu) "
                "expected=(%u,%llu,%llu) expect_event=%u since_ns=%llu\n", c->name,
                H_U(e.seq), actor, e.guest, e.epoch, H_U(e.value), H_U(e.time_ns), H_U(e.last_ns),
                e.code, H_U(e.address), H_U(e.detail), code, H_U(address), H_U(detail),
                (u32)expected, H_U(p->started));
            return VMM_EFAIL;
        }
        found++;
        vmm_cprintf(c->out, "monitor_host EVENT seq=%llu epoch=%u vcpu=%u code=%u address=%llu detail=%llu; log=manual\n",
            H_U(e.seq), e.epoch, e.vcpu, e.code, H_U(e.address), H_U(e.detail));
    }
    if (found != (expected ? 1U : 0U)) {
        vmm_cprintf(c->out, "monitor_host FAIL test=%s: event count=%u expected=%u actor=%u code=%u head=%llu->%llu\n",
                    c->name, found, expected ? 1U : 0U, actor, code, H_U(p->head), H_U(s.head));
        return VMM_EFAIL;
    }
    return VMM_OK;
}

static bool rejected_candidate(physical_addr_t a, physical_addr_t *out)
{
    u32 kind;
    /* Fixed safe arithmetic; the probe never maps or dereferences a. */
    if (a > ~(physical_addr_t)0 - 4) return FALSE;
    if (vmm_monitor_host_probe(a, 1, &kind) == VMM_EFAIL) {
        *out = a; return TRUE;
    }
    return FALSE;
}
static bool find_rejected(physical_addr_t *out)
{
    u32 i;
    physical_addr_t start, last;
    physical_size_t size;
    if (rejected_candidate(0, out)) return TRUE;
    for (i = 0; i < vmm_host_ram_bank_count(); i++) {
        start = vmm_host_ram_bank_start(i); size = vmm_host_ram_bank_size(i);
        if (start && rejected_candidate(start - 1, out)) return TRUE;
        if (size <= ~(physical_addr_t)0 - start) {
            last = start + size;
            if (rejected_candidate(last, out)) return TRUE;
        }
    }
    return rejected_candidate((~(physical_addr_t)0) & ~((physical_addr_t)VMM_PAGE_MASK), out);
}
static int range_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    physical_addr_t bad;
    int rc = begin(&c, out, test->name);
    (void)test; (void)cpu;
    if (rc) goto done;
    if (!find_rejected(&bad)) {
        vmm_cprintf(out, "monitor_host: no address rejected by existing command policy\n");
        rc = VMM_ENOTAVAIL; goto done;
    }
    H_CHECK(!checkpoint(&c, &p, c.actor));
    H_CHECK(vmm_monitor_host_guard(out, bad, 1, FALSE) == VMM_ERANGE);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_HOST_RANGE_REJECT, bad, 1, TRUE));
    H_CHECK(!checkpoint(&c, &p, c.actor));
    H_CHECK(vmm_monitor_host_guard(out, bad, 1, TRUE) == VMM_EFAIL);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_HOST_RANGE_REJECT, bad, (1ULL << 32) | 1, TRUE));
done:
    return end(&c, rc);
}

struct candidates {
    physical_addr_t address[64];
    u32 guest[64], count;
};
static void collect_mapping(struct vmm_guest *g, struct vmm_region *r,
                            physical_addr_t gpa, physical_addr_t hpa,
                            physical_size_t size, void *arg)
{
    struct candidates *list = arg;
    u32 i;
    physical_addr_t start, candidate;
    physical_size_t bank_size;
    (void)r; (void)gpa;
    if (!size || list->count == 64) return;
    for (i = 0; i < vmm_host_ram_bank_count(); i++) {
        start = vmm_host_ram_bank_start(i); bank_size = vmm_host_ram_bank_size(i);
        candidate = hpa > start ? hpa : start;
        if (candidate - hpa < size && candidate - start < bank_size &&
            candidate < ~(physical_addr_t)0) {
            list->address[list->count] = candidate;
            list->guest[list->count++] = g->id;
            break;
        }
    }
}
static void collect_region(struct vmm_guest *g, struct vmm_region *r, void *arg)
{
    vmm_guest_iterate_mapping(g, r, collect_mapping, arg);
}
static int collect_guest(struct vmm_guest *g, void *arg)
{
    vmm_guest_iterate_region(g, VMM_REGION_REAL | VMM_REGION_MEMORY | VMM_REGION_ISRAM,
                             collect_region, arg);
    vmm_guest_iterate_region(g, VMM_REGION_ISROM, collect_region, arg);
    return VMM_OK;
}
static int guest_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    struct candidates list = {0};
    u32 i, kind;
    int rc = begin(&c, out, test->name);
    (void)test; (void)cpu;
    if (rc) goto done;
    H_CHECK(!vmm_manager_guest_iterate(collect_guest, &list));
    /* Probe AFTER leaving the manager iterator: probe itself iterates Guests. */
    for (i = 0; i < list.count; i++)
        if (!vmm_monitor_host_probe(list.address[i], 1, &kind) && kind == VMM_MONITOR_HOST_GUEST) break;
    if (i == list.count) {
        vmm_cprintf(out, "monitor_host: no existing Guest mapping reaches the command write-denial branch\n");
        rc = VMM_ENOTAVAIL; goto done;
    }
    vmm_cprintf(out, "monitor_host: candidate guest=%u hpa=%llu; policy check only, no write\n",
                list.guest[i], H_U(list.address[i]));
    H_CHECK(!checkpoint(&c, &p, c.actor));
    H_CHECK(vmm_monitor_host_guard(out, list.address[i], 1, TRUE) == VMM_EFAIL);
    H_CHECK(!observed(&c, &p, c.actor, VMM_MONITOR_ACCESS_DENIED,
                     list.address[i], (1ULL << 32) | 1, TRUE));
done:
    return end(&c, rc);
}
static int shmem_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
    struct host_case c;
    struct checkpoint p;
    struct vmm_shmem *shm = NULL;
    u8 input[16], first[16], last[16], data[16];
    u32 kind;
    int rc = begin(&c, out, test->name);
    (void)test; (void)cpu;
    if (rc) goto done;
    /* Flush older NULL-actor reports before the first shared-memory check. */
    rc = flush_actor(&c, H_UNKNOWN);
    if (rc) goto done;
    shm = vmm_shmem_create("monitor-host-test", VMM_PAGE_SIZE, VMM_PAGE_SHIFT, NULL);
    if (VMM_IS_ERR_OR_NULL(shm)) {
        vmm_cprintf(out, "monitor_host FAIL test=%s: cannot create private shmem object\n", c.name);
        shm = NULL; rc = VMM_ENOMEM; goto done;
    }
    H_CHECK(shm->size >= sizeof(input) * 2);
    memset(input, 0x5a, sizeof(input));
    /* Positive command checks use ONLY our allocated page and access nothing. */
    H_CHECK(!vmm_monitor_host_probe(shm->addr, 1, &kind) && kind == VMM_MONITOR_HOST_RAM);
    H_CHECK(!checkpoint(&c, &p, c.actor));
    H_CHECK(!vmm_monitor_host_guard(out, shm->addr, 1, FALSE));
    H_CHECK(!vmm_monitor_host_guard(out, shm->addr, 1, TRUE));
    H_CHECK(!observed(&c, &p, c.actor, 0, 0, 0, FALSE));
    H_CHECK(!checkpoint(&c, &p, H_UNKNOWN));
    H_CHECK(vmm_shmem_write(shm, 0, input, sizeof(input), TRUE) == sizeof(input));
    H_CHECK(vmm_shmem_write(shm, shm->size - sizeof(input), input, sizeof(input), TRUE) == sizeof(input));
    H_CHECK(vmm_shmem_set(shm, shm->size - 8, 0xa5, 8, TRUE) == 8);
    H_CHECK(vmm_shmem_read(shm, 0, first, sizeof(first), TRUE) == sizeof(first));
    H_CHECK(!memcmp(first, input, sizeof(first)));
    H_CHECK(vmm_shmem_read(shm, shm->size - sizeof(last), last, sizeof(last), TRUE) == sizeof(last));
    H_CHECK(last[7] == 0x5a && last[8] == 0xa5 && last[15] == 0xa5);
    H_CHECK(!observed(&c, &p, H_UNKNOWN, 0, 0, 0, FALSE));
    memset(data, 0xcc, sizeof(data));
    H_CHECK(!checkpoint(&c, &p, H_UNKNOWN));
    H_CHECK(!vmm_shmem_read(shm, shm->size, data, 1, TRUE) && data[0] == 0xcc);
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size, 1, TRUE));
    H_CHECK(!checkpoint(&c, &p, H_UNKNOWN));
    H_CHECK(!vmm_shmem_write(shm, shm->size - 1, input, 2, TRUE));
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size - 1, 2, TRUE));
    H_CHECK(!checkpoint(&c, &p, H_UNKNOWN));
    H_CHECK(!vmm_shmem_set(shm, shm->size, 0, 1, TRUE));
    H_CHECK(!observed(&c, &p, H_UNKNOWN, VMM_MONITOR_SHMEM_BOUNDS, shm->size, 1, TRUE));
    H_CHECK(vmm_shmem_read(shm, 0, data, sizeof(data), TRUE) == sizeof(data));
    H_CHECK(!memcmp(data, first, sizeof(data)));
    H_CHECK(vmm_shmem_read(shm, shm->size - sizeof(data), data, sizeof(data), TRUE) == sizeof(data));
    H_CHECK(!memcmp(data, last, sizeof(data)));
done:
    if (shm) vmm_shmem_destroy(shm);
    return end(&c, rc);
}

#define HOST_REGISTER(test_name, fn) \
static struct wboxtest test_name = {.name = #test_name, .run = fn}; \
static int __init test_name##_init(void) { return wboxtest_register("monitor", &test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name, #test_name, "Monitor maintainers", "GPL", WBOXTEST_IPRIORITY + 1, test_name##_init, test_name##_exit)
HOST_REGISTER(monitor_host_range, range_run);
HOST_REGISTER(monitor_host_guest_guard, guest_run);
HOST_REGISTER(monitor_host_shmem, shmem_run);
