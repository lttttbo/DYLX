# Monitor wboxtest v4

日期：2026-10-23。基于已经合入的 v4 全调度对象监控。

新增 monitor 白盒组及 CONFIG_WBOXTEST_MONITOR（默认关闭）。六个用例：
monitor_lifecycle、monitor_config、monitor_scheduler、monitor_memory、monitor_storm、monitor_output。

## 合入内容

- main.patch：只修改 libs/wboxtest/openconf.cfg 的一个配置入口，新增 libs/wboxtest/monitor/ 下9个文件。
- full_files/：全部修改后和新增文件的完整内容，按工程目录排列。
- merge_locations.txt：已有文件参考行号、锚点和新文件路径。
- host_tests_and_docs.patch：开发机复现脚本与详细说明，可选合入，不进入目标固件。
- design.md：每个用例的输入、断言、隔离原理、命令和验收边界。
- validation/：ARM64编译、主机执行、隔离检查和故意注入错误后的检测记录。
- SHA256SUMS.txt：交付校验。

先在工程副本执行 git apply --check main.patch；有私有差异时按定位说明合入。
不需要修改已有 scheduler 或生产监控代码，也不需要提高 monitor 线程优先级。

## 编译与执行

CONFIG_MONITOR_AGENT=y
CONFIG_CMD_MONITOR=y
CONFIG_WBOXTEST=y
CONFIG_CMD_WBOXTEST=y
CONFIG_WBOXTEST_MONITOR=y

wboxtest group_list
wboxtest test_list
wboxtest run_groups 1 monitor
wboxtest run_groups 10 monitor

也可单独执行，例如：wboxtest run_tests 1 monitor_storm
核对 monitor 组中有全部六个用例。每个用例应 passed，并显示 failures 0 out of N，N>0。
不能仅凭命令返回成功判断通过；当前公共 wboxtest 命令不传播各用例的失败状态。

## 隔离与覆盖范围

测试直接编译工程内的生产实现，使用私有槽、虚拟时间、模拟Guest映射和固定输出缓冲。
不会 start/stop 业务 monitor，不与真实 timer 竞争，不注册第二个 monitor 命令，不向业务日志注入模拟异常。
共享内存检查走真实访问检查实现，实际读写仅触达32字节测试缓冲。
用例在 run 内初始化和清理，不依赖上游 setup 失败后的处理方式。

本批验证统计和判定逻辑、配置解析、边界拒绝、去重及输出关键字段。
不等同于真实scheduler点位、Guest stage-2异常、真实exit入口、硬件IRQ、日志落盘、CPU占用或ROM预算验收。
生产测量时关闭测试开关。原生产监控容量问题不由本测试包解决。

## 已验证

ARM64实际工程头文件编译：6个新增C文件，内部执行/外部执行/开机启用三种配置均通过。
同一批白盒源码主机执行：6个用例 × 3轮 × 3种配置，共54次通过。
隔离符号、测试init代码保留位置及生产monitor对象字节一致性检查通过。
独立副本故意引入READY起点刷新、门限大于等于、只读检查绕过三种错误，均被对应测试检出。
补丁应用后文件一致性和反向检查通过；未执行完整固件链接、产品QEMU或目标板运行。
