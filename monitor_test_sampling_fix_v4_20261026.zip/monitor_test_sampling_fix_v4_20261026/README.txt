Monitor v4 采样等待判据修正 / 2026-10-26

一、这批输出能说明什么
原六项隔离用例通过；三项实际 Hypervisor 内存用例失败，不能将本次结果算成整体通过。
三项都在约 1 秒结束且没有 H_CHECK 提示，符合公共 begin()/sampled()/stable() 提前返回的路径。
原 stable() 将整个 monitor 的 skipped 计数增加视为失败，即使锁竞争发生在其他 vCPU。
开发机模型已复现：只跳过 slot 0，而测试实际使用 actor 2/NULL，三个旧用例仍全部返回 -1。
这是已确认的测试判据缺陷；你的板端是否正好由此触发，仍需前后 monitor status 或新版诊断确认。
lost/errors、配置或 epoch 改变也可能使原代码在此处失败，本包不会掩盖这些问题。

二、你当前已经运行九项统一测试：只合入根目录的三文件修正
  fix_installed_flat.patch
  full_files/core/include/vmm_monitor.h
  full_files/core/monitor/monitor_agent.c
  full_files/libs/wboxtest/monitor/memory_runtime.c

小修正以 monitor_tests_flat_v4_20261025 为准确基线，仅修改上述三个文件。
私有工程请按 merge_locations.txt 的函数/位置合入；完整文件供对照，不要覆盖自己的其他改动。
三个文件必须一起更新，否则会出现新增只读测试接口的声明或链接错误。
原 memory.c 已通过，无需再次修改；reference 中保留上次兼容修正后的完整文件供核对。
不增加目录层级、头文件或编译选项；继续只有 CONFIG_WBOXTEST_MONITOR。

三、若从最初记录版重新合入
observer_base/from_observer.patch 直接以 monitor_observer_from_20261023_v4_20261025 为基线，
包含之前统一测试整理及本次修正。它与根目录小修正是二选一路线，不要叠加应用。
observer_base/cmd_memory_from_uploaded.patch 是之前原命令打点/只读适配，内容未改变；
已合入命令改动的工程不要重复应用。该补丁以你原上传 cmd_memory.c 为基线。
observer_base/full_files 给出该路线对应完整文件；原文件删改位置见其中 previous_merge_locations.txt，
本次采样修正位置仍见根目录 merge_locations.txt。CCM、共享内存原策略及 Guest 不变。

四、修正原理
在测试开关内添加静态数组 test_sample_actor，每个槽位一个 u64，额外 RAM 为
8*(CONFIG_MAX_VCPU_COUNT+1) 字节，无动态分配，关闭测试后整个数组和接口消失。
采样器只有成功获得对应槽位锁并执行 memory_flush 后才递增其计数。
只读接口 vmm_monitor_test_sample_actor(actor,out) 读取该计数；actor=~0U 指 NULL/shmem 槽位。
计数不随 start/stop、slot RESET 或 epoch 更新清零；用例另行校验 enabled/epoch/config_seq。
每一步等待目标槽位两次成功采样；全局 skipped 的增长只输出 INFO。
目标槽位一直跳过，即便全局 sampler 持续运行，也会在该步骤最多 8 秒后失败。
合法访问的“无事件”断言同样必须等待目标槽位，不能因没采到而假通过。
共享内存接口 actor=NULL，单独建立并等待 NULL 槽位基线。
仍核对事件 type/actor/guest/epoch/code/address/detail/value/时间；漏记、错码、聚合混入、覆盖不算成功。
仍拒绝运行期间的启停、配置改变、lost/errors 增加；不改日志是否落盘的人工验收约定。
测试不主动调用 sample/drain，不提高 monitor 优先级，不新增访问控制策略。

五、重新测试
重新编译并启动修正后的固件，然后执行：
  monitor start
  monitor status
  unittest run_groups 1 monitor
  monitor status
测试期间保持配置和 VM 映射稳定；monitor_host_guest_guard 仍需存在原策略会拒绝写入的 Guest 映射。
正常时 range 约 6 秒、guest_guard 约 4 秒、shmem 约 14 秒，仅为 1 秒周期模型估计；
真实调度/锁竞争可延长，总体不是原先约 1 秒失败就结束的行为。

输出解释：
  INFO ... global skipped=A->B; target progress checked separately
    全局有锁竞争跳过，但通过与否取决于本用例目标的进度和事件，INFO 不表示错误。
  FAIL ... phase=baseline/event: target sampling timeout actor=N completed=0 need=2 ...
    指定目标没有足够采样进度；N=4294967295 是 NULL/shared-memory 槽位。
  FAIL ... state changed enabled=... epoch=... config_seq=... lost=... errors=... skipped=...
    显示初始值与当前值；除 skipped 外的稳定性条件发生了变化。
  FAIL ... event count=0 expected=1 ...
    目标已采样但没有匹配记录，继续检查生产打点是否正确合入、事件主体是否一致。
  FAIL ... event mismatch ...
    已出现该主体内存事件，但字段不符合预期；可能是错码或其他事件干扰，需要按输出定位。
  no existing Guest mapping ...
    测试前置条件不足；不是“越权检查已验证通过”。
若仍失败，保留完整 monitor_host FAIL 行及前后 status 第一行即可继续定位。

六、本次验证与限制
- ARM64 严格编译：开启测试 9 个当前编译单元、关闭测试 2 个单元，另检查归档 Guest 源码；
  无重复全局符号，关闭时全部 7 个测试接口消失。
- 测试关闭时 monitor_agent 的可装载节内容/大小与上一版相同。
- 原六项隔离用例 54 次执行通过；三种模式只读接口回归及 8 项证据解析回归通过。
- 18 组开发机模型场景全部符合预期，含 360 组命令原策略返回/分类对照。
  无关采样跳过和目标偶发跳过可通过；目标/NULL 槽位持续饥饿、事件阶段饥饿、漏记、错码、
  无采样器、监控关闭、lost/errors/epoch/config 变化均按预期检出。
  反例模型报告 PASS 表示“成功检测预期的用例失败”，不是对应功能场景已在板端通过。
- 小修正、直接记录版补丁、原命令补丁、可选工具补丁的应用/结果/反向还原校验通过。
本次没有你的完整私有固件，也未连接你的 QEMU/板卡，不能代替板端复测。
现有九项用例仍不能单独证明所有 Guest 访问、真实 Guest exit/调度全链路及 ROM/CPU 占用要求。
optional_verification 仅为开发机模型工具增量，不参与固件构建；无需为板端测试合入。
