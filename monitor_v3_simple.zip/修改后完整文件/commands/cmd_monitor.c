/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_cmdmgr.h>
#include <vmm_stdio.h>
#include <libs/stringlib.h>
static void monitor_usage(struct vmm_chardev *cdev)
{
	vmm_cprintf(cdev, "monitor start|stop|status|events|config\n"
		"monitor config exit_limit|sustain_s|window_min_ms|window_max_ms <decimal>\n");
}
static int monitor_exec(struct vmm_chardev *cdev, int argc, char **argv)
{
	static const char *const keys[] = {"exit_limit", "sustain_s", "window_min_ms", "window_max_ms"};
	const char *p;
	u32 key, value = 0, digit;
	int rc;
	if (argc == 2) {
		if (!strcmp(argv[1], "start")) return vmm_monitor_enable(TRUE);
		if (!strcmp(argv[1], "stop")) return vmm_monitor_enable(FALSE);
		if (!strcmp(argv[1], "status")) return vmm_monitor_dump(cdev, VMM_MONITOR_STATUS);
		if (!strcmp(argv[1], "events")) return vmm_monitor_dump(cdev, VMM_MONITOR_EVENTS_VIEW);
		if (!strcmp(argv[1], "config")) return vmm_monitor_dump(cdev, VMM_MONITOR_CONFIG_VIEW);
	}
	if (argc == 4 && !strcmp(argv[1], "config")) {
		for (key = 0; key < VMM_MONITOR_CONFIG_KEYS; key++) {
			if (!strcmp(argv[2], keys[key])) break;
		}
		p = argv[3];
		if (!*p) goto invalid;
		for (; *p; p++) {
			digit = (u32)(*p - '0');
			if (digit > 9 || value > (~0U - digit) / 10) goto invalid;
			value = value * 10 + digit;
		}
		rc = vmm_monitor_configure(key, value);
		if (rc) {
			vmm_cprintf(cdev, "monitor: config failed (%d)\n", rc);
			return rc;
		}
		vmm_cprintf(cdev, "OK: %s=%u\n", keys[key], value);
		return VMM_OK;
	}
invalid:
	monitor_usage(cdev);
	return VMM_EINVALID;
}
static struct vmm_cmd monitor_cmd;
/* Built-in command remains behind the platform's existing authentication. */
int __init vmm_monitor_cmd_init(void)
{
	strcpy(monitor_cmd.name, "monitor");
	strcpy(monitor_cmd.desc, "HV monitor");
	monitor_cmd.usage = monitor_usage;
	monitor_cmd.exec = monitor_exec;
	return vmm_cmdmgr_register_cmd(&monitor_cmd);
}
