/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"

/* Deterministic hook boundaries, not a test of hardware context switching. */
static int scheduler_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	int rc=VMM_OK;
	u32 id;
	u64 base;
	struct mt_snapshot s;
	(void)test; (void)cpu;
	mt_begin(); MT_CHECK(mt_enable(TRUE)==VMM_OK); base=mt_now();
	for (id=0;id<MT_COUNT;id++) {
		mt_record(id,MON_STATE,VMM_VCPU_STATE_READY,base);
		mt_record(id,MON_STATE,VMM_VCPU_STATE_READY,base+50);
		mt_record(id,MON_SELECTED,base+200,0);
		mt_record(id,MON_DISPATCH,base+100,base+300);
		mt_snapshot(id,&s);
		MT_CHECK(s.ready.count==1 && s.ready.sum==200 && s.ready.max==200);
		MT_CHECK(s.dispatch.count==1 && s.dispatch.sum==200 && !s.waiting);
		MT_CHECK(s.kind==(id<2?0:id==MT_IDLE?2:1));
		MT_CHECK(s.guest==(id<2?id:~0U));
		mt_record(id,MON_SELECTED,base+500,0); /* no duplicate ready sample */
		mt_record(id,MON_STATE,VMM_VCPU_STATE_READY,base+500);
		mt_record(id,MON_STATE,VMM_VCPU_STATE_PAUSED,base+600);
		mt_record(id,MON_SELECTED,base+700,0);
		mt_record(id,MON_DISPATCH,base+50,base+20); /* reversed timestamps */
		mt_snapshot(id,&s); MT_CHECK(s.ready.count==1 && s.dispatch.count==1);
		mt_record(id,MON_STATE,VMM_VCPU_STATE_READY,base+1000);
		mt_time(base+1100);
		MT_CHECK(mt_command("status",NULL,NULL)==VMM_OK);
		MT_CHECK(strstr(mt_output(),"\"ready_age_ns\":100"));
		mt_record(id,MON_SELECTED,base+1400,0); mt_snapshot(id,&s);
		MT_CHECK(s.ready.count==2 && s.ready.sum==600 && s.ready.max==400);
	}
	mt_cpu(1); mt_record(MT_IDLE,MON_STATE,VMM_VCPU_STATE_READY,base+2000);
	mt_snapshot(MT_IDLE,&s); MT_CHECK(s.kind==2); /* remote state notification */
	mt_vcpu(MT_HOST)->guest=mt_vcpu(0)->guest;
	mt_exits(MT_HOST,1000,1); mt_record(MT_HOST,MON_DISPATCH,0,10);
	mt_snapshot(MT_HOST,&s); MT_CHECK(s.kind==1 && s.guest==~0U && !s.exits);
	mt_record(MT_IDLE,MON_STATE,VMM_VCPU_STATE_UNKNOWN,base+2000);
	mt_snapshot(MT_IDLE,&s); MT_CHECK(!s.present && !s.ready.count);
	MT_CHECK(!mt_overflow());
out:
	mt_end(); return rc;
}
MT_REGISTER(monitor_scheduler, scheduler_run);
