# 验证记录与限制

## 已执行

1. 在上传源文件副本上依次执行两个补丁的 `git apply --check` 和实际apply；结果与生成的目标片段逐字节一致。
2. 宿主GCC编译并执行28个copy/zerocopy模拟场景（每条分支14种），对比原函数与已插桩函数的业务调用序列和结束状态；一致。
   场景覆盖空队列、单包、多包、批量flush、XDP ENOSPC回退、XDP失败、发送EAGAIN/其他错误/短返回、预算、尾部待处理、通知复查和busy中断。
3. 原与新通用work入队函数的宿主模拟对照：多次提交、已排队合并、清位后重入队、worker不存在；原test-and-set、llist_add、wake_up_process调用次数及状态一致。
4. 新诊断头文件及proc/seq_file代码使用本环境Linux 6.12.96 amd64内核头文件完成模块编译和modpost，无构建警告。
   此项使用了仅含探针所需字段的测试版vhost私有结构，**没有**验证厂商vhost.h的完整ABI。
5. 采集脚本经Bash、Dash和BusyBox ash语法检查；时长变量未使用特殊变量SECONDS。

## 未执行

- 未获取厂商完整内核树、vhost.h、构建配置及其完整依赖。
- 未完成实际vendor net.c/vhost.c整体ARM64编译。
- 未加载测试模块，未进行板端/真实网络/RT调度/STR/并发卸载运行验证。
- 不承诺零性能扰动；此版本只计数、无热路径printf/stack/clock，但仍有函数调用、条件分支和短计数临界区。

## 可复现的宿主模拟

```sh
sh tests/run_host_tests.sh
```

这些测试不能替代目标编译与上板验证。包内不提供可直接加载的测试.ko。
