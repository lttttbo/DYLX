# EVENT_IDX 开关效果对照工具

## 1. 本轮要回答的问题

本轮不是再次确认`event_idx=1`，而是比较在**相同通知路由、亲和性和负载下**，EVENT_IDX开启后：

| 观测对象 | 在哪里采集 | 代表什么 |
|---|---|---|
| `tx_queue_N_kicks` | Android virtio网卡的ethtool驱动统计；有接口才采集 | Guest实际发出的TX队列通知，最接近此前CCM→TTWU/IPI链的起点 |
| `rx_queue_N_kicks` | 同上 | Guest补充RX buffer后通知后端的次数，不是RX中断 |
| virtio TX/RX IRQ | Android `/proc/interrupts` | 到达Guest的虚拟网卡中断，不是ServerVM物理eth0中断 |
| Function-call IPI | ServerVM `/proc/interrupts` | 系统级跨核工作入口，间接指标，不等于kick数 |
| eth0 IRQ | ServerVM `/proc/interrupts` | 物理网卡中断，作为辅助对照，不是EVENT_IDX直接控制对象 |
| 流量、丢包、CPU记账 | 两端计数和PC iperf日志 | 防止吞吐降低或工作量减少造成“通知变少”的假象 |

**EVENT_IDX不直接控制物理eth0 IRQ，也不直接规定IPI次数。** 它控制virtqueue两向通知：Guest→后端kick，以及后端→Guest已使用buffer通知。一次通知不一定对应一个包、一个IPI或一个最终IRQ。

Linux 5.15参考`virtio_net`已经有`tx_queue_N_kicks/rx_queue_N_kicks`计数，在`virtqueue_kick_prepare()`允许且`virtqueue_notify()`成功时增加。厂商驱动是否保留这些字段以实际读取为准；没有字段时本工具显示N/A，不用IPI猜测。

本工具**不启用trace、不修改亲和性、不启停Guest、不修改EVENT_IDX/asyncio/poll配置，也不统计`vring_need_event()`返回false的内部次数**。只验证实际通知/IRQ是否减少。已有flags抑制、NAPI和其他合并机制仍会影响实际结果；不能将输出百分比解释为某条内部条件分支的“理论抑制率”。

## 2. 文件

- `eventidx_count.sh`：同一个采集脚本，在ServerVM和Android各运行一份；只需系统shell，不需板端Python。
- `eventidx_report.py`：PC端离线计算与比较，Python 3.8及以上，仅标准库。
- `virtio_ethtool_stats.c`：**可选**的只读统计工具源代码，供Android没有ethtool可执行文件时使用。不会修改驱动。已有ethtool时不用编译它。
- `tests/test_tools.py`、`VALIDATION.md`：模拟测试和验证范围。

## 3. 固定本次对照条件

用户最新运行是`client + vhost + EVENT_IDX=1`。本轮就保持普通client，不另改asyncio，比较：

| 项目 | OFF组 | ON组 |
|---|---|---|
| 网络参数 | `-s 00:0.0,virtio-net,tap=tap1,vhost` | 完全相同 |
| 网络IOEM路由 | client | client |
| EVENT_IDX | 0 | 1 |
| DSM定时poll | 0 | 0 |
| vhost busyloop | 0 | 0 |
| ring、irq亲和性、ioeventfd/vhost亲和性 | 相同 | 相同 |
| Android发送CPU/端口、报文长度、发送速率 | 相同 | 相同 |

**`off/on`只是采集标签，绝不会替你开关EVENT_IDX。** 沿用现有DSM补丁：OFF组保持默认清位，禁用那一行`net->base.device_caps |= event_idx_bit;`；ON组恢复该行及原支持性判断。除这一开关外，不夹带其他修改。分别构建/部署DSM，正常停止、重新启动Guest/DSM使特征重新协商；不能启动第二个DSM并行访问原始块设备。

开始前确认日志：

- OFF：`negotiated=0 sent=0`，两网络队列`event_idx=0`。
- ON：`negotiated=1 sent=1`，两网络队列`event_idx=1`。
- 两组网络通知均为`route=client`，`busyloop_us=0`。
- 只看当前网络VQMAP/VQCFG，不把别的设备的asyncio记录或已解绑的老worker拼进来。

当前原场景曾只有约448～461 Mbps，故**第一对对照使用400 Mbps，不使用940 Mbps**。这样更容易保证两边实际负载相同，专门看通知效果。若关闭组连400 Mbps也达不到，则两组一起降到300 Mbps重测，不单独改变一组速率。

停止其他性能采集（R6、N4/N5、IPI探针、trace和逐秒eth0脚本等），不改变它们的代码。脚本不会替你修改这些开关。

为避免线程迁移掩盖EVENT_IDX效果，建议两组都固定为此前同一种跨核布局：ioeventfd在CPU1、vhost和eth0 IRQ在CPU0。每次重启先根据`ps`和`/proc/interrupts`确认新TID/IRQ，再执行：

```sh
# IO_TID、VH_TID、ETH_IRQ必须是本次实际对象；不要沿用旧编号。
taskset -pc 1 "$IO_TID"
taskset -pc 0 "$VH_TID"
echo 0 > "/proc/irq/$ETH_IRQ/smp_affinity_list"
cat "/proc/irq/$ETH_IRQ/effective_affinity_list"
```

如果使用另一种布局也可以，但两组必须相同；本脚本只核对首尾状态，不自动绑核或恢复，也不能证明首尾之间没有短暂配置变化。

## 4. 放置脚本，先检查Android是否能读到kick计数

ServerVM、Android各放一份`eventidx_count.sh`。Android建议放`/data/local/tmp`并用root串口终端；PC保留Python解析器。以下两端都以接口名`eth0`举例，若Android实际接口名不同，用`NET_IF=实际网卡名`指定。

Android：

```sh
cd /data/local/tmp
sh eventidx_count.sh inspect android
```

正常会打印：

```text
role=android ... virtio=virtioN
feature_path=.../features event_idx_bit29=0或1
irq_method=... irq_ids=...
...
Guest kick counters via ...:
    rx_queue_0_kicks: ...
    tx_queue_0_kicks: ...
```

`features`是Linux逐位输出、最低位在前的字符串。脚本读取第30个字符（bit29），不是将整个字符串当作常见的高位在前二进制数。

**若找不到ethtool，不需要取消整个测试**：仍能采Guest虚拟IRQ和ServerVM IPI，但不能直接得出kick是否变少。要完整比较两向通知，使用已有Android版ethtool：

```sh
ETHTOOL=/data/ethtool sh eventidx_count.sh inspect android
```

也可使用附带的可选只读工具，构建方法在第9节。若工具存在但厂商驱动不导出kicks，本工具仍标记N/A；这时该项需要后续针对驱动补计数，不能凭空补零。

ServerVM：

```sh
sh eventidx_count.sh inspect server
```

## 5. OFF组：两边先等流量，再启动Android iperf

### PC接收端

使用原服务端，避免重复监听5201。需要重新启动时正常停止旧服务再执行：

```sh
iperf3 -s -p 5201 -i 10 2>&1 | tee pc_eventidx_off.log
```

### ServerVM采集终端

```sh
sh eventidx_count.sh capture server off client 30
```

### Android采集终端（root）

```sh
cd /data/local/tmp
sh eventidx_count.sh capture android off client 30
```

如果ethtool放在`/data/ethtool`，同一条采集命令前加`ETHTOOL=/data/ethtool`。这只是统计工具路径，不是功能开关。

**两个采集终端均出现READY后**，在Android另一个终端执行：

```sh
cd /data
./iperf3 -A 1 --cport 41001 -p 5201 -c 192.168.1.1 \
    -u -b 400M -l 1400 -t 120 -i 10
```

同一OS可用一个串口先后台启动采集，但要把其日志保存，确认READY后再运行iperf；使用两个终端更直观。

脚本自动：检测主方向≥5000包/秒 → 暖机15秒 → 两次端点快照之间等待30秒 → 完成。采集窗口内没有循环扫描线程、轮询dmesg或每包输出；开始/结束才读取计数。

完成后各输出一个目录，例如（实际名称以脚本打印为准）：

```text
ServerVM: .../eventidx_counts/server_off_日期_时间_PID
Android:  .../eventidx_counts/android_off_日期_时间_PID
```

**等iperf120秒结束再停止PC服务端。** 不要只保留最终总平均，10秒区间输出也保留。

## 6. ON组

正常停机，部署开启EVENT_IDX的DSM并重新启动；其他配置及亲和性按OFF组重新核对。启用这项能力不需要改变Linux、CCM、HOS或Android镜像。

PC日志改为：

```sh
iperf3 -s -p 5201 -i 10 2>&1 | tee pc_eventidx_on.log
```

ServerVM：

```sh
sh eventidx_count.sh capture server on client 30
```

Android采集终端：

```sh
cd /data/local/tmp
sh eventidx_count.sh capture android on client 30
```

两个READY后，在Android发送终端运行与OFF**完全相同**的120秒400 Mbps命令。

首轮以一对测试确认采集方法和差异。正式认定收益前，同负载各重复2～3次。不要拿不同路由的历史940 Mbps结果代替本轮OFF数据。

## 7. 复制四个目录到PC并一键比较

复制整个目录，保留文件名；无需在板端安装Python。

```sh
python3 eventidx_report.py compare \
    --server-off  /实际/server_off目录 \
    --server-on   /实际/server_on目录 \
    --android-off /实际/android_off目录 \
    --android-on  /实际/android_on目录 \
    --out eventidx_result
```

生成：

```text
eventidx_result/feedback.txt       # 主要反馈文件
eventidx_result/comparison.md
eventidx_result/comparison.json    # 本地保留原始解析结果
```

计算方法：每个计数都用自己的实际时间窗口计算速率；归一化为：

```text
每万包事件数 = 事件频率 / 同方向包速率 × 10000
减少率 = (OFF每万包事件数 - ON每万包事件数) / OFF每万包事件数 × 100%
```

窗口接近一致时，等价于`事件增量/报文增量×10000`。使用速率形式是为处理端点读取的微小时间差。不是用某个固定理论包速率代替实际数据。

比较内容：Guest TX kick、RX补充kick、Guest TX/RX/配置/共享IRQ、ServerVM Function-call IPI、ServerVM物理eth0 IRQ、流量和CPU busy记账。

### 如何解释

| 结果 | 可以支持的结论 |
|---|---|
| TX kick/万包减少，IPI/万包也减少 | Guest→后端通知确实减少，并与原跨核唤醒负担减轻相互支持 |
| Guest虚拟IRQ减少，但TX kick和IPI基本不变 | 完成通知侧有收益，不代表原TX通知往返瓶颈得到明显缓解 |
| 只有物理eth0 IRQ变化 | 不足以证明EVENT_IDX效果，可能与流量、合并策略或其他活动有关 |
| IRQ少了，同时吞吐也大幅下降 | 先按包数归一化并确认同等负载，不能直接称为收益 |
| EVENT_IDX已协商但所有归一化指标基本不变 | 本负载下没有观察到显著收益，不等于该特征从未进入其分支 |
| TX IRQ两组本来都接近0 | 这个指标不敏感，应看kick等其他项；不能算“100%抑制” |
| 数据显示N/A | 接口不可用/向量不能拆分，绝不表示真实计数为0 |

**本工具不承诺“节省多少IPI处理微秒”或“修复了多少百分比吞吐损失”**，也不重新做R6归因；它只回答当前功能开关有没有可观察的通知收益。

## 8. 常见异常及边界

### 自动IRQ识别失败

先执行`inspect`看sysfs与`/proc/interrupts`。确认实际网卡专属IRQ后，手动指定，例如：

```sh
# 将列表替换为这次实际的网卡IRQ，不要照抄历史编号。
IRQ_LIST='实际IRQ列表，以逗号或空格分隔' sh eventidx_count.sh capture android off client 30
```

脚本通过接口对应virtio设备及其PCI MSI向量/明确中断action名称匹配，避免把所有virtio设备都算进来。不固定使用IRQ131。

TX/RX若共用一个IRQ，无法凭`/proc/interrupts`拆分，报告会显示共享合计；不会把其他设备的IRQ当作本队列。

### 已在跑iperf，需要立即采

```sh
WAIT_MODE=manual WARMUP=5 sh eventidx_count.sh capture server off client 30
```

确保剩余压测时间覆盖暖机和窗口；自动等待模式推荐优先使用。

### Server配置日志缺失或多个vhost-net

报告会标记REVIEW/配置未核实，不从旧初始化猜测。保留最新网络的IOEM_CFG/VQMAP/VQCFG，或用`VHOST_TID=实际TID`限定解析。TID变化后不要继续沿用旧值。读取的线程身份、亲和性必须在窗口前后一致。

### READ-ONLY不等于绝对零扰动

/proc读取和可选的两次ethtool ioctl仍有少量执行开销。本脚本不循环读取物理网卡私有stats；ethtool仅用于Android的virtio驱动统计。需要结合PC相邻10秒区间检查采集期间是否异常降速。

### 不同OS时钟

ServerVM与Android分别检测稳定流量、独立取窗口。它们不严格同步，分析器不跨OS直接相减时间戳；首先在各自OFF/ON窗口内归一化。避免显著其他流量，PC接收日志用于判断稳定性和丢包。

### CPU统计

CPU百分比来自本OS的`/proc/stat`全核平均，包含其他业务；不把Guest/guest_nice重复加入总量。busy排除idle、iowait、steal，单独保留steal字段。它不是纯vhost的CPU消耗，也不是HOS全部物理CPU开销。context文件的时间不用于该窗口CPU计算。

## 9. Android没有ethtool时的可选工具

附带`virtio_ethtool_stats.c`只调用GET类型ethtool接口；不读取或消费eventfd，也不设置网卡、队列或特征。

在编译主机使用**能生成Android可运行程序的工具链**编译。例如已有的AArch64 Linux工具链具有静态libc时：

```sh
aarch64-poky-linux-gcc -O2 -static -Wall -Wextra \
    virtio_ethtool_stats.c -o virtio_ethtool_stats
```

若已source工具链环境且`CC`带有必需的sysroot选项，可使用该环境提供的编译命令。若没有静态libc，不要将依赖glibc动态加载器的Linux程序直接当成Android程序；改用实际安装的Android NDK工具链构建。

将生成的AArch64程序与`eventidx_count.sh`放在Android的同一目录，并赋予执行权限，脚本会自动识别；或者显式指定：

```sh
chmod 755 /data/local/tmp/virtio_ethtool_stats
/data/local/tmp/virtio_ethtool_stats -S eth0
ETHTOOL=/data/local/tmp/virtio_ethtool_stats \
    sh /data/local/tmp/eventidx_count.sh inspect android
```

若驱动本身没有kicks统计，这个工具也不会凭空生成该计数。构建的是小型用户态诊断工具，**不是新增内核打点，也不要求重烧kernel**。

## 10. 完成后提供什么

只需要：

1. `eventidx_result/feedback.txt`。
2. `pc_eventidx_off.log`、`pc_eventidx_on.log`。

原始四个目录先在本地保留。只有出现IRQ/配置匹配问题时，才补对应的`irq_selection.txt`和当前网络初始化日志；不需要数万行trace。

## 11. 依据与范围

本工具结合用户提供的vhost通知逻辑：`vhost_notify()`决定是否调用`eventfd_signal(call_ctx)`，`vhost_enable_notify()`在EVENT_IDX模式更新`avail_event`。下面的公开源码仅用于核对标准字段和统计接口，不能代替厂商源码。

- Virtio 1.2，2.7.7／2.7.10：两向通知抑制。https://docs.oasis-open.org/virtio/virtio/v1.2/virtio-v1.2.html
- Linux v5.15 `drivers/net/virtio_net.c`：`virtnet_sq_stats/rq_stats.kicks`、`start_xmit()`、`try_fill_recv()`、ethtool统计命名。https://raw.githubusercontent.com/torvalds/linux/v5.15/drivers/net/virtio_net.c
- Linux v5.15 `drivers/virtio/virtio.c`：features bitstring从bit0开始输出。https://raw.githubusercontent.com/torvalds/linux/v5.15/drivers/virtio/virtio.c
- Linux v5.15 `/proc`文档：IRQ/CPU计数。https://www.kernel.org/doc/html/v5.15/filesystems/proc.html

未在用户板卡实际运行，验证范围见`VALIDATION.md`。
