"""Developer model of the real runtime testcase; not a Guest/board run."""
from pathlib import Path
import argparse,json,os,re,subprocess

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cc',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[2]
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
    inc=out/'include'
    for n in ['vmm_types.h','vmm_scheduler.h','vmm_manager.h','vmm_timer.h','vmm_stdio.h',
              'vmm_modules.h','vmm_smp.h','vmm_cmdmgr.h','vmm_mutex.h','vmm_delay.h',
              'libs/wboxtest.h','libs/stringlib.h','libs/mathlib.h','arch_barrier.h']:
        f=inc/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('#include "host.h"\n')
    (inc/'vmm_error.h').write_text('\n'.join(s for s in (root/'core/include/vmm_error.h').read_text().splitlines()
        if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',s))+'\n')
    testcase=(root/'libs/wboxtest/monitor/storm_runtime.c').read_text()
    for forbidden in ['vmm_monitor_record(', 'vmm_monitor_exit(', 'vmm_monitor_sample(',
                      'vmm_monitor_drain(', 'mt_exits(', 'mt_sample(']:
        assert forbidden not in testcase, forbidden
    agent=(root/'core/monitor/monitor_agent.c').read_text()
    base=(root/'tests/monitor/test_monitor.c').read_text().replace(
        '#include "../../core/monitor/monitor_agent.c"', '#include "model_agent.c"')
    source='#define main unused_baseline_main\n'+base+'\n#undef main\n'
    source+='#include "'+(root/'libs/wboxtest/monitor/storm_runtime.c').as_posix()+'"\n'
    source+='#include "runtime_storm_model.c"\n'
    (out/'runtime_model.c').write_text(source)
    mutations={
      'missing_event': [('d->active = emit(&e);','d->active = TRUE;')],
      'duplicate': [('if (d->active) goto next;','/* mutation: no dedup */')],
      'early': [('d->windows >= cfg.value[VMM_MONITOR_SUSTAIN_S]','d->windows >= 1'),
                ('d->sustained >= cfg.value[VMM_MONITOR_SUSTAIN_S] * VMM_MONITOR_NS','d->sustained >= VMM_MONITOR_NS')],
      'wrong_rate': [('e.value = udiv64(d->count * VMM_MONITOR_NS, d->interval);',
                      'e.value = 1 + udiv64(d->count * VMM_MONITOR_NS, d->interval);')],
      'wrong_guest': [('e.guest = d->guest; e.vcpu = i;','e.guest = d->guest + 1; e.vcpu = i;')],
      'wrong_limit': [('e.detail = cfg.value[VMM_MONITOR_EXIT_LIMIT];','e.detail = 1 + cfg.value[VMM_MONITOR_EXIT_LIMIT];')],
      'no_rearm': [('d->windows = 0; d->sustained = 0; d->active = FALSE;',
                    'd->windows = 0; d->sustained = 0; /* mutation: no rearm */')]
    }
    cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
    flags=['-std=gnu11','-O1','-Wall','-Werror','-Wno-unused-function','-I'+str(inc),
           '-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
    flags+=['-D'+s for s in ['MONITOR_STORM_RUNTIME_MODEL=1','CONFIG_MONITOR_AGENT=1',
        'CONFIG_MONITOR_EXTERNAL_EXECUTOR=1','CONFIG_CMD_MONITOR=1','CONFIG_WBOXTEST_MONITOR=1',
        'CONFIG_MAX_VCPU_COUNT=4','CONFIG_CPU_COUNT=12','CONFIG_MONITOR_EXIT_RATE=50000','CONFIG_MONITOR_STORM_SECONDS=5']]
    scenarios=['normal','preactive','original_low','unrelated_skip','target_skip_once','no_guest',
               'no_exits','no_sampler','disabled','load_stops','target_starved','invalid_windows',
               'lost','errors','external_config','epoch','stop']
    report={}
    for variant in ['normal',*mutations]:
        body=agent
        for before,after in mutations.get(variant,[]):
            assert body.count(before)==1,(variant,before)
            body=body.replace(before,after)
        (out/'model_agent.c').write_text(body)
        exe=out/(variant+'.exe')
        extra=[] if variant=='normal' else ['-DMODEL_BAD_MONITOR=1']
        build=subprocess.run(cc+flags+extra+[str(out/'runtime_model.c'),str(root/'commands/cmd_monitor.c'),'-o',str(exe)],
                             capture_output=True,text=True)
        (out/(variant+'_compile.txt')).write_text(build.stdout+build.stderr)
        if build.returncode:raise RuntimeError(build.stdout+build.stderr)
        for scenario in scenarios if variant=='normal' else ['normal']:
            run=subprocess.run([str(exe),scenario],capture_output=True,text=True)
            (out/(variant+'_'+scenario+'.txt')).write_text(run.stdout+run.stderr)
            if run.returncode:raise RuntimeError(run.stdout+run.stderr)
            if variant!='normal': assert 'FAIL phase=' in run.stdout
            report[variant+'/'+scenario]='passed';print('PASS runtime storm',variant,scenario,flush=True)
    (out/'report.json').write_text(json.dumps(dict(checks=report,board_executed=False,
        testcase_injects_exits=False,original_configuration_checked=True),indent=2)+'\n')

if __name__=='__main__':main()
