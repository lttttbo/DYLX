core-objs-$(CONFIG_MONITOR_AGENT) += monitor/monitor_agent.o
core-objs-$(CONFIG_MONITOR_AGENT) += monitor/monitor_stats.o
core-objs-$(CONFIG_MONITOR_AGENT) += monitor/monitor_irq.o
core-objs-$(CONFIG_MONITOR_AGENT) += monitor/monitor_guest.o
core-objs-$(CONFIG_MONITOR_AGENT) += monitor/monitor_diag.o
