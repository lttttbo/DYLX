/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
/* Observe an existing error path. Never provoke a fault, change permissions,
 * inject an event, register a buffer or invoke a test hypercall here. */
static int memory_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct vmm_monitor_test_event e;
    struct vmm_monitor_test_state state;
    u64 start,deadline;
    u32 count;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(!vmm_monitor_test_state(&state));
    start=vmm_timer_timestamp(); deadline=start+ml_timeout(&c);
    vmm_cprintf(out,"monitor_live WAIT: observe a real memory/CCM failure on selected vCPU; no injection\n");
    do {
        ML_REQUIRE(!ml_scan(&c,state.head,3,&e,&count));
        if (count) break;
        vmm_msleep(20);
    } while (vmm_timer_timestamp()<deadline);
    ML_REQUIRE(count==1 && e.time_ns>=start && e.value>0);
    ML_REQUIRE(e.code>=VMM_MONITOR_SHMEM_BOUNDS && e.code<=VMM_MONITOR_CCM_ELEMENT_REJECTED);
    ML_REQUIRE(!ml_log_wait(&c,e.seq));
out:
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_memory,memory_run);
