# Monitor live v4：从 20261023 升级后的使用入口

本文件替代 23 日版的专用测试 Guest 操作说明。新版在现有 Guest 上观察事件，不再使用 mailbox、测试 Guest 镜像和旧 setup/start 流程。

请阅读 [记录版说明](monitor_observer_v4.md)，先执行 `monitor_live target <全局vCPU ID>` 选择现有 Guest；具体调度、陷入风暴和内存事件测试的触发条件见该说明第 7 节。

原 tests/monitor/live_guest、protocol.h 不再被新版 live 用例使用，可保留归档。原只读观察接口及日志回执继续复用。
