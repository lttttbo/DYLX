# Monitor v4 编码规范整理版

日期：2026-11-05。文件名使用 ASCII，版本仍标注 v4。

## 本次交付范围

基于当前逐行说明书对应的最终生产实现：monitor_runtime_storm_v4_20261026 中的
monitor_agent.c、vmm_monitor.h、cmd_monitor.c。后续 storm_init/load/diagnostics 迭代仅改测试，
本包兼容这些生产接口；原生产文件校验值见 file_manifest.json。

三个完整文件位于 full_files，并提供等价的 changes.patch。没有新增固件源文件、头文件、
.inc 文件或编译开关。生产采样周期、配置范围、JSON schema=3、内存监控策略和打点接口保持原行为。
本包整理生产代码及其条件编译的只读测试接口，不整体重排 libs/wboxtest/monitor 用例源码。

## 对应用户要求

1. 三个交付文件中 goto 数量为零。
2. 所有 if/else 分支使用大括号；for 循环体也统一使用大括号。
3. 每个结构体成员单独一行，枚举项、变量声明和多条操作拆开。
4. 展开初始化列表和长调用，保留原有字段顺序、类型、枚举值及数组容量。

## 函数调整

- vmm_monitor_record：关闭监控的锁内复查失败时，显式解锁后返回，代替 goto done。
- vmm_monitor_sample：保留全局配置快照、slot trylock、memory_flush、测试计数和统一解锁。
  新增同文件 static sample_slot，将窗口结算和风暴判断放入辅助函数。
  辅助函数的提前返回只结束当前 slot 的处理；外层始终释放 slot 锁，并继续下一项。
  helper 不获取/释放 slot 锁，不打印、不阻塞、不申请内存。
- sample_slot：保留跨配置窗口丢弃、无效窗口清零累计、host/idle 不判风暴、严格大于阈值、
  连续窗口和持续时间双判据、active 去重及低速窗口恢复。配置改变不直接清除 active。
- monitor_exec：新增同文件 static monitor_parse_value，验证非空十进制输入和 u32 溢出。
  输入格式错误仍输出 usage 并返回 VMM_EINVALID；非法配置键/范围仍交给 configure，
  保留 config failed 提示。成功修改仍输出简短 OK，不改成 JSON。
- 其余函数和测试结构主要调整排版、分支大括号、声明和初始化列表。

## 手工合入

1. 对照 file_manifest.json 确认基线，参照 merge_locations.txt 的函数/结构体锚点。
2. 三个文件没有私有修改时，可使用 full_files 内完整文件。
3. 已有私有修改时，按 changes.patch 逐函数合并；不要覆盖项目新增接口、日志适配或配置调整。
4. vmm_monitor.h 的字段顺序和枚举值必须保留。此次没有 ABI 或序列化字段变更。
5. 原 scheduler、异常入口、CCM、共享内存等打点继续调用原接口，无需再合入历史补丁。

需要自动应用时，在源码根目录先执行：

```text
git apply --check changes.patch
git apply changes.patch
```

完整文件和补丁是同一份修改的两种形式，不需要重复合入。

## 内存与代码体积

ARM64 SMP、12 CPU、MAX_VCPU_COUNT=64、Zig/Clang -Os 参考编译：

| 项目 | 整理前 | 整理后 |
|---|---:|---:|
| 生产 monitor_agent + cmd_monitor 可写静态 RAM | 16,304 B | 16,304 B |
| 开启测试后的上述两个生产文件可写静态 RAM | 17,024 B | 17,024 B |
| 生产 monitor_agent + cmd_monitor 加载段 | 5,475 B | 5,503 B |

测试 support.c 内复用的私有 monitor 实例静态 RAM 也不变，加载段增加 36 B。
因此启用当前测试套件时，相关对象加载段总增量为 28+36=64 B，未计最终链接对齐。
没有增加动态分配调用或缓冲区；线程栈容量、事件环容量和 slot 数量配置不变。
这次是编码规范整理，不是 VAPOOL 空间不足修复，也没有证明最终 ROM<=5 KiB 或运行时栈峰值。
HOS 的 GCC、私有头文件及链接脚本可能给出不同结果，最终以产品 ELF/map 为准。

## 验证结果

- 代码检查：零 goto；if/else/for 大括号齐全；结构体成员单独声明。
- ARM64 严格编译：内部生产、内部测试、外部生产、外部测试、开机自启动五种模式，
  同时对比整理前后；8 个现有测试源文件、2026-10-30 风暴诊断版和关闭功能的头文件也编译通过。
- 现有六项隔离用例：三种模式、每项三轮，共 54 次通过。
- 只读观测接口三种模式通过，事件解析/匹配 8 项回归通过。
- 内存路径模型 18 组通过；风暴模型 29 组通过，其中包含 7 种故意破坏实现的检出检查。
- 主补丁和可选开发机脚本补丁均通过应用、文件比对及反向还原验证。
- 没有完整 HOS 私有固件链接和板卡/QEMU 运行结果，不能替代产品环境回归。

建议板端合入后按原流程执行 monitor start、monitor config、monitor status、monitor events，
并运行 unittest run_groups 1 monitor（上游命令名为 wboxtest），观察事件和配置恢复。
VAPOOL 余量测试仍按之前商定的自启动/测试开关对照进行。

## 可选开发机验证脚本

optional_verification 中的 run_runtime_storm_checks.py 只调整 7 类故障注入的源码匹配锚点，
适配 sample_slot 拆分后的 cfg->value 和多行分支。没有删除故障注入检查、放宽测试判据。
它不参与固件编译，不影响板端 unittest；若不运行这套开发机模型，可不合入。
可单独应用 optional_verification/model_runner.patch，或使用其中的完整 Python 文件。

文件校验值见 SHA256SUMS.txt；验证摘要见 validation_summary.json 和 validation/。
