Monitor v4：真实风暴测试适配启动期退出速率回落 / 2026-10-26

1. 对本次结果的判断
目标 Guest 0/vCPU 71 已产生并匹配 type=1 风暴事件 seq=2，事件速率 575/s、门限 500/s。
首次真实采集/判定/记录链路已获得证据。但去重阶段随后遇到未超限窗口，返回 ENOTAVAIL(-3)。
这不是发现了重复告警；是负载已经不足以验证“同一次持续风暴不重复”的前置条件。
去重、恢复、再次触发尚未完整完成，不能把本次整个用例算为通过。原配置已经恢复为 50000/s、5s。
多个 vCPU 同时告警是全局门限降低后的正常结果，用例只匹配选定的 vCPU。

2. 本次单文件修正
只修改 libs/wboxtest/monitor/storm_runtime.c：
- 增加本文件测试常量 SR_LOW=1，测试临时门限使用接口允许的最低值 1 次/秒。
- 不再用启动期短暂高峰的四分之一决定门限；仍自动选择近期有实际退出的 Guest vCPU。
- 仍要求真实速率严格超过门限、满足 5 秒及足够有效窗口，保留事件字段、去重和恢复判据。
- 去重期间若连 1 次/秒都不能持续超过，仍明确失败，另打印 exits/interval_ns/limit。
- 保留上一版 e={0} 的 GCC 显式初始化修正；不关闭编译告警。

这只是功能用例临时配置。生产默认门限、采样逻辑、Guest/CCM、内存策略和测试框架均未修改。
运行结束或普通失败/超时后恢复原 exit_limit/sustain_s；检测到外部改配置时不覆盖外部设置。
不忽略低负载窗口，不跳过去重阶段，不注入模拟 exit，不把未完成测试标记成通过。
事件和 config_seq 历史保留；其他 Guest 也可能因全局门限 1/s 而产生告警。

3. 合入
你当前已经合入 e={0}：使用 fix_current.patch，基线为 monitor_storm_init_fix_v4_20261026。
若从最初 monitor_runtime_storm_v4_20261026 的文件合入：使用 fix_from_runtime_v4.patch，已包含初始化修正。
两份补丁二选一。完整文件位于 full_files/libs/wboxtest/monitor/storm_runtime.c。
若没有自己的修改可以替换该文件；若有私有改动按 merge_locations.txt 合入。
不重做全量合入，不改 objects.mk/openconf.cfg，不新增开关/头文件/目录层级。

4. 复测
保持现有 Guest 运行，先单独执行：
  monitor start
  unittest run_tests 1 monitor_storm_runtime
  monitor config
预期打印 test limit=1 sustain_s=5，然后完整走过 quiet/trigger/dedup/recover/retrigger。
必须出现两条属于选定 vCPU 的 EVENT，最后 restored 原值及 PASS，才算该项通过。
确认后再执行 unittest run_groups 1 monitor；测试总数仍为十项。
若仍因真实负载不足失败，请保留新增 load dropped 行；它会给出实际窗口计数和时长。

5. heap leakage 大数说明
18446744073709543680 = 2^64 - 7936。
当前开源 libs/wboxtest/wboxtest.c 的 __wboxtest_run_test() 使用：
  unsigned long leak;
  leak = 测试前全局空闲堆字节数 - 测试后全局空闲堆字节数;
若后者比前者多 7936 字节，会无符号回绕打印该大数。
按此算法它表示全局空闲堆净增加 7936 字节，不能当成实际泄漏巨量内存。
测试期间 Guest/后台服务持续运行，全局堆差值不能单独归因到当前用例；也不能据此排除其他泄漏。
上游该提示不增加 fail_count；本次明确失败来自 sr_phase 返回 -3。
若你私有 unittest 改过这一计算，最终以私有实现为准。本包没有修改框架计算或屏蔽提示。

6. 验证
用模型复现 5110/s 基线、575/s 触发、随后 124/s 的负载回落：旧门限 500/s 在 dedup 失败，
新门限 1/s 完成首次告警、持续去重、恢复及第二次告警，且原配置恢复。
新模型共 29 组：原 24 组，加上述峰值回落、2/s 低速流、带采样抖动的低速流、去重阶段无退出、
去重阶段恰好等于门限。后两种必须失败，证明没有放宽持续超限条件。
模型中的漏报/重复/提前告警/错误事件参数/不能恢复等反例仍被检出。
Zig/Clang ARM64 -Os/-O2 严格编译、两种基线补丁应用及反向还原通过。
本地没有你的 GCC 12.3 工具链，本次未执行私有固件完整链接或板端测试。
日志落盘和 JSON 完整性仍按约定人工检查，不属于本次修正。
