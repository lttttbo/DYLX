/* SPDX-License-Identifier: GPL-2.0 */
/* Include ONCE in the C file containing the ioeventfd handler.
 * Temporary object attribution: counts matched requests just before the
 * existing eventfd_signal() call; never calls eventfd_signal() itself.
 * No printk, allocation, trace output or pointer dereference in the hot hook.
 * Intended for 5.15 APIs; this does NOT register another module_init().
 */
#ifndef _DEBUG_IOEVENTFD_OBJECT_PROBE_H
#define _DEBUG_IOEVENTFD_OBJECT_PROBE_H
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/percpu.h>
#include <linux/cpu.h>
#include <linux/smp.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/mutex.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/sort.h>
#include <linux/ktime.h>
#include <linux/hash.h>
#include <linux/mm.h>
#include <linux/string.h>

#define IOEM_BITS 6
#define IOEM_SLOTS (1U << IOEM_BITS)
struct ioem_row {
	u64 addr, length, data, hits;
	unsigned long ctx;
	u32 vmid, req_type;
	pid_t source_tid;
	unsigned int cpu;
};
struct ioem_data {
	u64 total, overflow;
	struct ioem_row rows[IOEM_SLOTS];
};
static DEFINE_PER_CPU(struct ioem_data, ioem_stats);
static DEFINE_PER_CPU(raw_spinlock_t, ioem_locks) =
	__RAW_SPIN_LOCK_UNLOCKED(ioem_locks);
static DEFINE_MUTEX(ioem_control);
static bool ioem_enabled;
static u64 ioem_start_ns, ioem_stop_ns;
/* -1 records all VMs. Restrict before arming when multiple VMs are active. */
static int ioem_vmid = -1;
module_param_named(ioem_vmid, ioem_vmid, int, 0600);
MODULE_PARM_DESC(ioem_vmid, "Debug matched-ioeventfd VM filter; -1=all, set before arming");
/* Report one CPU when report truncation occurs. -1 reports all. */
static int ioem_cpu = -1;
module_param_named(ioem_cpu, ioem_cpu, int, 0600);

static bool ioem_same(const struct ioem_row *a, const struct ioem_row *b)
{
	return a->ctx == b->ctx && a->vmid == b->vmid &&
		a->addr == b->addr && a->length == b->length &&
		a->data == b->data && a->req_type == b->req_type &&
		a->source_tid == b->source_tid;
}
static inline void ioem_note(u32 vmid, u32 type, u64 addr, u64 length,
			    u64 data, const void *eventfd_ctx)
{
	struct ioem_row key = { 0 };
	struct ioem_data *d;
	raw_spinlock_t *lock;
	unsigned long flags, h;
	unsigned int cpu, slot, i;
	int filter;
	if (!READ_ONCE(ioem_enabled) || in_nmi())
		return;
	filter = READ_ONCE(ioem_vmid);
	if (filter >= 0 && vmid != (u32)filter)
		return;
	key.vmid = vmid;
	key.req_type = type;
	key.addr = addr;
	key.length = length;
	key.data = data;
	key.ctx = (unsigned long)eventfd_ctx;
	key.source_tid = task_pid_nr(current);
	local_irq_save(flags);
	cpu = raw_smp_processor_id();
	key.cpu = cpu;
	lock = this_cpu_ptr(&ioem_locks);
	d = this_cpu_ptr(&ioem_stats);
	raw_spin_lock(lock);
	if (!READ_ONCE(ioem_enabled))
		goto out;
	d->total++;
	h = key.ctx ^ (unsigned long)key.addr ^ (unsigned long)key.data ^
		((unsigned long)key.vmid << 7) ^ (unsigned long)key.source_tid;
	slot = hash_long(h, IOEM_BITS);
	for (i = 0; i < IOEM_SLOTS; i++) {
		struct ioem_row *row = &d->rows[(slot + i) & (IOEM_SLOTS - 1)];
		if (!row->hits) {
			*row = key;
			row->hits = 1;
			goto out;
		}
		if (ioem_same(row, &key)) {
			row->hits++;
			goto out;
		}
	}
	d->overflow++;
out:
	raw_spin_unlock(lock);
	local_irq_restore(flags);
}
static void ioem_stop_and_drain(void)
{
	int cpu;
	unsigned long flags;
	WRITE_ONCE(ioem_enabled, false);
	for_each_possible_cpu(cpu) {
		raw_spinlock_t *lock = &per_cpu(ioem_locks, cpu);
		raw_spin_lock_irqsave(lock, flags);
		raw_spin_unlock_irqrestore(lock, flags);
	}
}
static int ioem_run_set(const char *val, const struct kernel_param *kp)
{
	bool on;
	int cpu, ret;
	unsigned long flags;
	ret = kstrtobool(val, &on);
	if (ret)
		return ret;
	mutex_lock(&ioem_control);
	ioem_stop_and_drain();
	ioem_stop_ns = ktime_get_ns();
	if (on) {
		for_each_possible_cpu(cpu) {
			raw_spinlock_t *lock = &per_cpu(ioem_locks, cpu);
			raw_spin_lock_irqsave(lock, flags);
			memset(&per_cpu(ioem_stats, cpu), 0, sizeof(struct ioem_data));
			raw_spin_unlock_irqrestore(lock, flags);
		}
		ioem_start_ns = ktime_get_ns();
		ioem_stop_ns = 0;
		WRITE_ONCE(ioem_enabled, true);
	}
	mutex_unlock(&ioem_control);
	return 0;
}
static int ioem_run_get(char *buf, const struct kernel_param *kp)
{
	return scnprintf(buf, PAGE_SIZE, "%u\n", READ_ONCE(ioem_enabled));
}
static int ioem_sort_count(const void *aa, const void *bb)
{
	const struct ioem_row *a = aa, *b = bb;
	if (a->hits != b->hits)
		return a->hits > b->hits ? -1 : 1;
	if (a->cpu != b->cpu)
		return a->cpu < b->cpu ? -1 : 1;
	if (a->ctx != b->ctx)
		return a->ctx < b->ctx ? -1 : 1;
	return 0;
}
static int ioem_report_get(char *buf, const struct kernel_param *kp)
{
	struct ioem_row *rows;
	u64 total = 0, overflow = 0, printed = 0;
	int cpu, n = 0, filter_cpu = READ_ONCE(ioem_cpu);
	unsigned int i, nr = 0, shown = 0;
	mutex_lock(&ioem_control);
	if (READ_ONCE(ioem_enabled)) {
		n = -EBUSY;
		goto unlock;
	}
	if (filter_cpu < -1 || filter_cpu >= nr_cpu_ids ||
	    (filter_cpu >= 0 && !cpu_possible(filter_cpu))) {
		n = -EINVAL;
		goto unlock;
	}
	rows = kcalloc((size_t)num_possible_cpus() * IOEM_SLOTS,
		       sizeof(*rows), GFP_KERNEL);
	if (!rows) {
		n = -ENOMEM;
		goto unlock;
	}
	/* stop_and_drain excluded in-flight writers; control mutex excludes start. */
	for_each_possible_cpu(cpu) {
		struct ioem_data *d = &per_cpu(ioem_stats, cpu);
		if (filter_cpu >= 0 && cpu != filter_cpu)
			continue;
		total += d->total;
		overflow += d->overflow;
		for (i = 0; i < IOEM_SLOTS; i++)
			if (d->rows[i].hits)
				rows[nr++] = d->rows[i];
	}
	sort(rows, nr, sizeof(*rows), ioem_sort_count, NULL);
	n += scnprintf(buf + n, PAGE_SIZE - n,
		"# ioem v1 start_ns=%llu stop_ns=%llu vm_filter=%d cpu_filter=%d\n",
		(unsigned long long)ioem_start_ns, (unsigned long long)ioem_stop_ns,
		READ_ONCE(ioem_vmid), filter_cpu);
	n += scnprintf(buf + n, PAGE_SIZE - n,
		"# matched_signal_attempts=%llu key_overflow=%llu keys=%u\n",
		(unsigned long long)total, (unsigned long long)overflow, nr);
	n += scnprintf(buf + n, PAGE_SIZE - n,
		"# MATCH,cpu,tid,vmid,type,addr,len,data,eventfd_ctx,count\n");
	for (i = 0; i < nr; i++) {
		struct ioem_row *r = &rows[i];
		/* Keep room for the truncation footer; never silently truncate a row. */
		if (PAGE_SIZE - n < 350)
			break;
		n += scnprintf(buf + n, PAGE_SIZE - n,
			"MATCH,%u,%d,%u,%u,0x%llx,%llu,0x%llx,0x%lx,%llu\n",
			r->cpu, r->source_tid, r->vmid, r->req_type,
			(unsigned long long)r->addr, (unsigned long long)r->length,
			(unsigned long long)r->data, r->ctx,
			(unsigned long long)r->hits);
		shown++;
		printed += r->hits;
	}
	n += scnprintf(buf + n, PAGE_SIZE - n,
		"# printed_rows=%u truncated_rows=%u printed_hits=%llu\n",
		shown, nr - shown, (unsigned long long)printed);
	kfree(rows);
unlock:
	mutex_unlock(&ioem_control);
	return n;
}
static const struct kernel_param_ops ioem_run_ops = {
	.set = ioem_run_set, .get = ioem_run_get,
};
static const struct kernel_param_ops ioem_report_ops = {
	.get = ioem_report_get,
};
module_param_cb(ioem_run, &ioem_run_ops, NULL, 0600);
module_param_cb(ioem_report, &ioem_report_ops, NULL, 0400);
MODULE_PARM_DESC(ioem_run, "Debug matched-ioeventfd capture: 1 reset/start; 0 stop/drain");
MODULE_PARM_DESC(ioem_report, "Read only after stopping; contains debug kernel object addresses");
#endif
