# Exact decimal counter subtraction, portable POSIX awk.
# Usage: awk -f hos_net_delta.awk before.tsv after.tsv
BEGIN { FS = OFS = "\t"; bad = 0 }
function norm(s) { sub(/^0+/, "", s); return s == "" ? "0" : s }
function valid(s) { return s ~ /^[0-9]+$/ }
function cmp(a,b, i,x,y) {
    a=norm(a); b=norm(b)
    if (length(a) != length(b)) return length(a) > length(b) ? 1 : -1
    for(i=1;i<=length(a);i++) {
        x=substr(a,i,1)+0; y=substr(b,i,1)+0
        if(x!=y) return x>y ? 1 : -1
    }
    return 0
}
function subtract(a,b, i,j,x,borrow,out) {
    a=norm(a); b=norm(b); j=length(b); borrow=0; out=""
    for(i=length(a);i>0;i--) {
        x=(substr(a,i,1)+0)-borrow-(j>0 ? substr(b,j,1)+0 : 0)
        if(x<0) { x+=10; borrow=1 } else borrow=0
        out=x out; j--
    }
    return norm(out)
}
function known(s) { return s!="" && s!="UNAVAILABLE" }
FNR==NR {
    if($1=="meta") ma[$2]=$3
    if($1=="id") ia[$2]=$3
    if($1=="counter") {
        k=$2 SUBSEP $3; a[k]=$4; keys[k]=1
        dev[k]=$2; counter[k]=$3
    }
    next
}
{
    if($1=="meta") mb[$2]=$3
    if($1=="id") ib[$2]=$3
    if($1=="counter") {
        k=$2 SUBSEP $3; b[k]=$4; keys[k]=1
        dev[k]=$2; counter[k]=$3
    }
}
END {
    print "interface","counter","before","after","delta","quality"
    comparable=known(ma["boot"]) && known(mb["boot"]) && \
        known(ma["ns"]) && known(mb["ns"]) && \
        ("x" ma["boot"] == "x" mb["boot"]) && ("x" ma["ns"] == "x" mb["ns"])
    split(ma["uptime"],ta," "); split(mb["uptime"],tb," ")
    clock_ok=ta[1] ~ /^[0-9]+([.][0-9]+)?$/ && tb[1] ~ /^[0-9]+([.][0-9]+)?$/ && tb[1]+0>=ta[1]+0
    n=0
    for(k in keys) {
        n++; d=dev[k]; delta="-"; quality="VALID"
        if(!comparable || !clock_ok || !valid(ia[d]) || !valid(ib[d]) || cmp(ia[d],ib[d])!=0)
            quality="INCOMPARABLE_IDENTITY_OR_TIME"
        else if(!valid(a[k]) || !valid(b[k])) quality="UNAVAILABLE"
        else if(cmp(b[k],a[k])<0) quality="COUNTER_DECREASED"
        else delta=subtract(b[k],a[k])
        if(quality!="VALID") bad=1
        print d,counter[k],(a[k]==""?"-":a[k]),(b[k]==""?"-":b[k]),delta,quality
    }
    if(n==0) { print "-","-","-","-","-","NO_COUNTERS"; bad=1 }
    exit bad ? 3 : 0
}
