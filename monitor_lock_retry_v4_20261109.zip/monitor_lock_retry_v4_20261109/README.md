# HOS monitor v4：采样取锁的有界重试

基线是已经合入的 `monitor_lock_diagnostics_v4_20261109`。
本包修正 monitor 在一次独占写失败后直接跳过整轮采样的处理方式；仍需单板回归确认效果。

## 本次现场日志的结论

两次失败的目标均为 guest=0/vCPU=73，采样 CPU 为物理 CPU0：

| 阶段 | 采样尝试增量 | 成功增量 | busy 增量 | exclusive 增量 |
|---|---:|---:|---:|---:|
| trigger | 20 | 10 | 0 | 10 |
| retrigger | 20 | 3 | 0 | 17 |

可以确认这些失败尝试都走了“LDAXR 读取空闲，随后 STXR 返回非零”的分支。
没有任何一次失败在 LDAXR 时读到锁被占用。因此 `last_busy_owner=4294967295` 表示没有
busy 观测，不是 CPU 编号，也不能据此说 CPU3 连续持锁了 17 秒。

第一轮仍能看到约 5270 次/秒的 Guest exit。2 秒窗口的计数约 10500，8 秒窗口约 42200，
说明窗口变长后计数仍在累计；负载没有消失。窗口超过默认 1250 ms 上限后，
`sample_slot()` 将它标为 invalid，清零连续窗口数和持续时间，因此不能累计到连续 5 秒。

第二轮第一次 trigger 已产生目标事件 seq=100，dedup、recover 也已完成；失败发生在
retrigger。361 秒是新配置重建基线，362、363 秒得到两个有效窗口，之后 17 次目标
采样取锁全部失败，最终超时。其他 vCPU 的 WARNING 不能替代 vCPU73 自身的触发证据。

软件处理链路已经明确：

```text
STXR 失败
  -> 原实现不重试，本轮目标采样 skipped
  -> 下次成功采样可能间隔 2 秒、8 秒或更长
  -> 超出有效窗口上限，连续性被清零
  -> trigger/retrigger 无法收集连续 5 秒证据
  -> 测试 20 秒超时
```

STXR 失败只表示这次独占写没有成功，不等于锁一直被占用。
同一独占保留粒度内的其他写入也可能使独占操作失败；具体是哪一种干扰，现场日志尚未证明。
Arm 给出的独占操作示例在写失败后重新执行独占读写。
依据：[Arm《Implementation Software Synchronization Primitives in A64》，第 3 章](https://documentation-service.arm.com/static/68c223238a337a2bc6645c0a?token=)。

因此，本包改善采样在这种失败下继续推进的能力，没有宣称已经定位了硬件层独占保留失效的来源。

## 修复规则

ARM64+SMP 的每个 monitor 采样槽使用以下规则：

1. 关闭中断、禁止抢占，随后读取当前物理 CPU 编号。
2. LDAXR 如果读到锁被占用，立即失败返回，不等待持锁者。
3. 如果读到空闲，尝试 STXR；成功后执行原有采样流程。
4. 如果 STXR 失败，在同一次调用中重新执行 LDAXR/STXR；最多 8 次尝试，包含第一次。
5. 连续 8 次 STXR 都失败时，恢复中断/抢占状态，保留原 skipped 和无效窗口语义。
6. 期间某次重试读到 busy，同样立即返回，不继续凑满 8 次。

重试循环全部在汇编块中，没有在独占指令之间插入计数写入、日志、函数调用或睡眠。
`MONITOR_LOCK_ATTEMPTS=8U` 是局部实现常量，不是新 Kconfig 或运行时阈值；8 是有限预算，
不是架构保证成功的次数。限制尝试次数不等于承诺固定的纳秒执行时间。

这套重试用于所有采样槽，不只用于测试选中的 vCPU73。关闭白盒测试开关后，
生产 ARM64 monitor 仍保留修复。非 ARM64 或非 SMP 路径维持原来的通用 trylock 行为。

通用 `arch_spin_trylock()`、`vmm_spin_trylock_irqsave`、调度器、CCM 和 Guest 均不改。
没有改动窗口有效性、exit_limit、sustain_s、1 秒采样周期、日志策略和 20 秒测试超时。
原有测试依然会临时设置阈值并在结束时恢复；没有通过放宽判据使测试通过。

## 文件及手工合入

```text
core/monitor/monitor_agent.c
core/include/vmm_monitor.h
libs/wboxtest/monitor/storm_runtime.c
```

包内 `changes.patch` 从上述最新取锁诊断版起算，不是从最早 observer 版起算。
`full_files/` 是三个完整修改文件；`merge_locations.txt` 给出函数名和参考行号。
三个文件需要一起合入，项目中其他私有改动应保留。

文件与基线一致时可在源码根目录执行：

```text
git apply --check changes.patch
git apply changes.patch
```

完整文件替换与应用补丁二选一。没有新增固件源文件、头文件、编译选项或 Guest 程序。

### monitor_agent.c

- 新增 `sample_lock_result`，临时保存一次采样轮内的独占失败次数、尝试次数和最后读取值。
- 原测试专用 `test_lock_try()` 替换为 `sample_lock_try()`。后者必须位于
  `CONFIG_WBOXTEST_MONITOR` 之外，因为生产采样也需要重试。
- `vmm_monitor_sample()` 的测试开启和关闭两条路径均调用新辅助函数。
  只有被观察的目标传入诊断结果指针，其他槽传 NULL；所有槽采用相同的取锁策略。
- `test_lock_note()` 仍只存在于测试构建中，且在目标锁释放后统计一整轮的结果。
  不在重试循环内取得 event_lock，也不逐次写统计。

### vmm_monitor.h

只扩展已有测试统计结构，增加 rounds、retry_success、exhausted 和 max_attempts。
原 begin/read/end 接口不变，generation、epoch、config_seq 各自含义不变。

### storm_runtime.c

超时诊断补充新计数。成功测试完成、配置恢复并结束观察后，新增四行
`monitor_lock_summary`，让成功轮也能证明是否发生过重试恢复。
没有在阶段轮询中新增打印或读取统计。

## 新版计数的含义

旧版每轮只尝试一次，所以 attempts 等于采样轮数。新版存在重试后必须区分：

| 字段 | 含义 |
|---|---|
| rounds | 对这个目标发起采样取锁的轮数，默认约每秒一轮 |
| attempts | 底层取锁尝试总次数，包含首次和重试 |
| acquired | 最终成功取得锁的轮数，每轮最多加 1 |
| exclusive | 所有 STXR 失败次数，包括后来重试成功的那些失败 |
| busy | 最后因为读到锁被占用而结束的轮数 |
| retry_success | 经至少一次 STXR 失败后，在同轮重试成功的轮数 |
| exhausted | 连续 8 次 STXR 失败、耗尽预算而跳过的轮数 |
| unknown | 非 ARM64/SMP 通用回退中无法细分的失败轮数 |
| max_attempts | 本次完整观察期间，单轮尝试次数最大值，不超过 8 |

两条统计关系：

```text
attempts = acquired + busy + exclusive + unknown
rounds   = acquired + busy + exhausted + unknown
```

`exclusive>0` 不再意味着窗口一定被跳过：如果同轮重试成功，仍完成正常采样。
全局 skipped 仅在整轮最终失败时增加，不按中间 STXR 失败次数增加。
`last_result=2` 表示最终因独占失败耗尽预算；`last_result=0` 表示最终成功，期间可能发生过重试。
watch_owner_mask、last_busy_owner 仍记录完整观察期间的信息，不是单个阶段的专属统计。

超时块中的 `A->B` 是阶段前后计数，应看增量。成功块是本轮测试的累计总量。
其他 vCPU 的失败不包含在该目标统计中；单目标统计不能证明全系统所有槽都无丢采样。

## 单板验证

使用与本次失败相同的板卡、Guest、负载及编译选项，先运行原来的 10 轮：

```text
monitor start
unittest run_tests 10 monitor_storm_runtime
```

不需要整个 monitor group。HOS 命令名是 unittest，开源命令名是 wboxtest。

重点查看成功轮末尾：

```text
monitor_lock_summary rounds=23 acquired=23 retry_success=5
monitor_lock_summary busy=0 exclusive=5 unknown=0
monitor_lock_summary exhausted=0 max_attempts=2
```

这是开发机模型示例，不是单板实测。它表示 5 轮经历一次 STXR 失败后第二次成功，
23 轮全部完成采样，没有耗尽重试预算。

- 多轮通过且 retry_success>0、exhausted=0：说明在该目标上实际观察到重试挽回了采样。
- 多轮通过但 retry_success=0：只能说明这次没有观察到需要重试的情况，不能单独证明修复效果。
- exhausted 继续增加并导致超时：保留两种诊断块；下一步检查内存属性、独占保留粒度、
  锁及相邻热写数据布局等。不能仅靠无限增大次数或超时掩盖问题。
- busy 增加：这是另一条最终失败路径，需要调查持锁路径，不能按独占失败处理。

本包解决的是采样对单次独占写失败过于敏感的问题，不提供任意竞争下必然及时采样的保证。

## 参考开销与验证

参考 ARM64 / Os / MAX_VCPU_COUNT=64，相对于上一份取锁诊断包：

| 项目 | 之前 | 本版 |
|---|---:|---:|
| 测试关闭时 agent 静态可写段 | 16080 B | 16080 B |
| 测试关闭时 agent 装载段 | 4680 B | 4728 B |
| 测试开启时 agent 静态可写段 | 16912 B | 16928 B |
| 测试开启时 agent 装载段 | 7028 B | 7144 B |
| storm_runtime 静态可写段 | 2032 B | 2032 B |
| storm_runtime 装载段 | 9481 B | 10061 B |

测试统计结构从 104 B 增为 128 B，可写段增量受整体布局对齐影响。
sr_diagnostics、sr_phase_state、sr_context 的 sizeof 分别是 656、688、168 B，
不是函数实际栈高水位。本次无动态分配，也没有按 vCPU 增加诊断数组。
上表是目标文件段统计，不能替代 HOS 最终 map，也不代表已满足总 ROM 或 CPU 占用验收。

已完成 26 次 ARM64 目标文件编译（Os/O2、内置/外部、测试开关开/关及私有 support），
检查生产和测试版实际汇编包含有限循环，独占序列内没有插入数据访问/函数调用。
全部使用严格告警，并检查单帧 2048 B 告警门限。

开发机模型包括原有 34 个通用场景、45 个 ARM64 指令结果模拟场景、独立的尝试次数边界和
IRQ/抢占配对检查，以及原隔离用例 54 次执行。特别检查了第 1～8 次成功、连续失败到达上限、
首次 busy、失败两次后遇到 busy，以及结果指针为 NULL 的生产调用方式。
永久失败仍超时并恢复配置，没有改为 PASS。

模型只模拟 ARM64 指令返回结果，不能复现实际硬件的独占监视器行为。真实汇编完成编译和
检查，尚未执行 HOS 的 GCC 12.3 完整链接或单板测试。请用上面的板端计数验证本次改进。
