/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __VMM_MONITOR_H__
#define __VMM_MONITOR_H__

#include <vmm_types.h>
#include <vmm_error.h>

#define VMM_MONITOR_BUCKETS 16
#define VMM_MONITOR_EVENTS 32
#define VMM_MONITOR_BATCH 8
#define VMM_MONITOR_NS 1000000000ULL
#define VMM_MONITOR_UNKNOWN ((u32)-1)

struct vmm_vcpu;
struct vmm_chardev;

enum vmm_monitor_fault {
	VMM_MONITOR_SHMEM_BOUNDS = 1,
	VMM_MONITOR_MAP_REJECT,
	VMM_MONITOR_ACCESS_DENIED,
};
enum vmm_monitor_event_type {
	VMM_MONITOR_EXIT_STORM = 1,
	VMM_MONITOR_EXIT_RECOVER,
	VMM_MONITOR_MEMORY,
	VMM_MONITOR_READY_SLOW,
	VMM_MONITOR_IRQ_SLOW,
};

struct vmm_monitor_hist {
	u64 count, sum, min, max;
	u64 bins[VMM_MONITOR_BUCKETS];
};
struct vmm_monitor_latency {
	u64 count, mean_ns, min_ns, max_ns, p99_upper_ns;
};
struct vmm_monitor_streak {
	u64 elapsed;
	u32 windows;
	bool active;
};
struct vmm_monitor_snapshot {
	u32 guest_id, vcpu_id, generation, hcpu, state;
	bool present, valid;
	u64 timestamp_ns, interval_ns, ready_age_ns;
	u64 exits, exit_rate, faults, last_address, last_detail;
	u32 last_fault, last_exit;
	struct vmm_monitor_latency ready, irq;
};
struct vmm_monitor_event {
	u64 sequence, timestamp_ns, value, detail;
	u32 type, guest_id, vcpu_id, generation, code;
};
struct vmm_monitor_config {
	u32 exit_rate, sustain_seconds;
	u64 ready_limit_ns, irq_limit_ns;
	bool log, publish;
};
struct vmm_monitor_status {
	bool enabled;
	u64 samples, late_samples, sample_max_ns, busy_snapshots;
	u64 events, overwritten, publish_errors, work_errors;
	u64 irq_untracked;
	struct vmm_monitor_config config;
};

struct vmm_monitor_hirq_context {
	u64 timestamp_ns;
	u32 hirq;
};

/* Pure bounded arithmetic, also used by host-side tests. */
void vmm_monitor_hist_add(struct vmm_monitor_hist *h, u64 ns);
void vmm_monitor_hist_read(const struct vmm_monitor_hist *h,
			   struct vmm_monitor_latency *out);
int vmm_monitor_storm_step(struct vmm_monitor_streak *s, u64 count,
			   u64 dt, u32 rate, u32 seconds, bool valid);
static inline bool vmm_monitor_range_valid(u64 size, u64 offset, u64 length)
{
	return offset <= size && length <= size - offset;
}

#ifdef CONFIG_MONITOR_AGENT
int vmm_monitor_init(void);
bool vmm_monitor_enabled(void);
int vmm_monitor_enable(bool enabled);
int vmm_monitor_configure(const struct vmm_monitor_config *config);
void vmm_monitor_status(struct vmm_monitor_status *out);
int vmm_monitor_snapshot(u32 id, struct vmm_monitor_snapshot *out);
int vmm_monitor_event_get(u64 sequence, struct vmm_monitor_event *out);
/* Scheduler calls with sched_lock held. No monitor path acquires sched_lock. */
void vmm_monitor_state(struct vmm_vcpu *vcpu, u32 state, u64 now);
void vmm_monitor_exit(struct vmm_vcpu *vcpu, u32 reason);
void vmm_monitor_mem_fault(struct vmm_vcpu *actor, u32 kind,
			   u64 address, u64 detail);
/* Caller guarantees one matched sample, monotonic clock and stable vCPU. */
void vmm_monitor_irq_sample(struct vmm_vcpu *vcpu, u64 start_ns, u64 end_ns);
struct vmm_monitor_hirq_context vmm_monitor_hirq_enter(u32 hirq);
void vmm_monitor_hirq_exit(struct vmm_monitor_hirq_context previous);
void vmm_monitor_irq_pending(struct vmm_vcpu *vcpu, u32 virq, u32 hirq);
void vmm_monitor_irq_injected(struct vmm_vcpu *vcpu, u32 virq);
void vmm_monitor_irq_cancel(struct vmm_vcpu *vcpu, u32 virq);
void vmm_monitor_irq_reset(struct vmm_vcpu *vcpu);
u64 vmm_monitor_irq_untracked(void);
/* External executor mode: one serialized high-priority sampler, one worker. */
void vmm_monitor_sample(u64 now);
void vmm_monitor_drain(void);

/* Link-time project adapters: no allocation, no waiting for a Guest reply.
 * publish must copy the entire JSON record before returning VMM_OK.
 * These are intentionally not raw Guest physical-address interfaces.
 */
int vmm_monitor_platform_publish(const char *json, u32 length);
void vmm_monitor_platform_sample(u64 now);
int vmm_monitor_platform_diagnose(struct vmm_chardev *cdev);
#else
static inline int vmm_monitor_init(void) { return VMM_OK; }
static inline bool vmm_monitor_enabled(void) { return FALSE; }
/* Macros deliberately do not evaluate timestamp/current-vCPU arguments. */
#define vmm_monitor_state(...) do { } while (0)
#define vmm_monitor_exit(...) do { } while (0)
#define vmm_monitor_mem_fault(...) do { } while (0)
#define vmm_monitor_irq_sample(...) do { } while (0)
#define vmm_monitor_irq_pending(...) do { } while (0)
#define vmm_monitor_irq_injected(...) do { } while (0)
#define vmm_monitor_irq_cancel(...) do { } while (0)
#endif
#endif
