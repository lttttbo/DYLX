/* Host-only Xvisor API model. Production sources are compiled unchanged. */
#ifndef MONITOR_TEST_HOST_H
#define MONITOR_TEST_HOST_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef unsigned int bool;
typedef unsigned int irq_flags_t;
#define TRUE 1
#define FALSE 0
#define __weak __attribute__((weak))
#define __init
#define __exit
#define arch_wmb() do { } while (0)
typedef struct { long value; } atomic_t;
typedef struct { u64 value; } atomic64_t;
static inline u64 arch_atomic64_read(atomic64_t *a) { return a->value; }
static inline void arch_atomic64_inc(atomic64_t *a) { a->value++; }
static inline long arch_atomic_read(atomic_t *a) { return a->value; }
static inline void arch_atomic_write(atomic_t *a, long n) { a->value = n; }
static inline void arch_atomic_inc(atomic_t *a) { a->value++; }
typedef struct { int held; } vmm_spinlock_t;
#define DEFINE_SPINLOCK(n) vmm_spinlock_t n = { 0 }
#define INIT_SPIN_LOCK(p) ((p)->held = 0)
#define vmm_spin_lock_irqsave_lite(p,f) do { (f)=0; assert(!(p)->held); (p)->held=1; } while (0)
#define vmm_spin_unlock_irqrestore_lite(p,f) do { (void)(f); assert((p)->held); (p)->held=0; } while (0)
extern int fail_next_trylock;
static inline int host_trylock(vmm_spinlock_t *p) {
    if(fail_next_trylock) { fail_next_trylock=0; return 0; }
    if(p->held) return 0;
    p->held=1; return 1;
}
#define vmm_spin_trylock_irqsave(p,f) ((f)=0,host_trylock(p))
#define vmm_spin_unlock_irqrestore(p,f) vmm_spin_unlock_irqrestore_lite(p,f)
struct vmm_mutex { int held; };
extern int fake_irq_context;
#define INIT_MUTEX(p) ((p)->held=0)
#define DEFINE_MUTEX(n) struct vmm_mutex n = {0}
static inline void vmm_mutex_lock(struct vmm_mutex *m) { assert(!fake_irq_context && !m->held); m->held=1; }
static inline void vmm_mutex_unlock(struct vmm_mutex *m) { assert(m->held); m->held=0; }
struct vmm_guest { u32 id; };
struct vmm_guest *vmm_manager_guest(u32 id);
struct vmm_guest *vmm_manager_guest_find(const char *name);
void vmm_msleep(unsigned long ms);
void vmm_udelay(unsigned long us);
struct vmm_vcpu { u32 id, hcpu; bool is_normal; struct vmm_guest *guest; };
#define VMM_VCPU_STATE_UNKNOWN 1
#define VMM_VCPU_STATE_RESET 2
#define VMM_VCPU_STATE_READY 4
#define VMM_VCPU_STATE_RUNNING 8
#define VMM_VCPU_STATE_PAUSED 16
#define VMM_VCPU_STATE_HALTED 32
extern u64 fake_time;
extern u32 fake_cpu;
static inline u64 vmm_timer_timestamp(void) { return fake_time; }
static inline u32 vmm_smp_processor_id(void) { return fake_cpu; }
static inline u64 udiv64(u64 a, u64 b) { assert(b); return a/b; }
#define vmm_snprintf snprintf
int vmm_printf(const char *, ...);
struct vmm_chardev { int unused; };
int vmm_cprintf(struct vmm_chardev *, const char *, ...);
struct vmm_cmd {
    char name[32], desc[160];
    void (*usage)(struct vmm_chardev *);
    int (*exec)(struct vmm_chardev *, int, char **);
};
int vmm_cmdmgr_register_cmd(struct vmm_cmd *);
int vmm_cmdmgr_unregister_cmd(struct vmm_cmd *);
int vmm_cmdmgr_execute_cmd(struct vmm_chardev *, int, char **);
#define VMM_EXPORT_SYMBOL(x)
#define VMM_DECLARE_MODULE(a,b,c,d,init,exit) int host_command_init(void) { (void)exit; return init(); }
#if defined(CONFIG_MONITOR_AGENT) && !defined(CONFIG_MONITOR_EXTERNAL_EXECUTOR)
struct vmm_thread { int unused; };
struct vmm_workqueue { struct vmm_thread thread; };
struct vmm_work { void (*func)(struct vmm_work *); };
struct vmm_timer_event { void (*handler)(struct vmm_timer_event *); bool active; u64 expiry; };
#define INIT_WORK(w,f) ((w)->func=(f))
#define INIT_TIMER_EVENT(e,h,p) do { (e)->handler=(h); (e)->active=0; } while(0)
static inline bool vmm_cpu_online(u32 cpu) { return cpu < CONFIG_CPU_COUNT; }
static inline const void *vmm_cpumask_of(u32 cpu) { return (const void *)(uintptr_t)(cpu+1); }
struct vmm_workqueue *vmm_workqueue_create(const char *,u32);
struct vmm_thread *vmm_workqueue_get_thread(struct vmm_workqueue *);
int vmm_threads_set_affinity(struct vmm_thread *,const void *);
int vmm_workqueue_destroy(struct vmm_workqueue *);
int vmm_workqueue_schedule_work(struct vmm_workqueue *,struct vmm_work *);
int vmm_timer_event_start(struct vmm_timer_event *,u64);
int vmm_smp_ipi_sync_call(const void *,u32,void (*)(void *,void *,void *),void *,void *,void *);
#endif
#endif
