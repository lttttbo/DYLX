# HOS 网络故障排查手册

版本：v2　日期：2026-11-23

适用对象：基于 Xvisor 的 ARM64 HOS；Linux ServerVM 运行 ACRN 衍生 Device Model，Android 使用 virtio 网络设备，CCM 连接 ServerVM 与 Hypervisor 的 I/O 请求及中断通知。

遇到网络故障，先找出同一条测试流在哪两个观测点之间停止，再沿这一段检查队列、通知和执行线程。网卡存在、接口 UP、某个中断计数增长，都只能证明链路中的一部分工作正常。

## 1 使用范围与现场架构确认

### 1.1 HOS 中已确认的组成

| 组成 | 已确认的项目事实 | 排查时的含义 |
| --- | --- | --- |
| Hypervisor | 基于 Xvisor，ARM64，包含项目自己的 GICv3 和虚拟化扩展 | 上游 Xvisor 的函数和行为不能直接替代 HOS 实现 |
| Guest | Linux ServerVM 和 Android；产品共 12 个物理核，两个 Guest 静态划分 CPU | 用当前 `vcpu list` 建立 vCPU 到物理核的映射，不复用旧日志中的编号 |
| Device Model | ServerVM 使用 ACRN 衍生 DM，由项目 DSM 启动 Android | 需要同时查看 DSM 启动配置、DM 参数及运行日志 |
| CCM | 已提供的代码包含 ioreq、ioeventfd、irqfd、asyncio 共享缓冲区和 HVC 调用 | virtqueue 没有推进时，需要检查跨 VM 的通知路径 |
| 内存 | Guest 内存按配置分配；后端通过项目映射接口访问相关共享内存 | 配置固定并不保证每次启动的队列地址、映射及通知绑定都正确 |

以下项目必须在故障现场填写。它们决定后续应该检查哪条路径。

| 现场项 | 记录内容 | 确认方法 |
| --- | --- | --- |
| 物理网络设备归属 | 由 ServerVM 驱动、其他域驱动，或经过额外交换设备 | HOS 设备分配配置、ServerVM 网卡驱动及设备树 |
| Android 虚拟网卡传输 | virtio-pci 或 virtio-mmio；legacy 或 modern | Android sysfs 设备路径、驱动日志、DM 设备配置 |
| 后端执行位置 | DM 用户态，或 ServerVM 内核 vhost-net | DM 启动参数、初始化成功日志、打开的 fd、工作线程 |
| ServerVM 网络拓扑 | bridge、路由/NAT、macvtap 或项目自定义后端 | `ip -d link`、`bridge link`、路由和防火墙配置 |
| 设备与地址 | Android 网卡、TAP、bridge、物理口、VLAN、IP/MAC、网络命名空间 | 第 4 节的现场清单 |
| 通知机制 | 普通 ioreq、asyncio/ioeventfd；返回方向 MSI/irqfd 或其他机制 | 注册日志和第 11 节的调用链 |

本文的 TAP/bridge 图表示一种需要现场确认的网络连接方式，不意味着所有 HOS 板型都使用该方式。若使用 vhost-net，DM 仍负责设备配置，但数据搬运可能由内核完成。ACRN 文档可用于理解这一分工，具体参数与功能以 HOS 的 DM 分支为准。[ACRN virtio-net 架构](https://projectacrn.github.io/3.1/developer-guides/hld/virtio-net.html)、[ACRN DM 参数](https://projectacrn.github.io/2.7/user-guides/acrn-dm-parameters.html)。

**资料边界：**本版函数说明基于此前提供的 HOS/CCM 源码快照。尚未核实到你提及的那次 virtio-net 故障对话及最终补丁，因此本文不会把某项推测写成该次故障的已确认根因。现网代码有变化时，应按函数名核对，不依赖旧行号。

### 1.2 排查路线

| 入口与条件 | 阅读顺序 |
| --- | --- |
| 第一次发现网络异常 | 第 4 章确认角色 → 第 5 章基础配置 → 第 6 章小流量 → 第 7 章定位区间 |
| TAP 与物理口之间缺包 | 第 8 章转发层 |
| Android 与 TAP 之间缺包 | 第 9 章前端 → 第 10 章后端 → 证据需要时第 11 章通知链 |
| 能通信但丢包或延迟异常 | 第 12 章 |
| 仅升级、重启或恢复后异常 | 第 13 章 |
| 按阶段采集结果 | 第 14～15 章配套脚本 |

## 2 前十分钟的排查顺序

1. 记录故障时间、版本、启动方式和方向。明确是 Android 发不出、收不到，还是只有某个应用失败。
2. 保存两端接口、路由、邻居、网卡统计和中断计数，先保留现场。
3. 验证 ServerVM 到外部测试机的连通性，确定外部链路能否独立工作。
4. 在拓扑允许时，验证 Android 到 ServerVM 本地地址；再测试 Android 到外部测试机。
5. 使用低速、单流、固定方向的测试，同时观察 Android、TAP 和物理口。首先检查 ARP/邻居发现，再看实际业务流。
6. 找到报文停止的区间后，再增加该区间的队列及通知计数。不要同时修改 offload、IRQ affinity、线程优先级和 MTU。

```mermaid
flowchart TD
    A[网络故障] --> B{Android 网卡是否存在}
    B -->|否| C[检查设备枚举和特性协商]
    B -->|是| D{ServerVM 到外部是否正常}
    D -->|否| E[检查物理口和外部网络]
    D -->|是| F[按方向比较 Android TAP 物理口抓包]
    F --> G{报文在哪里停止}
    G --> H[Android 与后端之间]
    G --> I[TAP 与物理口之间]
    G --> J[物理口与外部之间]
    H --> K[检查 virtqueue CCM 通知和调度]
    I --> L[检查 bridge VLAN 路由和过滤规则]
    J --> M[检查链路 对端和回程]
```

如果物理口不属于 ServerVM，应把第 3 步换成实际出口域的同等检查。如果不存在 ServerVM 可达的本地三层地址，不把“Android ping ServerVM 不通”单独作为 virtio 失败的证据。

## 3 数据链路与通知链路

### 3.1 报文数据在哪里流动

以下示意假定物理口在 ServerVM，后端连接 TAP。

```mermaid
flowchart LR
    A[Android 应用与协议栈] <--> B[virtio net 前端]
    B <--> C[共享 virtqueue 和报文缓冲区]
    C <--> D[DM 用户态后端]
    C <--> E[vhost net 内核后端]
    D <--> F[TAP]
    E <--> F
    F <--> G[ServerVM bridge 或路由]
    G <--> H[物理网卡]
    H <--> I[交换机与外部测试机]
```

图中 DM 用户态和 vhost-net 表示两种候选数据路径，应按当前配置选择对应分支。不要将两个分支理解成每个包都必须依次经过的两级处理。

Hypervisor 负责隔离、地址访问和设备访问转发，并通过 CCM 等机制通知后端。报文主体通常位于 virtqueue 描述符引用的缓冲区；不能把“网络发了一个包”直接等同于“一次 HVC”或“一次 I/O request”。

上游 Xvisor 的 `emulators/net/virtio_net.c` 和 `netswitch` 是另一套后端实现。HOS 使用 ServerVM 中的 ACRN 衍生 DM 时，应先确认调用实际落在哪套后端，避免只在上游 netswitch 中打点。

### 3.2 TX 和 RX 必须注明观察者

本文默认 TX/RX 从 **Android 虚拟网卡** 的角度描述。

| 数据方向 | Android 队列 | TAP 后端端点的操作 | ServerVM TAP 接口统计 | 物理口统计 |
| --- | --- | --- | --- | --- |
| Android 发往外部 | TX：提交待发送报文 | 用户态后端向 TAP fd 写入；vhost 走对应内核路径 | 通常表现为 TAP RX 增长 | PHY TX 增长 |
| 外部发往 Android | RX：Android 先提供空接收缓冲区 | 用户态后端从 TAP fd 读取；vhost 走对应内核路径 | 通常表现为 TAP TX 增长 | PHY RX 增长 |

TAP 是 Linux 看到的虚拟以太网接口：向其用户态端点写入，相当于向 Linux 接收路径送入帧；从端点读取，相当于取走 Linux 向该接口发送的帧。因此，Android TX 与 TAP TX 不能直接同向比较。[Linux TUN/TAP 文档](https://docs.kernel.org/networking/tuntap.html)。

统计应比较同一时间段的增量。GSO/GRO、合包、分段、广播和其他业务会使各层包数不完全相等；`rx_packets` 也不等于应用最终收到的报文数。[Linux 接口统计说明](https://docs.kernel.org/networking/statistics.html)。

### 3.3 三类共享数据不要混淆

| 对象 | 主要内容 | 停止推进的典型表现 |
| --- | --- | --- |
| virtqueue | 描述符、可用/已用信息及报文缓冲区引用 | Android TX 堵塞、RX 无缓冲区、used 不更新 |
| 普通 ioreq 共享区 | 某次设备访问的地址、宽度、值、方向、处理状态 | Guest 等待寄存器访问完成，初始化或 kick 卡住 |
| asyncio sbuf | 已注册异步通知的标识；所给实现传递 eventfd context 对应的值 | 通知无法入队或 ServerVM 没有消费通知 |

`asyncio sbuf` 不是网络包队列；其元素不是 Ethernet 帧。所给代码中的该标识也不是 DM 用户态 fd 数字，不能直接拿去查 `/proc/PID/fd/数字`。

### 3.4 从 Android 通知后端

```mermaid
flowchart TD
    A[Android 提交描述符并按需通知] --> B[HOS handle_io_request]
    B --> C{是否匹配 asyncio 地址}
    C -->|是| D[insert_asyncio_request 写入 sbuf]
    C -->|否| E[insert_io_request 发布普通请求]
    D --> F[ccm_upcall 通知 ServerVM]
    E --> F
    F --> G[CCM 中断与 ioreq 工作队列]
    G --> H[asyncio_dispatch]
    G --> I[ioreq_dispatch 分配处理客户端]
    H --> J[eventfd_signal 唤醒相应消费者]
    I --> K[DM 默认客户端或内核处理客户端]
    K --> L[按注册关系处理请求或发出 eventfd]
```

该图展开的是已提供代码中的控制路径，不要求每个包都触发完整流程。队列通知可以被抑制或合并；工作队列也可以合并多次唤醒。

### 3.5 从后端通知 Android

完成报文处理后，后端先发布完成信息，再按通知规则通知前端。对于已提供代码中的 MSI 路径：

- 用户态 DM 可以调用 `IOCTL_INJECT_MSI`，由 CCM `hsm.c` 转入 `hcall_inject_msi()`。
- 注册了 irqfd 的内核路径，在 `ccm_irqfd_wakeup()` 收到 `POLLIN` 后调用 `irqfd_inject()`，继而调用 `msi_inject()` 和 HVC。
- HOS `cpu_hcall.c::hcall_inject_msi()` 读取调用方 Guest 中的 MSI 参数，并尝试通过 `vmm_devemu_emulate_write()` 交给目标 VM 的设备模型处理。

**这一步成功，不等于 Android 的 ISR 已经执行。**之后还要核对 MSI 地址/数据对应的虚拟设备、ITS/LPI 或其他中断路由、目标 vCPU，以及 Android 驱动的中断与 NAPI 处理。所给 HOS 函数本身没有直接提供“最终 LPI 已送达”的证明。

CCM `vm.c` 中关于 MSI 地址位域的旧注释带有 ACRN 原始模型背景。ARM64 HOS 的实际含义应以接收端虚拟中断设备实现为准，不能直接把其中的地址位解释成当前目标 vCPU。

## 4 第一步 确认在哪个系统和哪条链路排查

**目标：先把接口和角色对应起来。**在错误的 Guest、错误的网络命名空间或错误的接口上抓包，会把正常链路误判成丢包。第 4～7 章是共同入口；第 7 章定位到区间后，按结果选择第 8～13 章，不必每次全部执行。

以下输出均为**解释字段用的示意数据，不是本机或单板实测结果**。示例地址属于文档地址段，执行前替换为实际地址。命令前不写提示符，避免把 `root@host#` 一起复制。

### 4.1 先建立一张接口对应表

| 项目 | 桥接示例 | 路由示例 |
| --- | --- | --- |
| Android 网卡/IP | eth0 / 192.0.2.20 | eth0 / 198.51.100.2 |
| ServerVM Android 侧 | tap0 加入 br0 | tap0 / 198.51.100.1 |
| ServerVM 物理侧 | eth0 加入 br0，br0 为 192.0.2.1 | eth0 / 192.0.2.1 |
| 外部测试机 | 192.0.2.10 | 192.0.2.10，需回程路由或已有 NAT |
| DM PID | 1234，必须现场查询 | 同左 |

桥接情况下，物理口是 bridge slave，IP 放在 br0 上是正常配置；不能因为 eth0 没有 IP 就判故障。路由/NAT 情况下，外部主动访问 Android 可能受既有策略限制，不能照搬桥接场景的双向可达预期。

### 4.2 用基础命令识别接口和父设备

执行位置：ServerVM 和 Android 各执行一次。

```sh
uname -a
ip link show
ip addr show
ip -d link show
```

| 命令 | 具体作用 | 重点字段 |
| --- | --- | --- |
| `uname -a` | 记录正在运行的内核，避免拿构建目录版本替代运行版本 | 内核版本、构建标识 |
| `ip link show` | 列出接口、行政状态、链路状态和 MTU | 接口名、UP、LOWER_UP、master、mtu |
| `ip addr show` | 查看各接口实际配置的地址 | inet/inet6、前缀长度、scope |
| `ip -d link show` | 查看设备类型和附加信息 | bridge、tun/tap、vlan、master；选项不支持时保留前两项 |

ServerVM 桥接示例：

```text
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 master br0 state UP
4: tap0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 master br0 state UNKNOWN
5: br0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 state UP
    inet 192.0.2.1/24 scope global br0
```

这个结果说明 eth0、tap0 同属于 br0；不代表 bridge 一定允许二者转发，还要检查第 8 章的端口/VLAN/规则。TAP 的 `state UNKNOWN` 本身不等于故障。物理口的 carrier 与实际链路另看第 6 章。

Android 中进一步确认网卡驱动：

```sh
AND_IF=eth0
readlink -f "/sys/class/net/$AND_IF/device"
readlink -f "/sys/class/net/$AND_IF/device/driver"
```

参考结果：

```text
/sys/devices/platform/.../pci0000:00/0000:00:02.0/virtio0
/sys/bus/virtio/drivers/virtio_net
```

第一行父链包含 PCI 设备，可以继续沿 PCI transport 检查；若父链属于平台 MMIO 设备，则走对应 MMIO 路径。第二行只证明绑定了 virtio-net 驱动，不证明数据队列和通知已经工作。

### 4.3 确认 DM 所在命名空间

执行位置：ServerVM。先用 `ps -A` 查看进程列表，结合 DSM 启动记录确定真正的 DM PID；不要仅凭进程名猜测。然后执行：

```sh
DM_PID=1234
readlink /proc/self/ns/net
readlink "/proc/$DM_PID/ns/net"
tr '\000' ' ' < "/proc/$DM_PID/cmdline"
```

`readlink` 读取网络命名空间标识；`tr` 把 cmdline 中的 NUL 参数分隔符转换为空格，显示 DM 实际启动参数。

参考结果：

```text
net:[4026531992]
net:[4026532450]
acrn-dm ... virtio-net,tap0,vhost ...
```

两个 namespace 标识不同：当前 shell 中的接口列表不能直接代表 DM 所在空间。具备 `nsenter` 时，可**明确进入 DM 的网络命名空间**再查询：

```sh
nsenter -t "$DM_PID" -n ip link show
```

这里仅切换该条查询命令的网络视图，不调整任何接口。实际 DM 参数以 HOS 分支为准；出现 vhost 字样还需确认初始化成功，见第 10 章。

**本章出口：**明确 Android 接口、ServerVM 出口、TAP、bridge/路由模式和命名空间后进入第 5 章。网卡缺失时直接进入第 9 章；后端/TAP 没建立时进入第 10 章。

配套采集：`basic`；需要确认 DM 时再执行 `backend --dm-pid PID`，详见第 14 章。

## 5 第二步 排除接口 地址 选路与邻居问题

**进入条件：**接口已经找对。先排除配置不成立的情况，再讨论前端或后端实现。

### 5.1 接口是否真正启用

执行位置：发生故障的系统。变量均替换为实际值。

```sh
IFACE=eth0
ip link show dev "$IFACE"
ip addr show dev "$IFACE"
cat "/sys/class/net/$IFACE/mtu"
cat "/sys/class/net/$IFACE/operstate"
```

分别查看接口标志、地址、MTU 和操作状态。下面情况优先留在本层处理：

```text
2: eth0: <BROADCAST,MULTICAST> mtu 1500 state DOWN
```

没有行政 `UP`，不能据此证明 virtio 驱动丢包。应先确认启动脚本/网络服务为什么没有启用接口。本文脚本只记录现状，不自动执行 `ip link set`。

### 5.2 发往指定地址会走哪里

执行位置：发送端；先使用字面 IP，暂时绕开 DNS。

```sh
PEER_IP=192.0.2.10
ip route get "$PEER_IP"
ip route show table all
ip rule show
```

| 命令 | 作用 | 分析方法 |
| --- | --- | --- |
| `ip route get` | 查询当前调用上下文访问该 IP 的选路 | 核对 dev、src、via 是否符合预期 |
| `ip route show table all` | 列出全部路由表 | 不只看 main 表，尤其 Android 有多张策略表 |
| `ip rule show` | 查看选表规则 | 核对源地址、fwmark、UID 等条件，不能只看默认路由 |

桥接示例中 Android 的参考结果：

```text
192.0.2.10 dev eth0 src 192.0.2.20 uid 0
    cache
```

如果得到 `Network is unreachable`，或显示从 WLAN/其他接口出去，应先定位选路配置。查询成功只说明内核能选出路径，不表示下一跳可达。[ip route 手册](https://man7.org/linux/man-pages/man8/ip-route.8.html)。

### 5.3 下一跳有没有解析成功

```sh
ip neigh show dev "$IFACE"
```

参考输出及判断：

```text
192.0.2.10 lladdr 02:00:00:00:00:10 REACHABLE
192.0.2.1 lladdr 02:00:00:00:00:01 STALE
192.0.2.30 INCOMPLETE
```

- REACHABLE 表示当前邻居可达状态；不能据此保证业务端口正常。
- STALE 是邻居缓存状态，常见且不必然异常。
- 测试流量期间持续 INCOMPLETE/FAILED，应抓 ARP/IPv6 邻居发现的请求和应答，进入第 7 章。
- 访问非直连目标时，应检查 `ip route get` 指出的下一跳网关。外部目标 IP 没有自己的邻居条目可以是正常现象。

### 5.4 只有域名或 Android 应用失败

如果字面 IP 测试正常、域名失败，优先检查该环境的 DNS 解析和配置。具备 `nslookup` 时，执行 `nslookup example.com` 观察是否收到解析结果；这会发出 DNS 请求，使用实际允许访问的测试域名。Linux 可查看实际解析服务配置，不能假定 Android 采用 `/etc/resolv.conf`。

Android 的 shell 测试正常，但应用异常时：

```sh
dumpsys connectivity
dumpsys ethernet
ip rule show
```

前两条读取 Android 网络服务状态。示意结果可能包括：

```text
TRANSPORT_ETHERNET
LinkAddresses: [192.0.2.20/24]
Routes: [192.0.2.0/24 -> ... eth0]
DnsAddresses: [192.0.2.53]
```

不同 Android 版本格式会变化，重点核对应用选中的 network、接口、DNS、路由及 VPN。服务不存在、权限不足需要标记“未采集”，不能解释为网络配置为空。

**本章出口：**配置有问题，先按项目既有网络管理方式处理后复测；配置看似正常，进入第 6 章。仅应用失败时留在 Android 网络策略/应用层，不直接修改 CCM。

配套采集：`basic --iface IF --peer IP`。脚本的 route get 不发送业务探测包，也不代表应用 UID 的全部选路条件。

## 6 第三步 用小流量区分外部链路和虚拟链路

**目标：**先确认哪几条路径可用，而不是一开始就跑满带宽。

### 6.1 先测 ServerVM 自身出口

执行位置：ServerVM。

```sh
PHY=eth0
ethtool "$PHY"
ethtool -i "$PHY"
ethtool -S "$PHY"
```

| 命令 | 作用 | 参考结果与解释 |
| --- | --- | --- |
| `ethtool IF` | 查询物理链路协商 | `Speed: 1000Mb/s; Duplex: Full; Link detected: yes`：物理链路成立，未证明 IP 通信 |
| `ethtool -i IF` | 确认实际驱动、固件、bus 信息 | 便于对应设备树和驱动日志，避免分析错设备 |
| `ethtool -S IF` | 读取驱动定义的统计 | 比较两次采样的 CRC、missed、drop 等增量；名称因驱动而异 |

如果物理口无链路，先检查线缆、交换端口和 NIC 初始化。若 ethtool 不存在，用 `cat /sys/class/net/eth0/carrier` 观察：通常 1 有 carrier、0 无 carrier；接口未启用或驱动不支持时可能读失败，不当作 0。

使用少量探测。桥接示例中 ServerVM 的三层接口为 br0，因此绑定 br0：

```sh
ping -I br0 -c 5 192.0.2.10
```

路由示例中出口 IP 在 eth0，可绑定 eth0。Android 发包绑定自己的实际接口。脚本 `probe` 额外提供总时限。

参考成功结果：

```text
5 packets transmitted, 5 received, 0% packet loss
rtt min/avg/max/mdev = 0.8/1.1/1.5/0.2 ms
```

这说明本次 ICMP 往返成功；没有回答 TCP/UDP、不同包长和高负载是否正常。100% 丢包也可能是 ICMP 被过滤，需要结合抓包或允许的业务协议验证。

### 6.2 按矩阵逐项测试

| 顺序 | 执行位置与示例 | 成功可以缩小到哪里 | 失败后的下一步 |
| --- | --- | --- | --- |
| A | ServerVM：`ping -I br0 -c 5 192.0.2.10` | 本机到外部路径可用 | 第 7 章检查物理口/对端，勿先改 virtio |
| B | Android：`ping -I eth0 -c 5 192.0.2.1` | 一条 Android 到 ServerVM 本地往返路径可用 | 第 7 章重点看 Android 和 TAP |
| C | Android：`ping -I eth0 -c 5 192.0.2.10` | 本次完整往返可用 | A/B 正常而 C 失败，优先看转发/回程 |
| D | 对端主动访问 Android 的地址 | 入站连接路径在该策略下可用 | NAT/过滤设计本来禁止时，不判 virtio 失败 |

路由示例的 B 项应使用 Android 侧网关 198.51.100.1。若 ServerVM 根本没有可供 Android 访问的本地 IP，跳过 B 并注明原因，不临时更改拓扑来满足表格。

### 6.3 用受控 UDP 复查业务收发

对端运行 `iperf3 -s`，建立测试服务；客户端运行：

```sh
iperf3 -c 192.0.2.10 -u -b 1M -l 256 -t 10 -i 1
iperf3 -c 192.0.2.10 -u -b 1M -l 256 -t 10 -i 1 -R
```

`-u` 选择 UDP，`-b` 限制目标平均速率，`-l` 设置发送数据报长度，`-t` 限制时长，`-i` 指定报告间隔，`-R` 反转数据方向。UDP 仍需 TCP 控制连接；控制连接失败与 UDP 数据丢失要分开看。[iperf3 使用说明](https://software.es.net/iperf/invoking.html)。

参考接收端汇总：

```text
0.00-10.00 sec  1.19 MBytes  1.00 Mbits/sec  0.080 ms  0/4883 (0%) receiver
```

重点看接收端丢失比例及实际速率。不要将 UDP jitter 当成 HOS 的 vCPU 调度延迟。没有 iperf3 时用既有业务的低流量请求代替，保留协议、方向与序号。

**本章出口：**记录 A/B/C/D 和正反向结果。存在不通或丢失进入第 7 章；完全能通但性能异常进入第 12 章。

配套动作：只读 `uplink`；显式发包 `probe`。iperf3 由操作者按本节单独启动，采集脚本不会自动施加负载。

## 7 第四步 用同一测试流找到报文停止的区间

**进入条件：**已知失败方向。先抓低速、容易关联的 ICMP/UDP 流，不用高频串口日志代替抓包。

### 7.1 同时建立四个观测点

| 观测点 | 在哪里执行 | 能看到什么 |
| --- | --- | --- |
| Android 网卡 | Android | 协议栈收发路径中的报文；TX 抓到不等于已发布 virtqueue |
| TAP | ServerVM 的目标网络命名空间 | Linux 网络栈与后端端点交界的报文 |
| 物理口 | ServerVM/实际出口域 | NIC 软件路径的报文；TX 抓到不等于硬件已成功发到线上 |
| 外部测试机 | 对端 | 对端实际接收/发送的软件观察结果 |

在各自系统先设置对应接口名，然后执行：

```sh
IFACE=tap0
timeout -k 2 -s INT 15 tcpdump -p -n -i "$IFACE" -s 256 -c 2000 -U -w capture.pcap
```

| 选项 | 具体作用 |
| --- | --- |
| `timeout ... 15` | 到 15 秒向本次抓包发送 SIGINT；2 秒后仍不结束则强制终止；需工具支持 |
| `-p` | 不主动打开混杂模式，减少“抓包改变 MAC 过滤”的干扰 |
| `-n` | 不做地址/端口名称解析 |
| `-i` | 指定抓包接口，避免 `any` 混淆层次 |
| `-s 256` | 每包保留前 256 字节，通常足以分析头部；报文可能被截断 |
| `-c 2000` | 限制抓取包数；不能单独替代时间限制，因为没流量时不会退出 |
| `-U -w` | 保存 pcap，并及时刷新包数据 |

高负载达到包数上限后抓包会提前结束；应确认各观测点有共同时间段。若需应用载荷或大包完整内容，提高 snaplen 并记录截断情况。脚本默认短时、不加过滤，避免漏掉 VLAN/ARP/IPv6 控制包；分析时再按测试流筛选。

读取示例：

```sh
tcpdump -nn -e -r capture.pcap
```

`-r` 离线读取，`-e` 显示二层头。样例：

```text
02:00:00:00:00:20 > 02:00:00:00:00:10, IPv4, 192.0.2.20 > 192.0.2.10:
ICMP echo request, id 42, seq 3, length 64
```

关联 IP、MAC、ICMP id/seq 或业务序号；若经过 NAT，先明确地址转换后再关联。不用两个未经同步的 Guest 时间戳直接相减计算单向延迟。

### 7.2 Android 外发的分支判断

| Android | TAP | 物理口/对端 | 范围与下一步 |
| --- | --- | --- | --- |
| 没有测试流 | 无 | 无 | 回第 5 章：应用、路由、接口；先排除抓包过滤/权限问题 |
| 有 | 无 | 无 | Android—后端区间；第 9 章确认前端提交，再第 10～11 章 |
| 有 | 有 | 物理口无 | 第 8 章：ServerVM 转发层 |
| 有 | 有 | 物理口有、对端无 | NIC 硬件/外部链路/对端过滤；结合硬件统计，不直接归因于 virtio |
| 请求到对端 | — | 应答未到 Android | 换成返回方向，按下一表继续 |

### 7.3 Android 接收的分支判断

| 最后有对应包的位置 | 下一步 |
| --- | --- |
| 对端发出，ServerVM 物理口无 | 检查外部 VLAN、目的 MAC、链路、NIC 接收及抓包位置 |
| 物理口有，TAP 无 | 第 8 章：bridge/路由、VLAN、过滤和回程 |
| TAP 有，Android 无 | 第 10 章查后端取包和 RX buffer；第 9 章查前端 refill/回收；used 已发布则第 11 章 |
| Android 有，应用未收到 | 协议校验、socket、Android 网络策略和应用；回第 5 章 |

### 7.4 用计数交叉验证而不是单凭 pcap

```sh
ip -s link show dev tap0
ip -s link show dev eth0
```

两次读取之间只发送一组易识别流量。示意增量：

```text
Android eth0 TX packets: +10
ServerVM tap0 RX packets: +10
ServerVM eth0 TX packets: +10
```

这是桥接外发方向上的一致证据，不要求真实环境永远逐包相等。GSO/GRO、其他业务和抓包丢包会改变数量。[Linux 接口统计](https://docs.kernel.org/networking/statistics.html)。

tcpdump 退出示例：

```text
20 packets captured
20 packets received by filter
0 packets dropped by kernel
```

若 dropped 增长，先承认抓包证据不完整。checksum incorrect 或大于 MTU 的本地包也可能与 offload/抓取位置有关，转第 12 章核对，不直接判线侧坏包。

**本章出口：**把范围写成“Android—TAP”“TAP—物理口”或“物理口—对端”，并注明方向。只有报文和队列证据一致时才进一步归因到组件。

配套动作：`capture` 在各端分别运行，`sample` 同步采接口计数。脚本不会自动跨机器对齐时间或判断丢包根因。

## 8 第五步 检查 ServerVM 的转发层

**进入条件：**同一测试包已到 TAP，却未到物理口，或反向已到物理口却未到 TAP。

### 8.1 桥接模式先看成员和端口状态

执行位置：ServerVM 对应网络命名空间。

```sh
bridge link show
bridge vlan show
bridge fdb show br br0
```

- `bridge link`：确认 tap0 和物理口加入同一个 bridge，端口是否处于 forwarding。
- `bridge vlan`：确认 PVID、允许 VLAN、untagged/tagged 属性。
- `bridge fdb`：确认目的 MAC 学习到哪一个端口，或是否存在静态错误条目。

参考结果：

```text
2: eth0: ... master br0 state forwarding priority 32 cost 100
4: tap0: ... master br0 state forwarding priority 32 cost 100

port    vlan-id
eth0    1 PVID Egress Untagged
tap0    1 PVID Egress Untagged

02:00:00:00:00:20 dev tap0 master br0
02:00:00:00:00:10 dev eth0 master br0
```

上述示例中两端属于相同 VLAN，Android MAC 学在 tap0，对端 MAC 学在 eth0。若一个端口 blocking/disabled，或两端 VLAN 不匹配，先留在此层。FDB 缺少动态条目不一定是错误，初期可能通过 flooding 学习，需要结合实际帧。[Linux bridge 文档](https://docs.kernel.org/networking/bridge.html)。

没有 `bridge` 工具时，可用 `ip -d link show` 和 `ls /sys/class/net/br0/brif` 确认成员，但它们不能完整替代 VLAN/FDB 检查，应注明这部分证据缺失。

### 8.2 路由模式看转发选择和回程

以下仅用于第 4 章的路由示例：

```sh
cat /proc/sys/net/ipv4/ip_forward
ip route get 192.0.2.10 from 198.51.100.2 iif tap0
ip rule show
ip route show table all
```

参考结果：

```text
1
192.0.2.10 from 198.51.100.2 dev eth0
```

`ip_forward=1` 是 IPv4 路由转发的一项前提；查询加入 from/iif 后更接近这类转发报文的条件，但仍不是对所有 fwmark、VRF 或过滤规则的模拟。查询选路正确后，还需确认对端知道如何返回 198.51.100.0/24，或已有 NAT 正确处理回程。纯二层桥接不要求此开关为 1。

### 8.3 检查过滤和出口排队

```sh
nft list ruleset
iptables-save
ip6tables-save
tc -s qdisc show dev eth0
tc -s filter show dev eth0 ingress
```

这些命令只读：前三条展示实际过滤/NAT 规则；后两条看出口排队及 ingress 分类。nft 和 iptables 可能只是不同视图，不保证都有独立规则；某个工具不存在不代表系统没有防火墙。

参考规则片段：

```text
chain forward {
    type filter hook forward priority filter; policy drop;
    iifname "tap0" oifname "eth0" counter packets 10 bytes 840 accept
}
```

在此示例中，匹配该规则的外发包被允许，但返回方向仍需检查其他规则和连接状态。只有规则配置了 counter，才能据其增量分析命中；不能因为输出没有 counter 就认定规则没执行。

qdisc 示例：

```text
Sent 8400 bytes 100 pkt (dropped 5, overlimits 0 requeues 0)
backlog 0b 0p
```

测试期间 dropped 从 0 增至 5，说明这里存在丢弃证据；需结合队列规则和负载，不直接归因于虚拟中断。

**本章出口：**转发规则/端口明显异常，按项目配置修复后重做第 6～7 章。TAP 到物理口已经通而 Android 一侧仍缺包，进入第 9～11 章。不得为了排查直接清空防火墙或重建 bridge。

配套采集：`forward --tap tap0 --phy eth0 --bridge br0`；路由模式省略不存在的 bridge。

### 8.4 路由规则正确但仍在 ServerVM 丢包：检查反向路径校验

只读查看 IPv4 入口接口和 all 的配置；把 tap0 替换为实际收包接口：

```sh
cat /proc/sys/net/ipv4/conf/all/rp_filter
cat /proc/sys/net/ipv4/conf/tap0/rp_filter
```

示例依次返回 1 和 0。Linux 对该接口使用二者较大值，因此仍按 1（strict）检查：到源地址的最佳反向路由若不是收包接口，可能丢弃报文。0 为不做此项源地址校验，2 为 loose，检查源地址是否可由任意接口到达。非对称路由和策略路由需要结合实际入接口、源地址、路由表及 fwmark 分析；这些值本身不能证明已经发生丢包。[Linux rp_filter 定义](https://docs.kernel.org/networking/ip-sysctl.html)

先保存配置并核对回程，不直接将 all 改成 0。该检查适用于 IPv4 路由路径，不把它作为纯二层 bridge 的必备设置，也不把上述 IPv4 选项套用于 IPv6。

## 9 第六步 判断 Android 前端有没有真正提交和回收

**进入条件：**缺包区间在 Android—TAP，或 Android 根本没有网卡。

### 9.1 先确认枚举 驱动与接口队列

执行位置：Android。

```sh
readlink -f /sys/class/net/eth0/device
readlink -f /sys/class/net/eth0/device/driver
cat /sys/class/net/eth0/device/uevent
ls /sys/class/net/eth0/queues
dmesg
```

| 命令 | 作用与参考结果 | 不能证明什么 |
| --- | --- | --- |
| device/driver 链接 | 例如 virtio0、virtio_net；建立设备对应 | 不能证明数据面已正常运行 |
| uevent | 例如 `DRIVER=virtio_net` 等设备信息 | 没有字段也可能与设备类型有关 |
| queues | 例如 `rx-0 tx-0`；查看接口公布的队列 | 不能直接读到 vring 索引 |
| dmesg | 寻找 virtio probe、queue、分配、reset 错误 | 权限失败不是“没有错误” |

如果 /sys/class/net/eth0 不存在，先列出实际接口和 /sys/bus/virtio/devices。没有 virtio 设备时查 DSM/DM 设备配置和 PCI/MMIO 枚举；有设备但没绑定时查驱动及初始化失败。此时继续抓 TAP 只能辅助证明后端是否建立，不能替代前端枚举证据。

### 9.2 前端 TX 抓到包之后还差什么

Android TX 抓包能看到报文，却不能保证驱动已向 virtqueue 发布描述符。需要在实际驱动/virtqueue 实现中读取以下进度，或加入最小临时打点：

```text
示意队列快照，非现有 shell 命令输出
vm=android queue=tx0 generation=7
avail=120 backend_last_avail=110 used=110 guest_last_used=110
```

在同一 queue、同一代次下，avail 增长到 120，后端消费仍为 110，说明前端至少发布了新工作，下一步去第 10 章查消费，再到第 11 章查通知。若发送过程中 avail 一直不动，则先查前端队列停止、描述符耗尽、分配失败和完成回收。

Linux 没有一条在所有版本均可用、可直接打印上述全部索引的通用命令。脚本不会伪造这些字段；无法获得队列进度时，应把结论保留为“Android—后端区间，证据不足”。

### 9.3 RX 要先判断有没有接收缓冲区

```text
示意 A：rx_buffers_available=0   used=410   guest_last_used=410
示意 B：rx_buffers_available=32  used=420   guest_last_used=410
```

- A：后端可能有包，却没有可用 buffer；查 Android refill、内存分配和队列状态。
- B：后端已经发布完成，Guest 回收停在旧位置；查前端中断/NAPI、通知重新开启和 vCPU 调度，进入第 11～12 章。
- 后端既没有取到包也没有推进 used，则转第 10 章，而不是只改前端中断处理。

以上示意针对 split ring。索引有回绕，设备重置后也会重新开始；packed ring 必须使用对应状态与 wrap 信息。

**本章出口：**拿到“没有提交”“已提交未消费”“已完成未回收”中的一种证据后，再转向对应组件。

配套采集：`frontend --role android --iface eth0`；只收集公开接口、驱动、统计和日志，队列内部证据需实际实现支持。

## 10 第七步 判断 DM 或 vhost 后端有没有消费队列

**进入条件：**前端已发布数据但 TAP 没包，或 TAP 有入站包而 Android 收不到。

### 10.1 先确认本次真正使用的后端

执行位置：ServerVM。

```sh
DM_PID=1234
ls -l "/proc/$DM_PID/fd"
cat "/proc/$DM_PID/fdinfo/12"
ps -T -p "$DM_PID"
ls "/proc/$DM_PID/task"
```

参考结果：

```text
12 -> /dev/net/tun
13 -> /dev/vhost-net
14 -> anon_inode:[eventfd]

pos:    0
flags:  0100002
iff:    tap0
```

`ls -l fd` 建立进程与打开对象的关系；`fdinfo/12` 中的 iff 将 TAP fd 对应到接口。FD 12 只是示例，必须替换。fdinfo 是否包含 iff 取决于内核实现。

`ps -T -p` 查看 DM 线程；选项不支持时用 task 目录得到 TID，再读取 `/proc/PID/task/TID/status` 查看 Name、State、Cpus_allowed_list。对持续睡眠的线程，要判断它是没有工作还是有工作却没被唤醒，不能仅凭 S 状态判故障。

打开 /dev/vhost-net 不等于启用成功：还要核对初始化日志中 memory table、vring、kick/call eventfd 和 backend 设置结果。反过来，lsmod 没有 vhost 也不能证明不用，因为可能编进内核。

### 10.2 按队列消费点继续缩小

需要后端真实日志或临时打点；如下是**建议记录格式示意**：

```text
vm=1 queue=tx0 last_avail=110 avail=120 consumer_runs=0
vm=1 queue=tx0 last_avail=120 tap_write_rc=-1 errno=11
vm=1 queue=rx0 tap_read_bytes=128 rx_buffers=16 used_before=41 used_after=42
```

| 证据 | 如何分析 | 下一步 |
| --- | --- | --- |
| 有新 avail，但 consumer_runs 不增加 | 没唤醒或线程没运行，二者尚未区分 | 第 11 章通知；第 12 章调度 |
| 消费了描述符，TAP 写返回 EAGAIN | 发生背压，应查看是否注册后续可写唤醒并重试 | 后端错误处理与 TAP/网络出口 |
| TAP 取到包、有 RX buffer，却不发布 used | 映射、拷贝、描述符权限/长度或完成发布路径 | 后端内部 |
| used 发布成功但 Android 不回收 | 数据已到完成环，转向通知或前端处理 | 第 11 章 |

用户态后端检查 TAP read/write 的**返回值和实际字节数**；vhost-net 数据面在内核时，不会每包都出现 DM 用户态 read/write。不能用“DM 没读 TAP”直接证明 vhost 路径故障。

Linux v6.12 上游可从 handle_tx/handle_rx、kick 处理及 used 发布定位；HOS 分支应先搜索实际函数，不能硬套名称。[Linux v6.12 vhost-net](https://raw.githubusercontent.com/torvalds/linux/v6.12/drivers/vhost/net.c)。

**本章出口：**后端消费入口未执行，转第 11 章；执行却未及时完成，查内部返回值/第 12 章；完成已发布但前端无进度，检查返回通知。

配套采集：`backend --dm-pid PID --tap TAP`。脚本不会读取 DM 内存或自动挂调试器。

## 11 第八步 沿 HOS 和 CCM 定位通知断点

**进入条件：**已经确认队列存在工作，而消费者没有推进，或完成已发布却没有前端回收。普通 ioreq 与 asyncio 是候选路径，不是每次都依次经过的两站。

### 11.1 先观察现成的中断与采样信息

ServerVM/Android 各保存两次：

```sh
cat /proc/interrupts
cat /proc/softirqs
```

第一条显示 Linux IRQ 的每 CPU 累计计数；第二条是软中断活动，不是每包计数。ServerVM 中可用 `grep -i dev_ccm /proc/interrupts` 找 CCM；没有输出仅表示未匹配到名称，还需看完整表、驱动注册和权限。

示例：

```text
           CPU0  CPU1  CPU2  CPU3
 45:       1000     0     0     0  ... dev_ccm
```

十秒后 CPU0 从 1000 增到 1010，说明对应处理入口有活动，不证明这十次都属于目标网卡或目标 queue。

HOS shell 中人工执行：

```text
vcpu list
hos irq stats
monitor status
monitor events
```

这些不是 Linux 命令，不能在 ServerVM 执行 shell 脚本来直接代替。vcpu list 用于建立 Guest vCPU、HOS ID 与物理核映射；IRQ 表用于核对实际路由；monitor 提供辅助调度/exit 样本。示意样本 `"valid":0` 或旧 time_ns 不能证明此时网络调度异常。

### 11.2 去程逐跳检查

| 路径与函数 | 当前代码作用 | 本跳的有效证据与下一步 |
| --- | --- | --- |
| HOS handle_io_request | 处理设备访问并选择普通/异步路径 | VM、queue 对应地址、读写、宽度、值；先确认命中哪一路 |
| 普通 insert_io_request | 发布 slot 请求并等待完成 | PENDING 是否被看到；卡在等 backend 还是等 completion |
| 异步 get_asyncio_desc / insert_asyncio_request | 地址匹配、sbuf 入队并 upcall | 注册描述命中、入队成功；sbuf 满要看 head 是否推进 |
| ServerVM ioreq_intr_handler / ioreq_dispatcher | 接收 upcall 并安排工作 | IRQ 进入、工作实际执行、目标 VM 被遍历是不同证据 |
| 普通 ioreq_dispatch | 查找客户端并唤醒 | 找到默认 DM 或内核客户端；无客户端不能算通知成功 |
| 普通 ioeventfd_handler | 匹配后 eventfd_signal | 明确 hit/miss；所给代码未匹配也可以返回 0 |
| 异步 asyncio_dispatch | 取 sbuf 标识并 signal eventfd | head 推进、正确对象被通知；不能当作普通 handler 必须执行 |
| 后端消费者 | 消费实际 queue | eventfd signal 之后消费者是否真正运行和推进 last_avail |

函数分别位于已提供的 vmm_u_ioreq.c、ioreq.c、ioeventfd.c；不要只按名称猜定义文件。

最小诊断示意：

```text
mmio_notify=20 path=normal
ioeventfd_handler_enter=20 match_hit=0 match_miss=20
backend_consume=0
```

范围已缩到普通通知匹配：对比注册的地址、长度、类型和 data/wildcard，与实际写入是否一致。此时“handler 返回 0”不能推翻 match_miss 证据。

异步路径的另一示意：

```text
async_enqueue=20 async_dequeue=0 full_retry=1000
```

优先确认 ServerVM CCM 工作是否运行、sbuf 是否共享正确以及消费者是否阻塞。不要再为普通 ioeventfd_handler 未执行增加无关打点。

### 11.3 返回方向逐跳检查

```text
后端发布 used
  -> call eventfd / 用户态 IOCTL_INJECT_MSI
  -> irqfd_inject + msi_inject / hsm.c ioctl 分支
  -> cpu_hcall.c::hcall_inject_msi
  -> HOS 虚拟设备及中断路由
  -> Android IRQ/NAPI
  -> 回收 used
```

这是两种返回入口的合并示意。未使用 irqfd 的用户态路径不要求 irqfd 回调增加。

在你提供的 HOS 实现中，hcall_inject_msi 通过 vmm_devemu_emulate_write 交给目标 VM 的设备模型。rc 成功仅证明该接口接受/处理了请求，不能等同于最终 ITS/LPI 已送达或 Android ISR 已执行。需要继续记录实际虚拟中断映射、目标 vCPU、pending 和前端处理进度。

### 11.4 只有对应停顿出现时再核查源码

- 普通请求已被后端完成，Guest 却还在等待：核对 completion 初始化、PENDING 发布、完成和 wait 的实际先后顺序。
- ioreq_dispatcher 处理前面的 VM 后停止：核对遇到无 ioreq_buf 时的 break 是否跳过后续目标 VM。
- asyncio 注册显示成功但没生效：核对内部注册表及失败返回传播，不只看外层 rc。
- 同一通知地址供多个 queue 使用：核对所给异步地址匹配模型是否还需要区分写入值，不能假定它与普通 ioeventfd 的匹配语义一致。

这些是针对源码快照的检查点，不是当前故障的既定根因，也不要求改变已有访问策略。

**本章出口：**得到最后成功的一跳和第一处缺失证据，再针对该段增加最小打点。不要在每次 MMIO/IRQ 中直接打印长日志，以免改变原故障。

配套采集：ServerVM/Android 用 `notify`，HOS 用附带的人工命令清单。脚本不宣称能直接读取未导出的 virtqueue、eventfd match 或 VGIC 内部状态。

## 12 第九步 处理能通信但丢包 延迟或大包异常

**进入条件：**第 6 章低流量能通，压力、包长或特定方向下才异常。

### 12.1 先做两个计数快照

```sh
sh hos_net_diag.sh sample --role servervm --tap tap0 --phy eth0 --seconds 5 --out ./case/sample
```

脚本保存原始 sysfs 计数、boot_id、网络命名空间、ifindex、uptime，再计算精确十进制差值。示意 delta.tsv：

```text
interface  counter      before  after  delta  quality
tap0       rx_packets   1000    1100   100    VALID
eth0       tx_packets   900     995    95     VALID
eth0       tx_dropped   0       5      5      VALID
```

这里可以把出口丢弃列为重点，但不能仅凭两接口差 5 就认定五个目标包都在该处丢失；还需流量关联。若 quality 是 COUNTER_DECREASED 或 INCOMPARABLE_IDENTITY_OR_TIME，不能使用差值给出丢包结论。

同时读取 `ethtool -S eth0` 和 `tc -s qdisc show dev eth0` 区分驱动/硬件统计与排队丢弃。累计计数的定义见 [Linux 接口统计](https://docs.kernel.org/networking/statistics.html)。

### 12.2 按一个变量递增负载

对同一方向、同一队列配置，依次选择 1 Mbit/s、10 Mbit/s 等项目允许速率；固定 256 字节，再改变长度。示例：

```sh
iperf3 -c 192.0.2.10 -u -b 10M -l 256 -t 30 -i 1
iperf3 -c 192.0.2.10 -u -b 10M -l 1200 -t 30 -i 1
```

第一条改变负载，第二条在相同平均速率下改变包长，因此包率也会变化。若要严格研究包长影响，应同时记录 packet/s，不把这两次结果当作完全等价压力。

对照发送端与接收端结果，记录首次出现丢包的条件。TCP 另测，不能用 TCP 的成功重传掩盖底层丢失。

### 12.3 区分大包与 offload 问题

```sh
cat /sys/class/net/eth0/mtu
ethtool -k eth0
ethtool -k tap0
```

参考输出：

```text
rx-checksumming: on
tx-checksumming: on
tcp-segmentation-offload: on
generic-receive-offload: on
```

这些是该接口的 offload 配置，不等于 virtio 协商位图。结合前后端 header 长度、mergeable RX、MTU、VLAN/隧道和路径 MTU 检查。只有在已保存原值、允许变更的实验中，才逐项 A/B 关闭相应能力并恢复；采集脚本不会改 offload。

### 12.4 区分通知没到和线程没运行

ServerVM：

```sh
ps -T -p 1234
cat /proc/softirqs
cat /proc/net/softnet_stat
```

ps 看 DM 线程；softirqs 看 NET_RX/NET_TX 等活动；softnet_stat 是每 CPU 的内核网络处理统计，字段与版本相关，原样保存，不按固定列盲判 root cause。

示意证据：

```text
eventfd_signal at T0
consumer starts at T0 + 20 ms
last_avail advances immediately after consumer starts
```

先查 ServerVM Linux 线程竞争和 HOS 对应 vCPU 是否获调度。反之，消费者一直运行却目标 queue 永远没被唤醒，回第 11 章查绑定或通知条件。WQ_HIGHPRI 不保证 ServerVM vCPU 立即运行；NAPI 中断与包数也不一一对应。[Linux NAPI](https://docs.kernel.org/networking/napi.html)。

**本章出口：**把问题明确为配置/包格式、队列背压、执行延迟或通知缺失中的候选项，并给出相应证据。只说“网络慢”“IRQ 少”不足以定位。

配套采集：`sample`、`schedule`；与第 7 章的短时抓包及受控负载配合。

## 13 第十步 对比升级 重启和恢复前后并复验

**进入条件：**只有某内核、某启动次序、Android 重启或恢复后发生故障，或者已做出候选修复。

### 13.1 在正常与异常环境执行相同采集

```sh
sh hos_net_diag.sh compat --role android --iface eth0 --out ./case/before
sh hos_net_diag.sh compat --role servervm --tap tap0 --phy eth0 --dm-pid 1234 --out ./case/before
```

改变版本/生命周期后，用 after 目录重做。PID 要重新查，不能复用已退出进程的旧编号。compat 采集版本、设备/公开 features、接口能力、DM 绑定及日志；Android 没有 DM，省略 dm-pid 是正常使用方式。

| 对比内容 | 参考差异 | 应继续查什么 |
| --- | --- | --- |
| 内核/DM/CCM 版本 | 5.15 与 6.12、不同 DM 提交 | 确认只有哪个组件变化 |
| 公开的设备 features 与日志 | 新旧位图不同 | 区分后端提供、前端选择、最终接受，不能仅凭一份位图代表全部 |
| queue/通知注册 | 旧地址 A，重启后新地址 B | eventfd/asyncio/irqfd 是否跟着新 queue 重建 |
| 后端和 TAP | fd、接口、namespace 改变 | 消费者是否仍绑定旧对象 |
| 中断映射 | MSI/向量/目标 vCPU 改变 | 返回通知是否使用当前映射 |

features sysfs 文件不存在时，表示该公开接口不可用；需要驱动/DM 日志补充，不能假设位图是 0。新内核支持某特性，也不等于本设备已协商该特性。Virtio 的初始化和协商规则应结合实际 transport 核对。[Virtio 1.2 规范](https://docs.oasis-open.org/virtio/virtio/v1.2/virtio-v1.2.html)。

### 13.2 重启后沿生命周期重新检查

参考记录：

```text
before: vm=1 device=net0 generation=7 queue=tx0 kick_object=A
after : vm=1 device=net0 generation=8 queue=tx0 kick_object=A
```

对象仍为 A 并不自动证明错误；需要核对它是否被合法保留/重新绑定。如果旧 sbuf 或在途回调仍引用已撤销对象，或者新队列未完成注册，则是有效调查方向。把 reset、deassign、POLLHUP、重新注册与第一次收发放在同一时间线上。

### 13.3 修复后按相同断点复验

1. 重做最初失败的方向和负载，确认当时停止的 queue/通知/转发点现在能推进。
2. 验证反方向、低负载、原包长、大包和多流；不要只以 ping 恢复作为完成条件。
3. 涉及初始化/通知绑定的修改，增加 Android 重启、重复启动和恢复场景。
4. 保存完整的正常/异常/修复后证据；关闭临时日志后再测，防止时序扰动掩盖问题。
5. 采集或测试能力缺失写“未验证”，不写“通过”。

**本章出口：**形成“现象 → 最后成功点 → 首个失败点 → 根因证据 → 修复 → 同条件回归”的记录。

配套采集：`compat`，再按前述章节选择 probe/capture/sample。脚本没有自动重启、reset、修改特性或修复网络的功能。

## 14 配套脚本与部署

本章和第 15 章替代原第 15～16 章；原第 14 章的独立诊断数据建议已删除，章节连续编号。脚本用于上文逐层采集，不自动判定前端、后端或 CCM 根因。

### 14.1 文件和依赖

```text
hos_network_troubleshooting_v2_20261123/
  hos_network_troubleshooting_v2_20261123.md
  scripts/
    hos_net_diag.sh
    hos_net_delta.awk
    hos_commands.txt
  README.txt
  VALIDATION.md
  SHA256SUMS.txt
```

主脚本使用 POSIX sh，不依赖 Bash 数组、Python、jq、systemd 或固定网卡命名。awk 辅助文件只负责 sysfs 十进制计数的精确差值，避免大计数超过浮点整数精度；与主脚本放在同一目录。

必需的基础工具：sh、mkdir、date、cat、sleep、dirname、readlink。采集 ip、bridge、ethtool、tc、nft、ps 等时按实际可用性记录；某命令缺失/选项不支持不阻止其他证据保存。不同 Android 权限会限制 dmesg、proc fd、抓包，需要按项目现有方式获得相应权限。

脚本使用当前命名空间，**不自动 nsenter**。HOS 自身的 shell 不运行该 POSIX 脚本，按 hos_commands.txt 人工采集。

### 14.2 Linux 和 Android 的运行方法

将两个脚本文件一起放到 ServerVM 的工作目录，或 Android 可写目录，例如 /data/local/tmp/hos_net_diag。使用 sh 显式启动，无需 chmod，也避免 Android 不存在 /bin/sh 的问题：

```sh
cd /data/local/tmp/hos_net_diag
sh hos_net_diag.sh --help
sh hos_net_diag.sh selfcheck --role android --out /data/local/tmp/hos_net_reports
```

selfcheck 检查工具可用性和 timeout 语法能力；其本地 sleep 测试不发网络流量。Linux 可将 out 改为 ./hos_net_reports。

每次在 out 下创建独立的时间/角色/阶段/PID 子目录，不覆盖前一次结果。报告采用英文固定字段，便于精简系统输出和比较；本文给出字段中文解释。

### 14.3 每一阶段对应哪一章

| ACTION | 对应章节 | 输入重点 | 默认行为 |
| --- | --- | --- | --- |
| basic | 4～5 | role、iface，可选 peer | 版本、地址、路由、邻居、namespace；peer 只查路由 |
| uplink | 6 | phy 或 iface | 物理链路、驱动和统计 |
| forward | 8 | tap、phy、实际存在的 bridge | bridge/VLAN/FDB、转发/过滤和 qdisc |
| frontend | 9 | Android iface | 设备、驱动、公开 features、队列目录、日志 |
| backend | 10 | dm-pid，选填 tap | fd/fdinfo、namespace、线程和后端线索 |
| notify | 11 | role | IRQ、softirq 和内核日志 |
| schedule | 12 | iface/tap/phy、选填 dm-pid | 线程、CPU/softirq、接口与 offload |
| compat | 13 | 两端角色及本端实际对象 | 初始化/版本/能力/后端快照 |
| sample | 7、12 | 至少一个接口，seconds | 两次计数和精确差值，不自行产生测试流量 |
| probe | 6 | iface、字面 peer IP | 显式执行有包数和时间上限的 ping |
| capture | 7 | 单个 iface、seconds | 显式短时、限包数、非混杂抓包 |
| selfcheck | 14 | role、out | 检查运行条件 |

命令行参数说明：

| 参数 | 含义与边界 |
| --- | --- |
| --role | servervm/android/peer，只是报告角色，不会进入对应系统 |
| --iface | 本次主要接口；probe/capture/frontend 必填 |
| --phy / --tap / --bridge | 额外要采集的真实接口；没有就不填 |
| --dm-pid | 当前 DM 进程号，backend 必填，脚本不猜进程 |
| --peer | 字面 IPv4/IPv6，避免默认采集触发 DNS；route get 仍只是当前上下文 |
| --seconds | 1～60，默认 5；sample 等待间隔，或 probe/capture 时间上限 |
| --count | ping 包数上限 1～20，默认 5 |
| --packets | 抓包包数上限 1～10000，默认 2000 |
| --snaplen | 每包保存 64～4096 字节，默认 256；不是修改接口 MTU |
| --out | 输出父目录，支持空格；已有结果不覆盖 |
| --help | 显示入口和退出码，不采集 |

### 14.4 超时和失败处理

脚本用短 sleep 检查本机 timeout 是否支持 `-k`、`-s` 及到期返回行为。通过后，普通查询按 10 秒加 2 秒终止宽限执行。没有可靠 timeout 时：

- 保留简单本地查询，报告说明这些查询没有外部总时限。
- 跳过可能较慢的日志/服务查询。
- 拒绝 probe/capture，绝不退化成可能永久等待的抓包。
- 总结果标为 PARTIAL，操作人员可根据缺失项补采。

本地工具对 timeout 到期返回码处理不同。脚本仅把已识别的抓包限时退出及存在 pcap 作为 WINDOW_DONE；其他返回保留为 TIMEOUT/FAILED，不猜测成功。pcap 只有文件头时也可能非空，仍需看 tcpdump 的 captured/dropped 统计。

Ctrl+C 时脚本只通知本次启动的子进程，进行有限的清理观察并保存部分证据，不使用 killall/pkill 清理系统其他抓包。若仍无法确认退出，会打印 CLEANUP_UNCONFIRMED 和进程号，需人工核查；不会无限等待。因驱动不可中断睡眠等内核问题，任何用户态 timeout 都不能保证目标立即退出。

## 15 按排查步骤使用脚本及解读输出

### 15.1 第一次故障按这个顺序开始

ServerVM：

```sh
sh hos_net_diag.sh basic --role servervm --phy eth0 --tap tap0 --bridge br0 --peer 192.0.2.10 --out ./case/servervm
sh hos_net_diag.sh uplink --role servervm --phy eth0 --peer 192.0.2.10 --out ./case/servervm
```

Android：

```sh
sh hos_net_diag.sh basic --role android --iface eth0 --peer 192.0.2.10 --out /data/local/tmp/case/android
```

先按第 4～5 章看基础结果。确认允许发包后，ServerVM 与 Android 分别运行：

```sh
sh hos_net_diag.sh probe --role servervm --iface br0 --peer 192.0.2.10 --count 5 --seconds 10 --out ./case/servervm
sh hos_net_diag.sh probe --role android --iface eth0 --peer 192.0.2.1 --count 5 --seconds 10 --out /data/local/tmp/case/android
sh hos_net_diag.sh probe --role android --iface eth0 --peer 192.0.2.10 --count 5 --seconds 10 --out /data/local/tmp/case/android
```

这组使用桥接示例；路由模式替换接口和本地网关，不整段原样套用。probe 发包可能更新邻居缓存和网络计数，但不改接口/路由/防火墙配置。

### 15.2 仍不通再抓包划分范围

ServerVM 两个终端分别运行，Android/对端在各自终端执行同类动作：

```sh
sh hos_net_diag.sh capture --role servervm --iface tap0 --seconds 15 --packets 2000 --out ./case/servervm
sh hos_net_diag.sh capture --role servervm --iface eth0 --seconds 15 --packets 2000 --out ./case/servervm
```

抓包开始后再运行第 6 章的小流量测试。默认不设置过滤器，--peer 不会变成抓包过滤条件。它只控制 basic/uplink 的路由查询和 probe 的目标。

- TAP↔物理口之间缺包：执行 forward，按第 8 章分析。
- Android↔TAP 之间缺包：Android 执行 frontend；ServerVM 执行 backend；按第 9～10 章判断是否需要 notify。
- 能通但压力下异常：同时用 sample/schedule 与第 12 章受控负载。
- 升级或重启才异常：正常/异常各执行 compat，再用同一测试矩阵比较。

分支示例：

```sh
sh hos_net_diag.sh forward --role servervm --tap tap0 --phy eth0 --bridge br0 --out ./case/servervm
sh hos_net_diag.sh frontend --role android --iface eth0 --out /data/local/tmp/case/android
sh hos_net_diag.sh backend --role servervm --dm-pid 1234 --tap tap0 --out ./case/servervm
sh hos_net_diag.sh notify --role servervm --out ./case/servervm
sh hos_net_diag.sh sample --role servervm --tap tap0 --phy eth0 --seconds 5 --out ./case/servervm
sh hos_net_diag.sh schedule --role servervm --dm-pid 1234 --tap tap0 --phy eth0 --out ./case/servervm
```

这是可选分支集合，不要求把全部命令当成一次默认全量采集。若 DM 在不同 namespace，先核实脚本和输出目录在该进程环境中可见，再显式用 nsenter 在对应空间运行。

### 15.3 结果目录怎么看

```text
20261123T080000Z_servervm_basic_12345/
  report.txt
  index.tsv
  timeout_check.txt
  001_uname.txt
  ...
```

sample 另外生成 before.tsv、after.tsv、delta.tsv；capture 另外生成 capture.pcap。各命令日志保留调用参数、起止 UTC、原始输出和 rc；跨域 UTC 未同步时不要据此计算精确单向时延。

报告示例：

```text
TIMEOUT_GUARD=verified
[OK] links rc=0 file=006_links.txt
[MISSING] physical_stats rc=127 file=010_physical_stats.txt
[FAILED] kernel_log rc=1 file=015_kernel_log.txt
COLLECTION_PARTIAL; inspect MISSING/SKIP/FAILED/TIMEOUT; rc=3
```

这个合并示意用于解释字段，不是 basic 必然包含的文件列表；具体编号随动作和参数变化。

| 状态 | 含义 | 处理方式 |
| --- | --- | --- |
| OK | 命令退出 0 | 继续读输出判断；不等于网络通过 |
| MISSING | 命令不存在 | 换基础接口或补充工具，不能把结果按 0 处理 |
| SKIP | 文件缺失/不可读、条件不足，或不支持此项 | report 中有原因；证明该项未采集 |
| FAILED | 命令非零，可能权限/选项/运行错误 | 看同名日志的原始 stderr |
| TIMEOUT | 限时机制终止或对应超时返回 | 保留部分输出，定位采集能力或目标停顿 |
| WINDOW_DONE | 抓包到预定时限，保存了非空文件 | 查看包数和 dropped；没有数据仍不证明链路坏 |
| NAMESPACE_MISMATCH | shell 与 DM 网络视图不同 | 不把本 shell 的 TAP 缺失归因于 DM |
| COLLECTION_COMPLETE | 所选采集过程没有发现失败 | 不是端到端网络 PASS |
| COLLECTION_PARTIAL | 有缺失/失败/未验证能力 | 根据缺口补采，不强行定责 |

### 15.4 计数差值如何使用

delta.tsv 中：

- VALID：在同一次采样中，boot_id、namespace、ifindex 与时间条件一致，计数可比较。
- COUNTER_DECREASED：可能重置/驱动清零/回绕；脚本不猜原因，也不生成负丢包。
- INCOMPARABLE_IDENTITY_OR_TIME：身份缺失/变化或时间条件不成立，不能直接相减。
- UNAVAILABLE：计数字段没有读到有效十进制数。
- NO_COUNTERS：没有有效输入记录。

两次快照不是原子采样。短暂删除重建后复用同一 ifindex、同名接口属性在两次读取间改变，仍可能无法仅靠快照识别；有设备重置时应单独分段。接口计数超过 2^53 时辅助脚本仍用十进制字符串减法，不依赖 awk 浮点精度。

无需装 Python 或 jq。若 awk/辅助文件缺失，保留原始快照，报告 PARTIAL。只有 ID 一致、字段有效、时间窗口相同，才把差值与该次测试流量对应。

### 15.5 脚本能力的边界

脚本不自动读 Hypervisor 内存、不修改 CCM、不探测未知 ioctl、不触发任意 IRQ、不调整访问策略。它也不能凭公开接口读出所有 virtqueue 索引、ioeventfd match、sbuf 深度或最终 LPI 注入结果。

当流程已经缩小到第 9～11 章的内部断点，按该章明确的证据需求补充少量诊断即可；脚本结果用于说明为什么需要这个打点，以及该打点应该放在哪一段。

