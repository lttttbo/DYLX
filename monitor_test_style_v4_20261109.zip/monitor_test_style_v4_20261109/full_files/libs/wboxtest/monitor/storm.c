/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"

static int prime(void)
{
	int rc = mt_enable(TRUE);
	if (!rc) {
		rc = mt_config(VMM_MONITOR_EXIT_LIMIT, 100);
	}
	if (!rc) {
		rc = mt_config(VMM_MONITOR_SUSTAIN_S, 2);
	}
	mt_record(0, MON_STATE, VMM_VCPU_STATE_RESET, mt_now());
	mt_sample(mt_now() + VMM_MONITOR_NS); /* discard mixed configuration window */
	return rc;
}

static void window(u32 count, u64 duration)
{
	mt_exits(0, count, 1);
	mt_sample(mt_now() + duration);
}

static int storm_run(struct wboxtest *test, struct vmm_chardev *cdev, u32 cpu)
{
	u32 i;
	struct mt_global g;
	struct mt_snapshot s;
	struct mt_event e;
	(void)test;
	(void)cpu;
	MT_CHECK(prime() == VMM_OK);
	for (i = 0; i < 3; i++) {
		window(100, VMM_MONITOR_NS);
	}
	mt_global(&g);
	MT_CHECK(!g.head);
	window(101, VMM_MONITOR_NS);
	window(100, VMM_MONITOR_NS);
	mt_snapshot(0, &s);
	MT_CHECK(!s.windows && !s.sustained);
	window(101, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(!g.head);
	window(101, VMM_MONITOR_NS);
	MT_CHECK(mt_event(1, &e) && e.type == 1 && e.value == 101 && e.detail == 100 &&
		 e.sustain_s == 2);
	window(1000, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(g.head == 1);
	MT_CHECK(mt_config(VMM_MONITOR_EXIT_LIMIT, 50) == VMM_OK);
	window(1000, VMM_MONITOR_NS); /* discard, active episode retained */
	window(1000, VMM_MONITOR_NS);
	window(1000, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(g.head == 1);
	window(0, VMM_MONITOR_NS);
	window(51, VMM_MONITOR_NS);
	window(51, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(g.head == 2);
	mt_reset();
	MT_CHECK(prime() == VMM_OK);
	window(101, VMM_MONITOR_NS);
	window(1000, 2 * VMM_MONITOR_NS);
	mt_snapshot(0, &s);
	MT_CHECK(!s.valid && !s.windows && !s.active);
	window(101, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(!g.head);
	window(101, VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(g.head == 1);
	mt_reset();
	MT_CHECK(prime() == VMM_OK);
	mt_exits(0, 101, 1);
	mt_sample_skip(0, mt_now() + VMM_MONITOR_NS);
	mt_global(&g);
	MT_CHECK(g.skipped == 1 && !g.head);
	window(101, VMM_MONITOR_NS);
	mt_snapshot(0, &s);
	MT_CHECK(!s.valid && !s.windows);
	mt_reset();
	MT_CHECK(prime() == VMM_OK);
	window(81, 800000000);
	window(81, 800000000);
	mt_global(&g);
	MT_CHECK(!g.head);
	window(81, 800000000);
	mt_global(&g);
	MT_CHECK(g.head == 1); /* elapsed >=2s too */
	mt_reset();
	MT_CHECK(prime() == VMM_OK);
	mt_record(1, MON_STATE, VMM_VCPU_STATE_RESET, mt_now());
	mt_sample(mt_now() + VMM_MONITOR_NS); /* prime second Guest */
	for (i = 0; i < 2; i++) {
		mt_exits(1, 102, 0x100);
		mt_exits(MT_HOST, 200, 1);
		mt_exits(MT_IDLE, 200, 1);
		window(101, VMM_MONITOR_NS);
	}
	mt_global(&g);
	MT_CHECK(g.head == 2);
	MT_CHECK(mt_event(1, &e) && e.vcpu == 0);
	MT_CHECK(mt_event(2, &e) && e.vcpu == 1 && e.code == 0x100);
	MT_CHECK(!mt_overflow());
	return VMM_OK;
}

MT_REGISTER(monitor_storm, storm_run);
