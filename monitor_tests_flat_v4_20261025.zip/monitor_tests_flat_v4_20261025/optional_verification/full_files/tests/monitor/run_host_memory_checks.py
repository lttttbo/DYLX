"""Run actual host memory cases/guards against a platform model, not a board.
Requires the uploaded original and patched project cmd_memory sources.
"""
from pathlib import Path
import argparse,json,os,re,subprocess

def fn(s,name):
    m=re.search(r'^(?:static )?(?:inline )?(?:u32|int) '+name+r'\(',s,re.M)
    if not m:raise ValueError('Missing function '+name)
    i=s.index('{',m.start());depth=1;j=i+1
    while depth:
        depth+=(s[j]=='{')-(s[j]=='}');j+=1
    return s[m.start():j]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ['cc','out','original-command','command']:p.add_argument('--'+n,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[2];out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
    inc=out/'include'
    for n in ['vmm_types.h','vmm_scheduler.h','vmm_manager.h','vmm_timer.h','vmm_stdio.h',
              'vmm_modules.h','vmm_smp.h','vmm_cmdmgr.h','vmm_mutex.h','vmm_delay.h','vmm_guest_aspace.h',
              'vmm_host_ram.h','vmm_host_aspace.h','vmm_shmem.h','libs/wboxtest.h',
              'libs/stringlib.h','libs/mathlib.h','arch_barrier.h']:
        f=inc/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text('#include "host.h"\n',encoding='utf-8')
    (inc/'vmm_error.h').write_text('\n'.join(x for x in (root/'core/include/vmm_error.h').read_text().splitlines()
        if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',x))+'\n',encoding='utf-8')
    original=Path(a.original_command).read_text(encoding='utf-8');command=Path(a.command).read_text(encoding='utf-8')
    def guards(s):return s[s.index('struct memory_dump_request {'):s.index('static void memory_dump_func(')]
    orig=guards(original)
    for n in ['memory_dump_request','check_ram_addr_range','mapping_iter','device_region_iter','guest_list_iter',
              'check_addr_range','check_host_device_addr','check_device_addr_range','check_guest_addr_range',
              'check_read_memory','check_type_memory','check_write_memory']:
        orig=re.sub(r'\b'+n+r'\b','original_'+n,orig)
    shmem=(root/'core/vmm_shmem.c').read_text(encoding='utf-8')
    bodies='\n'.join(fn(shmem,n) for n in ['vmm_shmem_read','vmm_shmem_write','vmm_shmem_set'])
    source='''#include "host.h"
#include <vmm_monitor.h>
#include "../../core/monitor/monitor_agent.c"
'''.replace('../../core/monitor/monitor_agent.c',(root/'core/monitor/monitor_agent.c').as_posix())
    prefix=source+orig+'\n'
    post='\n#include "'+(root/'libs/wboxtest/monitor/memory_runtime.c').as_posix()+'"\n#include "host_memory_model.c"\n'
    flags=['-std=gnu11','-O1','-Wall','-Werror','-Wno-unused-function','-I'+str(inc),'-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
    flags+=['-D'+s for s in ['MONITOR_HOST_MEMORY_MODEL=1','CONFIG_MONITOR_AGENT=1','CONFIG_MONITOR_EXTERNAL_EXECUTOR=1','CONFIG_WBOXTEST_MONITOR=1',
        'CONFIG_MAX_VCPU_COUNT=4','CONFIG_CPU_COUNT=12','CONFIG_MONITOR_EXIT_RATE=50000','CONFIG_MONITOR_STORM_SECONDS=5']]
    cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
    report={}
    for mode in ['normal','missing_probes','wrong_code']:
        body=guards(command)+'\n'+bodies
        extra=[]
        if mode=='missing_probes':
            # Remove actual recording calls without changing rejection paths.
            body=body.replace('vmm_monitor_mem_fault(', 'discard_record(')
            body='#define discard_record(...) ((void)0)\n'+body
            extra=['-DMODEL_MISSING_PROBES=1']
        if mode=='wrong_code':
            body=body.replace('VMM_MONITOR_HOST_RANGE_REJECT','VMM_MONITOR_ACCESS_DENIED')
            extra=['-DMODEL_WRONG_CODE=1']
        c=out/(mode+'.c');exe=out/(mode+'.exe');c.write_text(prefix+body+post,encoding='utf-8')
        build=subprocess.run(cc+flags+extra+[str(c),'-o',str(exe)],capture_output=True,text=True)
        (out/(mode+'_compile.txt')).write_text(build.stdout+build.stderr,encoding='utf-8')
        if build.returncode:raise RuntimeError(build.stdout+build.stderr)
        for scenario in (['normal','policy','no_guest','no_sampler','skipped_sample','disabled'] if mode=='normal' else ['normal']):
            run=subprocess.run([str(exe),scenario],capture_output=True,text=True)
            (out/(mode+'_'+scenario+'.txt')).write_text(run.stdout+run.stderr,encoding='utf-8')
            if run.returncode:raise RuntimeError(run.stdout+run.stderr)
            report[mode+'/'+scenario]='passed';print('PASS',mode,scenario,flush=True)
    (out/'report.json').write_text(json.dumps({'checks':report,'board_executed':False},indent=2)+'\n',encoding='utf-8')

if __name__=='__main__':main()
