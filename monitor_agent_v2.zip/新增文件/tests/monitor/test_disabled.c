#include "host.h"
#include <vmm_monitor.h>
#include <vmm_monitor_diag.h>
static unsigned calls;
static u64 side_effect(void) { calls++; return 1; }
int main(void)
{
    /* Disabled hooks must not evaluate timestamps or other arguments. */
    vmm_monitor_state(NULL,0,side_effect());
    vmm_monitor_selected(NULL,side_effect());
    vmm_monitor_dispatch(NULL,side_effect(),side_effect());
    vmm_monitor_irq_pending_at(NULL,side_effect(),side_effect());
    vmm_monitor_irq_move(NULL,NULL,side_effect());
    vmm_monitor_diag_end(NULL,side_effect(),side_effect(),side_effect(),side_effect());
    assert(!vmm_monitor_diag_begin());
    vmm_monitor_exit(NULL,side_effect());
    vmm_monitor_mem_fault(NULL,0,side_effect(),side_effect());
    vmm_monitor_irq_sample(NULL,side_effect(),side_effect());
    vmm_monitor_irq_pending(NULL,side_effect(),side_effect());
    vmm_monitor_irq_injected(NULL,side_effect());
    vmm_monitor_irq_cancel(NULL,side_effect());
    assert(!calls && !vmm_monitor_enabled());
    /* Refer to function without invoking it, to retain -Werror coverage. */
    (void)side_effect;
    return 0;
}
