"""Exercise actual ARM64 stage-2 handler bodies with deterministic MMU mocks."""
import argparse, os, re, subprocess
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--cc',required=True); p.add_argument('--build-dir',required=True); a=p.parse_args()
root=Path(__file__).resolve().parents[2]; out=Path(a.build_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
src=(root/'arch/arm/cpu/arm64/cpu_vcpu_excep.c').read_text()
body=src[src.index('static int cpu_vcpu_stage2_map'):]
defs=(root/'arch/arm/cpu/arm64/include/cpu_defines.h').read_text()
defs='\n'.join(x for x in defs.splitlines() if re.match(r'#define\s+(ISS_ABORT_\w+|FSC_\w+)\s+0x[0-9a-fA-F]+\s*$',x))
prefix=r'''
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef u64 physical_addr_t;
typedef u64 physical_size_t;
typedef struct { u64 pc,pstate; } arch_regs_t;
struct vmm_guest { int ttbl; };
struct vmm_vcpu { struct vmm_guest *guest; };
struct mmu_page { u64 ia,oa,sz; u32 flags; };
#define VMM_OK 0
#define VMM_EFAIL -1
#define TRUE 1
#define VMM_REGION_ISRAM 256
#define VMM_REGION_ISROM 512
#define TTBL_L3_MAP_MASK (~4095ULL)
#define TTBL_L2_MAP_MASK (~((1ULL<<21)-1))
#define TTBL_L1_MAP_MASK (~((1ULL<<30)-1))
#define TTBL_L3_BLOCK_SIZE 4096
#define TTBL_L2_BLOCK_SIZE (1ULL<<21)
#define TTBL_L1_BLOCK_SIZE (1ULL<<30)
#define VMM_MONITOR_MAP_REJECT 2
#define VMM_MONITOR_PERMISSION 4
#define MMU_STAGE2 2
#define PSR_THUMB_ENABLED 32
#define PAR_PA_MASK (~4095ULL)
#define VA2PA_STAGE12 0
#define VA2PA_EL1 0
#define VA2PA_RD 0
#define arm_guest_priv(g) (g)
#define mrs(reg) (fake_##reg)
#define vmm_printf(...) ((void)0)
#define va2pa_at(a,b,c,d) ((void)0)
static u64 fake_far_el2=0xabcdef,fake_par_el1=0x1234000,last_addr,last_detail;
static int map_fail,map_page_fail,recheck_fail,faults,last_kind,emulated;
static void vmm_monitor_mem_fault(struct vmm_vcpu *v,u32 kind,u64 address,u64 detail) {
    (void)v; faults++; last_kind=kind; last_addr=address; last_detail=detail;
}
static int vmm_guest_physical_map(struct vmm_guest *g,u64 in,u64 size,u64 *out,u64 *available,u32 *flags) {
    (void)g; *out=in; *available=size; *flags=VMM_REGION_ISRAM; return map_fail?-1:0;
}
static void arch_mmu_pgflags_set(u32 *f,int stage,u32 flags) { (void)stage; *f=flags; }
static int mmu_map_page(int table,struct mmu_page *p) { (void)table; (void)p; return map_page_fail?-1:0; }
static int mmu_get_page(int table,u64 addr,struct mmu_page *p) { (void)table; (void)addr; (void)p; return recheck_fail?-1:0; }
static u32 vmm_host_memory_read(u64 addr,void *out,u32 size,int cacheable) { (void)addr; (void)cacheable; memset(out,0,size); return size; }
static int emulate_arm_inst(struct vmm_vcpu *v,arch_regs_t *r,u32 inst) { (void)v; (void)r; (void)inst; emulated++; return 0; }
static int emulate_thumb_inst(struct vmm_vcpu *v,arch_regs_t *r,u32 inst) { return emulate_arm_inst(v,r,inst); }
static int cpu_vcpu_emulate_load(struct vmm_vcpu *v,arch_regs_t *r,u32 il,u32 iss,u64 addr) { (void)il; (void)addr; return emulate_arm_inst(v,r,iss); }
static int cpu_vcpu_emulate_store(struct vmm_vcpu *v,arch_regs_t *r,u32 il,u32 iss,u64 addr) { return cpu_vcpu_emulate_load(v,r,il,iss,addr); }
'''
suffix=r'''
int main(void) {
    struct vmm_guest g={0}; struct vmm_vcpu v={&g}; arch_regs_t regs={0}; int n;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    assert(!cpu_vcpu_inst_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    map_page_fail=1;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    recheck_fail=1; assert(cpu_vcpu_data_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x4000) && !faults);
    map_page_fail=recheck_fail=0; map_fail=1;
    assert(cpu_vcpu_inst_abort(&v,&regs,1,FSC_TRANS_FAULT_LEVEL3,0x5000));
    assert(faults==1 && last_kind==2 && last_addr==0x5000); map_fail=0;
    assert(cpu_vcpu_data_abort(&v,&regs,1,FSC_PERM_FAULT_LEVEL3|0x400,0xdead));
    assert(faults==2 && last_kind==4 && last_addr==fake_far_el2 && (last_detail&0x400));
    assert(cpu_vcpu_inst_abort(&v,&regs,1,FSC_PERM_FAULT_LEVEL1,0xdead) && faults==3);
    n=faults;
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3|ISS_ABORT_ISV_MASK,0x6000));
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3|ISS_ABORT_ISV_MASK|ISS_ABORT_WNR_MASK,0x6000));
    assert(!cpu_vcpu_data_abort(&v,&regs,1,FSC_ACCESS_FAULT_LEVEL3,0x6000));
    assert(faults==n && emulated==3);
    puts("PASS: lazy map and SMP recovery not alarms; denied mapping/permission logged; FAR/FnV preserved; MMIO not misclassified");
    return 0;
}
'''
test=out/'abort_test.c'; test.write_text(prefix+defs+'\n'+body+suffix)
cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
exe=out/'abort.exe'; subprocess.run(cc+['-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter',str(test),'-o',str(exe)],check=True)
r=subprocess.run([str(exe)],capture_output=True,text=True,check=True)
(out/'abort.txt').write_text(r.stdout); print(r.stdout.strip())
