# monitor_agent v3：精简需求实现与手工合入说明

日期：2026-10-21。开源基线：`6e1a1fbd596f3da5ed2d244ec333113b2ec70e2f`。
适用：ARM64 Xvisor；产品 12 核、Linux/Android 两域，auth=4、mterm=3。

## 1. 本版范围及验收状态

本版仅保留 vCPU 调度/就绪等待、可感知的内存拒绝事件、exit 风暴、shell/JSON 和开关。
删除 Guest CPU/内存遥测及私有 HVC、指令诊断、IRQ 注入延迟、LPI/MOVI 配对、P99 直方图。
不修改产品的认证逻辑、Guest CPU 分配、GICv3/LPI 功能。

| 需求 | 实现与状态 |
|---|---|
| vCPU 调度延迟与就绪等待 | READY→selected；调度函数入口→上下文安装完成，分别记录累计次数/均值/最大值和当前 READY 等待年龄 |
| 内存越界/越权 | stage-2 映射请求被拒绝、终止处理的 permission fault、shmem 范围及授权检查；模型已覆盖，私有 DM/CCM 需接入 |
| exit 风暴日志 | 每 vCPU 实际时间窗口统计；默认严格 >50000/s，至少连续 5 个有效窗口且累计至少 5 秒；开始告警一次，恢复后可重新触发 |
| ROM ≤5KB | ARM64 `-Os` 对象段增量估算 5067 B；开机自动启用配置 5075 B；均小于 5120 B。**这不是完整产品固件链接结论，余量仅 53/45 B，合入后必须重新测量** |
| 内存分配 | 运行期静态槽与事件环；启动创建一个工作队列。符合之前确认的允许启动分配口径 |
| CPU <0.5% | **未板测**；需计入各核埋点、IRQ 统计、自动日志，不能用采样函数耗时单独证明 |
| 高优先级采集 | HV 执行路径与 timer IRQ；不依赖 Guest 主动让出 CPU，仍受宿主 IRQ 屏蔽和短锁竞争影响 |
| 结构化输出 | 选择“命令查看”分支，`monitor status/events` 输出 JSON；后台异常日志也是 JSON。无远程 virtio-serial/shmem 发布实现 |
| 编译/运行开关 | 默认编译关闭；编译开启时默认停止；命令 start/stop；另有开机启用配置 |

ROM 计入 monitor 核心、命令、既有函数埋点、共享内存授权包装器、初始化代码、常量和初始化数据；不将 shell/安全接口移出预算。
静态 BSS 15096 B（`MAX_VCPU_COUNT=64`，含命令对象），另计工作队列启动分配的线程栈和元数据。5KB 本版按 5120 字节理解，不是 5000 字节。
未执行完整固件链接、QEMU 启动、产品板运行、认证长稳或 CPU 开销测试。对象段测量不能替代这些验收。

## 2. 合入包选择

- **完整合入 patch**：相对上述干净开源基线；适合尚未合入 monitor 的分支。
- **从 v2 升级 patch**：相对本次修改前的 v2 参考树；包含删除和恢复旧打点，适合已合入上一版的分支。
- 两个 patch **二选一**，不能先完整合入再叠加升级 patch。
- `新增文件/` 提供相对开源基线的完整新文件；原有文件的变更同时提供函数/行号定位说明。
- 用户私有代码与参考树差异较大，应按函数与分支语义手工合入；不要直接覆盖整个 scheduler、VGIC 或异常处理函数。
- patch 中删除的都是本监控功能旧代码。特别是 `vgic.c` / `vmm_host_irq.c` 的升级差异，仅撤除 monitor IRQ 配对，**保留你已有打点和所有 GICv3/LPI 功能**。

可先在本地副本执行 `git apply --check 文件.patch`；该命令只检验上下文。存在冲突时按定位说明合入；不以强制覆盖代替人工判断。

## 3. 文件及函数职责

| 文件/函数 | 职责与打点依据 |
|---|---|
| `core/include/vmm_monitor.h` | 对外宏统一到 `vmm_monitor_record()`；编译关闭时宏不求值，时间戳参数也不执行 |
| `vmm_scheduler.c::__vmm_scheduler_next1/next2` | 目标确认后、`arch_vcpu_switch` 前调用 selected；返回后记录 dispatch；next2 当前 vCPU 再次被选中也要打点 |
| `vmm_scheduler.c::vmm_scheduler_state_change` | 真正更新状态时记录 READY/RESET/UNKNOWN 等；READY 重复通知不刷新起点，暂停/停止取消未完成等待 |
| `cpu_interrupts.c::do_sync` | 排除 EL2 自身异常后统计 Guest 同步退出；原有异常处理流程不变 |
| `cpu_interrupts.c::do_irq/do_hyp_fiq` | 仅当被打断上下文来自 Guest 时统计异步退出，原因标记为 `0x100` |
| `cpu_vcpu_excep.c::cpu_vcpu_stage2_map` | Guest 物理区域映射查询失败时记录 MAP_REJECT；成功懒映射、SMP 映射竞争恢复不记安全异常 |
| `cpu_vcpu_inst_abort/cpu_vcpu_data_abort` | 现有代码不恢复的 permission fault 记录 PERMISSION；正常 access fault/MMIO 仿真分支不记为权限违规 |
| `vmm_shmem.c::shmem_range` | 验证对象偏移、长度及宿主物理地址加法不回绕；原 read/write/set 均调用 |
| `shmem_guest_allowed/vmm_shmem_guest_access` | 按显式 actor 检查 GPA 映射、实际 backing、完整长度、只读属性及别名限制，再访问宿主内存 |
| `monitor_agent.c::vmm_monitor_record` | 按 vCPU 短锁更新时延、退出计数、内存异常摘要；不打印、不分配，不持有 scheduler 锁的反向引用 |
| `vmm_monitor_sample` | 唯一周期执行者；trylock 忙则跳过并计 skipped；计算有效窗口、持续时间、风暴状态；提交内存摘要 |
| `emit/memory_flush` | 固定 16 条环；保存原始异常首末时间；覆盖未输出事件时 lost 增加 |
| `tick/report/vmm_monitor_drain` | tick 在初始化核的 timer IRQ 执行；只有待输出事件才唤醒后台队列；每批最多 8 条 |
| `vmm_monitor_enable` | start 创建新 epoch，按槽惰性清理；stop 停止新数据接收；停止前已记录的内存异常仍能输出 |
| `vmm_monitor_dump` | 复制单槽/单事件后在锁外格式化，status 不清统计、events 不消耗后台游标 |
| `vmm_monitor_init` | 初始化静态槽，启动时创建 priority=3 日志队列并在当前核启动 timer；失败清理队列 |
| `cmd_monitor.c::vmm_monitor_cmd_init` | bool 内建命令直接注册；不再通过 module 表注册，减少冗余 ROM |
| `vmm_main.c` | 在 command manager 已初始化、modules 初始化前调用 monitor init，成功后注册命令；错误只报告，不阻止 Guest 启动 |

锁顺序固定为 slot→event；事件读取释放 event 锁后才读取 slot。采集不调用 mutex、不等 Guest 回复。后台输出不得在 IRQ 中调用。
宏入口只允许活着的 normal vCPU；不保留传入 vCPU 指针。私有调用者必须保证对象引用、调度状态及映射生命周期有效。

## 4. 时间及采样口径

```mermaid
flowchart LR
    R[真正进入 READY] --> S[选中且验证目标]
    D[调度函数入口] --> C[目标上下文安装完成]
    R --> M[静态 vCPU 槽]
    S --> M
    C --> M
    X[Guest exit / 内存拒绝] --> M
    M --> T[HV timer IRQ 每秒统计]
    T --> E[固定事件环]
    E --> W[后台 priority 3 日志]
    M --> Q[monitor status]
    E --> Q2[monitor events]
```

`ready` 是 READY→selected，`dispatch` 是调度函数进入→上下文安装完成。两者可能重叠，不能简单相加；dispatch 包含调度器及监控打点的执行时间，不是 Guest 第一条指令开始运行的精确时间。
两个时延统计是当前 epoch 内、自上次 vCPU RESET 后的**累计**值；不是上一秒直方图。不再输出 P99、jitter，也没有保存每次样本。
start 时已处在 READY 的 vCPU，如果没有随后收到 READY 状态通知，则不追补之前的等待，以免制造起点。
`ready_age_ns` 是查询时尚未结束的等待年龄；暂停/选中/停止后为 0。

exit 使用周期窗口计数。有效 dt 范围为 0.75～1.25 秒；异常间隔重置尚未完成的持续窗口，不把缺失时间记入连续 5 秒。已经触发的风暴在无效窗口上保持已告警状态，直到有效低负载窗口才解除内部状态。
风暴期间只写开始日志；恢复后下一次持续超限可以重新告警。本版不输出恢复事件，不 panic、不 reset、不限流。
门限判断使用 `count > floor(limit * dt / 1e9)`，不以显示值的舍入结果判断；日志 value 是实际速率向下取整。

## 5. 内存边界与私有 DM/CCM 接入

正式覆盖：二阶段映射/权限处理能感知的非法 CPU 访问，以及经过授权共享内存 API 检查发现的非法请求。
不覆盖已授权页面内的软件缓冲区越界；不自动覆盖 DMA/SMMU；不猜测缺少 actor 的宿主调用属于哪个 Guest。
监控是记录器，真正拒绝访问由原 MMU 路径或授权包装器完成；关掉监控并不撤掉已加入的共享内存范围/授权检查。

建议私有设备模型在服务 Guest 请求时调用：

```c
/* actor 必须来自当前请求的可信 Guest 上下文，不从 Guest 报文读取身份。 */
copied = vmm_shmem_guest_read(actor, shm, guest_pa, offset, dst, length, cacheable);
copied = vmm_shmem_guest_write(actor, shm, guest_pa, offset, src, length, cacheable);
```

这两个名称现在是宏，调用共同的 `vmm_shmem_guest_access(..., write)`；成功返回长度，失败返回 0。
调用者持有合法 Guest/shmem 引用，并串行化映射变更。查询到的 GPA 必须映射到该 shm 的同一 backing 偏移；请求不得跨出当前可映射段；alias 明确拒绝。不能只检查 Guest ID 后绕开范围/权限判断。
已有产品 ACL 拒绝分支也可以直接调用 `vmm_monitor_mem_fault(actor, kind, address, detail)`，避免重复访问或双重记账。
**参考树没有你的私有 DM/CCM 调用点，提供 API 不等于这些路径已经合入。**

内存 code 与 address/detail：

| code | 含义 | address | detail |
|---|---|---|---|
| 1 | SHMEM_BOUNDS | 授权 API 为请求 GPA；原宿主 API 无 actor 时为对象 offset | 请求长度 |
| 2 | MAP_REJECT | 映射查询失败的尝试 IPA | 返回错误码的 u64 表示；负数按 64 位补码解释 |
| 3 | ACCESS_DENIED | 授权共享内存请求的 GPA | 0=读，1=写；私有调用点应记录其约定的拒绝原因 |
| 4 | PERMISSION | FAR_EL2 原始值，**不能称为可靠 IPA** | 原始 ISS，FnV(bit10)=1 时 address 无效 |

permission fault 不能无条件用 HPFAR 推导物理地址，本版记录 FAR/ISS。产品若在 permission 分支进行脏页跟踪、COW 等合法恢复，应把记录点移至最终拒绝分支。
多个内存异常按同一 vCPU 合并；value 是总次数，time/last 是首末异常时间，code/address/detail 是**最后一次**异常的代表信息，并非每一种异常的完整追踪。重置和跨 epoch 清理前会提交旧摘要。

## 6. 配置、启动和 shell

```text
CONFIG_MONITOR_AGENT=y
CONFIG_CMD_MONITOR=y
CONFIG_MONITOR_PRIORITY=3
CONFIG_MONITOR_EXIT_RATE=50000
CONFIG_MONITOR_STORM_SECONDS=5
# CONFIG_MONITOR_START_ENABLED is not set
# CONFIG_MONITOR_EXTERNAL_EXECUTOR is not set

monitor start
monitor status
monitor events
monitor stop
```

优先级 3 只控制后台日志；不再存在优先级 6 的采样线程。timer 在调用初始化的 CPU 上启动，上游通常是启动核（一般为 0），通过 status.sampler_cpu 核对；本版移除 MONITOR_HCPU/IPI 启动流程。
初始化及 timer 使用要求该核持续在线；CPU hotplug 不在本次静态 12 核设计内。
stop 保留当前历史和队列，并允许先前已采集异常继续排出；每秒轻量 timer 仍存在，但没有新异常时不会唤醒日志线程。编译关闭去掉监控执行上下文。
start 已开启时是幂等的；stop→start 使用新 epoch，旧槽不再显示，直到新的打点产生。epoch 是启用批次，不是每次 vCPU RESET 的编号。
外部执行模式不创建 timer/队列，平台必须先 init，然后串行从 HV IRQ 调用 sample，每秒一次；从单一可睡眠后台调用 drain。此模式不是缺少平台调用也能自动工作的替代品。
产品 auth/mterm 的鉴权入口和命令白名单需要照旧保留；本版不绕过认证，也不能证明之前偶现认证卡住已经修复。
删除旧命令 cpu/irq/mem/guest/collect/diagnose/config；新命令仅四个。门限改为编译配置，运行时只启停。这里没有 `guest region_list` / `vm region_list` 的适配问题。

## 7. JSON schema=3

status 首行是全局状态；后续每行一个 normal vCPU。示例结构（数值仅示意）：

```json
{"schema":3,"enabled":1,"epoch":1,"sampler_cpu":0,"events":1,"lost":0,"skipped":0,"errors":0,"exit_limit":50000,"sustain_s":5}
{"schema":3,"guest":0,"vcpu":49,"epoch":1,"time_ns":1000000000,"interval_ns":1000000000,"valid":1,"exits":514,"ready_age_ns":0,"ready":[512,32554,1092208],"dispatch":[512,2000,9000]}
```

`ready/dispatch` 固定顺序为 **[样本次数, 平均纳秒, 最大纳秒]**，数组用于缩减格式字符串。count=0 表示无样本；不是零延迟证明。
`time_ns/interval_ns/exits/valid` 描述最近完成的 exit 统计窗口；时延累计值和 ready_age 来自命令读取时的单槽快照。不同 vCPU 行不保证同一瞬间快照。
`valid=1` 仅说明最近窗口时长在允许范围内，不代表系统健康；停止后窗口可能是历史值，要同时看 enabled 和时间。
查询时可按 `exits * 1e9 / interval_ns` 计算速率，不需要在每次 exit 中做除法。
`lost` 为被覆盖的尚未交给后台输出的事件数；`skipped` 为采样竞争跳过的槽数；`errors` 为 timer 重启/工作调度失败数，非零必须排查。

事件示例：

```json
{"schema":3,"seq":1,"time_ns":100,"last_ns":150,"type":3,"guest":1,"vcpu":54,"epoch":1,"code":3,"value":2,"address":8192,"detail":1}
```

type=1 是 exit 风暴，type=3 是内存摘要。风暴 time/last 是达到持续门限的判定时间，value 是速率，detail 是门限，code 是最后的 EC 或异步退出标记。
内存 time/last 是异常实际发生首末时间；guest/vcpu=4294967295 表示宿主调用无法归属 Guest。
`monitor events` 展示保留的最多 16 条事件，重复查询可能重复读到同一 seq，不改变后台输出游标。
环容量和后台每批 8 条有界；异常持续泛滥或后台被长期饿死时不能保证无损，丢失可见。避免将无限量同步串口日志放进 IRQ。
JSON 读取端应使用 64 位整数，避免 JavaScript Number 对大整数丢精度；JSONL 按行解析，并按 schema 区分旧版本。

## 8. 已执行验证及目标板测试

已执行：ARM64 开启/开机启用/关闭/外部执行/基线编译；ROM 对象段预算；主机生产代码模型；共享内存生产函数测试；ARM64 stage-2 生产函数测试；JSON 语法校验。详见包内报告与日志。

| 验收项 | 操作与预期 |
|---|---|
| CPU 两种区间 | 注入可控 READY 等待/切换工作量，分别比对时间戳；重复 READY 不改起点，暂停后不补样本 |
| 生命周期 | start/stop、vcpu reset/destroy/recreate；旧数据不串到新实例，停止前异常可排出 |
| 风暴边界 | 50000/s 不告警，50001/s 连续 5 个有效秒窗口告警一次；降低后再升高可重新触发 |
| 窗口质量 | 延迟 2 秒采样或制造锁竞争，不伪造连续 5 秒；检查 valid/skipped |
| 内存故障 | 未授权 IPA、终止 permission fault、shmem 长度越界/回绕/只读写入/错误 backing；对应事件与原失败返回一致 |
| 正常路径 | 合法懒映射、SMP 同页映射竞争恢复、MMIO load/store 仿真不产生内存越权告警 |
| 私有接口 | DM/CCM 的每条 Guest 内存访问路径明确使用授权包装器或 ACL 拒绝打点；不能只检验 API 存在 |
| 日志拥塞 | 暂停后台或持续制造异常，恢复后排出；lost 反映覆盖，没有 IRQ 中打印和无界排空 |
| auth/mterm | 默认停止、开启空载、Guest 压力、异常日志四种情况反复切换前台，检查认证交互和长稳 |
| ROM | 相同产品工具链/配置，未集成基线与集成版本比较最终加载段增量，含新增依赖和对齐，≤5120 B |
| CPU | 定义单核或整机分母与负载范围，包含所有核埋点和自动日志；建议关注最忙核，不能只看 12 核平均 |
| 确定性 | 测量 timer 到期→回调开始最大延迟、回调 WCET、最大 IRQ 屏蔽时间；明确验收上限 |

本地模型不能证明真实多核内存顺序、板端 WCET 或认证稳定性。生产私有锁和调度器 packed state 必须按语义适配。

复现命令（有 Python 和 Zig 的环境）：

```text
python tests/monitor/run_host_tests.py --cc <zig> --build-dir <host-build>
python tests/monitor/run_boundary_tests.py --cc <zig> --build-dir <shmem-build>
python tests/monitor/run_abort_tests.py --cc <zig> --build-dir <abort-build>
python tests/monitor/cross_compile.py --cc <zig> --build-dir <arm-build> --baseline-ref 6e1a1fbd596f3da5ed2d244ec333113b2ec70e2f --enforce-rom
```

私有仓库没有该基线时，可使用 `--baseline-dir <干净开源树>`。工具做翻译单元检查，不会自动生成可启动固件。
