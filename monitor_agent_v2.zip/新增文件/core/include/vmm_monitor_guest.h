/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __VMM_MONITOR_GUEST_H__
#define __VMM_MONITOR_GUEST_H__
#include <vmm_monitor.h>

/* Private ARM64 HVC ABI, deliberately separate from PSCI/SMCCC hvc #0. */
#define VMM_MONITOR_HVC_IMM 0x4d4f
#define VMM_MONITOR_HVC_MAGIC 0x584d4f4e00000001ULL
#define VMM_MONITOR_GUEST_CPU_VALID 1
#define VMM_MONITOR_GUEST_MEMORY_VALID 2
struct vmm_monitor_guest {
	u64 session, sequence, received_ns;
	u64 total_bytes, available_bytes, free_bytes;
	u32 cpu_bp, valid;
};
#ifdef CONFIG_MONITOR_AGENT
void vmm_monitor_guest_init(void);
void vmm_monitor_guest_reset(u32 guest);
int vmm_monitor_guest_report(struct vmm_vcpu *actor, u64 session, u64 sequence,
		u64 cpu_bp, u64 total, u64 available, u64 free_bytes, u64 valid);
int vmm_monitor_guest_get(u32 guest, struct vmm_monitor_guest *out);
void vmm_monitor_guest_sample(u64 now, u32 limit_bp);
void vmm_monitor_guest_event(u32 guest, u64 now, u64 value, u32 limit);
#endif
#endif
