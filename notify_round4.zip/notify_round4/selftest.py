#!/usr/bin/env python3
import unittest
from analyze_sched_wait import pair_events, percentile

class Pairing(unittest.TestCase):
    def test_complete(self):
        s='''w-79 [000] d..2 1.000001: sched_waking: comm=a pid=193 prio=120 target_cpu=001
<idle>-0 [001] d..2 1.000005: sched_wakeup: comm=a pid=193 prio=120 target_cpu=001
b-0 [001] d..2 1.000009: sched_switch: prev_comm=b prev_pid=0 prev_prio=120 prev_state=R ==> next_comm=a next_pid=193 next_prio=120'''
        rows, diag=pair_events(s,{193})
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['waking_to_wakeup_ns'],4000)
        self.assertEqual(rows[0]['runnable_to_run_ns'],4000)
        self.assertEqual(rows[0]['waking_to_run_ns'],8000)
        self.assertEqual(rows[0]['source_cpu'],0)
    def test_partial(self):
        rows,_=pair_events('''b-0 [001] d..2 1.000005: sched_wakeup: comm=a pid=193 prio=120 target_cpu=001
b-0 [001] d..2 1.000009: sched_switch: prev_pid=0 ==> next_pid=193''',{193})
        self.assertIsNone(rows[0]['waking_to_run_ns'])
        self.assertEqual(rows[0]['runnable_to_run_ns'],4000)
    def test_incomplete(self):
        rows,d=pair_events('w-79 [000] d..2 1.000001: sched_waking: comm=a pid=193 prio=120 target_cpu=001',{193})
        self.assertEqual(rows,[]);self.assertEqual(d['incomplete_end'],1)
    def test_duplicate(self):
        s='''w-79 [000] d..2 1.000001: sched_waking: comm=a pid=193 prio=120 target_cpu=001
w-79 [000] d..2 1.000002: sched_waking: comm=a pid=193 prio=120 target_cpu=001
b-0 [001] d..2 1.000005: sched_wakeup: comm=a pid=193 prio=120 target_cpu=001
b-0 [001] d..2 1.000009: sched_switch: prev_pid=0 ==> next_pid=193'''
        rows,d=pair_events(s,{193})
        self.assertEqual(d['duplicate_waking'],1)
        self.assertEqual(rows[0]['waking_to_run_ns'],7000)
    def test_time_reversal(self):
        s='''w-79 [000] d..2 2.000001: sched_waking: comm=a pid=193
b-0 [001] d..2 1.000005: sched_wakeup: comm=a pid=193'''
        with self.assertRaises(ValueError):pair_events(s,{193})
    def test_percentile(self):
        self.assertEqual(percentile([1000,3000],50),2)
        self.assertIsNone(percentile([],95))

if __name__=='__main__': unittest.main()
