#!/bin/sh
# A/B is a filename label, not a CPU policy. No full trace buffer is created.
set -eu
[ "$#" -ge 3 ] && [ "$#" -le 4 ] || { echo "Usage: sh $0 IO_TID VH_TID LABEL [duration=3]" >&2;exit 2; }
IO=$1;VH=$2;LABEL=$3;CAPTURE_S=${4:-3}
MODE=${MODE:-timing};SAMPLE_SHIFT=${SAMPLE_SHIFT:-8};REPORT_DELAY=${REPORT_DELAY:-60}
TX_ADDR=${TX_ADDR:-0x6020003004};PROC=${R6_PROC:-/proc/r6_notify};BASE=${OUTPUT_BASE:-/tmp/r6_notify}
case "$IO:$VH" in *[!0-9:]*|:*|*:) echo 'Invalid TID' >&2;exit 2;; esac
[ "$IO" -gt 0 ] && [ "$VH" -gt 0 ] && [ "$IO" != "$VH" ] || exit 2
case "$LABEL" in ''|*[!a-zA-Z0-9_.-]*) echo 'Invalid label' >&2;exit 2;; esac
awk -v v="$CAPTURE_S" 'BEGIN{if(v !~ /^[0-9]+([.][0-9]+)?$/ || v+0<0.1 || v+0>5)exit 1}' || { echo 'duration must be 0.1..5 seconds' >&2;exit 2; }
awk -v v="$SAMPLE_SHIFT" 'BEGIN{if(v !~ /^[0-9]+$/ || v+0>16)exit 1}' || exit 2
awk -v v="$REPORT_DELAY" 'BEGIN{if(v !~ /^[0-9]+$/ || v+0>600)exit 1}' || exit 2
case "$TX_ADDR" in 0x*) HEX=${TX_ADDR#0x};; *) echo 'TX_ADDR must be hexadecimal' >&2;exit 2;; esac
case "$HEX" in ''|*[!0-9a-fA-F]*) exit 2;; esac
[ "${#HEX}" -le 16 ] || exit 2
case "$MODE" in baseline) SHIFT=-2;; counts) SHIFT=-1;; timing) SHIFT=$SAMPLE_SHIFT;; *) echo 'MODE=baseline|counts|timing' >&2;exit 2;; esac
[ -r "$PROC" ] && [ -w "$PROC" ] || { echo "Missing $PROC; update kernel" >&2;exit 1; }
for t in "$IO" "$VH";do [ -r "/proc/$t/comm" ] || { echo "Missing TID $t" >&2;exit 1; };done
mkdir /tmp/r6_notify_capture.lock 2>/dev/null || { echo 'Existing capture or stale /tmp/r6_notify_capture.lock' >&2;exit 1; }
STARTED=0
cleanup(){ if [ "$STARTED" = 1 ];then echo stop > "$PROC" 2>/dev/null || :;fi;rmdir /tmp/r6_notify_capture.lock 2>/dev/null || :; }
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM HUP
if [ -n "${COLLECT_CPU:-}" ];then taskset -pc "$COLLECT_CPU" "$$" >/dev/null;fi
for p in /sys/module/ccm_proxy/parameters/ioem_run /sys/module/ccm_proxy/parameters/n4_run /sys/module/vhost_net/parameters/n4_run;do
 if [ -r "$p" ];then v=$(cat "$p");case "$v" in 0|N|n) :;; *) echo "Stop old probe: $p=$v" >&2;exit 1;;esac;fi
done
sleep 0.001 || { echo 'fractional sleep not supported' >&2;exit 1; }
OUT=$BASE/${LABEL}_${MODE}_$(date +%Y%m%d_%H%M%S)_$$;mkdir -p "$OUT"
context(){
 echo "label=$LABEL mode=$MODE io_tid=$IO vh_tid=$VH capture_s=$CAPTURE_S shift=$SHIFT tx_addr=$TX_ADDR"
 uname -a
 for t in "$IO" "$VH";do
  echo "TID=$t";cat "/proc/$t/comm";grep -E '^(Name|Pid|Tgid|Cpus_allowed_list):' "/proc/$t/status";cat "/proc/$t/stat"
  if [ -r "/proc/$t/schedstat" ];then printf 'schedstat=';cat "/proc/$t/schedstat";fi
 done
 cat /sys/devices/system/cpu/online
 awk '$NF=="eth0" {print}' /proc/interrupts
 IDS=$(awk '$NF=="eth0"{gsub(":","",$1);print $1}' /proc/interrupts)
 for irq in $IDS;do
  printf 'IRQ%s requested=' "$irq";cat "/proc/irq/$irq/smp_affinity_list"
  if [ -r "/proc/irq/$irq/effective_affinity_list" ];then printf 'IRQ%s effective=' "$irq";cat "/proc/irq/$irq/effective_affinity_list";fi
 done
}
context > "$OUT/context_before.txt"
cat "$PROC" > "$OUT/previous_report.txt" || { echo 'R6 already active or report failed' >&2;exit 1; }
echo "Capture $LABEL/$MODE for ${CAPTURE_S}s, then wait ${REPORT_DELAY}s before export."
STARTED=1
printf 'start %s %s %s %s\n' "$IO" "$VH" "$SHIFT" "$TX_ADDR" > "$PROC"
sleep "$CAPTURE_S"
echo stop > "$PROC"
STARTED=0
sleep "$REPORT_DELAY"
cat "$PROC" > "$OUT/r6_report.txt"
context > "$OUT/context_after.txt"
echo "OUTPUT_DIR=$OUT"
