core-objs-$(CONFIG_MONITOR_AGENT)+= monitor/monitor_agent.o
