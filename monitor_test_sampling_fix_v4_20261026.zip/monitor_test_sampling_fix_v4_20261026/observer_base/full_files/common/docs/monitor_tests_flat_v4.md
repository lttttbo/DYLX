> 2026-10-26 修正：按目标 actor 判断采样进度，补齐失败诊断。旧验证描述为 10 月 25 日历史结果；本次结果见外层 README.txt 和 validation。

# Monitor v4：平铺测试目录，直接从记录版合入

日期：2026-10-25。唯一基线：`monitor_observer_from_20261023_v4_20261025` 已合入后的工程。

## 1. 合入内容

本包按确认的目录方案重制，直接包含记录版之后的测试归组、三个 Hypervisor 内存用例、单一开关、头文件合并和目录整理。无需先合入任何中间测试包，也不要与之前的增量补丁叠加。

板端只合入根目录两份补丁：

1. `from_observer.patch`：以记录版为基线，修改核心测试支持和 wboxtest、整理目录及说明。
2. `cmd_memory_from_uploaded.patch`：记录版未修改该命令，因此以你上传的原 `cmd_memory.c.txt` 为基线，追加原拒绝分支的记录和检查适配函数。

两份均以 Hypervisor 根目录为路径起点。按 `merge_locations.txt` 的函数、上下文和原行号手工合入；新增/修改后的完整文件在 `full_files`，不要覆盖私有改动。上传命令首行缺注释开头斜杠，参考文件已补齐；工程头注释正确时忽略这个注释差异。

开发机模型、Python 脚本及其更新补丁统一放在包内 `optional_verification`，不在板端必需修改清单中。`optional_verification/tools_from_observer.patch` 仅用于开发机复验，板端不需要合入。生成的同名替代头文件只存在于开发机验证输出目录，不要覆盖正式头文件。

现有 CCM、Linux/Android 内核、VM 生命周期及访问策略沿用记录版。本包不重复修改调度器、cpu_hcall.c、vmm_u_ioreq.c 或 vmm_shmem.c。

## 2. 最终源码分布

```text
core/include/vmm_monitor.h       生产声明 + 测试开关下的测试接口和结构
core/monitor/monitor_agent.c     原监控实现 + 测试只读查询实现
commands/cmd_memory.c            原命令 + 拒绝记录点 + 测试检查适配

libs/wboxtest/monitor/
    openconf.cfg                唯一测试选项
    objects.mk                  明确列出七个编译对象
    common.h                    原测试内部头文件，保留
    support.c                   隔离实例、模拟时间和输出捕获
    lifecycle.c                 启停与配置两个用例
    scheduler.c                 调度统计白盒测试
    memory.c                    隔离内存测试
    memory_runtime.c            三个真实 Hypervisor 内存测试
    storm.c                     陷入风暴白盒测试
    output.c                    JSON/命令/日志调用测试
    guest_cases.c                原 Guest 配合用例，保留但本阶段不编译

tests/monitor/                  可选的开发机工具，不参与固件构建
```

板端 monitor 测试目录不再包含 host/live 子目录。不新增头文件，保留现有 common.h。

- 删除原 vmm_monitor_test.h；其内容以及命令检查适配声明统一放在 vmm_monitor.h 的 CONFIG_WBOXTEST_MONITOR 条件区。
- 删除 monitor_test.inc；四个只读查询函数直接放在 monitor_agent.c 末尾，同一测试条件下编译。
- 原 monitor_live 五份 C/H 的内容合并保存到 guest_cases.c，辅助函数在本文件内私有化；其三个用例和控制命令当前不注册。
- 删除补丁列出的旧 monitor_live 配置、对象列表及五份 C/H。保留 protocol.h 和用户其他文件，它们不参与当前构建。
- memory.c 使用隔离副本和替代访问接口；memory_runtime.c 使用真实 monitor、原命令检查和真实共享内存 API。保持两个编译单元，避免宏替换串用。

测试场景、等待、匹配和断言位于 wboxtest。monitor_agent.c 只保留访问内部 static 数据和锁所需的只读适配；cmd_memory.c 只保留访问原 static 检查函数所需的适配。这些测试接口随测试开关关闭而消失。

## 3. 配置和执行

monitor 测试仅有一个选项：

```text
CONFIG_WBOXTEST_MONITOR=y
```

已有框架及生产功能仍需 CONFIG_WBOXTEST=y、CONFIG_MONITOR_AGENT=y、CONFIG_CMD_MONITOR=y。CMD_WBOXTEST 和 CMD_MEMORY 由测试选项自动选择；没有 HOST/LIVE 子选项。

合入后重新生成配置，并清理旧测试对象后构建。旧 monitor_live/objects.mk 不可保留编译行。即使源文件存在，也不要用通配符把 guest_cases.c 加入 objects.mk。

```text
monitor start
wboxtest run_groups 1 monitor
```

当前固定 9 项：monitor_lifecycle、monitor_config、monitor_scheduler、monitor_memory、monitor_storm、monitor_output，以及 monitor_host_range、monitor_host_guest_guard、monitor_host_shmem。用例名称保持，文件名变成 memory_runtime.c。

逐项执行可用 `wboxtest run_tests 1 monitor_host_range` 等。当前不需要 monitor_live target、新 Guest 或 Guest 用户态程序。Guest 写保护用例仍需已有符合原检查条件的 Guest RAM/ROM 映射，但 Guest 可以不运行；缺少条件明确失败，不计为通过。测试期间保持 monitor 配置、启停和 VM 映射稳定；新增测试每次等待采样的上限为 8 秒。

## 4. 当前覆盖范围

| 用例 | 自动验证内容 | 边界 |
|---|---|---|
| 原六项隔离测试 | 启停、配置、调度统计、内存事件、exit 风暴、JSON 和日志调用 | 模拟时间/输入和私有实例，不代替真实调度器或 Guest exit 链路验收 |
| monitor_host_range | 原命令地址范围/分类拒绝，真实 monitor 事件参数匹配 | 只检查，不映射或读写非法物理地址 |
| monitor_host_guest_guard | 原禁止写 Guest 地址分支拒绝并记录 | 不写 Guest 地址；选择一个实际可达的既有映射 |
| monitor_host_shmem | 测试专用对象的合法读写/填充及三类普通越界，事件正确、拒绝后数据不变 | 使用真实共享内存 API，结束释放自有对象 |

三个实际内存用例不直接注入事件，不主动调用 sample/drain 制造成功。先记录事件游标、时间和真实采样完成序号，再等待目标槽位两次成功完成 memory_flush，核对 code/address/detail/主体/epoch/时间/次数。丢失、执行器错误、目标槽位采样停滞或证据混入不会算作通过；无关槽位的 skipped 增量仅作提示。

这些结果不覆盖任意 Hypervisor 裸指针越界、所有 Guest 自行访存或所有域。ROM ≤5KB、CPU <0.5%、真实执行上下文和日志落盘仍需单独验收。测试自身申请共享内存，不用于计量生产 monitor 的内存和 CPU 开销。

## 5. 记录和日志

schema=3、内存 type=3；原 code=1..7 保持，新增 code=8。

| 来源 | code | address | detail |
|---|---|---|---|
| 原 mem 范围/分类拒绝 | 8 | 检查的 HPA | 高32位：读0/写1；低32位：宽度 |
| 原禁止写 Guest 内存 | 3 | 检查的 HPA | 同上 |
| 原 shmem 越界 | 1 | 对象内 offset | 请求长度 |

命令拒绝记录主体是当前 host vCPU，不把被保护的 Guest 作为访问发起者。shmem 原接口 actor=NULL，guest/vcpu 为 4294967295。原写入分类可能合并下层错误，所以 code=8 只表示原检查拒绝，不将每次拒绝额外解释为实际物理越界。

自动输出中的 `monitor_host EVENT seq=... epoch=... ...; log=manual` 用于人工核对原日志后端的 JSON。用例不等待日志落盘、不增加存储实现。

## 6. 验证结果

本次重新验证：

- 当前构建 9 个 ARM64 编译单元；测试关闭 2 个编译单元；无重复全局符号，关闭时六个测试接口消失。
- 合并后的 guest_cases.c 单独编译检查通过，但不加入当前测试对象、不执行 Guest 用例。
- 原六项隔离用例 54 次执行、三种模式下的只读接口回归及 8 项历史证据解析测试通过。
- 360 组原/新命令返回和分类对照，以及三个实际用例代码的平台模型测试通过；漏记、错误事件码、无 Guest、停止/跳过采样和关闭监控反例按预期检测。
- 核对发布记录版及继承依赖的哈希；直接应用补丁、结果一致性、反向还原和打包校验通过。

板端必需补丁与可选开发机补丁分别列入清单。可选工具不会参与固件构建，板端必需文件与本次已验证源码一致。尚未完成你的私有固件完整链接或 QEMU/板卡执行。
