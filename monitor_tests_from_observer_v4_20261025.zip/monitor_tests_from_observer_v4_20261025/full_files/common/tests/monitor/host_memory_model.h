/* Host-only platform model; not used by firmware. */
#ifndef MONITOR_HOST_MEMORY_MODEL_H
#define MONITOR_HOST_MEMORY_MODEL_H
#include "host.h"
typedef uint8_t u8;
typedef u64 physical_addr_t;
typedef u64 physical_size_t;
#define VMM_PAGE_SHIFT 12
#define VMM_PAGE_SIZE 4096ULL
#define VMM_PAGE_MASK 4095ULL
#define VMM_IS_ERR_OR_NULL(p) (!(p) || (uintptr_t)(p) > (uintptr_t)-4096)
#define VMM_REGION_REAL 1
#define VMM_REGION_MEMORY 2
#define VMM_REGION_ISRAM 4
#define VMM_REGION_ISROM 8
#define VMM_REGION_ISDEVICE 16
#define WBOXTEST_IPRIORITY 1
struct vmm_region { u32 flags; };
struct vmm_resource { int unused; };
extern struct vmm_resource vmm_hostmem_resource;
struct vmm_shmem { physical_addr_t addr; physical_size_t size; };
struct wboxtest {
    char name[64];
    int (*run)(struct wboxtest *, struct vmm_chardev *, u32);
};
#define VMM_DECLARE_MODULE2(n,d,a,l,p,init,exit) \
    int init##_host(void) { (void)exit; return init(); }
int wboxtest_register(const char *, struct wboxtest *);
void wboxtest_unregister(struct wboxtest *);
static inline int vmm_mutex_trylock(struct vmm_mutex *m) {
    if(m->held) return 0;
    m->held=1;return 1;
}
struct vmm_vcpu *vmm_scheduler_current_vcpu(void);
u32 vmm_host_ram_bank_count(void);
physical_addr_t vmm_host_ram_bank_start(u32);
physical_size_t vmm_host_ram_bank_size(u32);
void *vmm_zalloc(size_t);
void vmm_free(void *);
int vmm_manager_guest_iterate(int (*)(struct vmm_guest *,void *),void *);
void vmm_guest_iterate_region(struct vmm_guest *,u32,void (*)(struct vmm_guest *,struct vmm_region *,void *),void *);
void vmm_guest_iterate_mapping(struct vmm_guest *,struct vmm_region *,
    void (*)(struct vmm_guest *,struct vmm_region *,u64,u64,u64,void *),void *);
int vmm_walk_tree_res(struct vmm_resource *,void *,int (*)(const char *,u64,u64,unsigned long,int,void *));
struct vmm_shmem *vmm_shmem_create(const char *,physical_size_t,u32,void *);
void vmm_shmem_destroy(struct vmm_shmem *);
u32 vmm_host_memory_read(physical_addr_t,void *,u32,bool);
u32 vmm_host_memory_write(physical_addr_t,void *,u32,bool);
u32 vmm_host_memory_set(physical_addr_t,u8,u32,bool);
#endif
