/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright (c) 2024 ZTE Authors. All rights reserved. */
#include "test_irq.h"

#define MODULE_DESC "test_irq_priority test"
#define MODULE_AUTHOR "ZTE Authors"
#define MODULE_LICENSE "GPL"
#define MODULE_IPRIORITY (WBOXTEST_IPRIORITY + 1)

static int priority_prepare_pair(u32 a, u32 expected_first)
{
	u32 i;
	int rc;

	for (i = a; i < a + 2U; i++) {
		rc = test_irq_set_affinity(i, vmm_cpumask_of(test_irq_cpu()));
		if (!rc) {
			rc = test_irq_set_priority(i, i == expected_first ? 0 : 1);
		}
		if (!rc) {
			rc = test_irq_register(i, "test_irq_priority");
		}
		if (rc) {
			return rc;
		}
	}
	return VMM_OK;
}

static int priority_pair_case(struct vmm_chardev *out, u32 number, u32 a, u32 first)
{
	int rc;

	vmm_cprintf(out, "TEST%u: pair=%u/%u expected_first=%u\n", number, test_irq_id(a),
		    test_irq_id(a + 1U), test_irq_id(first));
	rc = priority_prepare_pair(a, first);
	if (!rc) {
		rc = test_irq_pair(a, a + 1U, first);
	}
	return rc;
}

static int priority_sgi_case(struct vmm_chardev *out)
{
	u32 slot;
	int rc;

	vmm_cprintf(out, "TEST3: equal priority SGIs; complete SGI%u before raising SGI%u\n",
		    SGI_ID2, SGI_ID1);
	for (slot = TEST_IRQ_SGI1; slot <= TEST_IRQ_SGI2; slot++) {
		rc = test_irq_set_priority(slot, 0);
		if (!rc) {
			rc = test_irq_register(slot, "test_irq_sgi");
		}
		if (rc) {
			return rc;
		}
	}
	/* No assumption of FIFO ordering for two simultaneously pending equal IRQs. */
	rc = test_irq_sgi(TEST_IRQ_SGI2);
	if (!rc) {
		rc = test_irq_sgi(TEST_IRQ_SGI1);
	}
	return rc;
}

static int priority_high_freq(struct vmm_chardev *out)
{
	struct test_irq_result high;
	struct test_irq_result low;
	u64 started;
	u64 iterations = 0;
	u64 high_sum = 0;
	u64 low_sum = 0;
	int rc;

	vmm_cprintf(out, "TEST4: 60s repeated pairs, 100us delay after each completed pair\n");
	/* Allocate/register once, not once per trigger. Cleanup belongs to end(). */
	rc = priority_prepare_pair(4, 4);
	if (rc) {
		return rc;
	}
	started = vmm_timer_timestamp();
	do {
		rc = test_irq_pair(4, 5, 4);
		if (rc) {
			vmm_cprintf(out, "TEST4 failed iteration=%llu irq=%u/%u rc=%d\n",
				    (unsigned long long)iterations, test_irq_id(4), test_irq_id(5),
				    rc);
			return rc;
		}
		test_irq_result(4, &high);
		test_irq_result(5, &low);
		high_sum += high.latency_ns;
		low_sum += low.latency_ns;
		iterations++;
		vmm_udelay(100);
	} while (vmm_timer_timestamp() - started < 60000000000ULL);
	vmm_cprintf(out, "TEST4 pairs=%llu mean_high_ns=%llu mean_low_ns=%llu\n",
		    (unsigned long long)iterations, (unsigned long long)(high_sum / iterations),
		    (unsigned long long)(low_sum / iterations));
	return high_sum <= low_sum ? VMM_OK : VMM_EFAIL;
}

static int priority_get_case(struct vmm_chardev *out)
{
	u8 priority = 0;
	u32 levels = 0;
	u32 pmr = 0;
	int rc;

	vmm_cprintf(out, "TEST5: get logical priority and levels\n");
	rc = vmm_host_irq_get_priority(test_irq_id(0), &priority);
	if (!rc && priority != 0) {
		rc = VMM_EFAIL;
	}
	if (!rc) {
		rc = vmm_host_irq_priority_level(test_irq_id(0), &levels, &pmr);
		if (!rc && (levels < 2U || priority >= levels)) {
			rc = VMM_EFAIL;
		}
	}
	return rc;
}

static int test_irq_priority_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
	int rc = test_irq_begin(out, cpu, 2);

	(void)test;
	if (rc) {
		return rc;
	}
	rc = priority_pair_case(out, 1, 0, 0);
	if (!rc) {
		rc = priority_pair_case(out, 2, 2, 3);
	}
	if (!rc) {
		rc = priority_sgi_case(out);
	}
	if (!rc) {
		rc = priority_high_freq(out);
	}
	if (!rc) {
		rc = priority_get_case(out);
	}
	return test_irq_end(out, rc);
}

static struct wboxtest test_irq_priority = {
	.name = "irq_priority",
	.run = test_irq_priority_run,
};

static int __init test_irq_priority_init(void)
{
	return wboxtest_register("interrupt", &test_irq_priority);
}

static void __exit test_irq_priority_exit(void)
{
	wboxtest_unregister(&test_irq_priority);
}

VMM_DECLARE_MODULE(MODULE_DESC, MODULE_AUTHOR, MODULE_LICENSE, MODULE_IPRIORITY,
		   test_irq_priority_init, test_irq_priority_exit);
