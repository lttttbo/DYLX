# HOS 中断测试自动选择 v4（2026-11-11）

按本次要求，采用“扫描当前未注册 IRQ”的轻量方案，不建立资源池、不引入软件 IRQ 测试域，
不增加排他预留机制。没有改变真实 SPI 测试方式。

## 改动范围

- 新增一个 test_irq_select.c：扫描并发布六个运行时 SPI ID。
- 修改现有 test_irq.h：六个 SPI 宏改为读取运行时数组；SGI 保持原配置。
- 原 irq_priority/irq_affinity/irq_base/irq_type 的 run 起始处增加一次扫描并检查返回值。
- 两个 debug 入口已适配。
- 使用原中断测试编译条件，只需增加一个对象条目，没有新增 Kconfig 开关。

务必完成 manual_merge.txt 的所有步骤。仅应用 changes.patch 不会替你修改尚未提供的私有测试入口或 objects.mk。
头文件来自之前贴出的内容；若本地已补充声明，应保留这些内容。
SPI_ID* 现在是运行时表达式，不能再用于 case 标签、预处理 #if 或要求常量的全局初始化。
已提供的三个测试使用它们作为函数参数，适用；未提供的其他用法需要相应改为运行时初始化。

## 选择规则

每次串行 wboxtest .run 开始时，按 HIRQ 升序扫描 vmm_host_irq_count() 范围，选择三对。
本版针对当前 HOS 的 chip name="GICv3"，并要求：

1. descriptor/chip 有效，硬件 IRQ 为普通 SPI（32～1019）。排除扩展 IRQ、SGI/PPI、IPI 和 chained。
2. 所有 CONFIG_CPU_COUNT 对应的 action_list 均为空；不只检查当前 CPU，也检查离线 CPU 的记录。
3. 没有 Guest routed 标志。
4. get_routed_state 成功，硬件 masked、pending=0、active=0，当前读取 CPU 的软件 mask 也为真。
5. 能读取逻辑优先级和等级信息，至少支持两个等级，当前读回值在等级范围内。
6. 每对 HIRQ 相邻、HWIRQ 相邻，控制器及 chip_data 相同，且 HWIRQ 不跨 32 位 pending 寄存器。
   同时满足你当前 trigger_two 包装函数基于 HIRQ 的边界检查。
7. 六个 HIRQ 不重复，同一控制器/数据实例中的硬件 IRQ 也不重复。

名称为空、计数为零不是筛选要求；注销后留下的名称和历史计数不会阻止再次选取。
反之，某 IRQ 即使有非空旧名称，只要其他条件满足，也可能被选中。

只有找到完整三对并再次检查通过，才更新 SPI_ID1～SPI_ID6。
未找到完整三对返回 VMM_ENOTAVAIL；复查时发现占用/状态变化返回 VMM_EBUSY。
失败时六个 ID 保持为 ~0U，不沿用上次结果，也不会误用 IRQ0。

扫描只调用查询接口，不注册、unmask、清 pending 或试触发任何候选。
成功后由原测试执行真实寄存器操作和中断触发，不做“遍历试打全部 IRQ”。

## 输出

```text
IRQSCAN: current registration/state only; board ownership unknown
IRQSCAN: pair1 hirq=.../... hwirq=.../...
IRQSCAN: pair2 hirq=.../... hwirq=.../...
IRQSCAN: pair3 hirq=.../... hwirq=.../...
```

如果不足三对，输出 need 3 pairs、found 和拒绝原因摘要；拒绝数量按候选检查计数，
不是独立设备数量。已检查的相邻候选可能重复涉及同一个 IRQ。
号码每次 run 都可能变化，不保证仍选 151～156。

先确认合入完整后，可沿用原命令：

```text
unittest run_tests 1 irq_priority_debug
unittest run_tests 1 irq_priority_debug_spi56
```

两个诊断都从当次扫描结果取号：第一个使用 pair1，第二个使用 pair3。
它们分别扫描，不要求跨测试保持相同结果。
原测试入口也适配后，才运行对应的 irq_priority 等用例。

## 这个小范围方案明确不保证什么

扫描结果只表示检查时没有注册/Guest 路由记录且状态满足条件，不是板级授权或硬件资源归属证明。
尚未初始化、尚未注册或由其他固件管理的设备，仍可能实际占用这些物理中断。
本方案是在已说明该限制后，按当前调试需求提供的候选选择方式。

复查不是原子保留。现有 register 允许不同 dev 的 action 共享一个 IRQ，
其他驱动/Guest 路由仍可能在检查结束后注册。不要把“最终复查成功”理解为排他锁定。
使用现有串行 wboxtest 入口，测试期间不要并发执行另一套 IRQ 测试或动态装载/卸载设备及 Guest。
这项运行约束也不能解决未注册设备的板级归属未知问题。

SGI5/6 不在自动选择范围内，仍由原测试使用原配置。
本版只针对 GICv3 普通 SPI，不自动扫描 LPI、ITS、其他控制器。

## 原测试逻辑的边界

选择器不接管原测试的 handler，也不改原测试的断言和清理流程。
通过自动选号不等于修复以下既有问题：

- 原 case4 若仍忽略 test_irq_high_freq 返回值，仍可能出现 timeout 后 PASS。
- 原 case2/case3 若未重置 exec_order 下标，仍可能越界。
- 原测试仍需检查注册/注销返回值，并在失败路径清理自己的处理函数。
- “当前 affinity 必须等于 ALL”不是自动候选的保证；原有默认值假设若不成立，须按测试目标调整。
- 扫描不恢复上一用例留下的优先级、类型或 affinity；这些配置仍属于原测试的生命周期职责。

某个原用例失败后遗留 action，后续扫描会排除该 IRQ，但不会强行注销它。
重新扫描不是资源泄漏修复；若出现失败，应先保留日志并停止重复运行，排查清理路径。
本包保留这些边界，是为了把此次改动限定在自动选择，没有顺带重写整套测试。

## 验证

选择器和已修改的 debug 文件通过 12/16 核 ARM64 freestanding -O2 对象编译，
使用 -Wall -Wextra -Werror 和参考头文件必要的既有警告豁免。
私有优先级/触发 API 的声明在验证环境按已提供代码补入，未覆盖 HOS 私有头文件。

15 个接口模拟场景通过：正常选取、排除已路由/已注册项、排除 SGI/PPI 范围、
排除 pending/active/未 masked 项、硬件 bank 边界、非恒等 HIRQ/HWIRQ 映射、
查询失败、等级不足、优先级读回越界、最后一个 CPU 上注册、扫描后状态变化、
其他 chip、HIRQ 包装函数边界、重复硬件别名、历史名称/计数保留。
验证失败时号码全部无效、读锁成对释放，以及正常扫描不改 descriptor/硬件模型状态。

尚未执行 HOS 完整链接或单板测试，也未编译未提供完整源码的原四个测试文件。
changes.patch 已按标注基线验证正反向恢复；私有文件有差异时以手工合入说明为准。
