/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef VHOST_ROUND5_H
#define VHOST_ROUND5_H

/* Diagnostic-only API. Include after the local drivers/vhost/vhost.h.
 * Definitions/control live in vhost.c, never include the implementation twice.
 */
#include <linux/types.h>

struct vhost_dev;
struct vhost_work;
struct vhost_poll;
struct vhost_virtqueue;

#define N5_SOURCES(X) \
 X(DIRECT_WORK, "direct_work_api") \
 X(UNTAGGED_POLL, "untagged_poll_api") \
 X(POLL_EVENT, "poll_event") \
 X(POLL_START_READY, "poll_start_already_ready") \
 X(WEIGHT, "weight_limit") \
 X(IOTLB, "iotlb_update") \
 X(COPY_TAIL_PENDING, "copy_tail_not_proven_empty") \
 X(COPY_TAIL_RECHECK, "copy_tail_notify_changed") \
 X(BUSY_PEER_PENDING, "busy_peer_not_proven_empty") \
 X(BUSY_PEER_RECHECK, "busy_peer_notify_changed") \
 X(COPY_BUSY_INTR, "copy_busy_interrupted") \
 X(ZCOPY_BUSY_INTR, "zcopy_busy_interrupted") \
 X(ZCOPY_COMPLETE, "zcopy_completion")

#define N5_EXITS(X) \
 X(UNSET, "unclassified") \
 X(NO_BACKEND, "no_backend") \
 X(PREFETCH, "metadata_prefetch_failed") \
 X(GETBUFS_ERROR, "get_tx_bufs_error") \
 X(EMPTY, "get_tx_bufs_empty") \
 X(XDP_FATAL, "xdp_build_fatal") \
 X(SEND_RETRY, "sendmsg_retry") \
 X(WEIGHT, "weight_limit") \
 X(ZCOPY_BUSY, "zcopy_empty_busy_interrupted")

#define N5_EVENTS(X) \
 X(PATH_COPY, "path_copy_calls") \
 X(PATH_ZCOPY, "path_zerocopy_calls") \
 X(COPY_CAN_BATCH, "copy_sndbuf_unlimited_calls") \
 X(DESC_FETCHED, "descriptor_heads_fetched") \
 X(DESC_EMPTY, "get_tx_bufs_empty_results") \
 X(DESC_ERROR, "descriptor_fetch_negative") \
 X(DESC_BAD_IN, "unexpected_in_descriptors") \
 X(DESC_ZERO_LEN, "zero_payload_length") \
 X(DISCARD, "descriptor_heads_discarded") \
 X(LOOP_DONE, "loop_done_not_wire_success") \
 X(LOOP_BYTES, "loop_done_bytes_not_wire_bytes") \
 X(XDP_OK, "xdp_build_ok") \
 X(XDP_ENOSPC, "xdp_enospc_fallback") \
 X(XDP_FATAL, "xdp_build_fatal") \
 X(BATCH_FLUSH, "batch_flush_calls") \
 X(BATCH_NO_XDP, "batch_flush_without_xdp") \
 X(BATCH_SEND, "xdp_batch_sendmsg_calls") \
 X(BATCH_FRAMES, "xdp_frames_submitted_attempts") \
 X(BATCH_SEND_ERROR, "xdp_batch_sendmsg_negative") \
 X(SEND_CALL, "single_sendmsg_calls") \
 X(SEND_FULL, "single_sendmsg_full_return") \
 X(SEND_SHORT, "single_sendmsg_short_return") \
 X(SEND_EAGAIN, "single_sendmsg_eagain") \
 X(SEND_ENOMEM, "single_sendmsg_enomem") \
 X(SEND_ENOBUFS, "single_sendmsg_enobufs") \
 X(SEND_OTHER, "single_sendmsg_other_negative") \
 X(TAIL_PENDING, "copy_tail_not_proven_empty") \
 X(TAIL_RECHECK, "copy_tail_notify_changed") \
 X(TAIL_NO_QUEUE, "copy_tail_no_self_requeue") \
 X(TAIL_BUSY_INTR, "copy_tail_busy_interrupted") \
 X(BUSY_ENTER, "tx_busy_poll_enter") \
 X(ZCOPY_USED, "zcopy_buffer_used") \
 X(ZCOPY_FALLBACK, "zcopy_buffer_copy_fallback") \
 X(ZCOPY_RECHECK, "zcopy_empty_notify_changed_continue")

#define N5_ENUM_SRC(a,b) N5_SRC_##a,
enum n5_source { N5_SOURCES(N5_ENUM_SRC) N5_SRC_COUNT };
#undef N5_ENUM_SRC
#define N5_ENUM_EXIT(a,b) N5_EXIT_##a,
enum n5_exit { N5_EXITS(N5_ENUM_EXIT) N5_EXIT_COUNT };
#undef N5_ENUM_EXIT
#define N5_ENUM_EVENT(a,b) N5_EV_##a,
enum n5_event { N5_EVENTS(N5_ENUM_EVENT) N5_EV_COUNT };
#undef N5_ENUM_EVENT

enum n5_tail_site { N5_SITE_COPY_TAIL, N5_SITE_BUSY_PEER };
enum n5_tail_outcome { N5_TAIL_NOT_RUN, N5_TAIL_PENDING, N5_TAIL_RECHECK,
                       N5_TAIL_NO_QUEUE, N5_TAIL_BUSY, N5_TAIL_COUNT };

/* One TX handler owns this under the original TX vq mutex. No callback outside
 * that mutex may touch it. No timestamps and no atomics in per-packet updates.
 */
struct vhost_n5_tx {
        bool active;
        u32 epoch;
        u16 before;
        bool packed;
        enum n5_exit exit;
        enum n5_tail_outcome tail;
        u64 event[N5_EV_COUNT];
};

static inline void n5_tx_add(struct vhost_n5_tx *t, enum n5_event e, u64 n)
{
        if (t->active)
                t->event[e] += n;
}
static inline void n5_tx_exit(struct vhost_n5_tx *t, enum n5_exit reason)
{
        if (t->active)
                t->exit = reason;
}

static inline void n5_tx_tail(struct vhost_n5_tx *t, enum n5_tail_outcome tail)
{
        if (t->active)
                t->tail = tail;
}

void vhost_n5_tx_begin(struct vhost_n5_tx *t, struct vhost_virtqueue *vq,
                       struct vhost_work *backend_work);
void vhost_n5_tx_end(struct vhost_n5_tx *t, struct vhost_virtqueue *vq);

/* Same queue semantics as vhost_poll_queue; the extra argument is only a tag.
 * Never call both this and the original queue function for a single event.
 */
void vhost_poll_queue_reason(struct vhost_poll *poll, enum n5_source source);

#endif
