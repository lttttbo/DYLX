/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __VMM_MONITOR_H__
#define __VMM_MONITOR_H__

#include <vmm_types.h>
#include <vmm_error.h>

#define VMM_MONITOR_NS 1000000000ULL
#define VMM_MONITOR_EVENTS 16

/* Indexes for the runtime configuration API; values are decimal integers. */
enum vmm_monitor_config_key {
	VMM_MONITOR_EXIT_LIMIT,
	VMM_MONITOR_SUSTAIN_S,
	VMM_MONITOR_WINDOW_MIN_MS,
	VMM_MONITOR_WINDOW_MAX_MS,
	VMM_MONITOR_CONFIG_KEYS
};

enum vmm_monitor_view {
	VMM_MONITOR_STATUS,
	VMM_MONITOR_EVENTS_VIEW,
	VMM_MONITOR_CONFIG_VIEW
};

struct vmm_vcpu;
struct vmm_chardev;

enum vmm_monitor_fault {
	VMM_MONITOR_SHMEM_BOUNDS = 1,
	VMM_MONITOR_MAP_REJECT,
	VMM_MONITOR_ACCESS_DENIED,
	VMM_MONITOR_PERMISSION,
	/* Existing CCM failure outcomes; these do not assert a policy violation. */
	VMM_MONITOR_CCM_READ_FAILED = 5,
	VMM_MONITOR_CCM_REGISTER_FAILED,
	VMM_MONITOR_CCM_ELEMENT_REJECTED,
	/* Existing mem command address classification/range rejection. */
	VMM_MONITOR_HOST_RANGE_REJECT = 8,
};
enum vmm_monitor_hook {
	MON_STATE,
	MON_SELECTED,
	MON_DISPATCH,
	MON_EXIT,
	MON_FAULT
};

#ifdef CONFIG_CMD_MONITOR
int vmm_monitor_cmd_init(void);
#else
static inline int vmm_monitor_cmd_init(void)
{
	return VMM_OK;
}
#endif

static inline bool vmm_monitor_range_valid(u64 size, u64 offset, u64 length)
{
	return offset <= size && length <= size - offset;
}

#ifdef CONFIG_MONITOR_AGENT
int vmm_monitor_init(void);
int vmm_monitor_enable(bool on);
void vmm_monitor_record(struct vmm_vcpu *v, u32 hook, u64 a, u64 b);
void vmm_monitor_sample(u64 now);
void vmm_monitor_drain(void);
int vmm_monitor_dump(struct vmm_chardev *c, u32 view);
int vmm_monitor_configure(u32 key, u32 value);

#define vmm_monitor_state(v, s, t) \
	vmm_monitor_record(v, MON_STATE, s, t)
#define vmm_monitor_selected(v, t) \
	vmm_monitor_record(v, MON_SELECTED, t, 0)
#define vmm_monitor_dispatch(v, a, b) \
	vmm_monitor_record(v, MON_DISPATCH, a, b)
#define vmm_monitor_exit(v, r) \
	vmm_monitor_record(v, MON_EXIT, r, 0)
#define vmm_monitor_mem_fault(v, k, a, d) \
	vmm_monitor_record(v, MON_FAULT + (k), a, d)
#else
static inline int vmm_monitor_init(void)
{
	return VMM_OK;
}

#define vmm_monitor_state(...) \
	do { \
	} while (0)
#define vmm_monitor_selected(...) \
	do { \
	} while (0)
#define vmm_monitor_dispatch(...) \
	do { \
	} while (0)
#define vmm_monitor_exit(...) \
	do { \
	} while (0)
#define vmm_monitor_mem_fault(...) \
	do { \
	} while (0)
#endif

#ifdef CONFIG_WBOXTEST_MONITOR
/* White-box test interfaces; omitted from production builds. */
/* Test-only read access. No reset, injection, sampler or drain entry points. */
struct vmm_monitor_test_latency {
	u64 count;
	u64 sum;
	u64 max;
};

struct vmm_monitor_test_state {
	u32 epoch;
	u32 enabled;
	u32 config_seq;
	u32 config[VMM_MONITOR_CONFIG_KEYS];
	u32 skipped;
	u32 errors;
	u64 head;
	u64 lost;
};

struct vmm_monitor_test_slot {
	u32 epoch;
	u32 guest;
	u32 kind;
	u32 config_seq;
	bool present;
	bool waiting;
	bool valid;
	bool active;
	u64 ready_since;
	u64 previous;
	u64 interval;
	u64 exits;
	struct vmm_monitor_test_latency ready;
	struct vmm_monitor_test_latency dispatch;
};

struct vmm_monitor_test_event {
	u64 seq;
	u64 time_ns;
	u64 last_ns;
	u64 value;
	u64 address;
	u64 detail;
	u32 type;
	u32 guest;
	u32 vcpu;
	u32 epoch;
	u32 code;
	u32 config_seq;
	u32 sustain_s;
	bool log_returned;
	u32 log_calls;
};

int vmm_monitor_test_sample_serial(u64 *out);
/* Successful memory-flush passes for one actor; ~0U selects NULL/shmem.
 * Monotonic across start/stop and slot resets; the caller checks epoch too. */
int vmm_monitor_test_sample_actor(u32 actor, u64 *out);
int vmm_monitor_test_state(struct vmm_monitor_test_state *out);
int vmm_monitor_test_slot(u32 id, struct vmm_monitor_test_slot *out);
int vmm_monitor_test_event(u64 seq, struct vmm_monitor_test_event *out);

enum vmm_monitor_host_kind {
	VMM_MONITOR_HOST_RAM,
	VMM_MONITOR_HOST_DEVICE,
	VMM_MONITOR_HOST_GUEST
};

/* These adapters run existing cmd_memory checks only; they never access PA. */
int vmm_monitor_host_probe(physical_addr_t addr, u32 width, u32 *kind);
int vmm_monitor_host_guard(struct vmm_chardev *out, physical_addr_t addr,
			   u32 width, bool write);
#endif /* CONFIG_WBOXTEST_MONITOR */
#endif /* __VMM_MONITOR_H__ */
