/* Host regression of the test-only inspection API, not a real Guest test. */
#define main baseline_regression_main
#include "test_monitor.c"
#undef main

int main(void)
{
	struct vmm_monitor_test_state g,copy;
	struct vmm_monitor_test_slot s;
	struct vmm_monitor_test_event e;
	u64 seq, progress, before;
	unsigned i;
	assert(vmm_monitor_test_state(&g)==VMM_ENOTAVAIL);
	assert(vmm_monitor_test_slot(0,&s)==VMM_ENOTAVAIL);
	assert(vmm_monitor_test_event(1,&e)==VMM_ENOTAVAIL);
	assert(vmm_monitor_test_sample_actor(0,&progress)==VMM_ENOTAVAIL);
	assert(!vmm_monitor_init()); assert(!vmm_monitor_enable(TRUE));
	assert(vmm_monitor_test_state(NULL)==VMM_EINVALID);
	assert(vmm_monitor_test_slot(CONFIG_MAX_VCPU_COUNT,&s)==VMM_EINVALID);
	assert(vmm_monitor_test_event(0,&e)==VMM_EINVALID);
	assert(vmm_monitor_test_sample_actor(0,NULL)==VMM_EINVALID);
	assert(vmm_monitor_test_sample_actor(CONFIG_MAX_VCPU_COUNT,&progress)==VMM_EINVALID);
	assert(!vmm_monitor_test_sample_actor(~0U,&progress) && !progress);
	/* A global pass does not prove every slot was flushed. */
	slots[0].lock.held=1;
	vmm_monitor_sample(fake_time);
	slots[0].lock.held=0;
	assert(!vmm_monitor_test_sample_actor(0,&progress) && !progress);
	assert(!vmm_monitor_test_sample_actor(1,&progress) && progress==1);
	assert(!vmm_monitor_test_sample_actor(~0U,&progress) && progress==1);
	assert(!vmm_monitor_test_sample_serial(&progress) && progress==1);
	vmm_monitor_sample(fake_time);
	assert(!vmm_monitor_test_sample_actor(0,&before) && before==1);
	vmm_monitor_state(&v[0],VMM_VCPU_STATE_RESET,fake_time);
	assert(!vmm_monitor_enable(FALSE)); assert(!vmm_monitor_enable(TRUE));
	assert(!vmm_monitor_test_sample_actor(0,&progress) && progress==before);
	vmm_monitor_sample(fake_time);
	assert(!vmm_monitor_test_sample_actor(0,&progress) && progress==before+1);
	vmm_monitor_state(&v[0],VMM_VCPU_STATE_READY,fake_time);
	vmm_monitor_selected(&v[0],fake_time+100);
	vmm_monitor_dispatch(&v[0],10,30);
	assert(!vmm_monitor_test_slot(0,&s));
	assert(s.present && s.kind==0 && s.guest==0 && s.ready.count==1 && s.ready.sum==100);
	assert(s.dispatch.count==1 && s.dispatch.sum==20);
	vmm_monitor_mem_fault(&v[0],VMM_MONITOR_PERMISSION,0x60000000,64);
	fake_time+=VMM_MONITOR_NS; vmm_monitor_sample(fake_time);
	assert(!vmm_monitor_test_state(&g)); seq=g.head;
	assert(!vmm_monitor_test_event(seq,&e) && !e.log_returned && !e.log_calls);
	assert(e.code==VMM_MONITOR_PERMISSION && e.address==0x60000000 && e.guest==0 && e.vcpu==0);
	assert(!vmm_monitor_test_state(&copy) && copy.head==g.head && copy.lost==g.lost);
	vmm_monitor_drain();
	assert(!vmm_monitor_test_event(seq,&e) && e.log_returned && e.log_calls==1);
	vmm_monitor_drain();
	assert(!vmm_monitor_test_event(seq,&e) && e.log_calls==1);
	for (i=0;i<VMM_MONITOR_EVENTS;i++) {
		vmm_monitor_mem_fault(&v[0],VMM_MONITOR_PERMISSION,i,0);
		fake_time+=VMM_MONITOR_NS; vmm_monitor_sample(fake_time);
	}
	assert(vmm_monitor_test_event(seq,&e)==VMM_ENOTAVAIL);
	assert(!vmm_monitor_test_event(seq+VMM_MONITOR_EVENTS,&e) && !e.log_returned && !e.log_calls);
	vmm_monitor_drain(); vmm_monitor_drain();
	assert(!vmm_monitor_test_event(seq+VMM_MONITOR_EVENTS,&e) && e.log_calls==1);
	/* Force a logger replay in this host model: observer must expose it. */
	cursor=seq+VMM_MONITOR_EVENTS; vmm_monitor_drain();
	assert(!vmm_monitor_test_event(seq+VMM_MONITOR_EVENTS,&e) && e.log_calls==2);
	puts("PASS: live observer snapshots, non-consuming reads, log receipt, wraparound, duplicate detection");
	return 0;
}
