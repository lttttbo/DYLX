# 性能监控 v4：客户机与宿主线程调度监控、统一日志与手工合入说明

交付版本：v4；整理日期：2026-10-23。
本次仅重新标注交付版本并规范交付文件命名，功能代码与 2026-10-22 的全调度对象版本完全一致。
JSON 协议仍为 schema=3，不因交付版本号改变。已经合入该功能版本的工程不必重复应用补丁。
交付文件及压缩包内目录、文件名采用纯英文和数字，保留 v4 版本号及标准扩展名；工程内原有文件路径、源码文件名及依赖include名保留，便于直接合入与复现测试。

实现及验证日期：2026-10-22。JSON schema 继续为 3，增加可选字段。开源基线：`6e1a1fbd596f3da5ed2d244ec333113b2ec70e2f`。
适用：ARM64 Xvisor；产品 12 核、Linux/Android 两域，auth=4、mterm=3。

## 1. 本版范围及验收状态

本版仅保留 vCPU 调度/就绪等待、可感知的内存拒绝事件、exit 风暴、shell/JSON 和开关。
删除 Guest CPU/内存遥测及私有 HVC、指令诊断、IRQ 注入延迟、LPI/MOVI 配对、P99 直方图。
不修改产品的认证逻辑、Guest CPU 分配、GICv3/LPI 功能。

| 需求 | 实现与状态 |
|---|---|
| vCPU 调度延迟与就绪等待 | Guest 与宿主线程均记录 READY→selected、调度函数入口→上下文安装完成的累计次数/均值/最大值和当前 READY 等待年龄；idle 单独标识 |
| 内存越界/越权 | stage-2 映射请求被拒绝、终止处理的 permission fault、shmem 范围及授权检查；模型已覆盖，私有 DM/CCM 需接入 |
| exit 风暴日志 | 每 Guest vCPU 实际时间窗口统计；默认严格 >50000/s，至少连续 5 个有效窗口且累计至少 5 秒；开始告警一次，恢复后可重新触发；host/idle 不参与 |
| ROM ≤5KB | **本次未达到。** ARM64 `-Os` 对象段增量估算 6553 B；开机自动启用 6561 B，超过 5120 B。运行时配置、完整事件日志和宿主线程分类增加了代码；不能沿用旧版 5067 B 的通过结论。最终产品链接仍需复测 |
| 内存分配 | 运行期静态槽与事件环；启动创建一个工作队列。符合之前确认的允许启动分配口径 |
| CPU <0.5% | **未板测**；需计入各核埋点、IRQ 统计、自动日志，不能用采样函数耗时单独证明 |
| 高优先级采集 | HV 执行路径与 timer IRQ；不依赖 Guest 主动让出 CPU，仍受宿主 IRQ 屏蔽和短锁竞争影响 |
| 结构化输出 | 选择“命令查看”分支，`monitor status/events` 输出 JSON；后台异常 JSON 仅调用一次 `vmm_lwarning("monitor", ...)`；产品日志后端负责落盘和串口镜像，不再额外输出短提示。无远程 virtio-serial/shmem 发布实现 |
| 编译/运行开关 | 默认编译关闭；编译开启时默认停止；命令 start/stop/config；另有开机启用配置 |

ROM 计入 monitor 核心、命令、既有函数埋点、共享内存授权包装器、初始化代码、常量和初始化数据；不将 shell/安全接口移出预算。
静态 BSS 16264 B（`MAX_VCPU_COUNT=64`，含命令对象），另计工作队列启动分配的线程栈和元数据。5KB 本版按 5120 字节理解，不是 5000 字节。
未执行完整固件链接、QEMU 启动、产品板运行、认证长稳或 CPU 开销测试。对象段测量不能替代这些验收。

## 2. 本次增量合入

本次补丁基于上一版“输出精简”实现。主补丁只修改 `core/monitor/monitor_agent.c` 和 `core/monitor/openconf.cfg`：
放开调度统计的 orphan 过滤，安全处理无 Guest 的宿主线程，增加 guest/host/idle 分类；exit 风暴仍只面向 Guest。
原有 config 简洁回显、后台单条 warning JSON、同一次持续风暴去重规则均保留。
另提供测试/文档补丁、full_files、基线 SHA256、函数及参考行号。
已经合入上一版 scheduler 打点的项目无需再次修改 scheduler。本次不覆盖用户的私有 scheduler 文件。

## 3. 文件及函数职责

| 文件/函数 | 职责与打点依据 |
|---|---|
| `core/include/vmm_monitor.h` | 对外宏统一到 `vmm_monitor_record()`；编译关闭时宏不求值，时间戳参数也不执行 |
| `vmm_scheduler.c::__vmm_scheduler_next1/next2` | 目标确认后、`arch_vcpu_switch` 前调用 selected；返回后记录 dispatch；next2 当前 vCPU 再次被选中也要打点 |
| `vmm_scheduler.c::vmm_scheduler_state_change` | 真正更新状态时记录 READY/RESET/UNKNOWN 等；READY 重复通知不刷新起点，暂停/停止取消未完成等待 |
| `cpu_interrupts.c::do_sync` | 排除 EL2 自身异常后统计 Guest 同步退出；原有异常处理流程不变 |
| `cpu_interrupts.c::do_irq/do_hyp_fiq` | 仅当被打断上下文来自 Guest 时统计异步退出，原因标记为 `0x100` |
| `cpu_vcpu_excep.c::cpu_vcpu_stage2_map` | Guest 物理区域映射查询失败时记录 MAP_REJECT；成功懒映射、SMP 映射竞争恢复不记安全异常 |
| `cpu_vcpu_inst_abort/cpu_vcpu_data_abort` | 现有代码不恢复的 permission fault 记录 PERMISSION；正常 access fault/MMIO 仿真分支不记为权限违规 |
| `vmm_shmem.c::shmem_range` | 验证对象偏移、长度及宿主物理地址加法不回绕；原 read/write/set 均调用 |
| `shmem_guest_allowed/vmm_shmem_guest_access` | 按显式 actor 检查 GPA 映射、实际 backing、完整长度、只读属性及别名限制，再访问宿主内存 |
| `monitor_agent.c::vmm_monitor_record` | 按 vCPU 短锁更新时延、退出计数、内存异常摘要；不打印、不分配，不持有 scheduler 锁的反向引用 |
| `vmm_monitor_sample` | 唯一周期执行者；trylock 忙则跳过并计 skipped；计算有效窗口、持续时间、风暴状态；提交内存摘要 |
| `emit/memory_flush` | 固定 16 条环；保存原始异常首末时间；覆盖未输出事件时 lost 增加 |
| `tick/report/vmm_monitor_drain` | tick 在初始化核的 timer IRQ 执行；只有待输出事件才唤醒后台队列；每批最多 8 条 |
| `vmm_monitor_configure` | 在 event 锁内校验并发布单个参数；同值写入不递增 config_seq；已有风暴 active 状态保留 |
| `print_event` | 固定 384 字节栈缓冲格式化；后台调用 warning 日志接口，events 查询输出到命令终端；不在采集锁内输出 |
| `vmm_monitor_enable` | start 创建新 epoch，按槽惰性清理；stop 停止新数据接收；停止前已记录的内存异常仍能输出 |
| `vmm_monitor_dump` | 复制单槽/单事件后在锁外格式化，status 不清统计、events 不消耗后台游标 |
| `vmm_monitor_init` | 初始化静态槽，启动时创建 priority=3 日志队列并在当前核启动 timer；失败清理队列 |
| `cmd_monitor.c::vmm_monitor_cmd_init` | bool 内建命令直接注册；不再通过 module 表注册，减少冗余 ROM |
| `vmm_main.c` | 在 command manager 已初始化、modules 初始化前调用 monitor init，成功后注册命令；错误只报告，不阻止 Guest 启动 |

锁顺序固定为 slot→event；事件读取释放 event 锁后才读取 slot。采集不调用 mutex、不等 Guest 回复。后台输出不得在 IRQ 中调用。
调度宏入口支持活着的 normal 与 orphan vCPU；exit 入口只接受具有有效 Guest 的 normal vCPU。
内存接口可记录宿主 actor，但不能据此虚构 Guest 身份。监控槽不保留传入 vCPU 指针。私有调用者必须保证对象引用、调度状态及映射生命周期有效。

## 4. 时间及采样口径

```mermaid
flowchart LR
    R[真正进入 READY] --> S[选中且验证目标]
    D[调度函数入口] --> C[目标上下文安装完成]
    R --> M[静态 vCPU 槽]
    S --> M
    C --> M
    X[Guest exit / 内存拒绝] --> M
    M --> T[HV timer IRQ 每秒统计]
    T --> E[固定事件环]
    E --> W[后台 priority 3]
    W --> L[vmm_lwarning 完整 JSON]
    M --> Q[monitor status]
    E --> Q2[monitor events]
```

`ready` 是 READY→selected，`dispatch` 是调度函数进入→上下文安装完成。两者可能重叠，不能简单相加；dispatch 包含调度器及监控打点的执行时间，不是 Guest 第一条指令开始运行的精确时间。
两个时延统计是当前 epoch 内、自上次 vCPU RESET 后的**累计**值；不是上一秒直方图。不再输出 P99、jitter，也没有保存每次样本。
start 时已处在 READY 的 vCPU，如果没有随后收到 READY 状态通知，则不追补之前的等待，以免制造起点。
`ready_age_ns` 是查询时尚未结束的等待年龄；暂停/选中/停止后为 0。

exit 使用周期窗口计数。有效 dt 默认范围为 0.75～1.25 秒，可用 window_min_ms/window_max_ms 调整；异常间隔重置尚未完成的持续窗口，不把缺失时间记入连续 5 秒。已经触发的风暴在无效窗口上保持已告警状态，直到有效低负载窗口才解除内部状态。
每个 vCPU 的一次持续风暴只生成一条开始事件，后台只调用一次日志接口输出 JSON，串口镜像由日志后端完成；有效未超限窗口恢复后，下一次持续超限可以重新告警。本版不输出恢复事件，不 panic、不 reset、不限流。
门限判断使用 `count > floor(limit * dt / 1e9)`，不以显示值的舍入结果判断；日志 value 是实际速率向下取整。

## 5. 内存边界与私有 DM/CCM 接入

正式覆盖：二阶段映射/权限处理能感知的非法 CPU 访问，以及经过授权共享内存 API 检查发现的非法请求。
不覆盖已授权页面内的软件缓冲区越界；不自动覆盖 DMA/SMMU；不猜测缺少 actor 的宿主调用属于哪个 Guest。
监控是记录器，真正拒绝访问由原 MMU 路径或授权包装器完成；关掉监控并不撤掉已加入的共享内存范围/授权检查。

建议私有设备模型在服务 Guest 请求时调用：

```c
/* actor 必须来自当前请求的可信 Guest 上下文，不从 Guest 报文读取身份。 */
copied = vmm_shmem_guest_read(actor, shm, guest_pa, offset, dst, length, cacheable);
copied = vmm_shmem_guest_write(actor, shm, guest_pa, offset, src, length, cacheable);
```

这两个名称现在是宏，调用共同的 `vmm_shmem_guest_access(..., write)`；成功返回长度，失败返回 0。
调用者持有合法 Guest/shmem 引用，并串行化映射变更。查询到的 GPA 必须映射到该 shm 的同一 backing 偏移；请求不得跨出当前可映射段；alias 明确拒绝。不能只检查 Guest ID 后绕开范围/权限判断。
已有产品 ACL 拒绝分支也可以直接调用 `vmm_monitor_mem_fault(actor, kind, address, detail)`，避免重复访问或双重记账。
**参考树没有你的私有 DM/CCM 调用点，提供 API 不等于这些路径已经合入。**

内存 code 与 address/detail：

| code | 含义 | address | detail |
|---|---|---|---|
| 1 | SHMEM_BOUNDS | 授权 API 为请求 GPA；原宿主 API 无 actor 时为对象 offset | 请求长度 |
| 2 | MAP_REJECT | 映射查询失败的尝试 IPA | 返回错误码的 u64 表示；负数按 64 位补码解释 |
| 3 | ACCESS_DENIED | 授权共享内存请求的 GPA | 0=读，1=写；私有调用点应记录其约定的拒绝原因 |
| 4 | PERMISSION | FAR_EL2 原始值，**不能称为可靠 IPA** | 原始 ISS，FnV(bit10)=1 时 address 无效 |

permission fault 不能无条件用 HPFAR 推导物理地址，本版记录 FAR/ISS。产品若在 permission 分支进行脏页跟踪、COW 等合法恢复，应把记录点移至最终拒绝分支。
多个内存异常按同一 vCPU 合并；value 是总次数，time/last 是首末异常时间，code/address/detail 是**最后一次**异常的代表信息，并非每一种异常的完整追踪。重置和跨 epoch 清理前会提交旧摘要。

## 6. 配置、启动和 shell

```text
CONFIG_MONITOR_AGENT=y
CONFIG_CMD_MONITOR=y
CONFIG_MONITOR_PRIORITY=3
CONFIG_MONITOR_EXIT_RATE=50000
CONFIG_MONITOR_STORM_SECONDS=5
# CONFIG_MONITOR_START_ENABLED is not set
# CONFIG_MONITOR_EXTERNAL_EXECUTOR is not set

monitor start
monitor status
monitor events
monitor stop

monitor config
monitor config exit_limit 100
monitor config sustain_s 5
monitor config window_min_ms 750
monitor config window_max_ms 1250
monitor start
```

优先级 3 只控制后台日志；不再存在优先级 6 的采样线程。timer 在调用初始化的 CPU 上启动，上游通常是启动核（一般为 0），通过 status.sampler_cpu 核对；本版移除 MONITOR_HCPU/IPI 启动流程。
初始化及 timer 使用要求该核持续在线；CPU hotplug 不在本次静态 12 核设计内。
stop 保留当前历史和队列，并允许先前已采集异常继续排出；每秒轻量 timer 仍存在，但没有新异常时不会唤醒日志线程。编译关闭去掉监控执行上下文。
start 已开启时是幂等的；stop→start 使用新 epoch，旧槽不再显示，直到新的打点产生。epoch 是启用批次，不是每次 vCPU RESET 的编号。
外部执行模式不创建 timer/队列，平台必须先 init，然后串行从 HV IRQ 调用 sample，每秒一次；从单一可睡眠后台调用 drain。此模式不是缺少平台调用也能自动工作的替代品。
产品 auth/mterm 的鉴权入口和命令白名单需要照旧保留；本版不绕过认证，也不能证明之前偶现认证卡住已经修复。
旧命令 cpu/irq/mem/guest/collect/diagnose 仍不提供。本次新增的 config 只支持下表，不恢复旧版遥测/诊断配置。

| 命令参数 | 含义 | 允许范围 | 开机默认 |
|---|---|---|---|
| exit_limit | 每 vCPU exit 速率门限，次/秒，严格大于才算超限 | 1～1000000000 | CONFIG_MONITOR_EXIT_RATE |
| sustain_s | 连续超限最短秒数，同时要求至少该数量的有效窗口 | 1～60 | CONFIG_MONITOR_STORM_SECONDS |
| window_min_ms | 采样窗口有效下界，毫秒 | 1～1000 | 750 |
| window_max_ms | 采样窗口有效上界，毫秒 | 1000～10000 | 1250 |

参数只接受十进制非负整数字符串，再按上表范围校验；负数、0、溢出、尾随字符、未知参数均失败且不改变配置。
`monitor config` 只输出一行参数文本，不输出 JSON；参数写入成功只回显 `OK: exit_limit=100` 这样的确认。
例如：
```text
root@host# monitor config exit_limit 100
OK: exit_limit=100
root@host# monitor config
exit_limit=100/s sustain_s=5s window_min_ms=750 window_max_ms=1250
```
非法输入仍返回错误码，不改配置；取值校验失败输出 `monitor: config failed (<错误码>)`，格式错误显示用法。
`monitor status`、`monitor events` 继续输出 JSON，供主动查询详情。配置在 stop/start 之间保留，重启恢复编译默认值，不写持久存储。
这涵盖当前所有数值判定门限。采样周期仍为 1 秒；线程优先级、环形队列容量不是告警门限，不在运行时修改。
READY/dispatch 当前只有统计，无延迟阈值报警；内存拒绝记录也不依赖次数阈值。

配置更新规则：
- 单条命令的配置发布在 event 锁下完成，config_seq 递增；同值写入不变更版本。
- 周期采样复制一致配置后才访问 vCPU 槽，保持 slot→event 的锁序。
- 下一次采样丢弃跨参数变更的窗口、清除未完成的连续超限累计，标记 valid=0，从新的完整窗口判断。
- READY/dispatch、epoch 和历史事件保持；已触发风暴的 active 状态保持，改阈值不会立即重复提醒。
- 更新时尚未写入环的旧配置判定会被拒绝；已经写入环、等待后台输出的旧事件保留其原 config_seq/门限/持续秒数。
- 再次告警需有效未超限窗口解除 active 后重新持续超限。stop→start 或 vCPU reset 是新的采集生命周期，可以重新告警。

日志输出规则：
- 后台只用 `vmm_lwarning("monitor", "%s", json_line)` 记录完整 JSON，不再额外调用 vmm_printf 输出短提示。
- 用户已确认该接口会同时落盘并输出串口，本次直接使用这条统一输出路径；不改全局日志模块或日志级别。
- 不使用 vmm_lerror_once：一次持续风暴按 vCPU 去重；恢复后的新风暴、不同 vCPU 仍能独立告警。
- 同一 seq 由后台游标最多处理一次；events 查询只读历史，不再次记录日志；命令主动查看仍可能看到同一 seq，这是预期行为。
- type=3 内存事件也走相同日志接口。配置命令本身不输出 JSON，但运行中的后台异常仍可异步输出 JSON。

## 7. JSON schema=3

status 首行是全局状态；后续每行一个 normal vCPU。示例结构（数值仅示意）：

```json
{"schema":3,"enabled":1,"epoch":1,"sampler_cpu":0,"events":1,"lost":0,"skipped":0,"errors":0,"exit_limit":50000,"sustain_s":5}
{"schema":3,"kind":"guest","guest":0,"vcpu":49,"epoch":1,"time_ns":1000000000,"interval_ns":1000000000,"valid":1,"exits":514,"ready_age_ns":0,"ready":[512,32554,1092208],"dispatch":[512,2000,9000]}
```

`ready/dispatch` 固定顺序为 **[样本次数, 平均纳秒, 最大纳秒]**，数组用于缩减格式字符串。count=0 表示无样本；不是零延迟证明。
`time_ns/interval_ns/exits/valid` 描述最近完成的 exit 统计窗口；时延累计值和 ready_age 来自命令读取时的单槽快照。不同 vCPU 行不保证同一瞬间快照。
`valid=1` 仅说明最近窗口时长在允许范围内，不代表系统健康；停止后窗口可能是历史值，要同时看 enabled 和时间。
查询时可按 `exits * 1e9 / interval_ns` 计算速率，不需要在每次 exit 中做除法。
`lost` 为被覆盖的尚未交给后台输出的事件数；`skipped` 为采样竞争跳过的槽数；`errors` 为 timer 重启/工作调度失败数，非零必须排查。

事件示例：

```json
{"schema":3,"seq":1,"time_ns":100,"last_ns":150,"type":3,"guest":1,"vcpu":54,"epoch":1,"code":3,"value":2,"address":8192,"detail":1}
```

schema 保持 3；本版每对象 status 行新增 kind，Guest/host/idle 的区分见第 9 节。此前的兼容扩展包括：全局行增加 window_min_ms/window_max_ms/config_seq；事件增加 config_seq/sustain_s。
type=1 的 config_seq/sustain_s 是生成事件时的配置版本/持续门限；type=3 这两个字段固定 0，表示不适用。
type=1 是 exit 风暴，type=3 是内存摘要。风暴 time/last 是达到持续门限的判定时间，value 是速率，detail 是门限，code 是最后的 EC 或异步退出标记。
内存 time/last 是异常实际发生首末时间；guest=4294967295 表示不归属 Guest。
有宿主 actor 时 vcpu 仍是其实际 ID；无 actor 的宿主 shmem 调用 vcpu 也为 4294967295。
`monitor events` 展示保留的最多 16 条事件，重复查询可能重复读到同一 seq，不改变后台输出游标。
环容量和后台每批 8 条有界；异常持续泛滥或后台被长期饿死时不能保证无损，丢失可见。避免将无限量同步串口日志放进 IRQ。
JSON 读取端应使用 64 位整数，避免 JavaScript Number 对大整数丢精度；JSONL 按行解析，并按 schema 区分旧版本。

## 8. 已执行验证及目标板测试

本次重新执行：宿主/idle 采集、空 Guest 指针、ID 跨类型复用、宿主 exit 排除、未运行日志线程时的采集、私有 scheduler 16 组配置回归；ARM64 开启/开机启用/关闭/外部执行/基线编译；ROM 对象段测量；内部/外部执行及开机自动启用主机模型；初始化失败注入；JSON 解析、最大字段宽度、运行时配置文本/单次日志输出/去重测试。
ROM 测量结果未通过 5 KiB 门限；其余上述编译和行为测试通过。共享内存与 stage-2 函数本次未修改，沿用前版验证，不将其表述为本次重新测试。

| 验收项 | 操作与预期 |
|---|---|
| CPU 两种区间 | 注入可控 READY 等待/切换工作量，分别比对时间戳；重复 READY 不改起点，暂停后不补样本 |
| 生命周期 | start/stop、vcpu reset/destroy/recreate；旧数据不串到新实例，停止前异常可排出 |
| 参数配置 | 通过 config 设置 100/2，检查简洁文本回显且无 JSON；非法值不改参数；改动后首个窗口 valid=0，旧累计不触发新门限 |
| 输出与去重 | 同一 vCPU 持续超限只调用一次日志宏，日志落盘和串口镜像各对应同一 seq；无额外短提示；events 重读不触发后台输出 |
| 改参时去重 | 风暴 active 时降低门限或改持续时间，持续高负载不再次生成后台日志；恢复后再超限可以产生新的 seq |
| 日志路由 | 产品日志中检索 prefix=monitor、seq；串口保留日志接口的 JSON 镜像，但不再出现额外 exit storm 短提示 |
| 风暴边界 | 50000/s 不告警，50001/s 连续 5 个有效秒窗口告警一次；降低后再升高可重新触发 |
| 窗口质量 | 延迟 2 秒采样或制造锁竞争，不伪造连续 5 秒；检查 valid/skipped |
| 内存故障 | 未授权 IPA、终止 permission fault、shmem 长度越界/回绕/只读写入/错误 backing；对应事件与原失败返回一致 |
| 正常路径 | 合法懒映射、SMP 同页映射竞争恢复、MMIO load/store 仿真不产生内存越权告警 |
| 私有接口 | DM/CCM 的每条 Guest 内存访问路径明确使用授权包装器或 ACL 拒绝打点；不能只检验 API 存在 |
| 日志拥塞 | 暂停后台或持续制造异常，恢复后排出；lost 反映覆盖，没有 IRQ 中打印和无界排空 |
| auth/mterm | 默认停止、开启空载、Guest 压力、异常日志四种情况反复切换前台，检查认证交互和长稳 |
| ROM | 相同产品工具链/配置，未集成基线与集成版本比较最终加载段增量，含新增依赖和对齐，≤5120 B |
| CPU | 定义单核或整机分母与负载范围，包含所有核埋点和自动日志；建议关注最忙核，不能只看 12 核平均 |
| 确定性 | 测量 timer 到期→回调开始最大延迟、回调 WCET、最大 IRQ 屏蔽时间；明确验收上限 |

本地模型不能证明真实多核内存顺序、板端 WCET 或认证稳定性。生产私有锁和调度器 packed state 必须按语义适配。

复现命令（有 Python 和 Zig 的环境）：

```text
python tests/monitor/run_host_tests.py --cc <zig> --build-dir <host-build>
python tests/monitor/run_boundary_tests.py --cc <zig> --build-dir <shmem-build>
python tests/monitor/run_abort_tests.py --cc <zig> --build-dir <abort-build>
python tests/monitor/cross_compile.py --cc <zig> --build-dir <arm-build> --baseline-ref 6e1a1fbd596f3da5ed2d244ec333113b2ec70e2f --enforce-rom
```

私有仓库没有该基线时，可使用 `--baseline-dir <干净开源树>`。工具做翻译单元检查，不会自动生成可启动固件。


## 9. 宿主线程扩展及优先级边界

### 9.1 覆盖对象与字段

| kind | 对象 | 调度统计 | exit 风暴 |
|---|---|---|---|
| guest | `is_normal=true` 且 guest 有效的 Guest vCPU | READY/dispatch | 保留 |
| host | orphan 宿主线程，例如 ipi、syswq、auth、mterm、monitor、设备工作线程 | READY/dispatch | 排除 |
| idle | `vmm_scheduler_idle_vcpu()` 返回的真正 idle 对象 | READY/dispatch，单独解释 | 排除 |

不根据 `vcpu list` 的 Domain ID、线程名字或优先级推测 Guest 身份。即使私有实现为宿主线程填了非空 guest 指针，只要 is_normal=false，仍按 host/idle 处理。
host/idle 的 guest 字段使用已有的无 Guest 哨兵值 `4294967295`；按 vcpu 字段与同一运行实例的 `vcpu list` 对照名称。为控制采集开销和静态容量，本版不复制线程名称。
示意输出如下，数值仅用于解释格式：

```json
{"schema":3,"kind":"host","guest":4294967295,"vcpu":1,"epoch":1,"time_ns":1000000000,"interval_ns":1000000000,"valid":1,"exits":0,"ready_age_ns":0,"ready":[20,300,1000],"dispatch":[20,500,1600]}
```

ready/dispatch 数组均为 `[累计次数, 平均纳秒, 最大纳秒]`。exits 对 host/idle 固定为 0，含义为不适用；不意味着 IPI 从未触发。valid 只表示最近采样间隔有效，不是“线程健康”结论，也不表示该线程最近一秒曾运行。
监控不提供线程 CPU 利用率、IPI 硬件 IRQ 执行时间、IPI 数量或调度时延超限告警。IPI 线程的调度时延与硬件 IRQ handler 耗时是不同指标。

start 后收到状态/选中/dispatch 等有效打点的对象才进入当前 epoch；始终处于 Paused/Reset、没有发生新打点的线程可能暂不出现在 status。所有对象均有资格采集，不等于启动时枚举所有对象并制造样本。
start 时已经 READY 的等待区间不会倒推起点；Paused/Reset 不累计 READY 等待。idle 长时间 READY 往往说明其他任务在使用 CPU，是正常优先级行为，不作为饥饿告警。

### 9.2 函数修改及已有打点复用

- `vmm_monitor_record()`：保留最大 ID 校验，接受 orphan 的 STATE/SELECTED/DISPATCH；MON_EXIT 在入口排除 orphan；Guest 字段只在 normal 且 guest 有效时读取，避免 NULL 解引用。
- `struct data`：增加 kind，继续使用按系统 ID 索引的静态槽，不创建第二套线程监控表。RESET/UNKNOWN/新 epoch 沿用清理逻辑，防止 ID 复用串数据。
- idle 在本核打点上与调度器实际 idle 指针比对，识别后在远程状态通知中保持分类。创建时 idle 指针尚未安装，或 start 后最初只有远程通知时，可短暂显示为 host，首次本核打点后变为 idle；不依赖名字前缀猜测。
- `vmm_monitor_sample()`：所有已记录对象更新窗口；host/idle 直接跳过 Guest 风暴判定。时延累计值仍由调度路径实时更新，采样函数没有搬到 monitor 线程中。
- `vmm_monitor_dump()`：复制槽后在锁外输出新增 kind；只读取静态副本，不保留 vCPU 指针，也不在打印时查找可能已销毁的对象。

用户最新版 scheduler 的 READY、selected、dispatch 调用原本没有 normal-only 限制，统一入口过滤才是缺少宿主统计的原因。因此本次继续复用既有 history/trace 时间戳和调用点，不重复增加时间戳读取。
已核对上游 ARM64 `arch_vcpu_switch()`：安装下一对象的寄存器上下文后返回；`arch_vcpu_post_switch()` 对 orphan 直接返回。已有 dispatch 的结束点可以用于宿主线程；它不是下一线程第一条指令的精确执行时刻。
若产品另外修改过 arch_vcpu_switch，使 C 调用在旧线程再次运行后才返回，则需重新适配结束点；本次未获得该私有体系结构文件。
`vmm_scheduler_idle_vcpu()` 在参考代码及用户提供的 scheduler 中是无锁查询。私有工程应保留此语义：record 的调用者可能已经持有 scheduler 锁，不能把这里改成会获取同一锁或发送同步 IPI 的查询。

### 9.3 monitor=3、ipi=7 为什么仍能采集

```mermaid
flowchart TB
    A[调度器实际执行 READY / selected / dispatch] --> B[在该路径直接更新静态槽]
    B --> C[本核高优先级线程也经过同一组打点]
    T[初始化核的 HV timer IRQ] --> S[每秒汇总及风暴判定]
    S --> E[固定事件环]
    E --> W[priority 3 monitor 日志线程]
    W --> L[日志后端及串口镜像]
    B --> Q[monitor status 查询]
```

数字 3 是日志工作线程的调度优先级，不是打点或 timer IRQ 的线程优先级。ipi=7 被选中时，记录操作已经由调度器执行；无需先运行 monitor 线程，也无需 monitor 抢占 ipi 来观察它。
在采样核允许 HV timer IRQ 到达和处理的前提下，Guest 或宿主线程处于运行态并不阻止周期汇总。若 ipi 的高优先级可运行负载长期占满采样核，priority=3 的日志工作线程和 mterm 可能得不到运行机会，事件排出和查询因此延迟。

但不能据此承诺“不受任何干扰”：

1. 长时间屏蔽 HV IRQ、异常优先级屏蔽、不可中断路径或定时器故障可能延迟/阻止采样；超出 window_min/max 的窗口标记 valid=0，并中断尚未达到持续门限的风暴计时。
2. timer 已停止时，旧的 valid=1 不会自动变成 0；需比较连续 status 的 time_ns/interval_ns，以及 errors/skipped。status 能否执行也受前台线程调度影响。
3. 日志线程长时间饿死会积压事件，16 条环溢出后 lost 增加；延迟输出时事件时间戳仍是采集/判定时间，不是打印时间。
4. 记录已经发生的调度边界不能替代 watchdog；硬锁死、永不完成的路径可能没有新的结束点。单纯提高 monitor 线程优先级无法解决屏蔽 IRQ 或硬锁死。

因此维持 priority=3；不为了观察 ipi=7 而提高到 7，也不改 auth=4、mterm=3 的关系。多核产品若需要更强的告警可达性，应另行验证采样/日志核布局和 watchdog，本次不预留新 CPU、不调整产品亲和性。

### 9.4 本次专项验证与目标板验收

已执行的主机模型验证：orphan guest=NULL；带非空 domain 指针的 host 仍不归属 Guest；未执行 drain 的情况下照常采集；READY 重复通知不刷新起点；idle 在指针后装及远程通知场景中的分类；ID 经 UNKNOWN/RESET 跨 host/idle/Guest 复用；host exit 超限不产生风暴；停启生命周期。
另外提取上一版已适配的用户 scheduler 实际函数，与本次生产 record 共同编译；对 monitor、history、trace、adaptive 四个编译选项执行 16 种组合。测试 Guest、priority=7 的 host、idle 的首次切换、同对象再选中、普通切换、延迟抢占及 history/trace 共享时间戳。该测试的锁/队列/体系结构由模型提供，不等同于实机多核抢占验证。

| 目标板场景 | 操作及预期 |
|---|---|
| 宿主覆盖 | start 后唤醒 ipi/syswq 并完成一次 auth/mterm 交互；对照 vcpu list 的 ID，status 应有 kind=host 及调度样本。没有唤醒的 Paused/Reset 对象允许暂不出现 |
| 高优先级采集 | 使用产品已有可控工作使 priority=7 的线程多次运行/阻塞；比较打点时间与 ready/dispatch。无须提高 monitor 优先级 |
| 延迟日志 | 在隔离测试中让日志线程暂时无法运行而维持 timer IRQ；恢复后检查事件原时间和 seq，确认采集与输出解耦。观察环覆盖时 lost |
| IRQ 延迟 | 使用有自动恢复的测试手段短时延迟采样核 IRQ；超出有效窗口应 valid=0，不能补造连续风暴。不要在前台手工制造不可恢复的关中断循环 |
| idle | 其他任务有负载时 idle 等待可增大；输出 kind=idle，不产生 exit 风暴 |
| Guest 风暴回归 | exit_limit=100、sustain_s=2；让实际 Guest 持续超限并跨过改参后的首个丢弃窗口，确认只记录一次，恢复后再次超限可重新记录 |
| 覆盖扩大后的开销 | 对比关闭/开启，在最忙核和整机分别测量全部打点、采样与日志成本；不能以日志线程 CPU 占用替代 monitor 总开销 |

本轮未运行用户 QEMU/最终板卡；CPU<0.5%、硬实时上限和认证长稳仍需产品验收。ROM 的当前不达标结果见第 1 节。
