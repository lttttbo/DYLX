/* Host platform model for running the delivered wboxtest translation units.
 * Scheduling, IRQ state and Guest mappings are not hardware emulation. */
#ifndef MONITOR_WBOX_HOST_H
#define MONITOR_WBOX_HOST_H
#include "host.h"
typedef uint8_t u8;
typedef u64 physical_addr_t;
typedef u64 physical_size_t;
#define __vmm_snprintf vsnprintf
#define WBOXTEST_IPRIORITY 1
struct wboxtest {
    char name[64];
    int (*setup)(struct wboxtest *, struct vmm_chardev *, u32);
    int (*run)(struct wboxtest *, struct vmm_chardev *, u32);
    void (*cleanup)(struct wboxtest *, struct vmm_chardev *);
};
int wboxtest_register(const char *, struct wboxtest *);
void wboxtest_unregister(struct wboxtest *);
#undef VMM_DECLARE_MODULE
#define VMM_DECLARE_MODULE(desc,author,license,priority,init,exit) \
    int init##_host(void) { (void)exit; return init(); }
#define VMM_DECLARE_MODULE2(name,desc,author,license,priority,init,exit) \
    VMM_DECLARE_MODULE(desc,author,license,priority,init,exit)
struct dlist { struct dlist *next, *prev; };
struct xref { long count; };
struct vmm_shmem {
    struct dlist head; struct xref ref_count; char name[64];
    physical_addr_t addr; physical_size_t size; u32 align_order; void *priv;
};
struct vmm_region { u32 flags; };
#define VMM_REGION_REAL 1
#define VMM_REGION_VIRTUAL 2
#define VMM_REGION_ALIAS 4
#define VMM_REGION_MEMORY 8
#define VMM_REGION_READONLY 128
#define VMM_REGION_ISRAM 256
#define VMM_REGION_ISSHARED 16384
#define VMM_ROUNDUP2_PAGE_SIZE(x) (((x)+4095)&~4095ULL)
#define VMM_ERR_PTR(x) ((void *)(intptr_t)(x))
#define container_of(ptr,type,member) ((type *)((char *)(ptr)-offsetof(type,member)))
#define INIT_LIST_HEAD(p) do { (p)->next=(p); (p)->prev=(p); } while(0)
static inline void host_unused_registry(void) { assert(!"unexpected shared-memory registry/allocator call"); }
#define list_for_each_entry(pos,head,member) \
    for ((pos)=NULL; (host_unused_registry(),0); (pos)=NULL)
static inline void list_add_tail(struct dlist *p,struct dlist *h) { (void)p;(void)h;host_unused_registry(); }
static inline void list_del(struct dlist *p) { (void)p;host_unused_registry(); }
static inline void xref_init(struct xref *x) { (void)x;host_unused_registry(); }
static inline void xref_get(struct xref *x) { (void)x;host_unused_registry(); }
static inline void xref_put(struct xref *x,void (*f)(struct xref *)) { (void)x;(void)f;host_unused_registry(); }
static inline void *vmm_zalloc(size_t n) { (void)n;host_unused_registry();return NULL; }
static inline void vmm_free(void *p) { (void)p;host_unused_registry(); }
static inline physical_size_t vmm_host_ram_alloc(physical_addr_t *p,physical_size_t n,u32 a) {
    (void)p;(void)n;(void)a;host_unused_registry();return 0;
}
static inline int vmm_host_ram_free(physical_addr_t p,physical_size_t n) {
    (void)p;(void)n;host_unused_registry();return 0;
}
#define vmm_shmem_guest_read(v,s,g,o,b,n,c) vmm_shmem_guest_access(v,s,g,o,b,n,c,FALSE)
#define vmm_shmem_guest_write(v,s,g,o,b,n,c) vmm_shmem_guest_access(v,s,g,o,b,n,c,TRUE)
#endif
