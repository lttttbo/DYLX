/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright (c) 2024 ZTE Authors. All rights reserved. */
#include "test_irq.h"

#define MODULE_DESC "test_irq_affinity test"
#define MODULE_AUTHOR "ZTE Authors"
#define MODULE_LICENSE "GPL"
#define MODULE_IPRIORITY (WBOXTEST_IPRIORITY + 2)

static int affinity_read_case(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(test_irq_id(0));
	const struct vmm_cpumask *mask = vmm_host_irq_get_affinity(irq);
	struct vmm_cpumask online;

	vmm_cprintf(out, "TEST1: irq=%u read current affinity\n", test_irq_id(0));
	if (!mask) {
		return VMM_EFAIL;
	}
	vmm_cpumask_and(&online, mask, cpu_online_mask);
	/* Reused IRQs need a valid target, not necessarily the initial ALL mask. */
	return vmm_cpumask_empty(&online) ? VMM_EFAIL : VMM_OK;
}

static int affinity_single_case(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(test_irq_id(1));
	struct vmm_cpumask empty = VMM_CPU_MASK_NONE;
	const struct vmm_cpumask *mask;
	int rc;

	vmm_cprintf(out, "TEST2: invalid arguments and single CPU affinity\n");
	/* Never construct cpumask_of(CONFIG_CPU_COUNT + 1): that is out of bounds. */
	if (vmm_host_irq_set_affinity(~0U, vmm_cpumask_of(test_irq_cpu()), FALSE) !=
	    VMM_ENOTAVAIL) {
		return VMM_EFAIL;
	}
	/* Save the hardware route before either negative call can reach the driver. */
	rc = test_irq_set_affinity(1, vmm_cpumask_of(test_irq_cpu()));
	if (!rc && vmm_host_irq_set_affinity(test_irq_id(1), NULL, FALSE) != VMM_EINVALID) {
		rc = VMM_EFAIL;
	}
	if (!rc && vmm_host_irq_set_affinity(test_irq_id(1), &empty, FALSE) != VMM_EINVALID) {
		rc = VMM_EFAIL;
	}
	if (!rc) {
		rc = test_irq_set_affinity(1, vmm_cpumask_of(test_irq_cpu()));
	}
	mask = vmm_host_irq_get_affinity(irq);
	if (!rc && (!mask || !vmm_cpumask_equal(mask, vmm_cpumask_of(test_irq_cpu())))) {
		rc = VMM_EFAIL;
	}
	return rc;
}

static int affinity_multiple_case(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(test_irq_id(2));
	struct vmm_cpumask requested = VMM_CPU_MASK_NONE;
	const struct vmm_cpumask *actual;
	u32 cpu;
	u32 count = 0;
	int rc;

	vmm_cprintf(out, "TEST3: two online CPUs in requested affinity\n");
	for (cpu = 0; cpu < (u32)vmm_cpu_count && cpu < CONFIG_CPU_COUNT; cpu++) {
		if (vmm_cpu_online(cpu)) {
			vmm_cpumask_set_cpu(cpu, &requested);
			if (++count == 2U) {
				break;
			}
		}
	}
	if (count != 2U) {
		return VMM_ENOTAVAIL;
	}
	rc = test_irq_set_affinity(2, &requested);
	actual = vmm_host_irq_get_affinity(irq);
	if (!rc && (!actual || !vmm_cpumask_equal(actual, &requested))) {
		rc = VMM_EFAIL;
	}
	return rc;
}

static int affinity_cache_case(struct vmm_chardev *out)
{
	struct vmm_host_irq *irq = vmm_host_irq_get(test_irq_id(3));
	const struct vmm_cpumask *actual;
	int rc;

	vmm_cprintf(out, "TEST4: SGI rejection and HOS hardware affinity fallback\n");
	if (vmm_host_irq_set_affinity(SGI_ID1, vmm_cpumask_of(test_irq_cpu()), FALSE) !=
	    VMM_EINVALID) {
		return VMM_EFAIL;
	}
	rc = test_irq_set_affinity(3, vmm_cpumask_of(test_irq_cpu()));
	if (!rc) {
		irq->affinity = VMM_CPU_MASK_NONE;
		actual = vmm_host_irq_get_affinity(irq);
		if (!actual || !vmm_cpumask_equal(actual, vmm_cpumask_of(test_irq_cpu()))) {
			rc = VMM_EFAIL;
		}
	}
	return rc;
}

static int test_irq_affinity_run(struct wboxtest *test, struct vmm_chardev *out, u32 cpu)
{
	int rc = test_irq_begin(out, cpu, 0);

	(void)test;
	if (rc) {
		return rc;
	}
	rc = affinity_read_case(out);
	if (!rc) {
		rc = affinity_single_case(out);
	}
	if (!rc) {
		rc = affinity_multiple_case(out);
	}
	if (!rc) {
		rc = affinity_cache_case(out);
	}
	/* No actions were registered here: end restores routes/masks, not strangers. */
	return test_irq_end(out, rc);
}

static struct wboxtest test_irq_affinity = {
	.name = "irq_affinity",
	.run = test_irq_affinity_run,
};

static int __init test_irq_affinity_init(void)
{
	return wboxtest_register("interrupt", &test_irq_affinity);
}

static void __exit test_irq_affinity_exit(void)
{
	wboxtest_unregister(&test_irq_affinity);
}

VMM_DECLARE_MODULE(MODULE_DESC, MODULE_AUTHOR, MODULE_LICENSE, MODULE_IPRIORITY,
		   test_irq_affinity_init, test_irq_affinity_exit);
