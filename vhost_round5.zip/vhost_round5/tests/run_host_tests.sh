#!/bin/sh
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT HUP INT TERM
CC=${CC:-cc}
for variant in original patched; do
    "$CC" -std=gnu11 -Wall -Wextra -Werror -Wno-unused-parameter \
        -Wno-unused-function -Wno-sign-compare -I "$D" \
        "$D/$variant.c" -o "$T/$variant"
    "$T/$variant" > "$T/$variant.out"
    "$CC" -std=gnu11 -Wall -Wextra -Werror -Wno-unused-function -I "$D" \
        "$D/queue_$variant.c" -o "$T/queue_$variant"
    "$T/queue_$variant" > "$T/queue_$variant.out"
done
diff -u "$T/original.out" "$T/patched.out"
diff -u "$T/queue_original.out" "$T/queue_patched.out"
echo 'PASS: 28 copy/zerocopy modeled scenarios preserve observed business-call sequence and terminal state.'
echo 'PASS: queue model preserves original test-and-set, enqueue and wake invocation counts.'
echo 'These are mocked host tests, NOT an actual driver/kernel/board execution test.'
