# R6准确修改位置

本说明与apply_r6.py一致。**使用安装器应用后，不要再手工添加一遍。** 当前基础必须保留R5的vhost_work_queue_tagged及N5 TX hook，R4的handle_tx_net origin已修正为2。

## 1. 文件总表

| 文件 | 函数 | 插入位置 |
|---|---|---|
| kernel/smp.c | __smp_call_single_queue | 新增局部token；原ipio_note_enqueue前记录发布；函数末记录独立的源端返回时间 |
| kernel/smp.c | generic_smp_call_function_single_interrupt | 原ipio_irq_enter前增加R6 enter；原ipio_irq_exit前增加R6 exit |
| kernel/smp.c | flush_smp_call_function_queue | 原llist_reverse_order之后、ipio_note_batch之前增加R6 batch |
| 实际CCM ioeventfd.c | ioeventfd_handler | WRITE地址解析完成后、原ioeventfds_lock mutex之前增加service |
| drivers/vhost/vhost.c | vhost_work_queue_tagged | 成功置queued位后、原llist_add前记录；原wake_up_process后记录原返回值；合并分支单独计数 |
| drivers/vhost/vhost.c | vhost_worker | **原clear_bit之前**取出本代work元数据；原work->fn返回后完成统计 |
| drivers/vhost/net.c | handle_tx | 原mutex前记录入口，原mutex成功后记录L，原N5 end/unlock前记录退出 |
| kernel/r6_notify.c | 新增 | 公共统计实现、三种模式、调度tracepoint回调和/proc接口 |
| kernel/r6_math.h | 新增 | 直方图、同周期时间分解 |
| include/linux/r6_notify.h | 新增 | 跨文件/模块调用声明 |
| kernel/r6_build_config.h | 自动生成 | 依据本地sched_switch TP_PROTO选择回调ABI |
| kernel/Makefile | 末尾新增 | obj-$(CONFIG_SMP) += r6_notify.o |

上述四份现有C文件的include区新增一次：

```c
#include <linux/r6_notify.h>
```

**kernel/sched/core.c不用修改；DSM和Android源码不用修改。** 调度事件由R6直接注册回调并在内核里累计，不生成全量trace文件。

## 2. SMP源端：在发布前保存token，不在发布后读node

在`__smp_call_single_queue()`的局部变量区添加：

```c
struct r6_queue_token r6q = { .slot = -1 };
```

原有ipio入队hook前：

```c
r6q = r6_ttwu_publish(cpu, node);                 /* 新增 */
ipio_note_enqueue(cpu, node, (unsigned long)_RET_IP_); /* 原有 */
/* 原debug处理、llist_add和IPI发送均保留。 */
```

函数正常末尾增加：

```c
r6_ttwu_publish_return(r6q);
```

原有debug ASYNC/SYNC提前返回不会形成目标TTWU样本。其他厂商提前返回路径须核对，安装器发现未知形态会拒绝。**返回耗时独立统计，不参与Q→D→A串行求和；接收CPU可能先于源端返回完成工作。**

## 3. SMP接收端

在generic handler中的原hook处：

```c
r6_call_irq_enter();  /* 新增 */
ipio_irq_enter();     /* 原有 */
/* 原flush等代码 */
r6_call_irq_exit();   /* 新增 */
ipio_irq_exit();      /* 原有 */
```

在flush的原位置：

```c
entry = llist_reverse_order(entry); /* 原有 */
r6_call_batch(entry);               /* 新增 */
ipio_note_batch(entry);             /* 原有，运行时关闭 */
/* 原callback执行逻辑保持不变。 */
```

不能放到callback执行或csd_unlock之后；届时队列项可能被复用。R6只匹配已保存task的真实wake_entry，不把未知CSD载荷强转为任务。

## 4. CCM：只有一处业务入口标记

在当前实际`ioeventfd_handler()`中：

```c
/* 原MMIO/PIO解析、READ提前返回等逻辑不动。此时addr已赋值。 */
r6_io_service(addr);                          /* 新增 */
mutex_lock(&client->vm->ioeventfds_lock);      /* 原有 */
/* 原ccm_ioeventfd_match、ioem_note、eventfd_signal、unlock不动。 */
```

该点是被选中TX地址的handler入口，尚未获得mutex。不是请求发布/请求完成点，也不会把一次唤醒强行等同于一个请求。`eventfd_signal()`仍然只调用原来的一次。

## 5. vhost提交：只观察原判断和原返回值

R5的`vhost_work_queue_tagged()`修改后主要结构：

```c
struct r6_work_token r6q = { .kind = -1 };
int woke;

if (!dev->worker)
        return;
if (!test_and_set_bit(VHOST_WORK_QUEUED, &work->flags)) {
        r6q = r6_work_publish(dev, work, dev->worker,
                             (unsigned int)source); /* 新增 */
        llist_add(&work->node, &dev->work_list);     /* 原有 */
        woke = wake_up_process(dev->worker);        /* 原有，只一次 */
        r6_work_wake_return(r6q, woke);             /* 新增 */
        n5_note_queue(dev, work, source, woke ? 1 : 0); /* 原有 */
} else {
        r6_work_merged(dev, work, dev->worker,
                       (unsigned int)source);      /* 新增 */
        n5_note_queue(dev, work, source, 2);        /* 原有 */
}
```

不要多执行一次test_and_set_bit、llist_add或wake_up_process。不能在原发布之后通过work->node取本代时间戳；目标可能已经执行并重新排队。

## 6. vhost执行：必须先分离本代样本，再清queued位

原worker循环内部：

```c
r6_work_execute(dev, work, dev->worker);     /* 新增：在clear之前 */
clear_bit(VHOST_WORK_QUEUED, &work->flags);  /* 原有，位置不变 */
__set_current_state(TASK_RUNNING);
/* 原kcov、N5 hook */
work->fn(work);                            /* 原有 */
r6_work_complete(dev, work, dev->worker);  /* 新增 */
/* 原kcov结束、need_resched等代码 */
```

queued位清除后生产者可再次提交同一work。R6用pending与executing两个代次存储，避免旧执行与新排队混淆。

## 7. vhost-net：修改原handle_tx，不重复包装n4_handle_tx

局部变量区：

```c
struct r6_tx_token r6t = { .kind = -1 };
```

原mutex前后：

```c
r6t = r6_tx_enter(&net->dev, &vq->poll.work,
                 &net->poll[VHOST_NET_VQ_TX].work, net->dev.worker);
mutex_lock_nested(&vq->mutex, VHOST_NET_VQ_TX); /* 原有 */
r6_tx_locked(&r6t, vq->last_avail_idx,
             vhost_has_feature(vq, VIRTIO_F_RING_PACKED),
             vhost_has_feature(vq, VIRTIO_RING_F_EVENT_IDX),
             vq->busyloop_timeout, vq->num);
/* 原N5 begin、后端检查、copy/zerocopy调用不动。 */
```

统一out出口：

```c
out:
        r6_tx_leave(&r6t, vq->last_avail_idx); /* 新增 */
        vhost_n5_tx_end(&net->n5_tx, vq);     /* 原有 */
        mutex_unlock(&vq->mutex);            /* 原有 */
```

n4_handle_tx、handle_tx_kick、handle_tx_net不再添加第二套R6包装。N4运行时关闭，N5运行时关闭，原代码保留。R6会覆盖无backend/预取失败等统一out分支，split链头统计不可解释为PC成功收包数。
