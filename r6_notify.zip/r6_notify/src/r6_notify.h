/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef _LINUX_R6_NOTIFY_H
#define _LINUX_R6_NOTIFY_H
#include <linux/types.h>
struct task_struct;
struct llist_node;
struct r6_queue_token { u64 epoch, seq, begin_ns; int slot; };
struct r6_work_token { u64 epoch, seq, begin_ns; int kind; unsigned int source; };
struct r6_tx_token { u64 epoch, seq; int kind; u16 before; bool active, packed; };
struct r6_queue_token r6_ttwu_publish(int cpu, struct llist_node *node);
void r6_ttwu_publish_return(struct r6_queue_token token);
void r6_call_irq_enter(void);
void r6_call_irq_exit(void);
void r6_call_batch(struct llist_node *entry);
void r6_io_service(u64 addr);
struct r6_work_token r6_work_publish(void *dev, void *work,
        struct task_struct *worker, unsigned int source);
void r6_work_wake_return(struct r6_work_token token, int original_return);
void r6_work_merged(void *dev, void *work, struct task_struct *worker,
        unsigned int source);
/* Must precede ORIGINAL clear_bit(VHOST_WORK_QUEUED, ...). */
void r6_work_execute(void *dev, void *work, struct task_struct *worker);
void r6_work_complete(void *dev, void *work, struct task_struct *worker);
struct r6_tx_token r6_tx_enter(void *dev, void *kick, void *backend,
        struct task_struct *worker);
void r6_tx_locked(struct r6_tx_token *token, u16 avail, bool packed,
        bool event_idx, unsigned int busyloop_us, unsigned int ring_size);
void r6_tx_leave(struct r6_tx_token *token, u16 avail);
#endif
