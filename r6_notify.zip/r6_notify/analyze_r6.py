#!/usr/bin/env python3
"""R6 aggregates and same-cohort arithmetic audits. No throughput attribution percentage."""
from __future__ import annotations
import argparse,csv,json,math,sys
from pathlib import Path
SOURCE_NAMES={0:'direct_work',1:'untagged_poll',2:'poll_event',3:'poll_start_ready',4:'weight',5:'iotlb',6:'copy_tail_pending',7:'copy_tail_notify_changed',8:'busy_peer_pending',9:'busy_peer_notify_changed',10:'copy_busy_interrupted',11:'zcopy_busy_interrupted',12:'zcopy_completion'}
def fields(xs):
    d={}
    for x in xs:
        if '=' not in x:raise ValueError('not key=value: '+x)
        k,v=x.split('=',1)
        try:d[k]=int(v,16) if v.startswith('0x') else int(v)
        except ValueError:d[k]=v
    return d
def quantile(h,f):
    n=sum(h)
    if not n:return None
    cut=math.ceil(n*f);s=0
    for i,x in enumerate(h):
        s+=x
        if s>=cut:return {'lower_ns':0 if i==0 else 64*2**(i-1),'upper_exclusive_ns':None if i==23 else 64*2**i}
    raise ValueError('histogram underflow')
def analyze(directory:Path,write=True):
    file=directory/'r6_report.txt' if directory.is_dir() else directory
    o={'tasks':{},'task_checks':{},'sources':{},'timing':{},'works':{},'queues':{},'network':{},'irq_cpus':[],'warnings':[],'errors':[]};ds={};hist={}
    for line,row in enumerate(csv.reader(file.read_text().splitlines()),1):
        if not row or row[0].startswith('#'):continue
        k=row[0]
        try:
            if k=='R6':o['metadata']=fields(row[1:])
            elif k=='TASK':o['tasks'][row[1]]=fields(row[2:])
            elif k=='CHECK_TASK':o['task_checks'][row[1]]=fields(row[2:])
            elif k=='SOURCE':o['sources'].setdefault(row[1],[]).append(fields(row[2:]))
            elif k in ('DIST','WDIST'):
                if len(row)!=9:raise ValueError('DIST field count')
                n,s,avg,mn,mx=map(int,row[4:])
                if n<=0 or min(s,avg,mn,mx)<0 or s//n!=avg or not mn<=avg<=mx:raise ValueError('invalid distribution')
                ds[tuple(row[1:4])]={'count':n,'sum_ns':s,'mean_ns':s/n,'min_ns':mn,'max_ns':mx}
            elif k=='HIST':
                if len(row)!=28:raise ValueError('HIST field count')
                h=list(map(int,row[4:]));
                if min(h)<0:raise ValueError('negative histogram')
                hist[tuple(row[1:4])]=h
            elif k=='IPI_CPU':o['irq_cpus'].append(fields(row[1:]))
            elif k=='IPI_TOTAL':o['ipi']=fields(row[1:])
            elif k=='NET':o['network'][row[1]]=fields(row[2:])
            elif k=='TX':o['tx']=fields(row[1:])
            elif k=='WORK':o['works'][row[1]]=fields(row[2:])
            elif k=='QUEUE':
                q=fields(row[2:]);q['source_name']=SOURCE_NAMES.get(q['source'],'other');o['queues'].setdefault(row[1],[]).append(q)
            else:raise ValueError('unknown record '+k)
        except (ValueError,IndexError) as e:raise ValueError(f'{file}:{line}: {e}') from e
    m=o.get('metadata',{})
    if m.get('version')!=1 or m.get('run')!=0:raise ValueError('expected stopped R6 v1 report')
    start=m['start_ns'];stop=m['stop_ns'];dur=(stop-start)*1e-9
    if start<=0 or dur<=0:raise ValueError('no completed capture')
    o['capture_seconds']=dur;o['mode']='baseline' if m['shift']==-2 else 'counts' if m['shift']==-1 else 'timing'
    for (role,path,name),d in ds.items():
        h=hist.get((role,path,name))
        if h is None or sum(h)!=d['count']:o['errors'].append('hist count mismatch '+str((role,path,name)));continue
        for f in [.5,.95,.99]:d['p'+str(round(f*100))+'_bin']=quantile(h,f)
        o['timing'].setdefault(role,{}).setdefault(path,{})[name]=d
    closure=[]
    def audit(role,path,parts,total):
        d=o['timing'].get(role,{}).get(path,{})
        if total not in d:return
        if any(x not in d for x in parts):o['errors'].append('missing partition '+role+'/'+path);return
        ns=[d[x]['count'] for x in parts+[total]];res=sum(d[x]['sum_ns'] for x in parts)-d[total]['sum_ns'];ok=len(set(ns))==1 and res==0
        closure.append({'role':role,'path':path,'total':total,'parts':parts,'count':ns[-1],'residual_ns':res,'pass':ok})
        if not ok:o['errors'].append('within-cycle partition mismatch '+role+'/'+path+'/'+total)
    for role,paths in o['timing'].items():
        for path in paths:
            if role in ('ioeventfd','vhost'):
                audit(role,path,['waking_to_activation','activation_to_switch'],'waking_to_switch')
                if path in ('queued_ipi','queued_non_ipi'):audit(role,path,['waking_to_publish','publish_to_rx_batch','rx_batch_to_activation'],'waking_to_activation')
            else:
                audit(role,path,['publish_to_execute','execute_to_tx_entry','tx_mutex_wait','tx_locked_elapsed','tx_leave_to_work_return'],'publish_to_work_return')
                audit(role,path,['publish_to_execute','execute_to_tx_entry'],'publish_to_tx_entry')
    o['within_cycle_closure']=closure
    for role,c in o['task_checks'].items():
        for k in ['invalid','duplicate','incomplete_rx','source_overflow','overwritten','migrated']:
            if c.get(k):o['warnings'].append(f'{role} {k}={c[k]}; inspect before attribution')
        t=o['tasks'][role]
        if m['shift']>=0 and t['valid_samples']<100:o['warnings'].append(f'{role}: only {t["valid_samples"]} valid timing samples')
        if m['shift']>=-1 and not t['services']:o['errors'].append(role+': no service hook; check TID/address/module deployment')
    for role,w in o['works'].items():
        for k in ['invalid','overwritten','missing_tx']:
            if w.get(k):o['errors'].append(f'{role} {k}={w[k]}')
        qs=o['queues'].get(role,[]);res=sum(q['new']-q['wake0']-q['wake1'] for q in qs)
        if res:o['warnings'].append(f'{role}: enqueue/return boundary residual={res}')
        if qs and sum(q['wake1'] for q in qs)==0:o['warnings'].append(role+': all actual wake returns zero; work count is NOT TTWU/IPI count')
    tx=o.get('tx',{})
    for k in ['identity_error','bad_heads','config_changes']:
        if tx.get(k):o['errors'].append(f'TX {k}={tx[k]}')
    if m['shift']>=-1 and (tx.get('bound')!=1 or not tx.get('completed')):o['errors'].append('TX not bound/no processing')
    o['rates']={'ipi_handler_entries_per_s':o.get('ipi',{}).get('handler_entries',0)/dur,'tx_heads_per_s':tx.get('heads',0)/dur,'tx_calls_per_s':tx.get('completed',0)/dur}
    for name,n in o['network'].items():
        if n.get('valid')!=1:o['warnings'].append(name+': missing/reset counters');continue
        nd=((n['after_begin_ns']+n['after_end_ns'])-(n['before_begin_ns']+n['before_end_ns']))*.5e-9
        if nd<=0:raise ValueError('invalid network snapshot times')
        skew=(max(0,start-n['before_begin_ns'])+max(0,n['after_end_ns']-stop))/(stop-start)
        n.update(window_seconds=nd,boundary_skew_fraction_upper=skew,tx_pps=n['tx_packets']/nd,rx_pps=n['rx_packets']/nd,tx_interface_mbps=n['tx_bytes']*8e-6/nd)
        if skew>.01:o['warnings'].append(f'{name}: network/probe boundary skew >1% ({skew:.3%})')
    eth=o['network'].get('eth0',{})
    if eth.get('valid')==1 and eth.get('tx_packets',0):
        if m['shift']>=-1:o['rates']['ipi_per_eth_tx_packet_approx']=o['ipi']['handler_entries']/eth['tx_packets']
    else:o['warnings'].append('no valid eth0 TX packets; this test expects upload')
    if m['shift']==-2:o['rates']={k:None for k in o['rates']}
    o['status']='INVALID' if o['errors'] else 'REVIEW_WARNINGS' if o['warnings'] else 'OK'
    o['notes']=['Partitions are same wake cycle/work generation, not UDP packet identities.','Task/work intervals overlap; never add their totals.','Sender return can follow receiver execution; NOT_ADDITIVE metrics are independent.','sched_switch precedes context switch; service is first selected handler after wake.','1/PPS is output spacing, not request latency. No automatic causal attribution fraction.','Quantiles are histogram intervals, not exact percentiles.']
    if write:
        dest=directory if directory.is_dir() else directory.parent
        (dest/'r6_summary.json').write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
        text=[f'R6 status={o["status"]} mode={o["mode"]} seconds={dur:.9f}','TX '+json.dumps(tx),'RATES '+json.dumps(o['rates']),f'PARTITION_AUDITS={len(closure)} FAILED={sum(not c["pass"] for c in closure)}']
        for name,n in o['network'].items():text.append('NET '+name+' '+json.dumps(n))
        for role,t in o['tasks'].items():
            text.extend(['TASK '+role+' '+json.dumps(t),'CHECK '+role+' '+json.dumps(o['task_checks'].get(role,{})),'SOURCES '+role+' '+json.dumps(o['sources'].get(role,[]))])
        for role,paths in o['timing'].items():
            for path,metrics in paths.items():
                for metric,d in metrics.items():text.append(f'TIME {role} {path} {metric} n={d["count"]} mean_us={d["mean_ns"]/1000:.4f}')
        for role,w in o['works'].items():text.append('WORK '+role+' '+json.dumps(w))
        for role,qs in o['queues'].items():
            for q in qs:text.append('QUEUE '+role+' '+json.dumps(q))
        text+=['WARNING '+v for v in o['warnings']]+['ERROR '+v for v in o['errors']]+['NOTE '+v for v in o['notes']]
        (dest/'r6_compact.txt').write_text('\n'.join(text)+'\n')
    return o

def compare(ad,bd):
    a=analyze(ad);b=analyze(bd);o={'A_status':a['status'],'B_status':b['status'],'rates_A':a['rates'],'rates_B':b['rates'],'phase_mean_delta_A_minus_B_ns':{},'notes':a['notes']}
    ea=a['network'].get('eth0',{});eb=b['network'].get('eth0',{})
    if ea.get('tx_pps',0) and eb.get('tx_pps',0):o.update(eth_tx_pps_A=ea['tx_pps'],eth_tx_pps_B=eb['tx_pps'],output_spacing_delta_us_NOT_latency=1e6/ea['tx_pps']-1e6/eb['tx_pps'])
    def mean(x,role,m):
        ds=[d[m] for p,d in x['timing'].get(role,{}).items() if p!='independent_publish_api' and m in d];n=sum(d['count'] for d in ds)
        return sum(d['sum_ns'] for d in ds)/n if n else None
    for role in ['ioeventfd','vhost','tx_kick','tx_backend']:
        metrics={k for p in a['timing'].get(role,{}).values() for k in p}|{k for p in b['timing'].get(role,{}).values() for k in p}
        for m in sorted(metrics):
            if 'NOT_ADDITIVE' in m:continue
            x=mean(a,role,m);y=mean(b,role,m)
            if x is not None and y is not None:o['phase_mean_delta_A_minus_B_ns'][role+'/'+m]=x-y
    o['warning']='Means may describe different mixes of wake/work sources. Inspect original path/source rows; no additivity of throughput effects is assumed.'
    return o

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',nargs='?',type=Path);p.add_argument('--compare',nargs=2,type=Path);p.add_argument('--out',type=Path,default=Path('r6_comparison.json'));x=p.parse_args()
    try:
        if x.compare:
            o=compare(*x.compare);x.out.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(x.out);return 0
        if x.directory is None:p.error('CAPTURE_DIR or --compare A B is required')
        o=analyze(x.directory);print('status='+o['status']);print(json.dumps(o['rates'],indent=2));print('OUTPUT: r6_compact.txt and r6_summary.json')
        return 2 if o['errors'] else 0
    except (OSError,ValueError,KeyError) as e:print('Analysis failed: '+str(e),file=sys.stderr);return 2
if __name__=='__main__':raise SystemExit(main())
