/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_scheduler.h>
#include <vmm_timer.h>
#include <vmm_smp.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <arch_barrier.h>
#include <libs/stringlib.h>
#include <libs/mathlib.h>

#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
#include <vmm_threads.h>
#include <vmm_workqueue.h>
#endif

#define U(x) ((unsigned long long)(x))

struct latency {
	u64 count;
	u64 sum;
	u64 max;
};

struct event {
	u64 seq;
	u64 time;
	u64 last;
	u64 value;
	u64 address;
	u64 detail;
	u32 type;
	u32 guest;
	u32 vcpu;
	u32 epoch;
	u32 code;
	u32 config_seq;
	u32 sustain_s;
};

enum object_kind {
	OBJECT_GUEST,
	OBJECT_HOST,
	OBJECT_IDLE
};

struct data {
	struct latency ready;
	struct latency dispatch;
	u64 ready_since;
	u64 previous;
	u64 exits;
	u64 interval;
	u64 count;
	u64 sustained;
	u32 epoch;
	u32 guest;
	u32 last_exit;
	u32 windows;
	u32 config_seq;
	u32 kind;
	bool present;
	bool waiting;
	bool active;
	bool valid;
	struct event memory;
};

struct slot {
	vmm_spinlock_t lock;
	struct data d;
};

struct monitor_config {
	u32 value[VMM_MONITOR_CONFIG_KEYS];
	u32 seq;
};

static struct slot slots[CONFIG_MAX_VCPU_COUNT + 1];
static DEFINE_SPINLOCK(event_lock);
static struct event ring[VMM_MONITOR_EVENTS];

#ifdef CONFIG_WBOXTEST_MONITOR
/* Receipt means the logging call returned, not that storage was flushed. */
static u64 test_logged[VMM_MONITOR_EVENTS];
static u32 test_log_calls[VMM_MONITOR_EVENTS];
static u64 test_sample_serial;
/* Each counter is protected by the corresponding slot lock. Test builds only. */
static u64 test_sample_actor[CONFIG_MAX_VCPU_COUNT + 1];
/* One selected actor only; ordinary builds have neither this state nor probe. */
static struct vmm_monitor_test_lock test_lock_stats;
#endif

static u64 head;
static u64 cursor = 1;
static u64 lost;
static u32 epoch;
static u32 sampler_cpu;

/* Protected by event_lock. Copy the entire configuration before taking slots. */
static struct monitor_config config = {
	.value = {
		CONFIG_MONITOR_EXIT_RATE,
		CONFIG_MONITOR_STORM_SECONDS,
		750,
		1250
	},
	.seq = 1
};

static atomic_t enabled = {0};
static atomic_t initialized = {0};
static atomic_t skipped = {0};
static atomic_t errors = {0};

#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static struct vmm_workqueue *queue;
static struct vmm_work work;
static struct vmm_timer_event timer;
static u64 deadline;
#endif

/* Lock order: slot -> event. No reader holds event_lock while taking a slot. */
static bool emit(struct event *e)
{
	irq_flags_t f;

	vmm_spin_lock_irqsave_lite(&event_lock, f);

	/* A concurrently published configuration invalidates an in-flight verdict. */
	if (e->type == 1 && e->config_seq != config.seq) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return FALSE;
	}

	e->seq = ++head;
	if (head - cursor >= VMM_MONITOR_EVENTS) {
		cursor++;
		lost++;
	}
	ring[(head - 1) % VMM_MONITOR_EVENTS] = *e;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return TRUE;
}

static __attribute__((noinline)) void memory_flush(struct data *d)
{
	if (d->memory.value) {
		emit(&d->memory);
		d->memory.value = 0;
	}
}

static void add(struct latency *s, u64 ns)
{
	s->count++;
	s->sum += ns;
	if (ns > s->max) {
		s->max = ns;
	}
}

/*
 * Scheduler hooks cover both normal and orphan vCPUs. Exit hooks remain
 * Guest-only. NULL identifies a host shmem bounds failure without an actor.
 */
void vmm_monitor_record(struct vmm_vcpu *v, u32 hook, u64 a, u64 b)
{
	struct slot *s;
	struct data *d;
	irq_flags_t f;
	u32 run;
	bool reset = hook == MON_STATE &&
		(a == VMM_VCPU_STATE_RESET || a == VMM_VCPU_STATE_UNKNOWN);

	if (!arch_atomic_read(&initialized) ||
	    (!arch_atomic_read(&enabled) && !reset) ||
	    (v && (v->id >= CONFIG_MAX_VCPU_COUNT ||
		   (v->is_normal && !v->guest))) ||
	    (hook == MON_EXIT && (!v || !v->is_normal)) ||
	    (!v && hook <= MON_FAULT)) {
		return;
	}

	s = &slots[v ? v->id : CONFIG_MAX_VCPU_COUNT];
	d = &s->d;
	vmm_spin_lock_irqsave_lite(&s->lock, f);
	run = arch_atomic_read(&enabled);
	if (!run && !reset) {
		vmm_spin_unlock_irqrestore_lite(&s->lock, f);
		return;
	}

	if (reset || d->epoch != run) {
		memory_flush(d);
		memset(d, 0, sizeof(*d));
		d->epoch = run;
		d->previous = vmm_timer_timestamp();
	}

	d->present = !(reset && a == VMM_VCPU_STATE_UNKNOWN);
	d->guest = v && v->is_normal ? v->guest->id : ~0U;
	if (v && v->is_normal) {
		d->kind = OBJECT_GUEST;
	} else {
		/*
		 * The idle pointer is installed after orphan creation. Recognize
		 * it on a local hook and retain it across remote state changes.
		 * This getter takes no scheduler lock (the caller may hold it).
		 */
		if (d->kind != OBJECT_IDLE) {
			d->kind = OBJECT_HOST;
		}
		if (v && v == vmm_scheduler_idle_vcpu(vmm_smp_processor_id())) {
			d->kind = OBJECT_IDLE;
		}
	}

	switch (hook) {
	case MON_STATE:
		if (a == VMM_VCPU_STATE_READY) {
			if (!d->waiting) {
				d->ready_since = b;
			}
			d->waiting = TRUE;
		} else {
			d->waiting = FALSE;
		}
		break;
	case MON_SELECTED:
		if (d->waiting && a >= d->ready_since) {
			add(&d->ready, a - d->ready_since);
		}
		d->waiting = FALSE;
		break;
	case MON_DISPATCH:
		if (b >= a) {
			add(&d->dispatch, b - a);
		}
		break;
	case MON_EXIT:
		d->exits++;
		d->last_exit = a;
		break;
	default:
		d->memory.last = vmm_timer_timestamp();
		if (!d->memory.value) {
			d->memory.time = d->memory.last;
		}
		d->memory.value++;
		d->memory.type = 3;
		d->memory.guest = d->guest;
		d->memory.vcpu = v ? v->id : ~0U;
		d->memory.epoch = run;
		d->memory.code = hook - MON_FAULT;
		d->memory.address = a;
		d->memory.detail = b;
	}

	vmm_spin_unlock_irqrestore_lite(&s->lock, f);
}

int vmm_monitor_enable(bool on)
{
	irq_flags_t f;

	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (!on) {
		arch_atomic_write(&enabled, 0);
	} else if (!arch_atomic_read(&enabled)) {
		/* Lazy epoch reset avoids locking all vCPUs with IRQs disabled. */
		if (!++epoch) {
			++epoch;
		}
		arch_atomic_write(&enabled, epoch);
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return VMM_OK;
}

/*
 * Preserve an active episode across configuration changes. A valid low-rate
 * window rearms it; neither a query nor changing limits repeats its alert.
 */
int vmm_monitor_configure(u32 key, u32 value)
{
	static const u32 bounds[VMM_MONITOR_CONFIG_KEYS][2] = {
		{1, 1000000000},
		{1, 60},
		{1, 1000},
		{1000, 10000}
	};
	irq_flags_t f;

	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}
	if (key >= VMM_MONITOR_CONFIG_KEYS ||
	    value < bounds[key][0] || value > bounds[key][1]) {
		return VMM_EINVALID;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (config.value[key] != value) {
		config.value[key] = value;
		if (!++config.seq) {
			++config.seq;
		}
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return VMM_OK;
}

/* The caller holds the slot lock and releases it after this function returns. */
static void sample_slot(struct data *d, u32 id, u64 now, u32 run,
			const struct monitor_config *cfg)
{
	struct event e;
	bool high;

	if (!run || d->epoch != run || !d->present) {
		return;
	}
	if (!d->config_seq && cfg->seq == 1) {
		d->config_seq = cfg->seq;
	}
	if (d->config_seq != cfg->seq) {
		/* Discard the window straddling the update; keep latency/history. */
		d->config_seq = cfg->seq;
		d->previous = now;
		d->interval = 0;
		d->count = 0;
		d->exits = 0;
		d->sustained = 0;
		d->windows = 0;
		d->valid = FALSE;
		return;
	}

	d->interval = now >= d->previous ? now - d->previous : 0;
	d->previous = now;
	d->count = d->exits;
	d->exits = 0;
	d->valid =
		d->interval >= (u64)cfg->value[VMM_MONITOR_WINDOW_MIN_MS] * 1000000 &&
		d->interval <= (u64)cfg->value[VMM_MONITOR_WINDOW_MAX_MS] * 1000000;
	if (!d->valid) {
		d->sustained = 0;
		d->windows = 0;
		return;
	}

	/* Host/idle scheduling is observable, but is not a Guest exit stream. */
	if (d->kind != OBJECT_GUEST) {
		return;
	}

	high = d->count > udiv64((u64)cfg->value[VMM_MONITOR_EXIT_LIMIT] *
				d->interval, VMM_MONITOR_NS);
	if (!high) {
		d->windows = 0;
		d->sustained = 0;
		d->active = FALSE;
		return;
	}
	if (d->active) {
		return;
	}

	d->windows++;
	d->sustained += d->interval;
	if (d->windows >= cfg->value[VMM_MONITOR_SUSTAIN_S] &&
	    d->sustained >= cfg->value[VMM_MONITOR_SUSTAIN_S] * VMM_MONITOR_NS) {
		e.address = 0;
		e.type = 1;
		e.time = now;
		e.last = now;
		e.guest = d->guest;
		e.vcpu = id;
		e.epoch = run;
		e.value = udiv64(d->count * VMM_MONITOR_NS, d->interval);
		e.detail = cfg->value[VMM_MONITOR_EXIT_LIMIT];
		e.code = d->last_exit;
		e.config_seq = cfg->seq;
		e.sustain_s = cfg->value[VMM_MONITOR_SUSTAIN_S];
		d->active = emit(&e);
	}
}

#ifdef CONFIG_WBOXTEST_MONITOR
/*
 * One attempt with the same IRQ/preemption ownership as the generic wrapper.
 * ARM64 preserves the value read by LDAXR separately from STXR's status.
 * No instrumentation or memory access is inserted between the exclusive pair.
 * Other architectures retain the original primitive and report unknown failure.
 */
static int test_lock_try(vmm_spinlock_t *lock, irq_flags_t *flags,
			 u32 *owner, u32 *reason)
{
#if defined(CONFIG_ARM64) && defined(CONFIG_SMP)
	u32 cpu;
	u32 observed;
	u32 status;

	arch_cpu_irq_save(*flags);
	vmm_scheduler_preempt_disable();
	cpu = vmm_smp_processor_id();
	__asm__ __volatile__(
		"ldaxr %w0, %2\n"
		"cmp %w0, %w4\n"
		"b.ne 1f\n"
		"stxr %w1, %w3, %2\n"
		"b 2f\n"
		"1: mov %w1, #1\n"
		"2:\n"
		: "=&r" (observed), "=&r" (status), "+Q" (lock->__tlock.lock)
		: "r" (cpu), "r" (__ARCH_SPIN_UNLOCKED)
		: "cc", "memory");
	*owner = observed;
	if (observed != (u32)__ARCH_SPIN_UNLOCKED) {
		*reason = VMM_MONITOR_LOCK_BUSY;
	} else if (status) {
		*reason = VMM_MONITOR_LOCK_EXCLUSIVE;
	} else {
		*reason = VMM_MONITOR_LOCK_ACQUIRED;
	}
	if (status) {
		vmm_scheduler_preempt_enable();
		arch_cpu_irq_restore(*flags);
		return 0;
	}
	return 1;
#else
	int acquired = vmm_spin_trylock_irqsave(lock, *flags);

	*owner = ~0U;
	*reason = acquired ? VMM_MONITOR_LOCK_ACQUIRED : VMM_MONITOR_LOCK_UNKNOWN;
	return acquired;
#endif
}

/* Publish after releasing the slot, including on a successful attempt. */
static void test_lock_note(u32 actor, u32 generation, u32 owner, u32 reason, u64 now)
{
	irq_flags_t f;
	struct vmm_monitor_test_lock *d = &test_lock_stats;

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (!d->active || d->actor != actor || d->generation != generation) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return;
	}
	d->attempts++;
	d->last_attempt_ns = now;
	d->last_result = reason;
	d->sampler_cpu = vmm_smp_processor_id();
	if (reason == VMM_MONITOR_LOCK_ACQUIRED) {
		d->acquired++;
	} else if (reason == VMM_MONITOR_LOCK_BUSY) {
		d->busy++;
		d->last_busy_owner = owner;
		d->last_busy_ns = now;
		if (owner < 64) {
			d->owner_mask |= 1ULL << owner;
		}
	} else if (reason == VMM_MONITOR_LOCK_EXCLUSIVE) {
		d->exclusive++;
	} else {
		d->unknown++;
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
}
#endif

/* Called only by one periodic executor. Never print or sleep here. */
void vmm_monitor_sample(u64 now)
{
	u32 i;
	u32 run = arch_atomic_read(&enabled);
	irq_flags_t f;
	struct data *d;
	struct monitor_config cfg;
#ifdef CONFIG_WBOXTEST_MONITOR
	u32 watch_actor;
	u32 watch_generation;
	u32 owner = ~0U;
	u32 reason = VMM_MONITOR_LOCK_UNKNOWN;
	int acquired;
#endif

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	cfg = config;
#ifdef CONFIG_WBOXTEST_MONITOR
	watch_actor = test_lock_stats.active ? test_lock_stats.actor : ~0U;
	watch_generation = test_lock_stats.generation;
#endif
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
#ifdef CONFIG_WBOXTEST_MONITOR
		if (i == watch_actor) {
			acquired = test_lock_try(&slots[i].lock, &f, &owner, &reason);
		} else {
			acquired = vmm_spin_trylock_irqsave(&slots[i].lock, f);
		}
		if (!acquired) {
			arch_atomic_inc(&skipped);
			if (i == watch_actor) {
				test_lock_note(i, watch_generation, owner, reason, now);
			}
			continue;
		}
#else
		if (!vmm_spin_trylock_irqsave(&slots[i].lock, f)) {
			arch_atomic_inc(&skipped);
			continue;
		}
#endif

		d = &slots[i].d;
		/* Faults captured before stop/reset must reach the event ring. */
		memory_flush(d);
#ifdef CONFIG_WBOXTEST_MONITOR
		/* A global pass may skip this slot; count successful flushes. */
		test_sample_actor[i]++;
#endif
		sample_slot(d, i, now, run, &cfg);
		vmm_spin_unlock_irqrestore(&slots[i].lock, f);
#ifdef CONFIG_WBOXTEST_MONITOR
		if (i == watch_actor) {
			test_lock_note(i, watch_generation, owner, reason, now);
		}
#endif
	}

#ifdef CONFIG_WBOXTEST_MONITOR
	/* Test-only completion fence: observers never force a sampling pass. */
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	test_sample_serial++;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
#endif
}

static __attribute__((noinline)) void print_event(struct vmm_chardev *c,
						const struct event *e, bool log)
{
	/* Fixed stack storage; the maximum encoded record fits in 384 bytes. */
	char line[384];

	vmm_snprintf(line, sizeof(line),
		"{\"schema\":3,\"seq\":%llu,\"time_ns\":%llu,\"last_ns\":%llu,"
		"\"type\":%u,\"guest\":%u,\"vcpu\":%u,\"epoch\":%u,\"code\":%u,"
		"\"value\":%llu,\"address\":%llu,\"detail\":%llu,"
		"\"config_seq\":%u,\"sustain_s\":%u}\n",
		U(e->seq), U(e->time), U(e->last), e->type, e->guest, e->vcpu,
		e->epoch, e->code, U(e->value), U(e->address), U(e->detail),
		e->config_seq, e->sustain_s);
	if (log) {
		vmm_lwarning("monitor", "%s", line);
	} else {
		vmm_cprintf(c, "%s", line);
	}
}

static bool event_get(u64 seq, struct event *e)
{
	irq_flags_t f;
	bool found;

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	found = seq && seq <= head && head - seq < VMM_MONITOR_EVENTS;
	if (found) {
		*e = ring[(seq - 1) % VMM_MONITOR_EVENTS];
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return found;
}

void vmm_monitor_drain(void)
{
	struct event e;
	u32 n;
	irq_flags_t f;

	/* One worker; a bounded batch prevents an endless log loop. */
	for (n = 0; n < 8; n++) {
		vmm_spin_lock_irqsave_lite(&event_lock, f);
		if (cursor > head) {
			vmm_spin_unlock_irqrestore_lite(&event_lock, f);
			break;
		}

		e = ring[(cursor++ - 1) % VMM_MONITOR_EVENTS];
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		print_event(NULL, &e, TRUE);
#ifdef CONFIG_WBOXTEST_MONITOR
		vmm_spin_lock_irqsave_lite(&event_lock, f);
		if (test_logged[(e.seq - 1) % VMM_MONITOR_EVENTS] != e.seq) {
			test_log_calls[(e.seq - 1) % VMM_MONITOR_EVENTS] = 0;
		}
		test_logged[(e.seq - 1) % VMM_MONITOR_EVENTS] = e.seq;
		test_log_calls[(e.seq - 1) % VMM_MONITOR_EVENTS]++;
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
#endif
	}
}

int vmm_monitor_dump(struct vmm_chardev *c, u32 view)
{
	static const char * const kinds[] = {
		"guest",
		"host",
		"idle"
	};
	u32 i;
	u32 current;
	u64 end;
	u64 drops;
	u64 seq;
	u64 now;
	irq_flags_t f;
	struct event e;
	struct data d;
	struct monitor_config cfg;

	if (view > VMM_MONITOR_CONFIG_VIEW) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	end = head;
	drops = lost;
	current = epoch;
	cfg = config;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	if (view == VMM_MONITOR_EVENTS_VIEW) {
		seq = end >= VMM_MONITOR_EVENTS ? end - VMM_MONITOR_EVENTS + 1 : 1;
		for (; seq <= end; seq++) {
			if (event_get(seq, &e)) {
				print_event(c, &e, FALSE);
			}
		}
		return VMM_OK;
	}

	if (view == VMM_MONITOR_CONFIG_VIEW) {
		vmm_cprintf(c,
			"exit_limit=%u/s sustain_s=%us "
			"window_min_ms=%u window_max_ms=%u\n",
			cfg.value[VMM_MONITOR_EXIT_LIMIT],
			cfg.value[VMM_MONITOR_SUSTAIN_S],
			cfg.value[VMM_MONITOR_WINDOW_MIN_MS],
			cfg.value[VMM_MONITOR_WINDOW_MAX_MS]);
		return VMM_OK;
	}

	vmm_cprintf(c,
		"{\"schema\":3,\"enabled\":%u,\"epoch\":%u,\"sampler_cpu\":%u,"
		"\"events\":%llu,\"lost\":%llu,\"skipped\":%u,\"errors\":%u,"
		"\"exit_limit\":%u,\"sustain_s\":%u,\"window_min_ms\":%u,"
		"\"window_max_ms\":%u,\"config_seq\":%u}\n",
		!!arch_atomic_read(&enabled), current,
		sampler_cpu, U(end), U(drops), (u32)arch_atomic_read(&skipped),
		(u32)arch_atomic_read(&errors), cfg.value[VMM_MONITOR_EXIT_LIMIT],
		cfg.value[VMM_MONITOR_SUSTAIN_S], cfg.value[VMM_MONITOR_WINDOW_MIN_MS],
		cfg.value[VMM_MONITOR_WINDOW_MAX_MS], cfg.seq);

	for (i = 0; i < CONFIG_MAX_VCPU_COUNT; i++) {
		vmm_spin_lock_irqsave_lite(&slots[i].lock, f);
		d = slots[i].d;
		vmm_spin_unlock_irqrestore_lite(&slots[i].lock, f);
		if (!d.present || d.epoch != current) {
			continue;
		}

		now = vmm_timer_timestamp();
		vmm_cprintf(c,
			"{\"schema\":3,\"kind\":\"%s\",\"guest\":%u,\"vcpu\":%u,"
			"\"epoch\":%u,\"time_ns\":%llu,\"interval_ns\":%llu,"
			"\"valid\":%u,\"exits\":%llu,\"ready_age_ns\":%llu,"
			"\"ready\":[%llu,%llu,%llu],\"dispatch\":[%llu,%llu,%llu]}\n",
			kinds[d.kind], d.guest, i, d.epoch,
			U(d.previous), U(d.interval), d.valid, U(d.count),
			U(d.waiting && arch_atomic_read(&enabled) == d.epoch &&
			  now >= d.ready_since ? now - d.ready_since : 0),
			U(d.ready.count),
			U(d.ready.count ? udiv64(d.ready.sum, d.ready.count) : 0),
			U(d.ready.max), U(d.dispatch.count),
			U(d.dispatch.count ?
			  udiv64(d.dispatch.sum, d.dispatch.count) : 0),
			U(d.dispatch.max));
	}

	return VMM_OK;
}

#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static void report(struct vmm_work *unused)
{
	vmm_monitor_drain();
}

static void tick(struct vmm_timer_event *ev)
{
	u64 now = vmm_timer_timestamp();
	irq_flags_t f;
	bool pending;
	int rc;

	vmm_monitor_sample(now);
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	pending = cursor <= head;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	if (pending) {
		rc = vmm_workqueue_schedule_work(queue, &work);
		if (rc && rc != VMM_EALREADY) {
			arch_atomic_inc(&errors);
		}
	}

	now = vmm_timer_timestamp();
	deadline += (udiv64(now >= deadline ? now - deadline : 0,
			   VMM_MONITOR_NS) + 1) * VMM_MONITOR_NS;
	if (vmm_timer_event_start(ev, deadline - now)) {
		arch_atomic_inc(&errors);
	}
}
#endif

int __init vmm_monitor_init(void)
{
	u32 i;
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	int rc;
#endif

	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
		INIT_SPIN_LOCK(&slots[i].lock);
	}
	sampler_cpu = vmm_smp_processor_id();
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	INIT_WORK(&work, report);
	INIT_TIMER_EVENT(&timer, tick, NULL);
	queue = vmm_workqueue_create("monitor", CONFIG_MONITOR_PRIORITY);
	if (!queue) {
		return VMM_ENOMEM;
	}

	rc = vmm_threads_set_affinity(vmm_workqueue_get_thread(queue),
				      vmm_cpumask_of(sampler_cpu));
	if (!rc) {
		deadline = vmm_timer_timestamp() + VMM_MONITOR_NS;
		rc = vmm_timer_event_start(&timer, VMM_MONITOR_NS);
	}
	if (rc) {
		vmm_workqueue_destroy(queue);
		return rc;
	}
#endif

	arch_wmb();
	arch_atomic_write(&initialized, 1);
#ifdef CONFIG_MONITOR_START_ENABLED
	vmm_monitor_enable(TRUE);
#endif
	return VMM_OK;
}

VMM_EXPORT_SYMBOL(vmm_monitor_record);
VMM_EXPORT_SYMBOL(vmm_monitor_enable);
VMM_EXPORT_SYMBOL(vmm_monitor_dump);
VMM_EXPORT_SYMBOL(vmm_monitor_configure);

#ifdef CONFIG_WBOXTEST_MONITOR
/* Diagnostic ownership does not modify samples, epochs or configuration. */
int vmm_monitor_test_lock_begin(u32 actor, u32 *generation)
{
	irq_flags_t f;
	u32 next;

	if (!generation || actor >= CONFIG_MAX_VCPU_COUNT) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (test_lock_stats.active) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return VMM_EBUSY;
	}
	next = test_lock_stats.generation + 1;
	if (!next) {
		next = 1;
	}
	memset(&test_lock_stats, 0, sizeof(test_lock_stats));
	test_lock_stats.actor = actor;
	test_lock_stats.generation = next;
	test_lock_stats.active = TRUE;
	test_lock_stats.sampler_cpu = ~0U;
	test_lock_stats.last_busy_owner = ~0U;
	test_lock_stats.last_result = ~0U;
	test_lock_stats.lock_address = (u64)(virtual_addr_t)&slots[actor].lock;
#if defined(CONFIG_ARM64) && defined(CONFIG_SMP)
	test_lock_stats.precise = 1;
#endif
	*generation = next;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return VMM_OK;
}

int vmm_monitor_test_lock_read(u32 generation, struct vmm_monitor_test_lock *out)
{
	irq_flags_t f;

	if (!generation || !out) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (test_lock_stats.generation != generation) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return VMM_EBUSY;
	}
	*out = test_lock_stats;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return VMM_OK;
}

int vmm_monitor_test_lock_end(u32 generation)
{
	irq_flags_t f;

	if (!generation) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (test_lock_stats.generation != generation) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return VMM_EBUSY;
	}
	test_lock_stats.active = FALSE;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return VMM_OK;
}

/* Read-only access for wboxtest; compiled out with the test option. */
int vmm_monitor_test_state(struct vmm_monitor_test_state *out)
{
	irq_flags_t f;

	if (!out) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	out->epoch = epoch;
	out->enabled = arch_atomic_read(&enabled);
	out->config_seq = config.seq;
	memcpy(out->config, config.value, sizeof(out->config));
	out->head = head;
	out->lost = lost;
	out->skipped = arch_atomic_read(&skipped);
	out->errors = arch_atomic_read(&errors);
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return VMM_OK;
}

int vmm_monitor_test_slot(u32 id, struct vmm_monitor_test_slot *out)
{
	irq_flags_t f;
	struct data *d;

	if (!out || id >= CONFIG_MAX_VCPU_COUNT) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&slots[id].lock, f);
	d = &slots[id].d;
	out->epoch = d->epoch;
	out->guest = d->guest;
	out->kind = d->kind;
	out->config_seq = d->config_seq;
	out->present = d->present;
	out->waiting = d->waiting;
	out->valid = d->valid;
	out->active = d->active;
	out->ready_since = d->ready_since;
	out->previous = d->previous;
	out->interval = d->interval;
	out->exits = d->count;
	out->ready = (struct vmm_monitor_test_latency){
		.count = d->ready.count,
		.sum = d->ready.sum,
		.max = d->ready.max
	};
	out->dispatch = (struct vmm_monitor_test_latency){
		.count = d->dispatch.count,
		.sum = d->dispatch.sum,
		.max = d->dispatch.max
	};
	vmm_spin_unlock_irqrestore_lite(&slots[id].lock, f);

	return VMM_OK;
}

int vmm_monitor_test_event(u64 seq, struct vmm_monitor_test_event *out)
{
	irq_flags_t f;
	struct event *e;

	if (!out || !seq) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (seq > head || head - seq >= VMM_MONITOR_EVENTS) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return VMM_ENOTAVAIL;
	}

	e = &ring[(seq - 1) % VMM_MONITOR_EVENTS];
	*out = (struct vmm_monitor_test_event){
		.seq = e->seq,
		.time_ns = e->time,
		.last_ns = e->last,
		.value = e->value,
		.address = e->address,
		.detail = e->detail,
		.type = e->type,
		.guest = e->guest,
		.vcpu = e->vcpu,
		.epoch = e->epoch,
		.code = e->code,
		.config_seq = e->config_seq,
		.sustain_s = e->sustain_s,
		.log_returned = test_logged[(seq - 1) % VMM_MONITOR_EVENTS] == seq,
		.log_calls = test_logged[(seq - 1) % VMM_MONITOR_EVENTS] == seq ?
			test_log_calls[(seq - 1) % VMM_MONITOR_EVENTS] : 0
	};
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return VMM_OK;
}

int vmm_monitor_test_sample_actor(u32 actor, u64 *out)
{
	irq_flags_t f;
	u32 id = actor == ~0U ? CONFIG_MAX_VCPU_COUNT : actor;

	if (!out || (actor != ~0U && actor >= CONFIG_MAX_VCPU_COUNT)) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&slots[id].lock, f);
	*out = test_sample_actor[id];
	vmm_spin_unlock_irqrestore_lite(&slots[id].lock, f);

	return VMM_OK;
}

int vmm_monitor_test_sample_serial(u64 *out)
{
	irq_flags_t f;

	if (!out) {
		return VMM_EINVALID;
	}
	if (!arch_atomic_read(&initialized)) {
		return VMM_ENOTAVAIL;
	}

	vmm_spin_lock_irqsave_lite(&event_lock, f);
	*out = test_sample_serial;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);

	return VMM_OK;
}
#endif /* CONFIG_WBOXTEST_MONITOR */
