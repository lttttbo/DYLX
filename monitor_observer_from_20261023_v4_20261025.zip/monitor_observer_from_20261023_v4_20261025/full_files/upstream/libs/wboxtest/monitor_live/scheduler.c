/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "common.h"
#include <vmm_threads.h>
#include <vmm_scheduler.h>
#include <vmm_completion.h>
struct hold_context {
    struct ml_context *live;
    struct vmm_completion done;
    struct vmm_monitor_test_slot held;
    u64 start,end;
    int rc;
};
static int hold_worker(void *arg)
{
    struct hold_context *h=arg;
    struct vmm_vcpu *v=h->live->vcpu;
    h->rc=VMM_EFAIL;
    vmm_scheduler_preempt_disable();
    /* Guest was descheduled naturally. Never pause/reset/resume its state. */
    if (vmm_manager_vcpu_get_state(v)==VMM_VCPU_STATE_READY && !ml_slot(h->live,&h->held) && h->held.waiting) {
        h->start=vmm_timer_timestamp();
        vmm_udelay(2000);
        h->end=vmm_timer_timestamp();
        if (vmm_manager_vcpu_get_state(v)==VMM_VCPU_STATE_READY) h->rc=VMM_OK;
    }
    vmm_scheduler_preempt_enable();
    vmm_completion_complete(&h->done);
    return 0;
}
static int schedule_run(struct wboxtest *test,struct vmm_chardev *out,u32 cpu)
{
    struct ml_context c;
    struct hold_context h={0};
    struct vmm_thread *worker=NULL;
    struct vmm_monitor_test_slot before,after;
    u64 timeout=5*VMM_MONITOR_NS,deadline,minimum;
    u32 target_cpu;
    int rc=ml_begin(&c,out);
    (void)test; (void)cpu;
    if (rc) goto out;
    ML_REQUIRE(c.vcpu->priority<=3);
    ML_REQUIRE(vmm_cpumask_weight(vmm_manager_vcpu_get_affinity(c.vcpu))==1);
    ML_REQUIRE(!vmm_manager_vcpu_get_hcpu(c.vcpu,&target_cpu));
    /* Keep auth/mterm CPU out of this bounded interference test. */
    ML_REQUIRE(target_cpu!=0);
    h.live=&c; INIT_COMPLETION(&h.done);
    worker=vmm_threads_create("monitor-test-hold",hold_worker,&h,3,VMM_THREAD_DEF_TIME_SLICE);
    ML_REQUIRE(worker);
    ML_REQUIRE(!vmm_threads_set_affinity(worker,vmm_cpumask_of(target_cpu)));
    ML_REQUIRE(!vmm_threads_start(worker));
    ML_REQUIRE(!vmm_completion_wait_timeout(&h.done,&timeout));
    ML_REQUIRE(!h.rc && h.end>=h.start+2000000ULL);
    /* Use the snapshot taken while the target was actually waiting.
     * Earlier dispatches before the worker started are not test evidence. */
    before=h.held;
    minimum=h.end-h.start;
    deadline=vmm_timer_timestamp()+5*VMM_MONITOR_NS;
    do {
        ML_REQUIRE(!ml_slot(&c,&after));
        if (after.ready.count>before.ready.count && after.dispatch.count>before.dispatch.count) break;
        vmm_msleep(10);
    } while (vmm_timer_timestamp()<deadline);
    ML_REQUIRE(after.ready.count>before.ready.count && after.ready.sum>=before.ready.sum+minimum);
    ML_REQUIRE(after.ready.max>=minimum);
    ML_REQUIRE(after.dispatch.count>before.dispatch.count && after.dispatch.sum>before.dispatch.sum);
    vmm_cprintf(out,"monitor_live SCHEDULE vcpu=%u hold_ns=%llu ready_count_delta=%llu dispatch_count_delta=%llu\n",
        c.id,ML_U(minimum),ML_U(after.ready.count-before.ready.count),ML_U(after.dispatch.count-before.dispatch.count));
out:
    if (worker) {
        if (vmm_threads_stop(worker)) rc=VMM_EFAIL;
        if (vmm_threads_destroy(worker)) rc=VMM_EFAIL;
    }
    return ml_end(&c,rc);
}
ML_REGISTER(monitor_live_schedule,schedule_run);
