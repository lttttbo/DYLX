"""Match read-only monitor_live receipts to an independent persistent-log export.
This checks observed evidence, not that all memory-error categories were exercised.
"""
import argparse,json,re
from pathlib import Path
CASES={'monitor_live_schedule','monitor_live_storm','monitor_live_memory'}
FIELDS=('seq','type','guest','vcpu','epoch','time_ns','code','address','value','detail')
def verify(console,stored):
    summaries=re.findall(r'wboxtest: test=(monitor_live_\w+) failures (\d+) out of (\d+)',console)
    if len(summaries)!=len(CASES) or {n for n,_,_ in summaries}!=CASES:
        raise ValueError('Need exactly one successful summary for each current case')
    if any(f!='0' or total!='1' for _,f,total in summaries) or 'monitor_live FAIL' in console:
        raise ValueError('Failed, skipped or repeated test')
    receipts=[]
    for line in console.splitlines():
        if 'monitor_live LOG ' not in line: continue
        r={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line.split('monitor_live LOG ',1)[1])}
        if not all(k in r for k in FIELDS): raise ValueError('Incomplete receipt')
        receipts.append(r)
    if len(receipts)!=3 or len({tuple(r[k] for k in FIELDS) for r in receipts})!=3:
        raise ValueError('Need two storm receipts and one observed-memory receipt')
    storms=[r for r in receipts if r['type']==1]; memory=[r for r in receipts if r['type']==3]
    if len(storms)!=2 or len(memory)!=1: raise ValueError('Wrong event categories')
    if memory[0]['code'] not in range(1,8) or memory[0]['value']<1:
        raise ValueError('Unknown or empty memory event')
    records=[];decoder=json.JSONDecoder()
    for line in stored.splitlines():
        at=line.find('{')
        if at<0: continue
        try:obj,_=decoder.raw_decode(line[at:])
        except ValueError:continue
        if isinstance(obj,dict) and obj.get('schema')==3 and all(type(obj.get(k)) is int for k in FIELDS):
            records.append(obj)
    for receipt in receipts:
        matches=[r for r in records if all(r[k]==receipt[k] for k in FIELDS)]
        if len(matches)!=1: raise ValueError(f"seq={receipt['seq']}: expected exactly one stored copy")
        r=matches[0]
        if type(r.get('last_ns')) is not int or r['last_ns']<r['time_ns']:raise ValueError('Invalid last_ns')
        if r['type']==1 and (type(r.get('config_seq')) is not int or
            type(r.get('sustain_s')) is not int or r['sustain_s']<2):raise ValueError('Invalid storm evidence')
    return {'live_cases':3,'matched_stored_events':3,'memory_categories_exercised':[memory[0]['code']],
            'storage_origin_must_be_verified_by_operator':True}
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--console',required=True);p.add_argument('--stored-log',required=True);a=p.parse_args()
    if Path(a.console).resolve()==Path(a.stored_log).resolve():p.error('Export stored logs independently')
    try:r=verify(Path(a.console).read_text(encoding='utf-8',errors='replace'),
                 Path(a.stored_log).read_text(encoding='utf-8',errors='replace'))
    except ValueError as e:raise SystemExit('FAIL: '+str(e))
    print('PASS: '+json.dumps(r))
if __name__=='__main__':main()
