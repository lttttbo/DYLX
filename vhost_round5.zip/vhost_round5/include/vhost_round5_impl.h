/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef VHOST_ROUND5_IMPL_H
#define VHOST_ROUND5_IMPL_H

/* Include ONLY in drivers/vhost/vhost.c, after the local vhost.h. */
#include "vhost_round5.h"
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/percpu.h>
#include <linux/ktime.h>
#include <linux/uaccess.h>
#include <linux/cpumask.h>
#include <linux/string.h>
#include <linux/spinlock.h>

#define N5_KINDS 2
#define N5_BINS 6
#define N5_OUTCOMES 3 /* queued+wake0, queued+wake1, merged */

struct n5_stats {
        u64 event[N5_EV_COUNT];
        u64 exit_calls[N5_EXIT_COUNT];
        u64 exit_bins[N5_EXIT_COUNT][N5_BINS];
        u64 exit_heads[N5_EXIT_COUNT];
        u64 exit_tail[N5_EXIT_COUNT][N5_TAIL_COUNT];
        u64 queue[N5_KINDS][N5_SRC_COUNT][N5_OUTCOMES];
        u64 executed[N5_KINDS];
        u64 tx_completed;
        u64 bad_units;
        u64 prebind_queue;
        u64 prebind_execute;
        u64 identity_conflict;
        u64 config_changed;
};
struct n5_cpu_data {
        raw_spinlock_t lock;
        struct n5_stats s;
};
struct n5_config {
        bool event_idx, packed;
        unsigned int busyloop, ring_size, weight, byte_weight;
};
static DEFINE_PER_CPU(struct n5_cpu_data, n5_pc);
static DEFINE_MUTEX(n5_control_lock);
static DEFINE_RAW_SPINLOCK(n5_binding_lock);
static bool n5_running;
static u32 n5_epoch;
static int n5_target_tid;
static u64 n5_start_ns, n5_stop_ns;
static struct vhost_dev *n5_dev;
static struct vhost_work *n5_kick_work, *n5_backend_work;
static struct n5_config n5_cfg;
static struct proc_dir_entry *n5_proc;

#define N5_NAME(a,b) b,
static const char * const n5_source_name[] = { N5_SOURCES(N5_NAME) };
static const char * const n5_exit_name[] = { N5_EXITS(N5_NAME) };
static const char * const n5_event_name[] = { N5_EVENTS(N5_NAME) };
#undef N5_NAME
static const char * const n5_kind_name[] = { "tx_kick_work", "tx_backend_work" };

/* Short accounting section only. No original work/queue/signal operation is
 * performed while any diagnostic raw spinlock is held. */
static struct n5_cpu_data *n5_lock_cpu(u32 epoch, unsigned long *flags)
{
        struct n5_cpu_data *pc;

        local_irq_save(*flags);
        pc = this_cpu_ptr(&n5_pc);
        raw_spin_lock(&pc->lock);
        if (!smp_load_acquire(&n5_running) || epoch != READ_ONCE(n5_epoch)) {
                raw_spin_unlock(&pc->lock);
                local_irq_restore(*flags);
                return NULL;
        }
        return pc;
}
static void n5_unlock_cpu(struct n5_cpu_data *pc, unsigned long flags)
{
        raw_spin_unlock(&pc->lock);
        local_irq_restore(flags);
}
static bool n5_worker_matches(struct vhost_dev *dev)
{
        struct task_struct *worker = READ_ONCE(dev->worker);

        return worker && task_pid_nr(worker) == READ_ONCE(n5_target_tid);
}
/* Pointers are identity tokens only: never dereference a stored pointer.
 * Only live objects passed by the original caller are accessed. */
static int n5_work_kind(struct vhost_dev *dev, struct vhost_work *work)
{
        if (!n5_worker_matches(dev))
                return -1;
        if (!smp_load_acquire(&n5_dev))
                return -2;
        if (READ_ONCE(n5_dev) != dev)
                return -1;
        if (work == READ_ONCE(n5_kick_work))
                return 0;
        if (work == READ_ONCE(n5_backend_work))
                return 1;
        return -1;
}
static void n5_note_queue(struct vhost_dev *dev, struct vhost_work *work,
                          enum n5_source source, int outcome)
{
        struct n5_cpu_data *pc;
        unsigned long flags;
        u32 epoch;
        int kind;

        if (!smp_load_acquire(&n5_running))
                return;
        epoch = READ_ONCE(n5_epoch);
        kind = n5_work_kind(dev, work);
        if (kind == -1)
                return;
        pc = n5_lock_cpu(epoch, &flags);
        if (!pc)
                return;
        if (kind == -2)
                pc->s.prebind_queue++;
        else if ((unsigned int)source < N5_SRC_COUNT &&
                 (unsigned int)outcome < N5_OUTCOMES)
                pc->s.queue[kind][source][outcome]++;
        n5_unlock_cpu(pc, flags);
}
static void n5_note_execute(struct vhost_dev *dev, struct vhost_work *work)
{
        struct n5_cpu_data *pc;
        unsigned long flags;
        u32 epoch;
        int kind;

        if (!smp_load_acquire(&n5_running))
                return;
        epoch = READ_ONCE(n5_epoch);
        kind = n5_work_kind(dev, work);
        if (kind == -1)
                return;
        pc = n5_lock_cpu(epoch, &flags);
        if (!pc)
                return;
        if (kind == -2)
                pc->s.prebind_execute++;
        else
                pc->s.executed[kind]++;
        n5_unlock_cpu(pc, flags);
}

void vhost_n5_tx_begin(struct vhost_n5_tx *t, struct vhost_virtqueue *vq,
                       struct vhost_work *backend_work)
{
        struct vhost_dev *dev = vq->dev;
        struct n5_cpu_data *pc;
        struct n5_config cfg;
        unsigned long flags;
        u32 epoch;
        bool conflict = false, changed = false;

        t->active = false;
        if (!smp_load_acquire(&n5_running) || !n5_worker_matches(dev))
                return;
        epoch = READ_ONCE(n5_epoch);
        cfg.event_idx = vhost_has_feature(vq, VIRTIO_RING_F_EVENT_IDX);
        cfg.packed = vhost_has_feature(vq, VIRTIO_F_RING_PACKED);
        cfg.busyloop = vq->busyloop_timeout;
        cfg.ring_size = vq->num;
        cfg.weight = dev->weight;
        cfg.byte_weight = dev->byte_weight;

        /* First selected TX call binds the two real work object identities. */
        if (!smp_load_acquire(&n5_dev)) {
                raw_spin_lock_irqsave(&n5_binding_lock, flags);
                if (smp_load_acquire(&n5_running) && epoch == READ_ONCE(n5_epoch) &&
                    !n5_dev) {
                        n5_kick_work = &vq->poll.work;
                        n5_backend_work = backend_work;
                        n5_cfg = cfg;
                        smp_store_release(&n5_dev, dev);
                }
                raw_spin_unlock_irqrestore(&n5_binding_lock, flags);
        }
        if (!smp_load_acquire(&n5_running) || epoch != READ_ONCE(n5_epoch))
                return;
        conflict = READ_ONCE(n5_dev) != dev ||
                   READ_ONCE(n5_kick_work) != &vq->poll.work ||
                   READ_ONCE(n5_backend_work) != backend_work;
        if (!conflict)
                changed = cfg.event_idx != n5_cfg.event_idx ||
                          cfg.packed != n5_cfg.packed ||
                          cfg.busyloop != n5_cfg.busyloop ||
                          cfg.ring_size != n5_cfg.ring_size ||
                          cfg.weight != n5_cfg.weight ||
                          cfg.byte_weight != n5_cfg.byte_weight;
        if (conflict || changed) {
                pc = n5_lock_cpu(epoch, &flags);
                if (pc) {
                        pc->s.identity_conflict += conflict;
                        pc->s.config_changed += changed;
                        n5_unlock_cpu(pc, flags);
                }
                if (conflict)
                        return;
        }
        memset(t, 0, sizeof(*t));
        t->epoch = epoch;
        t->before = vq->last_avail_idx;
        t->packed = cfg.packed;
        t->exit = N5_EXIT_UNSET;
        t->active = true;
}
EXPORT_SYMBOL_GPL(vhost_n5_tx_begin);

static unsigned int n5_units_bin(unsigned int n)
{
        if (!n) return 0;
        if (n == 1) return 1;
        if (n <= 4) return 2;
        if (n <= 16) return 3;
        if (n <= 64) return 4;
        return 5;
}
void vhost_n5_tx_end(struct vhost_n5_tx *t, struct vhost_virtqueue *vq)
{
        struct n5_cpu_data *pc;
        unsigned long flags;
        unsigned int i, reason;
        u16 units;

        if (!t->active)
                return;
        t->active = false;
        units = (u16)(vq->last_avail_idx - t->before);
        reason = (unsigned int)t->exit;
        if (reason >= N5_EXIT_COUNT)
                reason = N5_EXIT_UNSET;
        pc = n5_lock_cpu(t->epoch, &flags);
        if (!pc)
                return;
        pc->s.tx_completed++;
        for (i = 0; i < N5_EV_COUNT; i++)
                pc->s.event[i] += t->event[i];
        pc->s.exit_calls[reason]++;
        if ((unsigned int)t->tail < N5_TAIL_COUNT)
                pc->s.exit_tail[reason][t->tail]++;
        if (t->packed || units > 32768U) {
                pc->s.bad_units++;
        } else {
                pc->s.exit_bins[reason][n5_units_bin(units)]++;
                pc->s.exit_heads[reason] += units;
        }
        n5_unlock_cpu(pc, flags);
}
EXPORT_SYMBOL_GPL(vhost_n5_tx_end);

static void n5_sum_stats(struct n5_stats *to, const struct n5_stats *from)
{
        unsigned int i, j, k;
        for (i = 0; i < N5_EV_COUNT; i++) to->event[i] += from->event[i];
        for (i = 0; i < N5_EXIT_COUNT; i++) {
                to->exit_calls[i] += from->exit_calls[i];
                to->exit_heads[i] += from->exit_heads[i];
                for (j = 0; j < N5_TAIL_COUNT; j++)
                        to->exit_tail[i][j] += from->exit_tail[i][j];
                for (j = 0; j < N5_BINS; j++)
                        to->exit_bins[i][j] += from->exit_bins[i][j];
        }
        for (i = 0; i < N5_KINDS; i++) {
                to->executed[i] += from->executed[i];
                for (j = 0; j < N5_SRC_COUNT; j++)
                        for (k = 0; k < N5_OUTCOMES; k++)
                                to->queue[i][j][k] += from->queue[i][j][k];
        }
        to->tx_completed += from->tx_completed;
        to->bad_units += from->bad_units;
        to->prebind_queue += from->prebind_queue;
        to->prebind_execute += from->prebind_execute;
        to->identity_conflict += from->identity_conflict;
        to->config_changed += from->config_changed;
}
static int n5_show(struct seq_file *m, void *unused)
{
        struct n5_stats *sum;
        unsigned int i, j;
        int cpu;

        sum = kzalloc(sizeof(*sum), GFP_KERNEL);
        if (!sum)
                return -ENOMEM;
        mutex_lock(&n5_control_lock);
        seq_printf(m, "# vhost_n5 v1 run=%u epoch=%u tid=%d start_ns=%llu stop_ns=%llu\n",
                   n5_running, n5_epoch, n5_target_tid,
                   (unsigned long long)n5_start_ns, (unsigned long long)n5_stop_ns);
        if (n5_running) {
                seq_puts(m, "# Stop before reading counters. Commands: start TID; stop\n");
                goto out;
        }
        for_each_possible_cpu(cpu)
                n5_sum_stats(sum, &per_cpu(n5_pc, cpu).s);
        seq_printf(m, "IDENTITY,bound=%u,dev=%px,kick_work=%px,backend_work=%px\n",
                   n5_dev != NULL, n5_dev, n5_kick_work, n5_backend_work);
        seq_printf(m, "CONFIG,event_idx=%u,packed=%u,busyloop_us=%u,ring_size=%u,weight=%u,byte_weight=%u\n",
                   n5_cfg.event_idx, n5_cfg.packed, n5_cfg.busyloop,
                   n5_cfg.ring_size, n5_cfg.weight, n5_cfg.byte_weight);
        seq_printf(m, "CHECK,completed=%llu,bad_units=%llu,prebind_queue=%llu,prebind_execute=%llu,identity_conflict=%llu,config_changed=%llu\n",
                   (unsigned long long)sum->tx_completed,
                   (unsigned long long)sum->bad_units,
                   (unsigned long long)sum->prebind_queue,
                   (unsigned long long)sum->prebind_execute,
                   (unsigned long long)sum->identity_conflict,
                   (unsigned long long)sum->config_changed);
        seq_puts(m, "# EXIT,reason,calls,net_heads,zero,one,two_four,five_16,17_64,gt64\n");
        for (i = 0; i < N5_EXIT_COUNT; i++) {
                seq_printf(m, "EXIT,%s,%llu,%llu", n5_exit_name[i],
                           (unsigned long long)sum->exit_calls[i],
                           (unsigned long long)sum->exit_heads[i]);
                for (j = 0; j < N5_BINS; j++)
                        seq_printf(m, ",%llu", (unsigned long long)sum->exit_bins[i][j]);
                seq_putc(m, '\n');
        }
        seq_puts(m, "# EXIT_TAIL,reason,not_run,pending,recheck_changed,no_self_requeue,busy_interrupted\n");
        for (i = 0; i < N5_EXIT_COUNT; i++) {
                seq_printf(m, "EXIT_TAIL,%s", n5_exit_name[i]);
                for (j = 0; j < N5_TAIL_COUNT; j++)
                        seq_printf(m, ",%llu", (unsigned long long)sum->exit_tail[i][j]);
                seq_putc(m, '\n');
        }
        seq_puts(m, "# EVENT,name,count; counts from completed selected TX handlers\n");
        for (i = 0; i < N5_EV_COUNT; i++)
                seq_printf(m, "EVENT,%s,%llu\n", n5_event_name[i],
                           (unsigned long long)sum->event[i]);
        seq_puts(m, "# QUEUE,work,source,observed_outcomes,new_queued,merged,wake_return_0,wake_return_1\n");
        for (i = 0; i < N5_KINDS; i++) {
                for (j = 0; j < N5_SRC_COUNT; j++) {
                        u64 w0 = sum->queue[i][j][0], w1 = sum->queue[i][j][1];
                        u64 merged = sum->queue[i][j][2];
                        seq_printf(m, "QUEUE,%s,%s,%llu,%llu,%llu,%llu,%llu\n",
                                   n5_kind_name[i], n5_source_name[j],
                                   (unsigned long long)(w0 + w1 + merged),
                                   (unsigned long long)(w0 + w1),
                                   (unsigned long long)merged,
                                   (unsigned long long)w0, (unsigned long long)w1);
                }
                seq_printf(m, "EXECUTE,%s,%llu\n", n5_kind_name[i],
                           (unsigned long long)sum->executed[i]);
        }
        seq_puts(m, "# Queue outcomes are not packet counts or IPI counts.\n"
                    "# Executions need not equal enqueues: start/stop boundaries and pre-existing work.\n"
                    "# poll_event is a waitqueue callback; poll_start_already_ready is synchronous vfs_poll readiness.\n"
                    "# get_tx_bufs_empty is the loop observation BEFORE final batch flush/recheck.\n"
                    "# Not-proven-empty includes the original avail-read-error return; see TX errors/logs.\n");
out:
        mutex_unlock(&n5_control_lock);
        kfree(sum);
        return 0;
}
static int n5_open(struct inode *inode, struct file *file)
{
        return single_open(file, n5_show, NULL);
}

static void n5_stop_locked(void)
{
        unsigned long flags;
        int cpu;

        if (!n5_running)
                return;
        WRITE_ONCE(n5_running, false);
        /* Drain short accounting sections, NOT the real vhost work queues. */
        for_each_possible_cpu(cpu) {
                struct n5_cpu_data *pc = &per_cpu(n5_pc, cpu);
                raw_spin_lock_irqsave(&pc->lock, flags);
                raw_spin_unlock_irqrestore(&pc->lock, flags);
        }
        raw_spin_lock_irqsave(&n5_binding_lock, flags);
        raw_spin_unlock_irqrestore(&n5_binding_lock, flags);
        n5_stop_ns = ktime_get_ns();
}
static ssize_t n5_write(struct file *file, const char __user *buf,
                       size_t count, loff_t *ppos)
{
        char cmd[64], *input;
        int tid, cpu, ret = 0;
        unsigned long flags;

        if (!count || count >= sizeof(cmd))
                return -EINVAL;
        if (copy_from_user(cmd, buf, count))
                return -EFAULT;
        cmd[count] = '\0';
        input = strim(cmd);
        mutex_lock(&n5_control_lock);
        if (!strcmp(input, "stop")) {
                n5_stop_locked();
        } else if (!strncmp(input, "start ", 6) &&
                   !kstrtoint(strim(input + 6), 10, &tid) && tid > 0) {
                if (n5_running) {
                        ret = -EBUSY;
                        goto out;
                }
                for_each_possible_cpu(cpu) {
                        struct n5_cpu_data *pc = &per_cpu(n5_pc, cpu);
                        raw_spin_lock_irqsave(&pc->lock, flags);
                        memset(&pc->s, 0, sizeof(pc->s));
                        raw_spin_unlock_irqrestore(&pc->lock, flags);
                }
                raw_spin_lock_irqsave(&n5_binding_lock, flags);
                n5_dev = NULL;
                n5_kick_work = NULL;
                n5_backend_work = NULL;
                memset(&n5_cfg, 0, sizeof(n5_cfg));
                n5_target_tid = tid;
                n5_epoch++;
                if (!n5_epoch) n5_epoch++;
                n5_stop_ns = 0;
                n5_start_ns = ktime_get_ns();
                smp_store_release(&n5_running, true);
                raw_spin_unlock_irqrestore(&n5_binding_lock, flags);
        } else {
                ret = -EINVAL;
        }
out:
        mutex_unlock(&n5_control_lock);
        return ret ? ret : count;
}
static const struct proc_ops n5_ops = {
        .proc_open = n5_open,
        .proc_read = seq_read,
        .proc_write = n5_write,
        .proc_lseek = seq_lseek,
        .proc_release = single_release,
};
static int vhost_n5_debug_init(void)
{
        int cpu;
        for_each_possible_cpu(cpu)
                raw_spin_lock_init(&per_cpu(n5_pc, cpu).lock);
        n5_proc = proc_create("vhost_n5", 0600, NULL, &n5_ops);
        return n5_proc ? 0 : -ENOMEM;
}
static void vhost_n5_debug_exit(void)
{
        if (n5_proc)
                proc_remove(n5_proc);
        mutex_lock(&n5_control_lock);
        n5_stop_locked();
        mutex_unlock(&n5_control_lock);
}
#endif
