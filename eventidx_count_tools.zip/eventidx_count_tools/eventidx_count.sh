#!/bin/sh
# EVENT_IDX observable-effect capture, v1.0. Read-only; no tracing or affinity writes.
# Same script runs in ServerVM Linux and Android (root shell).
# Usage: sh eventidx_count.sh inspect android|server
#        sh eventidx_count.sh capture android|server off|on client|asyncio [seconds]
set -u
umask 077
LC_ALL=C
export LC_ALL
VERSION=1.0
PROC=${EIC_PROC_ROOT:-/proc}
SYS=${EIC_SYS_ROOT:-/sys}
NET_IF=${NET_IF:-eth0}
TAP_IF=${TAP_IF:-tap1}
DIRECTION=${DIRECTION:-up}
WARMUP=${WARMUP:-15}
WAIT_TIMEOUT=${WAIT_TIMEOUT:-120}
START_PPS=${START_PPS:-5000}
WAIT_MODE=${WAIT_MODE:-auto}
PAYLOAD=${PAYLOAD_BYTES:-1400}
ETHTOOL=${ETHTOOL:-}
if [ -z "$ETHTOOL" ]; then
    ETHTOOL=$(command -v ethtool 2>/dev/null || true)
fi
if [ -z "$ETHTOOL" ]; then
    SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)
    [ ! -x "$SCRIPT_DIR/virtio_ethtool_stats" ] || ETHTOOL="$SCRIPT_DIR/virtio_ethtool_stats"
fi
CMD=${1:-help}
ROLE=${2:-}
STATE=${3:-}
ROUTE=${4:-}
SECONDS_N=${5:-30}
OUT=

usage() {
    cat <<'EOF'
Usage:
  sh eventidx_count.sh inspect server|android
  sh eventidx_count.sh capture server|android off|on client|asyncio [seconds]

Defaults: NET_IF=eth0 TAP_IF=tap1 DIRECTION=up WARMUP=15
          WAIT_TIMEOUT=120 START_PPS=5000 WAIT_MODE=auto PAYLOAD_BYTES=1400
Optional: IRQ_LIST='77,78,79' (only after checking this NIC's IRQs)
          OUT_DIR=/new/directory
          ETHTOOL=/data/ethtool (or the optional virtio_ethtool_stats helper)

'off/on' and 'client/asyncio' describe the already-running configuration.
They DO NOT change EVENT_IDX, route, polling, affinity, sysctl, or trace settings.
Automatic mode waits for traffic, warms up, takes two endpoint snapshots.
Default measurement is 30 seconds. Start both collectors before iperf3.
If NIC IRQ discovery fails, use inspect; never guess IRQ numbers.
EOF
}
fail() {
    echo "ERROR: $*" >&2
    if [ -n "$OUT" ] && [ -d "$OUT" ]; then
        printf 'status=ERROR\nreason=%s\n' "$*" > "$OUT/status.env"
    fi
    exit 1
}
case "$CMD" in inspect|capture) ;; *) usage; exit 2;; esac
case "$ROLE" in server|android) ;; *) usage; exit 2;; esac
case "$NET_IF:$TAP_IF" in *[!A-Za-z0-9_.:-]*) fail 'Invalid interface name';; esac
case "$DIRECTION" in up|down) ;; *) fail 'DIRECTION must be up or down';; esac
for n in "$WARMUP" "$WAIT_TIMEOUT" "$START_PPS" "$SECONDS_N" "$PAYLOAD"; do
    case "$n" in ''|*[!0-9]*) fail 'Durations, START_PPS and PAYLOAD_BYTES must be integers';; esac
done
[ "$SECONDS_N" -gt 0 ] && [ "$SECONDS_N" -le 300 ] || fail 'seconds must be 1..300'
[ "$WARMUP" -le 120 ] && [ "$WAIT_TIMEOUT" -le 600 ] || fail 'Warm-up/timeout too large'
[ "$PAYLOAD" -gt 0 ] && [ "$PAYLOAD" -le 65507 ] || fail 'Invalid UDP payload length'
[ -r "$PROC/interrupts" ] && [ -r "$PROC/net/dev" ] || fail 'Cannot read interrupts or net/dev'
[ -d "$SYS/class/net/$NET_IF" ] || fail "No interface $NET_IF; set NET_IF to Android/ServerVM's actual NIC"
for c in awk cat readlink grep sort mkdir sleep uname date tr; do
    command -v "$c" >/dev/null 2>&1 || fail "Missing command: $c"
done

get_uptime() { read -r UPTIME_UNUSED UPTIME_IDLE < "$PROC/uptime" || return 1; printf '%s\n' "$UPTIME_UNUSED"; }
main_packets() {
    awk -v name="$NET_IF" -v dir="$DIRECTION" '
        index($0, ":") { k=index($0, ":"); n=substr($0,1,k-1); gsub(/^[ \t]+|[ \t]+$/, "",n);
          if(n==name) { s=substr($0,k+1); gsub(/^[ \t]+/,"",s); split(s,a,/[ \t]+/);
            if (dir=="up") print a[10]; else print a[2]; found=1; exit } }
        END {if(!found) exit 1}' "$PROC/net/dev"
}
DEVICE=$(readlink -f "$SYS/class/net/$NET_IF/device" 2>/dev/null || true)
VIRTIO=
FEATURE_PATH=
p=$DEVICE
n=0
while [ -n "$p" ] && [ "$p" != / ] && [ "$n" -lt 8 ]; do
    b=${p##*/}
    case "$b" in virtio[0-9]*)
        VIRTIO=$b
        [ ! -r "$p/features" ] || FEATURE_PATH=$p/features
        break;;
    esac
    p=${p%/*}; n=$((n+1))
done

# Return only numeric IRQ IDs. MSI vectors belong to this device/its PCI ancestor.
IRQ_METHOD=none
IRQ_IDS=
if [ -n "${IRQ_LIST:-}" ]; then
    IRQ_IDS=$(printf '%s' "$IRQ_LIST" | tr ',' ' ')
    IRQ_METHOD=manual
else
    p=$DEVICE; n=0
    while [ -n "$p" ] && [ "$p" != / ] && [ "$n" -lt 6 ]; do
        if [ -d "$p/msi_irqs" ]; then
            for f in "$p"/msi_irqs/*; do
                [ -e "$f" ] || continue
                b=${f##*/}
                case "$b" in ''|*[!0-9]*) ;; *) IRQ_IDS="$IRQ_IDS $b";; esac
            done
            [ -z "$IRQ_IDS" ] || { IRQ_METHOD=sysfs_msi; break; }
        fi
        p=${p%/*}; n=$((n+1))
    done
    if [ -z "$IRQ_IDS" ]; then
        if [ "$ROLE" = android ] && [ -n "$VIRTIO" ]; then token=$VIRTIO; else token=$NET_IF; fi
        IRQ_IDS=$(awk -v token="$token" '
          $1 ~ /^[0-9]+:$/ {
            hit=0; for(i=2;i<=NF;i++){s=$i;gsub(/[,;]/,"",s);
              if(s==token || index(s, token "-")==1 || index(s,token ":")==1)hit=1}
            if(hit){s=$1;sub(/:$/,"",s);print s}}' "$PROC/interrupts")
        [ -z "$IRQ_IDS" ] || IRQ_METHOD=action_name
    fi
fi
IRQ_IDS=$(printf '%s\n' $IRQ_IDS | awk 'NF' | sort -nu | tr '\n' ' ')
# Validate before using IDs in paths. Reject IDs absent from /proc/interrupts.
for irq in $IRQ_IDS; do
    case "$irq" in ''|*[!0-9]*) fail 'IRQ_LIST must contain only decimal IRQ numbers';; esac
    awk -v key="$irq:" '$1==key {yes=1} END{exit !yes}' "$PROC/interrupts" || fail "IRQ $irq is not present"
done
show_irqs() {
    awk -v ids="$IRQ_IDS" 'BEGIN{n=split(ids,a," ");for(i=1;i<=n;i++)want[a[i] ":"]=1}
        NR==1 || want[$1]' "$PROC/interrupts"
}
feature_bit() {
    if [ -n "$FEATURE_PATH" ] && [ -r "$FEATURE_PATH" ]; then
        awk 'NR==1 {gsub(/[ \t\r]/,""); if($0 ~ /^[01]+$/ && length($0)>29) print substr($0,30,1);else print "unknown"}' "$FEATURE_PATH"
    else printf 'unknown\n'; fi
}
if [ "$CMD" = inspect ]; then
    printf 'role=%s interface=%s device=%s virtio=%s\n' "$ROLE" "$NET_IF" "$DEVICE" "$VIRTIO"
    printf 'feature_path=%s event_idx_bit29=%s irq_method=%s irq_ids=%s\n' "$FEATURE_PATH" "$(feature_bit)" "$IRQ_METHOD" "$IRQ_IDS"
    if [ -n "$IRQ_IDS" ]; then show_irqs; else
        echo 'No exact NIC IRQ match. Full /proc/interrupts follows for manual identification:'
        cat "$PROC/interrupts"
    fi
    if [ "$ROLE" = android ]; then
        if [ -n "$ETHTOOL" ]; then
            echo "Guest kick counters via $ETHTOOL (read only):"
            "$ETHTOOL" -S "$NET_IF" 2>&1 | grep -E 'kicks|not supported|Cannot|ERROR|Operation' || true
        else
            echo 'No ethtool/helper: Guest kick counts will be N/A; IRQ capture remains available.'
        fi
    fi
    exit 0
fi
case "$STATE" in off) EXPECT=0;; on) EXPECT=1;; *) fail 'State must be off or on';; esac
case "$ROUTE" in client|asyncio) ;; *) fail 'Route must be client or asyncio';; esac
case "$WAIT_MODE" in auto|manual) ;; *) fail 'WAIT_MODE must be auto or manual';; esac
[ -n "$IRQ_IDS" ] || fail "No exact NIC IRQ match; run: NET_IF=$NET_IF sh $0 inspect $ROLE"
if [ "$ROLE" = android ]; then
    [ -n "$VIRTIO" ] || fail 'Android NIC is not identified as a virtio device; inspect its sysfs device path'
    actual=$(feature_bit)
    [ "$actual" = unknown ] || [ "$actual" = "$EXPECT" ] || fail "Android negotiated EVENT_IDX=$actual, but label=$STATE; change DSM build/restart first"
fi
OUT=${OUT_DIR:-"$PWD/eventidx_counts/${ROLE}_${STATE}_$(date +%Y%m%d_%H%M%S)_$$"}
[ ! -e "$OUT" ] || fail "Refusing to overwrite $OUT"
mkdir -p "$OUT" || fail "Cannot create $OUT"
trap 'fail "Interrupted; partial capture is not comparable"' INT TERM HUP
{
    printf 'version=%s\nrole=%s\nstate_declared=%s\nroute_declared=%s\n' "$VERSION" "$ROLE" "$STATE" "$ROUTE"
    printf 'net_if=%s\ntap_if=%s\ndirection=%s\npayload_bytes=%s\n' "$NET_IF" "$TAP_IF" "$DIRECTION" "$PAYLOAD"
    printf 'seconds_requested=%s\nwarmup=%s\nwait_mode=%s\n' "$SECONDS_N" "$WARMUP" "$WAIT_MODE"
    printf 'device=%s\nvirtio=%s\nfeature_path=%s\nirq_method=%s\nirq_ids=%s\n' "$DEVICE" "$VIRTIO" "$FEATURE_PATH" "$IRQ_METHOD" "$IRQ_IDS"
    printf 'vhost_tid_hint=%s\nethtool=%s\n' "${VHOST_TID:-}" "$ETHTOOL"
    printf 'kernel=%s\n' "$(uname -r)"
} > "$OUT/meta.env"
show_irqs > "$OUT/irq_selection.txt"
printf 'status=WAITING\n' > "$OUT/status.env"

context() {
    side=$1
    {
        printf 'uptime=%s\n' "$(get_uptime)"
        printf 'device=%s\n' "$(readlink -f "$SYS/class/net/$NET_IF/device" 2>/dev/null || true)"
        printf 'ifindex='; cat "$SYS/class/net/$NET_IF/ifindex" 2>/dev/null || echo unknown
        printf 'mac='; cat "$SYS/class/net/$NET_IF/address" 2>/dev/null || echo unknown
        printf 'online='; cat "$SYS/devices/system/cpu/online" 2>/dev/null || echo unknown
        printf 'boot_id='; cat "$PROC/sys/kernel/random/boot_id" 2>/dev/null || echo unknown
        for irq in $IRQ_IDS; do
            for k in smp_affinity_list effective_affinity_list; do
                printf 'irq_%s_%s=' "$irq" "$k"
                cat "$PROC/irq/$irq/$k" 2>/dev/null || echo unknown
            done
        done
    } > "$OUT/context.$side.env"
    if [ -n "$FEATURE_PATH" ]; then cat "$FEATURE_PATH" > "$OUT/features.$side" 2>/dev/null || :; fi
    if [ "$ROLE" = server ]; then
        # Initialization logs only; no performance probe is enabled here.
        dmesg 2>"$OUT/dmesg.$side.error" | grep -E 'IOEM_CFG|VQMAP|VQCFG' > "$OUT/kernel_map.$side.txt" || :
    fi
    : > "$OUT/threads.$side.tsv"
    for q in "$PROC"/[0-9]*/comm; do
        [ -r "$q" ] || continue
        IFS= read -r comm < "$q" || continue
        case "$comm" in vhost-*|VM*-ioeventfd-*|*dsm*|iperf3|vtnet*tx*) ;; *) continue;; esac
        procdir=${q%/comm}; tid=${procdir##*/}
        [ -r "$procdir/stat" ] || continue
        IFS= read -r st < "$procdir/stat" || continue
        rest=${st##*) }
        ident=$(printf '%s\n' "$rest" | awk '{print $20}')
        affinity=$(awk '$1=="Cpus_allowed_list:"{print $2}' "$procdir/status" 2>/dev/null)
        printf '%s\t%s\t%s\t%s\n' "$tid" "$comm" "$ident" "${affinity:-unknown}" >> "$OUT/threads.$side.tsv"
        case "$comm" in *dsm*) tr '\000' '\n' < "$procdir/cmdline" > "$OUT/dsm_${tid}.$side.argv" 2>/dev/null || :;; esac
    done
}
# Expensive metadata is deliberately OUTSIDE measurement endpoints.
context before
printf 'READY role=%s state=%s route=%s NIC=%s IRQs=%s\n' "$ROLE" "$STATE" "$ROUTE" "$NET_IF" "$IRQ_IDS"
show_irqs
if [ "$WAIT_MODE" = auto ]; then
    echo "Waiting for $DIRECTION traffic >= $START_PPS packets/s; start iperf3 now."
    t0=$(get_uptime) || fail 'No uptime'
    oldtime=$t0; old=$(main_packets) || fail 'No NIC counters'
    while :; do
        sleep 1
        now=$(get_uptime) || fail 'No uptime'; packets=$(main_packets) || fail 'NIC disappeared'
        ok=$(awk -v n="$packets" -v p="$old" -v t="$now" -v u="$oldtime" -v lim="$START_PPS" 'BEGIN{print (t>u && n>=p && (n-p)/(t-u)>=lim)?1:0}')
        if [ "$ok" = 1 ]; then printf 'flow_detect_uptime=%s\n' "$now" >> "$OUT/meta.env"; break; fi
        expired=$(awk -v n="$now" -v p="$t0" -v lim="$WAIT_TIMEOUT" 'BEGIN{print (n-p>=lim)?1:0}')
        [ "$expired" = 0 ] || fail 'Traffic wait timeout; no measurement was made'
        old=$packets; oldtime=$now
    done
fi
echo "Warm-up ${WARMUP}s; then ${SECONDS_N}s endpoint-only measurement."
sleep "$WARMUP"
printf 'status=RUNNING\n' > "$OUT/status.env"
snapshot() {
    side=$1
    for spec in netdev:net/dev interrupts:interrupts stat:stat softirqs:softirqs; do
        name=${spec%%:*}; rel=${spec#*:}
        get_uptime > "$OUT/$side.$name.begin" || fail 'No uptime'
        cat "$PROC/$rel" > "$OUT/$side.$name" 2>"$OUT/$side.$name.error" || fail "Cannot read $rel"
        get_uptime > "$OUT/$side.$name.end" || fail 'No uptime'
    done
    if [ "$ROLE" = android ] && [ -n "$ETHTOOL" ]; then
        get_uptime > "$OUT/$side.ethtool.begin" || fail 'No uptime'
        "$ETHTOOL" -S "$NET_IF" > "$OUT/$side.ethtool" 2> "$OUT/$side.ethtool.error"
        printf '%s\n' "$?" > "$OUT/$side.ethtool.rc"
        get_uptime > "$OUT/$side.ethtool.end" || fail 'No uptime'
    fi
}
snapshot before
sleep "$SECONDS_N"
snapshot after
printf 'status=OK\n' > "$OUT/status.env"
context after
printf 'capture_end_uptime=%s\n' "$(get_uptime)" >> "$OUT/meta.env"
cat > "$OUT/NOTES.txt" <<'EOF'
Only /proc and /sys were read. No EVENT_IDX/route/affinity/polling/probe changes.
NIC IRQ counts are delivered IRQ-handler entries, not vhost_notify(false) counts.
ServerVM eth0 IRQ is physical-NIC IRQ; Android virtio NIC IRQ is virtual.
ServerVM function-call IPI counts are indirect effects and system-wide.
Guest-to-backend kicks are read only if the Android driver exposes tx/rx_queue_N_kicks.
Unavailable ethtool/driver counters are reported as N/A, never inferred from IPI.
Metadata timestamps are NOT measurement endpoints; each counter has its own endpoints.
The two guests' clocks/windows are independent: compare OFF/ON within each role.
EOF
printf 'DONE: %s\n' "$OUT"
echo 'Run eventidx_report.py on the PC with all four directories. No raw trace is needed.'
