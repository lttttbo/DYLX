#!/bin/sh
# HOS network diagnostics v2. POSIX sh. No network configuration changes.
LC_ALL=C
export LC_ALL
umask 077
usage() {
    cat <<'USAGE'
Usage: sh hos_net_diag.sh ACTION [options]
Read-only: basic uplink forward frontend backend notify schedule compat sample selfcheck
Active (explicit only): probe (bounded ping), capture (bounded tcpdump)
Options:
  --role servervm|android|peer   label only, default servervm
  --iface NAME --phy NAME --tap NAME --bridge NAME
  --dm-pid PID                 actual DM PID, never guessed
  --peer IP                    literal IPv4/IPv6, not a hostname
  --seconds N                  sample/probe/capture 1..60, default 5
  --count N                    probe 1..20, default 5
  --packets N                  capture 1..10000, default 2000
  --snaplen N                  capture 64..4096 bytes, default 256
  --out DIRECTORY              output parent, default ./hos_net_reports
Each run creates a unique subdirectory; existing evidence is never overwritten.
probe/capture require verified timeout -k/-s support. No automatic namespace entry.
capture is non-promiscuous with NO filter; --peer does not filter capture.
Exit 0=collection completed (NOT network healthy), 2=arguments, 3=partial/failed,
5=output error, 130/143=interrupted.
USAGE
}
die() { printf '%s\n' "ERROR: $*" >&2; exit 2; }
number() {
    case "$2" in ''|*[!0-9]*) die "$1 must be decimal";; esac
    [ "${#2}" -le 9 ] || die "$1 is too large"
    [ "$2" -ge "$3" ] && [ "$2" -le "$4" ] || die "$1 outside $3..$4"
}
ifname() {
    case "$1" in ''|-*|.|..|*[!A-Za-z0-9_.:@-]*) die "invalid interface: $1";; esac
}
literal_ip() {
    case "$1" in
        *:*)
            ip_part=${1%%%*}
            case "$ip_part" in *[!0-9A-Fa-f:.]*) die "invalid IPv6 literal";; esac
            case "$1" in *%*) zone=${1#*%}; ifname "$zone";; esac ;;
        *.*.*.*)
            case "$1" in *[!0-9.]*|.*|*.|*..*) die "invalid IPv4 literal";; esac
            saved_ifs=$IFS; IFS=.; set -- $1; IFS=$saved_ifs
            [ "$#" -eq 4 ] || die "IPv4 needs four octets"
            for octet do number IPv4 "$octet" 0 255; done ;;
        *) die "--peer must be a literal IP, not a hostname";;
    esac
}
case "${1-}" in ''|-h|--help) usage; exit 0;; esac
action=$1; shift
case "$action" in basic|uplink|forward|frontend|backend|notify|schedule|compat|sample|selfcheck|probe|capture) ;;
    *) die "unknown action: $action";;
esac
role=servervm
iface= phy= tap= bridge= dm_pid= peer=
seconds=5; count=5; packets=2000; snaplen=256; out=./hos_net_reports
while [ "$#" -gt 0 ]; do
    case "$1" in -h|--help) usage; exit 0;; esac
    [ "$#" -ge 2 ] || die "missing value for $1"
    case "$1" in
        --role) role=$2;; --iface) iface=$2;; --phy) phy=$2;;
        --tap) tap=$2;; --bridge) bridge=$2;; --dm-pid) dm_pid=$2;;
        --peer) peer=$2;; --seconds) seconds=$2;; --count) count=$2;;
        --packets) packets=$2;; --snaplen) snaplen=$2;; --out) out=$2;;
        *) die "unknown option: $1";;
    esac
    shift 2
done
case "$role" in servervm|android|peer) ;; *) die "invalid --role";; esac
for name in "$iface" "$phy" "$tap" "$bridge"; do [ -z "$name" ] || ifname "$name"; done
[ -z "$dm_pid" ] || number --dm-pid "$dm_pid" 1 999999999
[ -z "$peer" ] || literal_ip "$peer"
number --seconds "$seconds" 1 60
number --count "$count" 1 20
number --packets "$packets" 1 10000
number --snaplen "$snaplen" 64 4096
[ -n "$out" ] || die "--out is empty"
case "$out" in *'
'*|*'	'*) die "--out cannot contain newline/tab";; esac
case "$out" in /*|./*|../*) ;; *) out=./$out;; esac
case "$action" in
    probe) [ -n "$iface" ] && [ -n "$peer" ] || die "probe needs --iface and --peer";;
    capture|frontend) [ -n "$iface" ] || die "$action needs --iface";;
    backend) [ -n "$dm_pid" ] || die "backend needs --dm-pid";;
    uplink) [ -n "$phy$iface" ] || die "uplink needs --phy or --iface";;
    sample) [ -n "$iface$phy$tap$bridge" ] || die "sample needs an interface";;
esac
# Override only in isolated fixtures; keep unset on the board.
sys=${HOS_NET_SYS_ROOT:-/sys}
proc=${HOS_NET_PROC_ROOT:-/proc}
for tool in mkdir date cat sleep dirname readlink; do
    command -v "$tool" >/dev/null 2>&1 || {
        printf 'ERROR: required utility missing: %s\n' "$tool" >&2; exit 3
    }
done
base=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 5
stamp=$(date -u +%Y%m%dT%H%M%SZ) || exit 5
mkdir -p "$out" || exit 5
run=$out/${stamp}_${role}_${action}_$$
mkdir "$run" || { printf 'ERROR: cannot create unique run directory\n' >&2; exit 5; }
report=$run/report.txt
index=$run/index.tsv
printf 'id\tlabel\tstate\trc\tfile\n' > "$index" || exit 5
printf 'HOS network diagnostics v2\nrole=%s action=%s\nsys_root=%s proc_root=%s\n' "$role" "$action" "$sys" "$proc" > "$report" || exit 5
printf 'Parameters: iface=%s phy=%s tap=%s bridge=%s dm_pid=%s peer=%s\n' "$iface" "$phy" "$tap" "$bridge" "$dm_pid" "$peer" >> "$report" || exit 5
printf 'run=%s\n' "$run"
partial=0; seq=0; child=; guard=0
note() { printf '%s\n' "$*" >> "$report" || exit 5; printf '%s\n' "$*"; }
on_signal() {
    sig_rc=$1
    trap '' INT TERM HUP
    if [ -n "$child" ]; then
        if [ "$action" = capture ] && [ "$guard" -eq 1 ]; then
            kill -INT "$child" 2>/dev/null
        else
            kill -TERM "$child" 2>/dev/null
        fi
        # A verified timeout owns its command; let it forward signals and
        # apply its kill grace. Never kill just the wrapper and orphan its job.
        for cleanup_tick in 1 2 3 4; do
            kill -0 "$child" 2>/dev/null || break
            if [ "$guard" -eq 0 ] && [ "$cleanup_tick" -eq 3 ]; then
                kill -KILL "$child" 2>/dev/null
            fi
            sleep 1
        done
        if kill -0 "$child" 2>/dev/null; then
            note "CLEANUP_UNCONFIRMED child_pid=$child; inspect this process, no global kill issued"
        else
            wait "$child" 2>/dev/null
        fi
        child=
    fi
    note "INTERRUPTED rc=$sig_rc; preserve partial evidence"
    exit "$sig_rc"
}
trap 'on_signal 130' INT
trap 'on_signal 143' TERM HUP
# Local capability check, never generates traffic.
if command -v timeout >/dev/null 2>&1; then
    timeout -k 2 -s TERM 1 sleep 2 > "$run/timeout_check.txt" 2>&1 &
    child=$!; wait "$child"; guard_rc=$?; child=
    case "$guard_rc" in 124|137|143) guard=1;; esac
fi
if [ "$guard" -eq 1 ]; then
    note "TIMEOUT_GUARD=verified; query limit=10s plus kill grace=2s"
else
    note "TIMEOUT_GUARD=unavailable; active/slow queries skipped, simple local queries have no timeout"
    partial=1
fi
interfaces=
for name in "$iface" "$phy" "$tap" "$bridge"; do
    [ -n "$name" ] || continue
    case " $interfaces " in *" $name "*) ;; *) interfaces="$interfaces $name";; esac
done
for name in $interfaces; do
    if [ ! -d "$sys/class/net/$name" ]; then
        note "UNAVAILABLE interface=$name in current namespace"; partial=1
    fi
done
record() {
    printf '%s\t%s\t%s\t%s\t%s\n' "$seq" "$label" "$state" "$rc" "$logfile" >> "$index" || exit 5
    note "[$state] $label rc=$rc file=$logfile"
}
run_cmd() {
    label=$1; shift
    seq=$((seq + 1))
    logfile=$(printf '%03d_%s.txt' "$seq" "$label")
    target=$run/$logfile
    {
        printf 'label=%s\ncommand:' "$label"
        for arg do printf ' [%s]' "$arg"; done
        printf '\nstart_utc='; date -u +%Y-%m-%dT%H:%M:%SZ
    } > "$target" || exit 5
    if ! command -v "$1" >/dev/null 2>&1; then
        printf 'tool_missing=%s\n' "$1" >> "$target" || exit 5
        state=MISSING; rc=127; partial=1
    else
        if [ "$guard" -eq 1 ]; then
            timeout -k 2 -s TERM 10 "$@" >> "$target" 2>&1 &
        else
            "$@" >> "$target" 2>&1 &
        fi
        child=$!; wait "$child"; rc=$?; child=
        state=OK
        if [ "$rc" -ne 0 ]; then
            state=FAILED
            case "$rc" in 124|137|143) [ "$guard" -eq 0 ] || state=TIMEOUT;; esac
            partial=1
        fi
    fi
    { printf '\nend_utc='; date -u +%Y-%m-%dT%H:%M:%SZ;
      printf 'rc=%s state=%s\n' "$rc" "$state"; } >> "$target" || exit 5
    record
}
skip() { note "[SKIP] $*"; partial=1; }
slow_cmd() {
    if [ "$guard" -eq 1 ]; then run_cmd "$@"; else skip "$1: reliable timeout unavailable"; fi
}
read_file() {
    if [ -r "$2" ]; then run_cmd "$1" cat "$2"; else skip "$1: absent or unreadable: $2"; fi
}
identity() {
    run_cmd uname uname -a
    read_file os_version "$proc/version"
    read_file uptime "$proc/uptime"
    read_file boot_id "$proc/sys/kernel/random/boot_id"
    run_cmd namespace readlink "$proc/self/ns/net"
    if [ "$role" = android ]; then run_cmd android_build getprop ro.build.fingerprint; fi
}
link_info() {
    for name in $interfaces; do
        [ -d "$sys/class/net/$name" ] || continue
        run_cmd "link_$name" ip -s link show dev "$name"
        for field in ifindex mtu operstate carrier address; do
            read_file "${field}_$name" "$sys/class/net/$name/$field"
        done
        if [ -L "$sys/class/net/$name/master" ]; then
            run_cmd "master_$name" readlink -f "$sys/class/net/$name/master"
        else note "master[$name]=none"; fi
    done
}
basic() {
    identity
    run_cmd links ip link show
    run_cmd addresses ip addr show
    run_cmd routes4 ip -4 route show table all
    run_cmd routes6 ip -6 route show table all
    run_cmd rules4 ip -4 rule show
    run_cmd rules6 ip -6 rule show
    run_cmd neighbors ip neigh show
    [ -z "$peer" ] || run_cmd route_get ip route get "$peer"
    read_file net_dev "$proc/net/dev"
    link_info
    if [ "$role" = android ]; then
        slow_cmd connectivity dumpsys connectivity
        slow_cmd ethernet dumpsys ethernet
    fi
}
uplink() {
    link_info
    port=${phy:-$iface}
    slow_cmd physical_link ethtool "$port"
    slow_cmd physical_driver ethtool -i "$port"
    slow_cmd physical_stats ethtool -S "$port"
    [ -z "$peer" ] || run_cmd route_get ip route get "$peer"
    run_cmd neighbors ip neigh show
}
forward() {
    run_cmd link_details ip -d link show
    run_cmd bridge_ports bridge link show
    run_cmd bridge_vlans bridge vlan show
    run_cmd bridge_fdb bridge fdb show
    run_cmd routes4 ip -4 route show table all
    run_cmd routes6 ip -6 route show table all
    run_cmd rules4 ip -4 rule show
    run_cmd rules6 ip -6 rule show
    read_file ip_forward "$proc/sys/net/ipv4/ip_forward"
    read_file ipv6_forward "$proc/sys/net/ipv6/conf/all/forwarding"
    read_file rp_filter_all "$proc/sys/net/ipv4/conf/all/rp_filter"
    for name in $interfaces; do
        read_file "rp_filter_$name" "$proc/sys/net/ipv4/conf/$name/rp_filter"
        run_cmd "qdisc_$name" tc -s qdisc show dev "$name"
        run_cmd "ingress_$name" tc -s filter show dev "$name" ingress
        if [ -d "$sys/class/net/$name/brif" ]; then run_cmd "bridge_members_$name" ls "$sys/class/net/$name/brif"; fi
    done
    slow_cmd nft_rules nft list ruleset
    slow_cmd iptables_rules iptables-save
    slow_cmd ip6tables_rules ip6tables-save
    link_info
}
device_info() {
    for name in $interfaces; do
        [ -d "$sys/class/net/$name" ] || continue
        run_cmd "device_$name" readlink -f "$sys/class/net/$name/device"
        run_cmd "driver_$name" readlink -f "$sys/class/net/$name/device/driver"
        read_file "uevent_$name" "$sys/class/net/$name/device/uevent"
        read_file "features_$name" "$sys/class/net/$name/device/features"
        run_cmd "queues_$name" ls "$sys/class/net/$name/queues"
        slow_cmd "offload_$name" ethtool -k "$name"
        slow_cmd "channels_$name" ethtool -l "$name"
    done
}
backend() {
    [ -n "$dm_pid" ] || { skip "backend: supply --dm-pid"; return; }
    [ -d "$proc/$dm_pid" ] || { skip "DM PID disappeared: $dm_pid"; return; }
    read_file dm_stat_before "$proc/$dm_pid/stat"
    run_cmd dm_namespace readlink "$proc/$dm_pid/ns/net"
    self_ns=$(readlink "$proc/self/ns/net" 2>/dev/null)
    dm_ns=$(readlink "$proc/$dm_pid/ns/net" 2>/dev/null)
    if [ -n "$self_ns" ] && [ -n "$dm_ns" ] && [ "$self_ns" != "$dm_ns" ]; then
        note "NAMESPACE_MISMATCH: shell=$self_ns dm=$dm_ns; interface data belongs to shell namespace"
    fi
    run_cmd dm_fds ls -l "$proc/$dm_pid/fd"
    # Fixed command, no user-controlled shell code.
    run_cmd dm_cmdline sh -c 'tr "\000" " " < "$1" || exit $?; printf "\n"' sh "$proc/$dm_pid/cmdline"
    run_cmd dm_threads ps -T -p "$dm_pid"
    read_file dm_status "$proc/$dm_pid/status"
    run_cmd dm_tasks ls "$proc/$dm_pid/task"
    found=0
    for info in "$proc/$dm_pid"/fdinfo/*; do
        [ -e "$info" ] || continue
        found=$((found + 1))
        [ "$found" -le 128 ] || { skip "fdinfo truncated at 128 entries"; break; }
        fd=${info##*/}
        read_file "fdinfo_$fd" "$info"
    done
    [ "$found" -gt 0 ] || skip "fdinfo absent, empty or inaccessible"
    read_file dm_stat_after "$proc/$dm_pid/stat"
    run_cmd tuntap ip tuntap show
    read_file modules "$proc/modules"
}
notify() {
    read_file interrupts "$proc/interrupts"
    read_file softirqs "$proc/softirqs"
    slow_cmd kernel_log dmesg
    note "No generic command exposes HOS virtqueue/CCM match counters; use chapter 11 instrumentation only after narrowing the path."
}
schedule() {
    read_file stat "$proc/stat"
    read_file uptime "$proc/uptime"
    read_file softirqs "$proc/softirqs"
    read_file softnet "$proc/net/softnet_stat"
    run_cmd processes ps -A
    if [ -n "$dm_pid" ]; then
        run_cmd dm_threads ps -T -p "$dm_pid"
        run_cmd dm_tasks ls "$proc/$dm_pid/task"
    fi
    link_info
    device_info
}
snapshot() {
    snap=$1
    {
        printf 'meta\tboot\t'
        if [ -r "$proc/sys/kernel/random/boot_id" ]; then cat "$proc/sys/kernel/random/boot_id"; else printf 'UNAVAILABLE\n'; fi
        printf 'meta\tns\t'
        readlink "$proc/self/ns/net" 2>/dev/null || printf 'UNAVAILABLE\n'
        printf 'meta\tuptime\t'
        if [ -r "$proc/uptime" ]; then cat "$proc/uptime"; else printf 'UNAVAILABLE\n'; fi
        for name in $interfaces; do
            printf 'id\t%s\t' "$name"
            if [ -r "$sys/class/net/$name/ifindex" ]; then cat "$sys/class/net/$name/ifindex"; else printf 'UNAVAILABLE\n'; fi
            for counter in rx_bytes rx_packets rx_errors rx_dropped tx_bytes tx_packets tx_errors tx_dropped; do
                printf 'counter\t%s\t%s\t' "$name" "$counter"
                if [ -r "$sys/class/net/$name/statistics/$counter" ]; then
                    cat "$sys/class/net/$name/statistics/$counter" || printf 'UNAVAILABLE\n'
                else printf 'UNAVAILABLE\n'; fi
            done
        done
    } > "$snap" || exit 5
}
sample() {
    snapshot "$run/before.tsv"
    read_file interrupts_before "$proc/interrupts"
    read_file softirqs_before "$proc/softirqs"
    sleep "$seconds"
    snapshot "$run/after.tsv"
    read_file interrupts_after "$proc/interrupts"
    read_file softirqs_after "$proc/softirqs"
    if command -v awk >/dev/null 2>&1 && [ -r "$base/hos_net_delta.awk" ]; then
        awk -f "$base/hos_net_delta.awk" "$run/before.tsv" "$run/after.tsv" > "$run/delta.tsv"
        delta_rc=$?
        [ "$delta_rc" -eq 0 ] || partial=1
        note "delta.tsv rc=$delta_rc; use raw uptime for elapsed time, not assumed --seconds"
    else skip "delta unavailable: awk/helper missing; raw snapshots retained"; fi
}
active() {
    [ "$guard" -eq 1 ] || { skip "$action requires verified timeout"; return; }
    [ -d "$sys/class/net/$iface" ] || { skip "$action: interface not present"; return; }
    seq=$((seq + 1)); label=$action
    logfile=$(printf '%03d_%s.txt' "$seq" "$label")
    target=$run/$logfile
    printf 'start_utc=' > "$target" || exit 5
    date -u +%Y-%m-%dT%H:%M:%SZ >> "$target" || exit 5
    if [ "$action" = probe ]; then
        ping_tool=ping
        case "$peer" in *:*) if command -v ping6 >/dev/null 2>&1; then ping_tool=ping6; fi;; esac
        command -v "$ping_tool" >/dev/null 2>&1 || { skip "ping missing"; return; }
        note "ACTIVE_PROBE: $peer via $iface; at most $count requests within ${seconds}s"
        printf 'command: timeout -k 2 -s TERM [%s] [%s] -I [%s] -c [%s] [%s]\n' "$seconds" "$ping_tool" "$iface" "$count" "$peer" >> "$target" || exit 5
        timeout -k 2 -s TERM "$seconds" "$ping_tool" -I "$iface" -c "$count" "$peer" >> "$target" 2>&1 &
    else
        command -v tcpdump >/dev/null 2>&1 || { skip "tcpdump missing"; return; }
        note "ACTIVE_CAPTURE: iface=$iface duration=${seconds}s packets=$packets snaplen=$snaplen; non-promiscuous, no filter"
        printf 'command: timeout -k 2 -s INT [%s] tcpdump -p -n -i [%s] -s [%s] -c [%s] -U -w [%s]\n' "$seconds" "$iface" "$snaplen" "$packets" "$run/capture.pcap" >> "$target" || exit 5
        timeout -k 2 -s INT "$seconds" tcpdump -p -n -i "$iface" -s "$snaplen" -c "$packets" -U -w "$run/capture.pcap" >> "$target" 2>&1 &
    fi
    child=$!; wait "$child"; rc=$?; child=
    state=OK
    if [ "$action" = capture ] && [ "$rc" -eq 124 ] && [ -s "$run/capture.pcap" ]; then
        state=WINDOW_DONE
    elif [ "$rc" -ne 0 ]; then
        state=FAILED
        case "$rc" in 124|137|143) state=TIMEOUT;; esac
        partial=1
    fi
    { printf '\nend_utc='; date -u +%Y-%m-%dT%H:%M:%SZ;
      printf 'rc=%s state=%s\n' "$rc" "$state"; } >> "$target" || exit 5
    record
    [ "$action" != capture ] || note "Nonempty pcap may be header-only. Inspect packet/drop counts; a quiet capture is inconclusive."
}
selfcheck() {
    for tool in ip bridge ethtool tc nft iptables-save ip6tables-save ps awk timeout ping ping6 tcpdump getprop dumpsys nsenter; do
        if command -v "$tool" >/dev/null 2>&1; then note "TOOL $tool=available"; else note "TOOL $tool=missing"; fi
    done
    identity
    note "Availability is not an end-to-end network verdict."
}
case "$action" in
    basic) basic;; uplink) uplink;; forward) forward;;
    frontend) link_info; device_info; notify;;
    backend) backend;; notify) notify;; schedule) schedule;;
    compat) identity; link_info; device_info;
        if [ "$role" = servervm ] || [ -n "$dm_pid" ]; then backend; fi
        notify;;
    sample) sample;; selfcheck) selfcheck;; probe|capture) active;;
esac
if [ "$partial" -eq 0 ]; then note "COLLECTION_COMPLETE; rc=0 is not a network PASS"; exit 0; fi
note "COLLECTION_PARTIAL; inspect MISSING/SKIP/FAILED/TIMEOUT; rc=3"
exit 3
