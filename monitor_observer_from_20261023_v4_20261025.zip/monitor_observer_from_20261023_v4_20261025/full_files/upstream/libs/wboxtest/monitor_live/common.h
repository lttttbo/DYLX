/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef MONITOR_LIVE_COMMON_H
#define MONITOR_LIVE_COMMON_H
#include <vmm_monitor_test.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <vmm_delay.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <libs/wboxtest.h>
#include <libs/stringlib.h>
#define ML_U(x) ((unsigned long long)(x))
struct ml_context {
    struct vmm_guest *guest;
    struct vmm_vcpu *vcpu;
    struct vmm_chardev *out;
    struct vmm_monitor_test_state baseline;
    u32 id, guest_id, timeout_s;
    bool locked;
};
int ml_begin(struct ml_context *, struct vmm_chardev *);
int ml_end(struct ml_context *, int);
int ml_check(struct ml_context *);
int ml_slot(struct ml_context *, struct vmm_monitor_test_slot *);
int ml_scan(struct ml_context *, u64, u32, struct vmm_monitor_test_event *, u32 *);
int ml_log_wait(struct ml_context *, u64);
u64 ml_timeout(struct ml_context *);
#define ML_REQUIRE(expr) do { if (!(expr)) { \
    vmm_cprintf(c.out,"monitor_live FAIL %s:%u: %s\n",__func__,__LINE__,#expr); \
    rc=VMM_EFAIL; goto out; } } while (0)
#define ML_REGISTER(test_name,fn) \
static struct wboxtest test_name={.name=#test_name,.run=fn}; \
static int __init test_name##_init(void) { return wboxtest_register("monitor_live",&test_name); } \
static void __exit test_name##_exit(void) { wboxtest_unregister(&test_name); } \
VMM_DECLARE_MODULE2(test_name,#test_name,"Monitor maintainers","GPL",WBOXTEST_IPRIORITY+1, \
    test_name##_init,test_name##_exit)
#endif
