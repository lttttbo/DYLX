/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef __VMM_MONITOR_DIAG_H__
#define __VMM_MONITOR_DIAG_H__
#include <vmm_monitor.h>
#define VMM_MONITOR_DIAG_SLOTS 16
struct vmm_monitor_diag_record {
	u64 pc, esr, count, sum_ns, max_ns, last_ns;
	u32 guest, vcpu, errors;
};
#ifdef CONFIG_MONITOR_AGENT
void vmm_monitor_diag_init(void);
u64 vmm_monitor_diag_begin(void);
void vmm_monitor_diag_end(struct vmm_vcpu *v, u64 pc, u64 esr, u64 start, int rc);
int vmm_monitor_diag_start(u32 ms);
void vmm_monitor_diag_stop(void);
int vmm_monitor_diag_get(u32 index, struct vmm_monitor_diag_record *out);
u64 vmm_monitor_diag_overflow(void);
#else
#define vmm_monitor_diag_begin() 0ULL
#define vmm_monitor_diag_end(...) do { } while (0)
#endif
#endif
