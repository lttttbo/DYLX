/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Diagnostic probe for two dedicated test SPIs; never use device/Guest IRQs. */
#include "test_irq.h"
#include <vmm_mutex.h>
#include <vmm_spinlocks.h>
#include <vmm_cpumask.h>
#include <arch_cpu_irq.h>

#define IPD_IRQS 2
#define IPD_FRAMES 12
#define IPD_TRACES 16
#define IPD_NS 1000000000ULL
#define IPD_U(x) ((unsigned long long)(x))
#define IPD_HW_STATE \
	(VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_MASKED)

enum ipd_stage {
	IPD_BEFORE,
	IPD_REGISTER_0,
	IPD_REGISTER_1,
	IPD_PRIORITY_0,
	IPD_PRIORITY_1,
	IPD_ARM,
	IPD_UNMASK_0,
	IPD_UNMASK_1,
	IPD_TRIGGER,
	IPD_WAIT,
	IPD_FINISH,
	IPD_CLEANUP
};

static const char *const ipd_stage_names[] = {"before",	   "register0", "register1", "priority0",
					      "priority1", "arm",	"unmask0",   "unmask1",
					      "trigger",   "wait",	"finish",    "cleanup"};

struct ipd_source {
	u32 id;
	struct vmm_host_irq *irq;
	const char *name;
	u8 priority;
	bool masked;
	bool attempted;
	bool priority_attempted;
};

struct ipd_frame_irq {
	u32 hw;
	int hw_rc;
	u8 priority;
	int priority_rc;
	u32 levels;
	u32 pmr_level;
	int level_rc;
	bool sw_masked;
	u32 count[CONFIG_CPU_COUNT];
	u32 calls;
	u32 fired;
};

struct ipd_frame {
	u64 time;
	u32 cpu;
	u32 stage;
	int rc;
	bool irq_off;
	struct ipd_frame_irq irq[IPD_IRQS];
};

struct ipd_trace {
	u64 time;
	u32 irq;
	u32 index;
	u32 cpu;
	u32 stage;
};

struct ipd_data {
	struct ipd_source source[IPD_IRQS];
	struct ipd_frame frame[IPD_FRAMES];
	struct ipd_trace trace[IPD_TRACES];
	u32 stage;
	u32 frames;
	u32 traces;
	u32 dropped;
	u32 calls[IPD_IRQS];
	u32 fired[IPD_IRQS];
	u32 first_cpu[IPD_IRQS];
	u32 first_order[IPD_IRQS];
	u32 sequence;
	int mask_rc[IPD_IRQS];
	bool triggered;
};

static struct ipd_data ipd;
/* Never reuse callback storage after an incomplete cleanup. */
static bool ipd_dirty;
static DEFINE_MUTEX(ipd_run_lock);
static DEFINE_SPINLOCK(ipd_trace_lock);

static void ipd_phase(u32 stage)
{
	irq_flags_t flags;
	vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
	ipd.stage = stage;
	vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
}

static vmm_irq_return_t ipd_handler(int irq, void *data)
{
	struct ipd_source *source = data;
	u32 index = (u32)(source - ipd.source);
	u32 cpu = vmm_smp_processor_id();
	u64 now = vmm_timer_timestamp();
	irq_flags_t flags;
	int rc;

	if (index >= IPD_IRQS || (u32)irq != source->id) {
		return VMM_IRQ_NONE;
	}
	/* Record entry before masking; no console output from IRQ context. */
	vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
	ipd.calls[index]++;
	if (ipd.traces < IPD_TRACES) {
		struct ipd_trace *trace = &ipd.trace[ipd.traces++];
		trace->time = now;
		trace->irq = (u32)irq;
		trace->index = index;
		trace->cpu = cpu;
		trace->stage = ipd.stage;
	} else {
		ipd.dropped++;
	}
	if (ipd.stage == IPD_TRIGGER || ipd.stage == IPD_WAIT) {
		if (!ipd.fired[index]) {
			ipd.first_cpu[index] = cpu;
			ipd.first_order[index] = ++ipd.sequence;
		}
		ipd.fired[index]++;
	}
	vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);

	rc = vmm_host_irq_mask(source->id);
	vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
	if (rc) {
		ipd.mask_rc[index] = rc;
	}
	vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
	return VMM_IRQ_HANDLED;
}

static void ipd_snapshot(u32 stage, int rc)
{
	struct ipd_frame *frame;
	irq_flags_t flags;
	u32 i;
	u32 cpu;

	if (ipd.frames >= IPD_FRAMES) {
		return;
	}
	frame = &ipd.frame[ipd.frames++];
	frame->time = vmm_timer_timestamp();
	frame->cpu = vmm_smp_processor_id();
	frame->irq_off = arch_cpu_irq_disabled();
	frame->stage = stage;
	frame->rc = rc;
	for (i = 0; i < IPD_IRQS; i++) {
		struct ipd_frame_irq *sample = &frame->irq[i];
		struct ipd_source *source = &ipd.source[i];
		sample->hw_rc =
			vmm_host_irq_get_routed_state(source->id, &sample->hw, IPD_HW_STATE);
		sample->priority_rc = vmm_host_irq_get_priority(source->id, &sample->priority);
		sample->level_rc = vmm_host_irq_priority_level(source->id, &sample->levels,
							       &sample->pmr_level);
		sample->sw_masked = vmm_host_irq_is_masked(source->irq);
		for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
			sample->count[cpu] = vmm_host_irq_get_count(source->irq, cpu);
		}
	}
	vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
	for (i = 0; i < IPD_IRQS; i++) {
		frame->irq[i].calls = ipd.calls[i];
		frame->irq[i].fired = ipd.fired[i];
	}
	vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
}

/* Aggregate includes per-CPU copies. Do not interpret it as device count. */
static u32 ipd_actions(struct ipd_source *source, bool own_only)
{
	struct vmm_host_irq_action *action;
	irq_flags_t flags;
	u32 count = 0;
	u32 cpu;
	for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
		vmm_read_lock_irqsave_lite(&source->irq->action_lock[cpu], flags);
		list_for_each_entry(action, &source->irq->action_list[cpu], head)
		{
			if (!own_only || action->dev == source) {
				count++;
			}
		}
		vmm_read_unlock_irqrestore_lite(&source->irq->action_lock[cpu], flags);
	}
	return count;
}

static int ipd_prepare(struct vmm_chardev *out, u32 high_irq, u32 low_irq)
{
	u32 i;
	u32 cpu;
	bool reject = FALSE;
	for (i = 0; i < IPD_IRQS; i++) {
		struct ipd_source *source = &ipd.source[i];
		source->id = i ? low_irq : high_irq;
		source->irq = vmm_host_irq_get(source->id);
		if (!source->irq || !source->irq->chip) {
			vmm_cprintf(out, "IRQDBG reject irq=%u: descriptor/chip unavailable\n",
				    source->id);
			return VMM_ENOTAVAIL;
		}
	}
	ipd_snapshot(IPD_BEFORE, VMM_OK);
	for (i = 0; i < IPD_IRQS; i++) {
		struct ipd_source *source = &ipd.source[i];
		struct ipd_frame_irq *saved = &ipd.frame[0].irq[i];
		u32 actions = ipd_actions(source, FALSE);
		source->name = vmm_host_irq_get_name(source->irq);
		source->priority = saved->priority;
		source->masked = !!(saved->hw & VMM_ROUTED_IRQ_STATE_MASKED);
		vmm_cprintf(out, "IRQDBG initial irq=%u hwirq=%u name=%s actions=%u\n", source->id,
			    source->irq->hwirq, source->name ? source->name : "-", actions);
		vmm_cprintf(out,
			    "IRQDBG state=0x%x type=0x%x routed=%u affinity=", source->irq->state,
			    vmm_host_irq_get_trigger_type(source->irq),
			    (u32)vmm_host_irq_is_routed(source->irq));
		for (cpu = 0; cpu < (u32)vmm_cpu_count && cpu < CONFIG_CPU_COUNT; cpu++) {
			if (vmm_cpumask_test_cpu(cpu, &source->irq->affinity)) {
				vmm_cprintf(out, "%u,", cpu);
			}
		}
		vmm_cprintf(out, "\n");
		if (actions || vmm_host_irq_is_routed(source->irq) ||
		    vmm_host_irq_is_per_cpu(source->irq) || vmm_host_irq_is_ipi(source->irq) ||
		    vmm_host_irq_is_chained(source->irq) || saved->hw_rc || saved->priority_rc ||
		    saved->level_rc || saved->levels < 2 || saved->priority >= saved->levels ||
		    (saved->hw & (VMM_ROUTED_IRQ_STATE_PENDING | VMM_ROUTED_IRQ_STATE_ACTIVE)) ||
		    saved->sw_masked != source->masked) {
			reject = TRUE;
		}
	}
	if (ipd.source[1].id != ipd.source[0].id + 1U || ipd.source[0].irq->hwirq < 32 ||
	    ipd.source[1].irq->hwirq >= 1020 ||
	    ipd.source[1].irq->hwirq != ipd.source[0].irq->hwirq + 1U ||
	    ipd.source[0].irq->hwirq / 32 != ipd.source[1].irq->hwirq / 32 ||
	    ipd.source[0].irq->chip != ipd.source[1].irq->chip || ipd.frame[0].irq_off) {
		reject = TRUE;
	}
	if (reject) {
		vmm_cprintf(out, "IRQDBG reject: IRQs must be idle dedicated SPIs, with "
				 "readable state/logical priorities and no registered actions\n");
		return VMM_EBUSY;
	}
	return VMM_OK;
}

static int ipd_exercise(void)
{
	irq_flags_t flags;
	u64 started;
	u32 i;
	u32 stage;
	u32 fired0;
	u32 fired1;
	int rc;

	/* Keep register/configure/unmask/trigger order comparable to case1. */
	for (i = 0; i < IPD_IRQS; i++) {
		stage = IPD_REGISTER_0 + i;
		ipd_phase(stage);
		ipd.source[i].attempted = TRUE;
		rc = vmm_host_irq_register(ipd.source[i].id, i ? "irqdbg_low" : "irqdbg_high",
					   ipd_handler, &ipd.source[i]);
		ipd_snapshot(stage, rc);
		if (rc) {
			return rc;
		}
	}
	for (i = 0; i < IPD_IRQS; i++) {
		stage = IPD_PRIORITY_0 + i;
		ipd_phase(stage);
		ipd.source[i].priority_attempted = TRUE;
		rc = vmm_host_irq_set_priority(ipd.source[i].id, (u8)i);
		ipd_snapshot(stage, rc);
		if (rc) {
			return rc;
		}
		if (ipd.frame[ipd.frames - 1].irq[i].priority_rc ||
		    ipd.frame[ipd.frames - 1].irq[i].priority != (u8)i) {
			return VMM_EFAIL;
		}
	}
	ipd_phase(IPD_ARM);
	ipd_snapshot(IPD_ARM, VMM_OK);
	for (i = 0; i < IPD_IRQS; i++) {
		stage = IPD_UNMASK_0 + i;
		ipd_phase(stage);
		rc = vmm_host_irq_unmask(ipd.source[i].id);
		ipd_snapshot(stage, rc);
		if (rc) {
			return rc;
		}
	}
	ipd_phase(IPD_TRIGGER);
	ipd.triggered = TRUE;
	started = vmm_timer_timestamp();
	rc = vmm_host_irq_trigger_two(ipd.source[0].id);
	ipd_snapshot(IPD_TRIGGER, rc);
	if (rc) {
		return rc;
	}
	ipd_phase(IPD_WAIT);
	do {
		vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
		fired0 = ipd.fired[0];
		fired1 = ipd.fired[1];
		vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
		if (fired0 && fired1) {
			return VMM_OK;
		}
		vmm_udelay(10);
	} while (vmm_timer_timestamp() - started < IPD_NS);
	return VMM_ETIMEDOUT;
}

static int ipd_cleanup(struct vmm_chardev *out)
{
	u32 i;
	u32 state;
	u32 remaining;
	u64 started;
	int result = VMM_OK;
	int rc;
	for (i = 0; i < IPD_IRQS; i++) {
		struct ipd_source *source = &ipd.source[i];
		if (!source->attempted) {
			continue;
		}
		rc = vmm_host_irq_mask(source->id);
		if (rc) {
			result = VMM_EFAIL;
		}
		if (ipd_actions(source, TRUE)) {
			rc = vmm_host_irq_unregister(source->id, source);
			vmm_cprintf(out, "IRQDBG cleanup irq=%u unregister_rc=%d\n", source->id,
				    rc);
		}
		remaining = ipd_actions(source, FALSE);
		started = vmm_timer_timestamp();
		do {
			state = 0;
			rc = vmm_host_irq_get_routed_state(source->id, &state, IPD_HW_STATE);
			if (rc || !(state & VMM_ROUTED_IRQ_STATE_ACTIVE)) {
				break;
			}
			vmm_udelay(10);
		} while (vmm_timer_timestamp() - started < 10000000ULL);
		if (remaining || rc || (state & VMM_ROUTED_IRQ_STATE_ACTIVE)) {
			vmm_cprintf(out,
				    "IRQDBG cleanup incomplete irq=%u actions=%u "
				    "state_rc=%d hw=0x%x; not restored\n",
				    source->id, remaining, rc, state);
			result = VMM_EFAIL;
			continue;
		}
		/* Initial pending/active were zero; clear only our dedicated test pending. */
		if (ipd.triggered) {
			rc = vmm_host_irq_set_routed_state(source->id, 0,
							   VMM_ROUTED_IRQ_STATE_PENDING);
			if (rc) {
				result = VMM_EFAIL;
				continue;
			}
		}
		if (source->priority_attempted &&
		    vmm_host_irq_set_priority(source->id, source->priority)) {
			result = VMM_EFAIL;
			continue;
		}
		vmm_host_irq_set_name(source->irq, source->name);
		rc = source->masked ? vmm_host_irq_mask(source->id)
				    : vmm_host_irq_unmask(source->id);
		if (rc) {
			result = VMM_EFAIL;
		}
		state = 0;
		rc = vmm_host_irq_get_routed_state(source->id, &state, IPD_HW_STATE);
		if (rc || (state & (VMM_ROUTED_IRQ_STATE_ACTIVE | VMM_ROUTED_IRQ_STATE_PENDING)) ||
		    !!(state & VMM_ROUTED_IRQ_STATE_MASKED) != source->masked) {
			vmm_host_irq_mask(source->id);
			result = VMM_EFAIL;
		}
	}
	return result;
}

static void ipd_dump(struct vmm_chardev *out, int rc)
{
	u32 f;
	u32 i;
	u32 cpu;
	irq_flags_t flags;
	struct ipd_trace trace;
	u32 traces;
	u32 dropped;

	for (f = 0; f < ipd.frames; f++) {
		struct ipd_frame *frame = &ipd.frame[f];
		vmm_cprintf(out, "IRQDBG step=%s rc=%d time_ns=%llu cpu=%u irq_off=%u\n",
			    ipd_stage_names[frame->stage], frame->rc, IPD_U(frame->time),
			    frame->cpu, (u32)frame->irq_off);
		for (i = 0; i < IPD_IRQS; i++) {
			struct ipd_frame_irq *sample = &frame->irq[i];
			vmm_cprintf(out,
				    "IRQDBG irq=%u hw_rc=%d hw=0x%x sw_mask=%u "
				    "calls=%u fired=%u\n",
				    ipd.source[i].id, sample->hw_rc, sample->hw,
				    (u32)sample->sw_masked, sample->calls, sample->fired);
			vmm_cprintf(out,
				    "IRQDBG irq=%u prio_rc=%d prio=%u level_rc=%d "
				    "levels=%u pmr_level=%u\n",
				    ipd.source[i].id, sample->priority_rc, sample->priority,
				    sample->level_rc, sample->levels, sample->pmr_level);
			vmm_cprintf(out, "IRQDBG irq=%u cpu_count_delta=", ipd.source[i].id);
			for (cpu = 0; cpu < CONFIG_CPU_COUNT; cpu++) {
				u32 delta = sample->count[cpu] - ipd.frame[0].irq[i].count[cpu];
				if (delta) {
					vmm_cprintf(out, "%u:%u,", cpu, delta);
				}
			}
			vmm_cprintf(out, "\n");
		}
	}
	vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
	traces = ipd.traces;
	dropped = ipd.dropped;
	vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
	for (i = 0; i < traces; i++) {
		vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
		trace = ipd.trace[i];
		vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
		vmm_cprintf(out, "IRQDBG callback=%u irq=%u cpu=%u stage=%s time_ns=%llu\n", i,
			    trace.irq, trace.cpu, ipd_stage_names[trace.stage], IPD_U(trace.time));
	}
	vmm_cprintf(out, "IRQDBG result=%d traces=%u dropped=%u\n", rc, traces, dropped);
}

static int ipd_run_pair(struct vmm_chardev *out, u32 test_hcpu, u32 high_irq, u32 low_irq)
{
	int rc;
	int cleanup_rc;
	u32 cpu0;
	u32 cpu1;
	u32 order0;
	u32 order1;
	u32 early;
	irq_flags_t flags;
	if (!vmm_mutex_trylock(&ipd_run_lock)) {
		return VMM_EBUSY;
	}
	if (ipd_dirty) {
		vmm_cprintf(out,
			    "IRQDBG reject: previous cleanup incomplete; reboot before retry\n");
		vmm_mutex_unlock(&ipd_run_lock);
		return VMM_EBUSY;
	}
	memset(&ipd, 0, sizeof(ipd));
	vmm_cprintf(out, "IRQDBG begin test_hcpu=%u actual_cpu=%u; dedicated SPIs only\n",
		    test_hcpu, vmm_smp_processor_id());
	vmm_cprintf(out, "IRQDBG pair high_irq=%u low_irq=%u; single trigger\n", high_irq, low_irq);
	rc = ipd_prepare(out, high_irq, low_irq);
	if (!rc) {
		ipd_dirty = TRUE;
		rc = ipd_exercise();
		ipd_phase(IPD_FINISH);
		ipd_snapshot(IPD_FINISH, rc);
		ipd_phase(IPD_CLEANUP);
		cleanup_rc = ipd_cleanup(out);
		if (!cleanup_rc) {
			ipd_dirty = FALSE;
		}
		ipd_snapshot(IPD_CLEANUP, cleanup_rc);
		vmm_spin_lock_irqsave_lite(&ipd_trace_lock, flags);
		cpu0 = ipd.first_cpu[0];
		cpu1 = ipd.first_cpu[1];
		order0 = ipd.first_order[0];
		order1 = ipd.first_order[1];
		early = ipd.calls[0] + ipd.calls[1] - ipd.fired[0] - ipd.fired[1];
		if (!rc && (ipd.fired[0] != 1 || ipd.fired[1] != 1 || ipd.mask_rc[0] ||
			    ipd.mask_rc[1] || ipd.dropped)) {
			rc = VMM_EFAIL;
		}
		vmm_spin_unlock_irqrestore_lite(&ipd_trace_lock, flags);
		vmm_cprintf(out,
			    "IRQDBG delivery_rc=%d cpu_high=%u cpu_low=%u "
			    "order_high=%u order_low=%u\n",
			    rc, cpu0, cpu1, order0, order1);
		vmm_cprintf(out, "IRQDBG outside_trigger_wait=%u cleanup_rc=%d\n", early,
			    cleanup_rc);
		if (!rc && (early || cpu0 != cpu1 || order0 != 1 || order1 != 2)) {
			vmm_cprintf(out, "IRQDBG priority evidence invalid: early callback, "
					 "different CPUs, or unexpected order\n");
			rc = VMM_EFAIL;
		}
		if (cleanup_rc) {
			rc = cleanup_rc;
		}
	}
	ipd_dump(out, rc);
	vmm_mutex_unlock(&ipd_run_lock);
	return rc;
}

static int ipd_run(struct wboxtest *test, struct vmm_chardev *out, u32 test_hcpu)
{
	int rc;

	(void)test;
	rc = test_irq_select_spis(out);
	if (rc) {
		return rc;
	}
	return ipd_run_pair(out, test_hcpu, (u32)SPI_ID1, (u32)SPI_ID2);
}

static int ipd_run_spi56(struct wboxtest *test, struct vmm_chardev *out, u32 test_hcpu)
{
	int rc;

	(void)test;
	rc = test_irq_select_spis(out);
	if (rc) {
		return rc;
	}
	return ipd_run_pair(out, test_hcpu, (u32)SPI_ID5, (u32)SPI_ID6);
}

static struct wboxtest ipd_test = {
	.name = "irq_priority_debug",
	.run = ipd_run,
};

static struct wboxtest ipd_test_spi56 = {
	.name = "irq_priority_debug_spi56",
	.run = ipd_run_spi56,
};

static int __init ipd_init(void)
{
	int rc;

	rc = wboxtest_register("interrupt", &ipd_test);
	if (rc) {
		return rc;
	}
	rc = wboxtest_register("interrupt", &ipd_test_spi56);
	if (rc) {
		wboxtest_unregister(&ipd_test);
	}
	return rc;
}

static void __exit ipd_exit(void)
{
	wboxtest_unregister(&ipd_test_spi56);
	wboxtest_unregister(&ipd_test);
}

VMM_DECLARE_MODULE("IRQ priority diagnostic probe", "HOS test maintainers", "GPL",
		   WBOXTEST_IPRIORITY + 1, ipd_init, ipd_exit);
