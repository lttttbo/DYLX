/* Host-only Xvisor API model. Production sources are compiled unchanged. */
#ifndef MONITOR_TEST_HOST_H
#define MONITOR_TEST_HOST_H
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
typedef uint32_t u32;
typedef uint64_t u64;
typedef unsigned int bool;
typedef unsigned int irq_flags_t;
#define TRUE 1
#define FALSE 0
#define __weak __attribute__((weak))
#define __init
#define __exit
#define arch_wmb() do { } while (0)
typedef struct { long value; } atomic_t;
typedef struct { u64 value; } atomic64_t;
static inline u64 arch_atomic64_read(atomic64_t *a) { return a->value; }
static inline void arch_atomic64_inc(atomic64_t *a) { a->value++; }
static inline long arch_atomic_read(atomic_t *a) { return a->value; }
static inline void arch_atomic_write(atomic_t *a, long n) { a->value = n; }
static inline void arch_atomic_inc(atomic_t *a) { a->value++; }
typedef struct { int held; } vmm_spinlock_t;
#define DEFINE_SPINLOCK(n) vmm_spinlock_t n = { 0 }
#define INIT_SPIN_LOCK(p) ((p)->held = 0)
#define vmm_spin_lock_irqsave_lite(p,f) do { (f)=0; assert(!(p)->held); (p)->held=1; } while (0)
#define vmm_spin_unlock_irqrestore_lite(p,f) do { (void)(f); assert((p)->held); (p)->held=0; } while (0)
extern int fail_next_trylock;
static inline int host_trylock(vmm_spinlock_t *p) {
    if(fail_next_trylock) { fail_next_trylock=0; return 0; }
    if(p->held) return 0;
    p->held=1; return 1;
}
#define vmm_spin_trylock_irqsave(p,f) ((f)=0,host_trylock(p))
#define vmm_spin_unlock_irqrestore(p,f) vmm_spin_unlock_irqrestore_lite(p,f)
struct vmm_mutex { int held; };
#define INIT_MUTEX(p) ((p)->held=0)
static inline void vmm_mutex_lock(struct vmm_mutex *m) { assert(!m->held); m->held=1; }
static inline void vmm_mutex_unlock(struct vmm_mutex *m) { assert(m->held); m->held=0; }
struct vmm_guest { u32 id; };
struct vmm_vcpu { u32 id, hcpu; bool is_normal; struct vmm_guest *guest; };
#define VMM_VCPU_STATE_UNKNOWN 0
#define VMM_VCPU_STATE_RESET 1
#define VMM_VCPU_STATE_READY 2
#define VMM_VCPU_STATE_RUNNING 4
#define VMM_VCPU_STATE_PAUSED 8
#define VMM_VCPU_STATE_HALTED 16
extern u64 fake_time;
extern u32 fake_cpu;
static inline u64 vmm_timer_timestamp(void) { return fake_time; }
static inline u32 vmm_smp_processor_id(void) { return fake_cpu; }
static inline u64 udiv64(u64 a, u64 b) { assert(b); return a/b; }
#define vmm_snprintf snprintf
int vmm_printf(const char *, ...);
struct vmm_chardev { int unused; };
int vmm_cprintf(struct vmm_chardev *, const char *, ...);
struct vmm_cmd {
    const char *name, *desc;
    void (*usage)(struct vmm_chardev *);
    int (*exec)(struct vmm_chardev *, int, char **);
};
int vmm_cmdmgr_register_cmd(struct vmm_cmd *);
int vmm_cmdmgr_unregister_cmd(struct vmm_cmd *);
int vmm_cmdmgr_execute_cmd(struct vmm_chardev *, int, char **);
#define VMM_EXPORT_SYMBOL(x)
#define VMM_DECLARE_MODULE(a,b,c,d,init,exit) int host_command_init(void) { (void)exit; return init(); }
#endif
