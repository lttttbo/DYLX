# Monitor v4：style 版超时诊断补充

本包基于 `monitor_style_v4_20261105`，补充 `monitor_storm_runtime` 的阶段超时诊断，
并把这一个测试源文件整理为零 goto、if/else/循环体带大括号、结构成员和变量声明分行的格式。

这是定位偶现问题的诊断版；没有宣称修复 quiet 超时，没有放宽通过条件、延长超时，
也没有把失败改为跳过或通过。实际根因仍要根据下一次 HOS 现场日志判断。

## 交付文件与合入

相对于 style 版，固件源码只修改：

```text
libs/wboxtest/monitor/storm_runtime.c
```

- `changes.patch`：从 style 版现有测试文件合入的增量补丁。
- `full_files/libs/wboxtest/monitor/storm_runtime.c`：完整修改文件。
- `full_files/core/monitor/monitor_agent.c`、`core/include/vmm_monitor.h`、
  `commands/cmd_monitor.c`：包内保留 style 版的三个完整生产文件，内容与原 style 包逐字节相同。
  已合入 style 的项目不需要重复覆盖它们；不要覆盖私有项目修改。
- `merge_locations.txt`：原文件和新文件的函数、结构体位置；私有工程用名称锚点定位。
- `file_manifest.json`：合入前后 SHA256。
- `optional_from_diagnostics.patch`：仅供已经合入 10 月 30 日旧诊断文件的项目使用。
  它与 changes.patch 是两条替代路径，不能叠加。
- `optional_verification/`：开发机模型脚本，与板端固件无关，不要求合入。
- `validation/`：参考编译结果和模型诊断示例；示例不是实际板卡故障日志。

基线测试文件已有 `SR_LOW=1U` 和事件变量初始化。原有 runtime_storm、sampling_fix 支持
必须存在；本包复用 style 版中已有的只读测试接口。没有新增头文件、源文件、目录层级或
Kconfig 选项。测试仍注册在 monitor 组，名称仍为 monitor_storm_runtime。

如果项目文件与基线一致，可在 HOS 源码根目录执行：

```text
git apply --check changes.patch
git apply changes.patch
```

完整文件与补丁选择一种。已自行改过测试代码的项目，请按函数位置手工合入。
如果使用旧诊断文件，改用 `optional_from_diagnostics.patch` 并先做 apply --check。

## 本次增加的现场信息

每个阶段的开始提示显示当阶段实际阈值，避免将总体提示中的 limit=1 误当作 quiet 的阈值：

```text
monitor_storm_runtime phase=quiet limit=1000000000/s
```

只在阶段达到 20 秒超时后，先打印完整 `monitor_storm_diag` 块，再打印 FAIL，并进入原来的
配置恢复流程。正常轮询不逐次打印，也不修改生产 monitor 的 JSON 或日志接口。
这避免通过频繁串口输出明显扰动待观察过程；诊断本身仍有少量观测开销，不能宣称零影响。

记录以下信息：

| 字段 | 含义 |
|---|---|
| phase / guest / vcpu / epoch | 超时阶段及目标身份 |
| start_ns / end_ns | 阶段开始和超时诊断采集时刻，单位 ns |
| expected_seq / actual_seq | 预期配置版本及诊断时读取的版本 |
| limit / sustain_s | 当阶段阈值和持续时间要求 |
| window_min_ms / window_max_ms | 有效窗口范围，测试不修改 |
| polls | 本阶段轮询次数 |
| frame_retries | slot→事件环→slot 读取不能确认一致快照的重试次数 |
| same_sample | 一致读取成功，但目标采样时间戳与上次相同的次数 |
| new_samples | 观察到不同采样时间戳的次数，包括旧配置和无效窗口 |
| consecutive_low / max_low | 当前连续有效未超限窗口数，以及阶段内达到过的最大值 |
| consecutive_high / high_ns | 当前连续有效超限窗口数及累计时长 |
| low_total / high_total | 本阶段被接受用于判定的未超限/超限窗口总数 |
| sampler_passes | 阶段前后全局采样遍历完成计数 |
| target_passes | 阶段前后目标槽取得锁并执行 memory_flush 后的计数 |
| global_skipped | 全局槽锁获取失败计数，不是目标 vCPU 的专属统计 |
| errors / lost | 生产监控器执行错误与事件丢失计数的前后值 |
| last_observed_age_ns | 诊断时刻距最后已观察窗口时间戳的时长；不是现场重新读取的最新槽 |
| future_stamp | 最后观察的窗口时间戳是否晚于诊断时刻；此时 age=0 不代表新鲜 |

`target_passes` 不等于有效窗口数，配置切换和无效窗口也可能使它增加。
全局状态、全局遍历计数、目标计数分别读取，不是同一个原子快照，不要根据相差 1 判断故障。

`rejected` 分类按同一窗口的第一个不满足条件的原因计数：

| 分类 | 原因 |
|---|---|
| config | 窗口属于旧配置版本 |
| invalid | 生产 monitor 的 valid=0，可能是配置基线重建或窗口时长不合格 |
| empty | valid=1，但 interval=0 |
| clock | sample_ns 小于 interval，无法计算窗口起点 |
| before_phase | 窗口起点早于本阶段开始，不能作为本阶段完整证据 |
| overflow | exits×10^9 存在 64 位溢出风险，原判据拒绝此样本 |

超时块还包含最近 8 个不同时间戳的一致窗口，每个窗口分三行：

```text
monitor_storm_diag win=3 result=invalid valid=0 active=0 config_seq=4
monitor_storm_diag win=3 read_ns=107000000000 sample_ns=107000000000
monitor_storm_diag win=3 interval_ns=2000000000 exits=4840
```

以上是开发机模型示例。result=low/high 表示窗口通过有效性检查后未超限/超限，其他值对应
上表。exits 是该窗口的计数，不是每秒速率。窗口序号是阶段内累计序号，保留最近 8 个时
起始序号可以大于 1。空窗口历史时不会伪造一个 last_observed_age_ns。

本次详细块针对阶段超时。选择目标失败、事件字段错误、外部配置改变等提前失败仍输出
原来的具体 FAIL 原因，不承诺每种提前失败都输出超时历史。

## 如何利用诊断定位

1. sampler_passes 增长，target_passes 长期不动：目标槽没有成功走到计数打点，
   结合全局 skipped 和生产代码检查目标锁竞争。不能仅凭全局 skipped 就证明目标被跳过。
2. 两种计数都不动：重点检查采样定时器/执行路径是否推进，以及是否读取了预期实例。
3. target_passes 增长，invalid 多，interval 经常为 2 秒或更大：目标有更新，但窗口
   超过默认 1250 ms 上限，需要排查采样跳过或延迟。
4. frame_retries 很多：读取快照一致性检查反复重试，需检查读取期间的更新情况。
5. max_low=1，随后出现 invalid/config 等：曾取得一个有效未超限窗口，但连续性被打断。

quiet 的成功条件是连续两个完整、有效、未超限窗口。这个阶段 exits=0 也可以通过；
consecutive_high=0/high_ns=0 本身正常。不能使用旧版的两个高窗口字段推断 quiet 的根因。
这些都是排查方向；不根据单一计数直接断言最终根因。

## 风格整理和函数分工

- `sr_candidate`、`sr_context`：原结构按字段分行，保留类型与字段顺序。
- `sr_observation_record`：保存一条窗口观察。
- `sr_diagnostics`：固定 8 条历史及阶段统计，运行时在测试线程栈上。
- `sr_phase_state`：集中本阶段的 previous、连续窗口数、累计时间和诊断数据。
- `sr_reject_reason`：按原先判定顺序解释窗口被拒绝的原因，不参与改变判据。
- `sr_note`：保存不同时间戳的一致窗口、更新分类计数，不打印、不分配内存。
- `sr_diagnostic_dump`：超时后输出诊断；先读取计数再打印，不持有生产 slot/event 锁打印。
- `sr_poll`：单次观察与判定。返回 EAGAIN 表示等待，OK 表示阶段通过，其他错误结束阶段。
- `sr_phase`：管理开始时刻、20 ms 轮询等待、20 秒期限和超时输出，替代原 goto wait。
- `sr_execute`：执行原有 select/quiet/trigger/dedup/recover/retrigger 顺序，提前返回错误。
- `sr_run`：拥有测试互斥锁，调用执行函数后统一尝试恢复配置并解锁，替代原 goto done。
- 用显式结构体初始化、init/exit 函数替代原单行注册宏，测试名称、组和优先级不变。

生产采样周期、窗口上下限、选择目标规则、严格超限比较、5 秒持续时间、事件字段校验、
去重、恢复、外部配置保护和历史保留行为保持原样。测试不调用 record/sample/drain 注入证据，
不创建 Guest，不改变 Guest 调度，阈值仍通过原生产 configure 接口临时修改。

## 内存与构建影响

参考 ARM64、MAX_VCPU_COUNT=64、Zig/Clang -Os：

| storm_runtime.o 项目 | style 原测试 | 本次诊断整理后 |
|---|---:|---:|
| 可写静态 RAM（含原模块描述数据） | 2032 B | 2032 B |
| 加载段（代码、常量等对象估算） | 6105 B | 8406 B |

加载段增加 2301 B；相对旧诊断文件仅增加 4 B。三个生产文件未变。
这部分测试代码编译进镜像就会增加镜像占用，可能影响你已经收紧的 VAPOOL 预算；
不能把“静态 RAM 不增”理解成“镜像和虚拟地址预算完全不增”。最终以 HOS 的 ELF/map 为准。

参考结构大小：单条观察 48 B，sr_diagnostics 520 B，包含它的 sr_phase_state 552 B，
两者是包含关系，不应重复相加。这些局部对象在运行测试时使用已有测试线程栈。
没有新增动态分配、线程或固定线程栈容量。ARM64 编译通过单函数 2048 B 栈帧告警门限，
该门限检查不等于完整调用链和中断叠加后的栈峰值证明。

## 复现命令和需要保留的输出

保持现有 Guest 和之前的业务负载，窗口仍使用原来的 750/1250 ms。先记录现有配置，再执行：

```text
monitor config
monitor start
unittest run_tests 10 monitor_storm_runtime
monitor config
```

需要增加复现机会时可将 10 改为 50。上游命令名是 wboxtest，项目使用 unittest。
测试期间不手动修改 monitor 配置或启停；测试会临时改变全局风暴阈值，所以其他 Guest
vCPU 也可能出现告警。失败后保留 target 行、阶段提示、完整 monitor_storm_diag 块、
FAIL 和 restored 行，不需要在失败后抢着手工读取 status 代替失败瞬间的证据。

若打印 restore skipped/restore failed，要根据提示检查 monitor config；外部配置改变时
测试不会覆盖别人的新配置。正常完成时会恢复原来的阈值和持续时间，事件历史不清空。

## 已完成验证与范围

- 新测试文件零 goto，if/else/for 均有大括号，结构字段独立声明，展开 tab 后行长不超过 100。
- 以 style 版实际头文件进行 ARM64 -Os/-O2、内部/外部执行配置严格编译；连同两个参考版本
  共 12 个编译单元通过。启用 -Wall -Wextra -Werror 和 2048 B 栈帧告警。
- 在同一 style 生产实现上，对旧诊断版和本版分别执行 34 组开发机模型场景，
  每组返回结果、事件、诊断计数、时间戳和输出逐字一致。
- 场景包含三类 quiet 超时、单次跳过后恢复、quiet 无 exit，以及七类故意破坏生产实现的检查。
  故意构造的故障仍被判失败，不以“测试报告通过”掩盖被测场景本应出现的失败。
- 验证成功运行不输出超时块、超时块在恢复配置之前打印、最多保留 8 条历史，
  本次模型诊断行长度小于 128 字符；这不是对所有极端数值行长的上界证明。
- 三份补丁均已正向应用、结果比对、反向还原验证；交付附带 SHA256。

没有执行产品 GCC 12.3 完整 HOS 链接或实际板卡/QEMU 测试。诊断版是否捕获你环境中的
偶现原因，仍需下一次现场复现确认。
