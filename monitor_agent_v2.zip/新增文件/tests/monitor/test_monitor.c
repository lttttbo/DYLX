#include "host.h"
#include <vmm_monitor.h>
#include <vmm_monitor_guest.h>
#include <vmm_monitor_diag.h>

u64 fake_time = 10 * VMM_MONITOR_NS;
u32 fake_cpu;
int fail_next_trylock;
int fake_irq_context;
static struct vmm_cmd *command;
static unsigned log_count;
static char output[32768];
static size_t output_len;
static struct vmm_guest guests[2] = {{0}, {1}};
static struct vmm_vcpu vcpus[4] = {
    {0,0,TRUE,&guests[0]}, {1,1,TRUE,&guests[1]},
    {2,2,TRUE,&guests[1]}, {3,3,TRUE,&guests[1]}
};
struct vmm_guest *vmm_manager_guest(u32 id) { return id < 2 ? &guests[id] : NULL; }
struct vmm_guest *vmm_manager_guest_find(const char *name) { (void)name; return &guests[0]; }
void vmm_msleep(unsigned long ms) { assert(!fake_irq_context); fake_time += (u64)ms * 1000000; }

int vmm_printf(const char *fmt, ...)
{
    assert(!fake_irq_context);
    int n; va_list args; va_start(args,fmt);
    n = vsnprintf(output+output_len,sizeof(output)-output_len,fmt,args);
    va_end(args); assert(n>=0 && output_len+n<sizeof(output));
    output_len+=n; log_count++; return n;
}
int vmm_cprintf(struct vmm_chardev *c, const char *fmt, ...)
{
    assert(!fake_irq_context);
    int n; va_list args; (void)c; va_start(args,fmt);
    n = vsnprintf(output+output_len,sizeof(output)-output_len,fmt,args);
    va_end(args); assert(n>=0 && output_len+n<sizeof(output));
    output_len+=n; return n;
}
int vmm_cmdmgr_register_cmd(struct vmm_cmd *c) { command=c; return 0; }
int vmm_cmdmgr_unregister_cmd(struct vmm_cmd *c) { (void)c; return 0; }
int vmm_cmdmgr_execute_cmd(struct vmm_chardev *c, int n, char **args)
{
    (void)c; assert(n==3 && !strcmp(args[0],"guest"));
    assert(!strcmp(args[1],"region_list")); return 0;
}
int host_command_init(void);

static void reset_run(void)
{
    assert(vmm_monitor_enable(FALSE)==0);
    fake_time+=VMM_MONITOR_NS;
    assert(vmm_monitor_enable(TRUE)==0);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
}
static void tick(void) { fake_time+=VMM_MONITOR_NS; vmm_monitor_sample(fake_time); }

static void test_math(void)
{
    struct vmm_monitor_hist h={0};
    struct vmm_monitor_latency s;
    struct vmm_monitor_streak storm={0};
    int i;
    vmm_monitor_hist_read(&h,&s); assert(!s.count && !s.p99_upper_ns);
    for(i=0;i<99;i++) vmm_monitor_hist_add(&h,1000);
    vmm_monitor_hist_add(&h,2000000000ULL);
    vmm_monitor_hist_read(&h,&s); assert(s.count==100 && s.p99_upper_ns==1000);
    vmm_monitor_hist_add(&h,2000000000ULL);
    vmm_monitor_hist_read(&h,&s); assert(s.p99_upper_ns==2000000000ULL);
    for(i=0;i<4;i++) assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE)==1);
    assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50000,VMM_MONITOR_NS,50000,5,TRUE)==-1);
    for(i=0;i<4;i++) assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(!vmm_monitor_storm_step(&storm,900000,3*VMM_MONITOR_NS,50000,5,TRUE));
    assert(storm.elapsed==0 && storm.windows==0);
    for(i=0;i<6;i++) assert(!vmm_monitor_storm_step(&storm,50001,800000000,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50001,800000000,50000,5,TRUE)==1);
    assert(vmm_monitor_range_valid(100,100,0));
    assert(!vmm_monitor_range_valid(100,101,0));
    assert(!vmm_monitor_range_valid(100,99,2));
    assert(!vmm_monitor_range_valid(~0ULL,~0ULL-3,8));
}

static void test_scheduler(void)
{
    struct vmm_monitor_snapshot s;
    u32 old_generation;
    reset_run();
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=2000;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=2000;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RUNNING,fake_time);
    tick(); assert(!vmm_monitor_snapshot(0,&s));
    assert(s.ready.count==1 && s.ready.max_ns==4000 && !s.valid);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && s.valid && s.ready.count==0);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=1234; assert(!vmm_monitor_snapshot(0,&s) && s.ready_age_ns==1234);
    old_generation=s.generation;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
    assert(!vmm_monitor_snapshot(0,&s) && s.generation!=old_generation && !s.ready_age_ns);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_UNKNOWN,fake_time);
    assert(vmm_monitor_snapshot(0,&s)==VMM_ENOTAVAIL);
    assert(!vmm_monitor_enable(FALSE));
    vmm_monitor_exit(&vcpus[0],1);
    assert(vmm_monitor_snapshot(0,&s)==VMM_ENOTAVAIL);
}

static void test_storm(void)
{
    struct vmm_monitor_status before, after;
    struct vmm_monitor_event e;
    int n,j;
    reset_run(); tick(); vmm_monitor_status(&before);
    for(n=0;n<5;n++) {
        for(j=0;j<50001;j++) vmm_monitor_exit(&vcpus[0],0x16);
        tick();
    }
    vmm_monitor_status(&after); assert(after.events==before.events+1);
    assert(!vmm_monitor_event_get(after.events,&e));
    assert(e.type==VMM_MONITOR_EXIT_STORM && e.value==50001 && e.code==0x16);
    tick(); assert(!vmm_monitor_event_get(after.events+1,&e));
    assert(e.type==VMM_MONITOR_EXIT_RECOVER);
    vmm_monitor_status(&before);
    fail_next_trylock=1; tick();
    vmm_monitor_status(&after); assert(after.busy_snapshots==before.busy_snapshots+1);
}

static void test_irq(void)
{
    struct vmm_monitor_hirq_context old,nested;
    struct vmm_monitor_snapshot s;
    struct vmm_monitor_status status;
    u64 drops;
    unsigned i;
    reset_run();
    old=vmm_monitor_hirq_enter(55);
    nested=vmm_monitor_hirq_enter(77);
    vmm_monitor_hirq_exit(nested);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    fake_time+=200;
    vmm_monitor_irq_pending(&vcpus[0],40,55); /* Coalescing preserves first. */
    fake_time+=100;
    vmm_monitor_irq_injected(&vcpus[0],40);
    vmm_monitor_irq_injected(&vcpus[0],40); /* Must not double-count. */
    vmm_monitor_hirq_exit(old);
    tick(); assert(!vmm_monitor_snapshot(0,&s));
    assert(s.irq.count==1 && s.irq.max_ns==300);
    vmm_monitor_status(&status); drops=status.irq_untracked;
    vmm_monitor_irq_pending(&vcpus[0],41,55); /* No matching host context. */
    old=vmm_monitor_hirq_enter(55);
    for(i=0;i<CONFIG_MONITOR_IRQ_SLOTS+1;i++) vmm_monitor_irq_pending(&vcpus[0],100+i,55);
    vmm_monitor_hirq_exit(old);
    vmm_monitor_status(&status); assert(status.irq_untracked==drops+2);
    reset_run();
    vmm_monitor_irq_injected(&vcpus[0],100);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
    old=vmm_monitor_hirq_enter(55);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    vmm_monitor_hirq_exit(old);
    fake_time+=100;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
    vmm_monitor_irq_injected(&vcpus[0],40);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
    old=vmm_monitor_hirq_enter(55);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    vmm_monitor_hirq_exit(old);
    vmm_monitor_irq_cancel(&vcpus[0],40);
    vmm_monitor_irq_injected(&vcpus[0],40);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
}

static void test_events(void)
{
    struct vmm_monitor_status st;
    struct vmm_monitor_snapshot s;
    struct vmm_monitor_event e;
    u64 before;
    unsigned i,j;
    reset_run();
    vmm_monitor_mem_fault(NULL,VMM_MONITOR_SHMEM_BOUNDS,~0ULL-4,8);
    tick(); assert(!vmm_monitor_snapshot(CONFIG_MAX_VCPU_COUNT,&s));
    assert(s.guest_id==VMM_MONITOR_UNKNOWN && s.faults==1);
    for(i=0;i<12;i++) {
        for(j=0;j<4;j++) vmm_monitor_mem_fault(&vcpus[j],VMM_MONITOR_ACCESS_DENIED,j,0xf);
        fake_time+=10*VMM_MONITOR_NS;
        vmm_monitor_sample(fake_time);
    }
    vmm_monitor_status(&st); assert(st.events>VMM_MONITOR_EVENTS && st.overwritten);
    assert(vmm_monitor_event_get(st.events-VMM_MONITOR_EVENTS,&e)==VMM_ENOTAVAIL);
    assert(!vmm_monitor_event_get(st.events,&e));
    st.config.publish=TRUE; assert(!vmm_monitor_configure(&st.config));
    before=st.publish_errors;
    output_len=0; log_count=0;
    vmm_monitor_drain();
    vmm_monitor_status(&st);
    assert(log_count==VMM_MONITOR_BATCH && st.publish_errors==before+VMM_MONITOR_BATCH);
    fputs(output,stdout); /* Python validates every emitted JSON record. */
    output_len=0;
}

static void test_starvation(void)
{
    struct vmm_monitor_status st;
    struct vmm_monitor_event e;
    u64 before;
    reset_run(); vmm_monitor_status(&st);
    st.config.ready_limit_ns=1000;
    assert(!vmm_monitor_configure(&st.config));
    before=st.events;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    tick(); vmm_monitor_status(&st);
    assert(st.events==before+1);
    assert(!vmm_monitor_event_get(st.events,&e));
    assert(e.type==VMM_MONITOR_READY_SLOW && e.code==1 && e.value==VMM_MONITOR_NS);
    st.config.ready_limit_ns=0;
    assert(!vmm_monitor_configure(&st.config));
}

static void test_commands(void)
{
    char *short_args[]={"monitor"};
    char *bad[]={"monitor","config","exit_rate","18446744073709551616"};
    char *status[]={"monitor","status"};
    char *collect[]={"monitor","collect"};
    char *mem[]={"monitor","mem","Linux"};
    assert(!host_command_init());
    assert(command->exec(NULL,1,short_args)==VMM_EINVALID);
    assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="0"; assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="-1"; assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="50000"; assert(!command->exec(NULL,4,bad));
    assert(!command->exec(NULL,3,mem));
    output_len=0;
    assert(!command->exec(NULL,2,status));
    assert(!command->exec(NULL,2,collect));
    fputs(output,stdout);
}

static void test_revision_two(void)
{
    struct vmm_monitor_snapshot snap;
    struct vmm_monitor_guest guest;
    struct vmm_monitor_status st;
    struct vmm_monitor_event event;
    struct vmm_monitor_diag_record diag;
    u64 start, before;
    unsigned i;
    reset_run();
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=5000;
    vmm_monitor_selected(&vcpus[0],fake_time-700);
    vmm_monitor_dispatch(&vcpus[0],fake_time-800,fake_time);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RUNNING,fake_time);
    tick(); assert(!vmm_monitor_snapshot(0,&snap));
    assert(snap.ready.count==1 && snap.ready.max_ns==4300);
    assert(snap.dispatch.count==1 && snap.dispatch.max_ns==800);

    /* LPI-sized ID and same-Guest MOVI preserve the source timestamp. */
    start=fake_time;
    vmm_monitor_irq_pending_at(&vcpus[1],8192,start);
    fake_time+=100;
    vmm_monitor_irq_move(&vcpus[1],&vcpus[2],8192);
    fake_time+=300;
    vmm_monitor_irq_injected(&vcpus[1],8192);
    vmm_monitor_irq_injected(&vcpus[2],8192);
    tick(); assert(!vmm_monitor_snapshot(2,&snap));
    assert(snap.irq.count==1 && snap.irq.max_ns==400);

    assert(vmm_monitor_guest_report(&vcpus[0],1,1,10001,1000,300,100,3)==VMM_EINVALID);
    assert(vmm_monitor_guest_report(&vcpus[0],1,1,9500,1000,1001,100,3)==VMM_EINVALID);
    assert(!vmm_monitor_guest_report(&vcpus[0],1,1,9500,1000,300,100,3));
    assert(vmm_monitor_guest_report(&vcpus[0],1,1,1,1000,300,100,3)==VMM_EINVALID);
    assert(!vmm_monitor_guest_get(0,&guest) && guest.cpu_bp==9500 && guest.total_bytes==1000);
    assert(vmm_monitor_guest_get(1,&guest)==VMM_ENOTAVAIL);
    vmm_monitor_status(&st); before=st.events;
    st.config.guest_cpu_limit_bp=9000;
    assert(!vmm_monitor_configure(&st.config)); tick();
    vmm_monitor_status(&st); assert(st.events==before+1);
    assert(!vmm_monitor_event_get(st.events,&event));
    assert(event.type==VMM_MONITOR_GUEST_CPU_HIGH && event.guest_id==0 && event.value==9500);
    tick(); vmm_monitor_status(&st); assert(st.events==before+1);
    assert(!vmm_monitor_guest_report(&vcpus[0],2,1,4000,1000,700,200,3));
    assert(!vmm_monitor_guest_get(0,&guest) && guest.session==2 && guest.sequence==1);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
    assert(vmm_monitor_guest_get(0,&guest)==VMM_ENOTAVAIL);
    assert(!vmm_monitor_enable(FALSE));
    assert(vmm_monitor_guest_report(&vcpus[0],2,2,1000,1000,700,200,3)==VMM_ENOTAVAIL);

    /* On-demand diagnostics work even when periodic monitoring is stopped. */
    assert(!vmm_monitor_diag_begin());
    assert(vmm_monitor_diag_start(0)==VMM_EINVALID);
    assert(!vmm_monitor_diag_start(100));
    assert(vmm_monitor_diag_start(100)==VMM_EBUSY);
    start=vmm_monitor_diag_begin(); fake_time+=1234;
    vmm_monitor_diag_end(&vcpus[0],0x1234,0x16ULL<<26,start,0);
    start=vmm_monitor_diag_begin(); fake_time+=2000;
    vmm_monitor_diag_end(&vcpus[0],0x1234,0x16ULL<<26,start,-1);
    assert(!vmm_monitor_diag_get(0,&diag));
    assert(diag.count==2 && diag.sum_ns==3234 && diag.max_ns==2000 && diag.errors==1);
    for(i=1;i<VMM_MONITOR_DIAG_SLOTS+2;i++) {
        start=vmm_monitor_diag_begin(); fake_time+=10;
        vmm_monitor_diag_end(&vcpus[0],0x2000+i*4,1ULL<<26,start,0);
    }
    assert(vmm_monitor_diag_overflow()==2);
    fake_time+=VMM_MONITOR_NS;
    start=vmm_monitor_diag_begin(); fake_time+=10;
    vmm_monitor_diag_end(&vcpus[0],0x1234,0x16ULL<<26,start,0);
    assert(!vmm_monitor_diag_get(0,&diag) && diag.count==2);
    vmm_monitor_diag_stop(); assert(!vmm_monitor_diag_begin());
    assert(!vmm_monitor_diag_start(1));
    vmm_monitor_diag_end(&vcpus[0],0x1234,0,start,0); /* prior window rejected */
    assert(vmm_monitor_diag_get(0,&diag)==VMM_ENOTAVAIL);
    vmm_monitor_diag_stop();
}

#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static struct vmm_workqueue queue;
static struct vmm_work *queued;
static struct vmm_timer_event *timer;
static int destroyed, start_error, ipi_timeout;
static void (*delayed_ipi)(void *,void *,void *);
struct vmm_workqueue *vmm_workqueue_create(const char *name,u32 priority) { (void)name; assert(priority==3); return &queue; }
struct vmm_thread *vmm_workqueue_get_thread(struct vmm_workqueue *q) { return &q->thread; }
int vmm_threads_set_affinity(struct vmm_thread *t,const void *mask) { (void)t; (void)mask; return 0; }
int vmm_workqueue_destroy(struct vmm_workqueue *q) { (void)q; destroyed++; return 0; }
int vmm_workqueue_schedule_work(struct vmm_workqueue *q,struct vmm_work *w) { assert(!destroyed && q==&queue); queued=w; return 0; }
int vmm_timer_event_start(struct vmm_timer_event *e,u64 duration) { timer=e; if(start_error) return start_error; e->active=1; e->expiry=fake_time+duration; return 0; }
int vmm_smp_ipi_sync_call(const void *mask,u32 timeout,void (*fn)(void *,void *,void *),void *a,void *b,void *c)
{ (void)mask; (void)timeout; if(ipi_timeout) {delayed_ipi=fn; return ipi_timeout==1?VMM_ETIMEDOUT:0;} fn(a,b,c); return 0; }
void vmm_udelay(unsigned long us) { fake_time+=(u64)us*1000; if(delayed_ipi) {void (*fn)(void *,void *,void *)=delayed_ipi; delayed_ipi=NULL; fn(NULL,NULL,NULL);} }
static void test_timer(void)
{
    struct vmm_monitor_status before,after;
    assert(timer && timer->active);
    vmm_monitor_enable(TRUE); vmm_monitor_status(&before);
    fake_time=timer->expiry;
    fake_irq_context=1; timer->handler(timer); fake_irq_context=0;
    vmm_monitor_status(&after); assert(after.samples==before.samples+1);
    assert(queued && timer->expiry>fake_time);
    queued->func(queued); queued=NULL;
    vmm_monitor_enable(FALSE); vmm_monitor_status(&before);
    fake_time=timer->expiry;
    fake_irq_context=1; timer->handler(timer); fake_irq_context=0;
    vmm_monitor_status(&after); assert(after.samples==before.samples);
    if(queued) queued->func(queued);
}
#endif

int main(int argc,char **argv)
{
    test_math();
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
    if(argc>1) {
        if(!strcmp(argv[1],"ipi-early")) { ipi_timeout=2; goto normal_init; }
        if(!strcmp(argv[1],"timer-fail")) start_error=VMM_EFAIL;
        else ipi_timeout=1;
        assert(vmm_monitor_init()!=0 && destroyed==1);
        if(delayed_ipi) delayed_ipi(NULL,NULL,NULL);
        if(timer) {fake_irq_context=1; timer->handler(timer); fake_irq_context=0;}
        puts("PASS: initialization failure and delayed callback cannot use destroyed queue"); return 0;
    }
normal_init:
#else
    (void)argc; (void)argv;
#endif
    assert(!vmm_monitor_init());
    assert(!vmm_monitor_enabled());
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
    test_timer();
#endif
    test_scheduler(); test_storm(); test_irq(); test_starvation(); test_events(); test_commands();
    test_revision_two();
    puts("PASS: arithmetic, lifecycle, IRQ/LPI/MOVI, distinct dispatch/ready, Guest telemetry, diagnostics, commands");
    return 0;
}
