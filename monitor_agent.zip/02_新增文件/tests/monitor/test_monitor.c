#include "host.h"
#include <vmm_monitor.h>

u64 fake_time = 10 * VMM_MONITOR_NS;
u32 fake_cpu;
int fail_next_trylock;
static struct vmm_cmd *command;
static unsigned log_count;
static char output[32768];
static size_t output_len;
static struct vmm_guest guests[2] = {{0}, {1}};
static struct vmm_vcpu vcpus[4] = {
    {0,0,TRUE,&guests[0]}, {1,1,TRUE,&guests[1]},
    {2,2,TRUE,&guests[1]}, {3,3,TRUE,&guests[1]}
};

int vmm_printf(const char *fmt, ...)
{
    int n; va_list args; va_start(args,fmt);
    n = vsnprintf(output+output_len,sizeof(output)-output_len,fmt,args);
    va_end(args); assert(n>=0 && output_len+n<sizeof(output));
    output_len+=n; log_count++; return n;
}
int vmm_cprintf(struct vmm_chardev *c, const char *fmt, ...)
{
    int n; va_list args; (void)c; va_start(args,fmt);
    n = vsnprintf(output+output_len,sizeof(output)-output_len,fmt,args);
    va_end(args); assert(n>=0 && output_len+n<sizeof(output));
    output_len+=n; return n;
}
int vmm_cmdmgr_register_cmd(struct vmm_cmd *c) { command=c; return 0; }
int vmm_cmdmgr_unregister_cmd(struct vmm_cmd *c) { (void)c; return 0; }
int vmm_cmdmgr_execute_cmd(struct vmm_chardev *c, int n, char **args)
{
    (void)c; assert(n==3 && !strcmp(args[0],"guest"));
    assert(!strcmp(args[1],"region_list")); return 0;
}
int host_command_init(void);

static void reset_run(void)
{
    assert(vmm_monitor_enable(FALSE)==0);
    fake_time+=VMM_MONITOR_NS;
    assert(vmm_monitor_enable(TRUE)==0);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
}
static void tick(void) { fake_time+=VMM_MONITOR_NS; vmm_monitor_sample(fake_time); }

static void test_math(void)
{
    struct vmm_monitor_hist h={0};
    struct vmm_monitor_latency s;
    struct vmm_monitor_streak storm={0};
    int i;
    vmm_monitor_hist_read(&h,&s); assert(!s.count && !s.p99_upper_ns);
    for(i=0;i<99;i++) vmm_monitor_hist_add(&h,1000);
    vmm_monitor_hist_add(&h,2000000000ULL);
    vmm_monitor_hist_read(&h,&s); assert(s.count==100 && s.p99_upper_ns==1000);
    vmm_monitor_hist_add(&h,2000000000ULL);
    vmm_monitor_hist_read(&h,&s); assert(s.p99_upper_ns==2000000000ULL);
    for(i=0;i<4;i++) assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE)==1);
    assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50000,VMM_MONITOR_NS,50000,5,TRUE)==-1);
    for(i=0;i<4;i++) assert(!vmm_monitor_storm_step(&storm,50001,VMM_MONITOR_NS,50000,5,TRUE));
    assert(!vmm_monitor_storm_step(&storm,900000,3*VMM_MONITOR_NS,50000,5,TRUE));
    assert(storm.elapsed==0 && storm.windows==0);
    for(i=0;i<6;i++) assert(!vmm_monitor_storm_step(&storm,50001,800000000,50000,5,TRUE));
    assert(vmm_monitor_storm_step(&storm,50001,800000000,50000,5,TRUE)==1);
    assert(vmm_monitor_range_valid(100,100,0));
    assert(!vmm_monitor_range_valid(100,101,0));
    assert(!vmm_monitor_range_valid(100,99,2));
    assert(!vmm_monitor_range_valid(~0ULL,~0ULL-3,8));
}

static void test_scheduler(void)
{
    struct vmm_monitor_snapshot s;
    u32 old_generation;
    reset_run();
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=2000;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=2000;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RUNNING,fake_time);
    tick(); assert(!vmm_monitor_snapshot(0,&s));
    assert(s.ready.count==1 && s.ready.max_ns==4000 && !s.valid);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && s.valid && s.ready.count==0);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    fake_time+=1234; assert(!vmm_monitor_snapshot(0,&s) && s.ready_age_ns==1234);
    old_generation=s.generation;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
    assert(!vmm_monitor_snapshot(0,&s) && s.generation!=old_generation && !s.ready_age_ns);
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_UNKNOWN,fake_time);
    assert(vmm_monitor_snapshot(0,&s)==VMM_ENOTAVAIL);
    assert(!vmm_monitor_enable(FALSE));
    vmm_monitor_exit(&vcpus[0],1);
    assert(vmm_monitor_snapshot(0,&s)==VMM_ENOTAVAIL);
}

static void test_storm(void)
{
    struct vmm_monitor_status before, after;
    struct vmm_monitor_event e;
    int n,j;
    reset_run(); tick(); vmm_monitor_status(&before);
    for(n=0;n<5;n++) {
        for(j=0;j<50001;j++) vmm_monitor_exit(&vcpus[0],0x16);
        tick();
    }
    vmm_monitor_status(&after); assert(after.events==before.events+1);
    assert(!vmm_monitor_event_get(after.events,&e));
    assert(e.type==VMM_MONITOR_EXIT_STORM && e.value==50001 && e.code==0x16);
    tick(); assert(!vmm_monitor_event_get(after.events+1,&e));
    assert(e.type==VMM_MONITOR_EXIT_RECOVER);
    vmm_monitor_status(&before);
    fail_next_trylock=1; tick();
    vmm_monitor_status(&after); assert(after.busy_snapshots==before.busy_snapshots+1);
}

static void test_irq(void)
{
    struct vmm_monitor_hirq_context old,nested;
    struct vmm_monitor_snapshot s;
    struct vmm_monitor_status status;
    u64 drops;
    unsigned i;
    reset_run();
    old=vmm_monitor_hirq_enter(55);
    nested=vmm_monitor_hirq_enter(77);
    vmm_monitor_hirq_exit(nested);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    fake_time+=200;
    vmm_monitor_irq_pending(&vcpus[0],40,55); /* Coalescing preserves first. */
    fake_time+=100;
    vmm_monitor_irq_injected(&vcpus[0],40);
    vmm_monitor_irq_injected(&vcpus[0],40); /* Must not double-count. */
    vmm_monitor_hirq_exit(old);
    tick(); assert(!vmm_monitor_snapshot(0,&s));
    assert(s.irq.count==1 && s.irq.max_ns==300);
    vmm_monitor_status(&status); drops=status.irq_untracked;
    vmm_monitor_irq_pending(&vcpus[0],41,55); /* No matching host context. */
    old=vmm_monitor_hirq_enter(55);
    for(i=0;i<CONFIG_MONITOR_IRQ_SLOTS+1;i++) vmm_monitor_irq_pending(&vcpus[0],100+i,55);
    vmm_monitor_hirq_exit(old);
    vmm_monitor_status(&status); assert(status.irq_untracked==drops+2);
    reset_run();
    vmm_monitor_irq_injected(&vcpus[0],100);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
    old=vmm_monitor_hirq_enter(55);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    vmm_monitor_hirq_exit(old);
    fake_time+=100;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_RESET,fake_time);
    vmm_monitor_irq_injected(&vcpus[0],40);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
    old=vmm_monitor_hirq_enter(55);
    vmm_monitor_irq_pending(&vcpus[0],40,55);
    vmm_monitor_hirq_exit(old);
    vmm_monitor_irq_cancel(&vcpus[0],40);
    vmm_monitor_irq_injected(&vcpus[0],40);
    tick(); assert(!vmm_monitor_snapshot(0,&s) && !s.irq.count);
}

static void test_events(void)
{
    struct vmm_monitor_status st;
    struct vmm_monitor_snapshot s;
    struct vmm_monitor_event e;
    u64 before;
    unsigned i,j;
    reset_run();
    vmm_monitor_mem_fault(NULL,VMM_MONITOR_SHMEM_BOUNDS,~0ULL-4,8);
    tick(); assert(!vmm_monitor_snapshot(CONFIG_MAX_VCPU_COUNT,&s));
    assert(s.guest_id==VMM_MONITOR_UNKNOWN && s.faults==1);
    for(i=0;i<12;i++) {
        for(j=0;j<4;j++) vmm_monitor_mem_fault(&vcpus[j],VMM_MONITOR_ACCESS_DENIED,j,0xf);
        fake_time+=10*VMM_MONITOR_NS;
        vmm_monitor_sample(fake_time);
    }
    vmm_monitor_status(&st); assert(st.events>VMM_MONITOR_EVENTS && st.overwritten);
    assert(vmm_monitor_event_get(st.events-VMM_MONITOR_EVENTS,&e)==VMM_ENOTAVAIL);
    assert(!vmm_monitor_event_get(st.events,&e));
    st.config.publish=TRUE; assert(!vmm_monitor_configure(&st.config));
    before=st.publish_errors;
    output_len=0; log_count=0;
    vmm_monitor_drain();
    vmm_monitor_status(&st);
    assert(log_count==VMM_MONITOR_BATCH && st.publish_errors==before+VMM_MONITOR_BATCH);
    fputs(output,stdout); /* Python validates every emitted JSON record. */
    output_len=0;
}

static void test_starvation(void)
{
    struct vmm_monitor_status st;
    struct vmm_monitor_event e;
    u64 before;
    reset_run(); vmm_monitor_status(&st);
    st.config.ready_limit_ns=1000;
    assert(!vmm_monitor_configure(&st.config));
    before=st.events;
    vmm_monitor_state(&vcpus[0],VMM_VCPU_STATE_READY,fake_time);
    tick(); vmm_monitor_status(&st);
    assert(st.events==before+1);
    assert(!vmm_monitor_event_get(st.events,&e));
    assert(e.type==VMM_MONITOR_READY_SLOW && e.code==1 && e.value==VMM_MONITOR_NS);
    st.config.ready_limit_ns=0;
    assert(!vmm_monitor_configure(&st.config));
}

static void test_commands(void)
{
    char *short_args[]={"monitor"};
    char *bad[]={"monitor","config","exit_rate","18446744073709551616"};
    char *status[]={"monitor","status"};
    char *collect[]={"monitor","collect"};
    char *mem[]={"monitor","mem","Linux"};
    assert(!host_command_init());
    assert(command->exec(NULL,1,short_args)==VMM_EINVALID);
    assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="0"; assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="-1"; assert(command->exec(NULL,4,bad)==VMM_EINVALID);
    bad[3]="50000"; assert(!command->exec(NULL,4,bad));
    assert(!command->exec(NULL,3,mem));
    output_len=0;
    assert(!command->exec(NULL,2,status));
    assert(!command->exec(NULL,2,collect));
    fputs(output,stdout);
}

int main(void)
{
    test_math();
    assert(!vmm_monitor_init());
    assert(!vmm_monitor_enabled());
    test_scheduler(); test_storm(); test_irq(); test_starvation(); test_events(); test_commands();
    puts("PASS: arithmetic, intervals, lifecycle, IRQ pairing, bounded events, commands");
    return 0;
}
