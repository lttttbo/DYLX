/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <vmm_monitor.h>
#include <vmm_manager.h>
#include <vmm_timer.h>
#include <vmm_smp.h>
#include <vmm_stdio.h>
#include <vmm_modules.h>
#include <arch_barrier.h>
#include <libs/stringlib.h>
#include <libs/mathlib.h>
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
#include <vmm_threads.h>
#include <vmm_workqueue.h>
#endif
#define U(x) ((unsigned long long)(x))
struct latency { u64 count, sum, max; };
struct event {
	u64 seq, time, last, value, address, detail;
	u32 type, guest, vcpu, epoch, code, config_seq, sustain_s;
};
struct data {
	struct latency ready, dispatch;
	u64 ready_since, previous, exits, interval, count, sustained;
	u32 epoch, guest, last_exit, windows, config_seq;
	bool present, waiting, active, valid;
	struct event memory;
};
struct slot { vmm_spinlock_t lock; struct data d; };
static struct slot slots[CONFIG_MAX_VCPU_COUNT + 1];
static DEFINE_SPINLOCK(event_lock);
static struct event ring[VMM_MONITOR_EVENTS];
static u64 head, cursor = 1, lost;
static u32 epoch, sampler_cpu;
/* Protected by event_lock. Copy the entire configuration before taking slots. */
static struct monitor_config {
	u32 value[VMM_MONITOR_CONFIG_KEYS], seq;
} config = {{CONFIG_MONITOR_EXIT_RATE, CONFIG_MONITOR_STORM_SECONDS, 750, 1250}, 1};
static atomic_t enabled = {0}, initialized = {0}, skipped = {0}, errors = {0};
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static struct vmm_workqueue *queue;
static struct vmm_work work;
static struct vmm_timer_event timer;
static u64 deadline;
#endif
/* Lock order: slot -> event. No reader holds event_lock while taking a slot. */
static bool emit(struct event *e)
{
	irq_flags_t f;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	/* A concurrently published configuration invalidates an in-flight verdict. */
	if (e->type == 1 && e->config_seq != config.seq) {
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		return FALSE;
	}
	e->seq = ++head;
	if (head - cursor >= VMM_MONITOR_EVENTS) { cursor++; lost++; }
	ring[(head - 1) % VMM_MONITOR_EVENTS] = *e;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return TRUE;
}
static __attribute__((noinline)) void memory_flush(struct data *d)
{
	if (d->memory.value) { emit(&d->memory); d->memory.value = 0; }
}
static void add(struct latency *s, u64 ns)
{
	s->count++; s->sum += ns;
	if (ns > s->max) s->max = ns;
}
/* Only normal vCPUs have slots; NULL identifies a host shmem bounds failure. */
void vmm_monitor_record(struct vmm_vcpu *v, u32 hook, u64 a, u64 b)
{
	struct slot *s;
	struct data *d;
	irq_flags_t f;
	u32 run;
	bool reset = hook == MON_STATE &&
		(a == VMM_VCPU_STATE_RESET || a == VMM_VCPU_STATE_UNKNOWN);
	if (!arch_atomic_read(&initialized) ||
	    (!arch_atomic_read(&enabled) && !reset) ||
	    (v && (!v->is_normal || v->id >= CONFIG_MAX_VCPU_COUNT)) ||
	    (!v && hook <= MON_FAULT)) return;
	s = &slots[v ? v->id : CONFIG_MAX_VCPU_COUNT]; d = &s->d;
	vmm_spin_lock_irqsave_lite(&s->lock, f);
	run = arch_atomic_read(&enabled);
	if (!run && !reset) goto done;
	if (reset || d->epoch != run) {
		memory_flush(d);
		memset(d, 0, sizeof(*d));
		d->epoch = run;
		d->previous = vmm_timer_timestamp();
	}
	d->present = !(reset && a == VMM_VCPU_STATE_UNKNOWN);
	d->guest = v ? v->guest->id : ~0U;
	switch (hook) {
	case MON_STATE:
		if (a == VMM_VCPU_STATE_READY) {
			if (!d->waiting) d->ready_since = b;
			d->waiting = TRUE;
		} else d->waiting = FALSE;
		break;
	case MON_SELECTED:
		if (d->waiting && a >= d->ready_since) add(&d->ready, a - d->ready_since);
		d->waiting = FALSE;
		break;
	case MON_DISPATCH:
		if (b >= a) add(&d->dispatch, b - a);
		break;
	case MON_EXIT:
		d->exits++; d->last_exit = a;
		break;
	default:
		d->memory.last = vmm_timer_timestamp();
		if (!d->memory.value) d->memory.time = d->memory.last;
		d->memory.value++;
		d->memory.type = 3;
		d->memory.guest = d->guest;
		d->memory.vcpu = v ? v->id : ~0U;
		d->memory.epoch = run;
		d->memory.code = hook - MON_FAULT;
		d->memory.address = a; d->memory.detail = b;
	}
done:
	vmm_spin_unlock_irqrestore_lite(&s->lock, f);
}
int vmm_monitor_enable(bool on)
{
	irq_flags_t f;
	if (!arch_atomic_read(&initialized)) return VMM_ENOTAVAIL;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (!on) arch_atomic_write(&enabled, 0);
	else if (!arch_atomic_read(&enabled)) {
		/* Lazy epoch reset avoids locking all vCPUs with IRQs disabled. */
		if (!++epoch) ++epoch;
		arch_atomic_write(&enabled, epoch);
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return VMM_OK;
}
/* Preserve an active episode across configuration changes. A valid low-rate
 * window rearms it; neither a query nor changing limits repeats its alert. */
int vmm_monitor_configure(u32 key, u32 value)
{
	static const u32 bounds[VMM_MONITOR_CONFIG_KEYS][2] = {
		{1, 1000000000}, {1, 60}, {1, 1000}, {1000, 10000}
	};
	irq_flags_t f;
	if (!arch_atomic_read(&initialized)) return VMM_ENOTAVAIL;
	if (key >= VMM_MONITOR_CONFIG_KEYS ||
		value < bounds[key][0] || value > bounds[key][1]) return VMM_EINVALID;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	if (config.value[key] != value) {
		config.value[key] = value;
		if (!++config.seq) ++config.seq;
	}
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return VMM_OK;
}
/* Called only by one periodic executor. Never print or sleep here. */
void vmm_monitor_sample(u64 now)
{
	u32 i, run = arch_atomic_read(&enabled);
	irq_flags_t f;
	struct data *d;
	struct event e;
	struct monitor_config cfg;
	bool high;
	vmm_spin_lock_irqsave_lite(&event_lock, f); cfg = config;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) {
		if (!vmm_spin_trylock_irqsave(&slots[i].lock, f)) {
			arch_atomic_inc(&skipped); continue;
		}
		d = &slots[i].d;
		/* Faults captured before stop/reset must still reach the event ring. */
		memory_flush(d);
		if (!run || d->epoch != run || !d->present) goto next;
		if (!d->config_seq && cfg.seq == 1) d->config_seq = cfg.seq;
		if (d->config_seq != cfg.seq) {
			/* Discard the window straddling the update; keep latency/history. */
			d->config_seq = cfg.seq; d->previous = now;
			d->interval = d->count = d->exits = d->sustained = 0;
			d->windows = 0; d->valid = FALSE;
			goto next;
		}
		d->interval = now >= d->previous ? now - d->previous : 0;
		d->previous = now;
		d->count = d->exits; d->exits = 0;
		d->valid = d->interval >= (u64)cfg.value[VMM_MONITOR_WINDOW_MIN_MS] * 1000000 &&
			d->interval <= (u64)cfg.value[VMM_MONITOR_WINDOW_MAX_MS] * 1000000;
		if (!d->valid) { d->sustained = 0; d->windows = 0; goto next; }
		high = d->count > udiv64((u64)cfg.value[VMM_MONITOR_EXIT_LIMIT] * d->interval, VMM_MONITOR_NS);
		if (!high) {
			d->windows = 0; d->sustained = 0; d->active = FALSE;
			goto next;
		}
		if (d->active) goto next;
		d->windows++; d->sustained += d->interval;
		if (d->windows >= cfg.value[VMM_MONITOR_SUSTAIN_S] &&
			d->sustained >= cfg.value[VMM_MONITOR_SUSTAIN_S] * VMM_MONITOR_NS) {
			e.address = 0;
			e.type = 1;
			e.time = e.last = now;
			e.guest = d->guest; e.vcpu = i; e.epoch = run;
			e.value = udiv64(d->count * VMM_MONITOR_NS, d->interval);
			e.detail = cfg.value[VMM_MONITOR_EXIT_LIMIT]; e.code = d->last_exit;
			e.config_seq = cfg.seq; e.sustain_s = cfg.value[VMM_MONITOR_SUSTAIN_S];
			d->active = emit(&e);
		}
next:
		vmm_spin_unlock_irqrestore(&slots[i].lock, f);
	}
}
static __attribute__((noinline)) void print_event(struct vmm_chardev *c,
                                                 const struct event *e, bool log)
{
	/* Fixed stack storage; the maximum encoded record fits in 384 bytes. */
	char line[384];
	vmm_snprintf(line, sizeof(line), "{\"schema\":3,\"seq\":%llu,\"time_ns\":%llu,\"last_ns\":%llu,"
		"\"type\":%u,\"guest\":%u,\"vcpu\":%u,\"epoch\":%u,\"code\":%u,"
		"\"value\":%llu,\"address\":%llu,\"detail\":%llu,"
		"\"config_seq\":%u,\"sustain_s\":%u}\n",
		U(e->seq), U(e->time), U(e->last), e->type, e->guest, e->vcpu,
		e->epoch, e->code, U(e->value), U(e->address), U(e->detail),
		e->config_seq, e->sustain_s);
	if (log) vmm_lwarning("monitor", "%s", line);
	else vmm_cprintf(c, "%s", line);
}
static bool event_get(u64 seq, struct event *e)
{
	irq_flags_t f;
	bool found;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	found = seq && seq <= head && head - seq < VMM_MONITOR_EVENTS;
	if (found) *e = ring[(seq - 1) % VMM_MONITOR_EVENTS];
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	return found;
}
void vmm_monitor_drain(void)
{
	struct event e;
	u32 n;
	irq_flags_t f;
	/* One worker; a bounded batch prevents an endless log loop. */
	for (n = 0; n < 8; n++) {
		vmm_spin_lock_irqsave_lite(&event_lock, f);
		if (cursor > head) { vmm_spin_unlock_irqrestore_lite(&event_lock, f); break; }
		e = ring[(cursor++ - 1) % VMM_MONITOR_EVENTS];
		vmm_spin_unlock_irqrestore_lite(&event_lock, f);
		print_event(NULL, &e, TRUE);
		if (e.type == 1)
			vmm_printf("\n[monitor] exit storm: guest=%u vcpu=%u seq=%llu; see log/monitor events\n",
                       e.guest, e.vcpu, U(e.seq));
	}
}
int vmm_monitor_dump(struct vmm_chardev *c, u32 view)
{
	u32 i, current;
	u64 end, drops, seq, now;
	irq_flags_t f;
	struct event e;
	struct data d;
	struct monitor_config cfg;
	if (view > VMM_MONITOR_CONFIG_VIEW) return VMM_EINVALID;
	if (!arch_atomic_read(&initialized)) return VMM_ENOTAVAIL;
	vmm_spin_lock_irqsave_lite(&event_lock, f);
	end = head; drops = lost; current = epoch; cfg = config;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	if (view == VMM_MONITOR_EVENTS_VIEW) {
		for (seq = end >= VMM_MONITOR_EVENTS ? end - VMM_MONITOR_EVENTS + 1 : 1; seq <= end; seq++)
			if (event_get(seq, &e)) print_event(c, &e, FALSE);
		return VMM_OK;
	}
	vmm_cprintf(c, "{\"schema\":3,\"enabled\":%u,\"epoch\":%u,\"sampler_cpu\":%u,"
		"\"events\":%llu,\"lost\":%llu,\"skipped\":%u,\"errors\":%u,"
		"\"exit_limit\":%u,\"sustain_s\":%u,\"window_min_ms\":%u,"
		"\"window_max_ms\":%u,\"config_seq\":%u}\n", !!arch_atomic_read(&enabled), current,
		sampler_cpu, U(end), U(drops), (u32)arch_atomic_read(&skipped),
		(u32)arch_atomic_read(&errors), cfg.value[VMM_MONITOR_EXIT_LIMIT],
		cfg.value[VMM_MONITOR_SUSTAIN_S], cfg.value[VMM_MONITOR_WINDOW_MIN_MS],
		cfg.value[VMM_MONITOR_WINDOW_MAX_MS], cfg.seq);
	if (view == VMM_MONITOR_CONFIG_VIEW) return VMM_OK;
	for (i = 0; i < CONFIG_MAX_VCPU_COUNT; i++) {
		vmm_spin_lock_irqsave_lite(&slots[i].lock, f); d = slots[i].d;
		vmm_spin_unlock_irqrestore_lite(&slots[i].lock, f);
		if (!d.present || d.epoch != current) continue;
		now = vmm_timer_timestamp();
		vmm_cprintf(c, "{\"schema\":3,\"guest\":%u,\"vcpu\":%u,\"epoch\":%u,"
			"\"time_ns\":%llu,\"interval_ns\":%llu,\"valid\":%u,\"exits\":%llu,\"ready_age_ns\":%llu,"
			"\"ready\":[%llu,%llu,%llu],\"dispatch\":[%llu,%llu,%llu]}\n",
			d.guest, i, d.epoch, U(d.previous), U(d.interval), d.valid, U(d.count),
			U(d.waiting && arch_atomic_read(&enabled) == d.epoch && now >= d.ready_since ? now - d.ready_since : 0),
			U(d.ready.count), U(d.ready.count ? udiv64(d.ready.sum, d.ready.count) : 0), U(d.ready.max),
			U(d.dispatch.count), U(d.dispatch.count ? udiv64(d.dispatch.sum, d.dispatch.count) : 0), U(d.dispatch.max));
	}
	return VMM_OK;
}
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
static void report(struct vmm_work *unused) { vmm_monitor_drain(); }
static void tick(struct vmm_timer_event *ev)
{
	u64 now = vmm_timer_timestamp();
	irq_flags_t f;
	bool pending;
	int rc;
	vmm_monitor_sample(now);
	vmm_spin_lock_irqsave_lite(&event_lock, f); pending = cursor <= head;
	vmm_spin_unlock_irqrestore_lite(&event_lock, f);
	if (pending) {
		rc = vmm_workqueue_schedule_work(queue, &work);
		if (rc && rc != VMM_EALREADY) arch_atomic_inc(&errors);
	}
	now = vmm_timer_timestamp();
	deadline += (udiv64(now >= deadline ? now - deadline : 0, VMM_MONITOR_NS) + 1) * VMM_MONITOR_NS;
	if (vmm_timer_event_start(ev, deadline - now)) arch_atomic_inc(&errors);
}
#endif
int __init vmm_monitor_init(void)
{
	u32 i;
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	int rc;
#endif
	for (i = 0; i <= CONFIG_MAX_VCPU_COUNT; i++) INIT_SPIN_LOCK(&slots[i].lock);
	sampler_cpu = vmm_smp_processor_id();
#ifndef CONFIG_MONITOR_EXTERNAL_EXECUTOR
	INIT_WORK(&work, report);
	INIT_TIMER_EVENT(&timer, tick, NULL);
	queue = vmm_workqueue_create("monitor", CONFIG_MONITOR_PRIORITY);
	if (!queue) return VMM_ENOMEM;
	rc = vmm_threads_set_affinity(vmm_workqueue_get_thread(queue), vmm_cpumask_of(sampler_cpu));
	if (!rc) {
		deadline = vmm_timer_timestamp() + VMM_MONITOR_NS;
		rc = vmm_timer_event_start(&timer, VMM_MONITOR_NS);
	}
	if (rc) { vmm_workqueue_destroy(queue); return rc; }
#endif
	arch_wmb();
	arch_atomic_write(&initialized, 1);
#ifdef CONFIG_MONITOR_START_ENABLED
	vmm_monitor_enable(TRUE);
#endif
	return VMM_OK;
}
VMM_EXPORT_SYMBOL(vmm_monitor_record);
VMM_EXPORT_SYMBOL(vmm_monitor_enable);
VMM_EXPORT_SYMBOL(vmm_monitor_dump);
VMM_EXPORT_SYMBOL(vmm_monitor_configure);
