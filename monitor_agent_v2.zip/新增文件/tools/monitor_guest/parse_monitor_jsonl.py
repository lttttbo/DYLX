"""Read pure monitor JSONL with Python integer precision.

Usage: python parse_monitor_jsonl.py qemu_monitor_sample_20261021.jsonl --output analysis.json
This validates exported fields, not actual hardware behavior or full IRQ coverage.
"""
import argparse
import json
from pathlib import Path

NS = 1_000_000_000
QUALITIES = {"disabled", "warmup", "stale", "valid", "warmup_or_gap"}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate field: " + key)
        result[key] = value
    return result


def uint(record, key):
    value = record[key]
    if type(value) is not int or not 0 <= value <= (1 << 64) - 1:
        raise ValueError(key + " must be an unsigned integer")
    return value


def reject_constant(value):
    raise ValueError("non-JSON number: " + value)


def classify(record):
    if "instruction_cycles" in record:
        return "diagnostic"
    if type(record.get("schema")) is not int or record["schema"] not in (1, 2):
        raise ValueError("unsupported schema")
    if record.get("kind") in {"guest_os", "trap_diagnostic", "diagnostic_summary"}:
        return record["kind"]
    if "seq" in record and "type" in record:
        return "event"
    if "enabled" in record and "samples" in record:
        return "status"
    if "ready" in record and "host_irq_to_lr" in record:
        return "snapshot"
    raise ValueError("unrecognized record type")


def latency(record):
    n = uint(record, "count")
    mean = uint(record, "mean_ns")
    p99 = uint(record, "p99_upper_ns")
    maximum = uint(record, "max_ns")
    jitter = uint(record, "jitter_range_ns")
    if not n:
        if any([mean, p99, maximum, jitter]):
            raise ValueError("zero count has nonzero statistics")
        return dict(count=0, mean_us=None, p99_upper_us=None,
                    max_us=None, min_us=None, jitter_range_us=None)
    if jitter > maximum or not maximum - jitter <= mean <= maximum:
        raise ValueError("latency mean/min/max/jitter are inconsistent")
    # A bucket upper bound can exceed the observed maximum. Do not reject it.
    return dict(count=n, mean_us=mean / 1000, p99_upper_us=p99 / 1000,
                max_us=maximum / 1000, min_us=(maximum - jitter) / 1000,
                jitter_range_us=jitter / 1000)


def analyze(path):
    snapshots, other, errors = [], [], []
    for line_number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line, object_pairs_hook=unique_object,
                                parse_constant=reject_constant)
            if not isinstance(record, dict):
                raise ValueError("record must be an object")
            kind = classify(record)
            if kind != "snapshot":
                other.append(dict(line=line_number, kind=kind, record=record))
                continue
            for key in ["guest", "vcpu", "generation", "hcpu", "state", "time_ns",
                        "interval_ns", "exits", "exit_rate", "last_exit", "ready_age_ns",
                        "faults_pending_summary", "last_address", "last_fault", "last_detail"]:
                uint(record, key)
            if record["quality"] not in QUALITIES:
                raise ValueError("unknown quality")
            dt = record["interval_ns"]
            if record["quality"] == "valid" and not NS * 3 // 4 <= dt <= NS * 5 // 4:
                raise ValueError("valid quality with invalid interval")
            # The first warmup reports interval_ns=0; its rate is not meaningful.
            expected_rate = record["exits"] * NS // dt if dt else None
            if expected_rate is not None and record["exit_rate"] != expected_rate:
                raise ValueError("exit_rate does not match floor(exits * 1e9 / interval_ns)")
            snapshots.append(dict(line=line_number, guest=record["guest"], vcpu=record["vcpu"],
                schema=record["schema"], generation=record["generation"], hcpu=record["hcpu"], state_raw=record["state"],
                quality=record["quality"], time_ns=record["time_ns"], interval_ns=dt,
                exits=record["exits"], exit_rate=record["exit_rate"],
                last_exit_raw=record["last_exit"], ready=latency(record["ready"]),
                host_irq_to_lr=latency(record["host_irq_to_lr"]),
                dispatch=latency(record["dispatch"]) if "dispatch" in record else None))
        except (ValueError, KeyError, TypeError) as error:
            errors.append(dict(line=line_number, error=str(error)))
    return dict(snapshot_count=len(snapshots),
                guest_ids=sorted({r["guest"] for r in snapshots}),
                observed_hcpus=sorted({r["hcpu"] for r in snapshots}),
                irq_sample_count=sum(r["host_irq_to_lr"]["count"] for r in snapshots),
                errors=errors, snapshots=snapshots, other_records=other,
                note="valid denotes window quality, not system health; null latency means no samples")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = analyze(args.input)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
    return bool(result["errors"])


if __name__ == "__main__":
    raise SystemExit(main())
