/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef XM_PARSE_H
#define XM_PARSE_H
#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
#include <string.h>
#include <limits.h>
struct xm_cpu { uint64_t field[8]; };
static int xm_cpu_read(FILE *f, struct xm_cpu *c)
{
	char line[512];
	return !fgets(line, sizeof(line), f) || sscanf(line,
		"cpu %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64" %"SCNu64,
		&c->field[0], &c->field[1], &c->field[2], &c->field[3],
		&c->field[4], &c->field[5], &c->field[6], &c->field[7]) != 8 ? -1 : 0;
}
static int xm_cpu_usage(const struct xm_cpu *a, const struct xm_cpu *b, uint64_t *bp)
{
	uint64_t total = 0, idle = 0, delta;
	unsigned i;
	for (i = 0; i < 8; i++) {
		if (b->field[i] < a->field[i]) return -1;
		delta = b->field[i] - a->field[i];
		if (UINT64_MAX - total < delta) return -1;
		total += delta;
		if (i == 3 || i == 4) idle += delta;
	}
	if (!total) return -1;
	*bp = (uint64_t)(((__uint128_t)(total - idle) * 10000) / total);
	return 0;
}
static int xm_mem_read(FILE *f, uint64_t *total, uint64_t *available, uint64_t *free_bytes)
{
	char line[256], key[64], unit[8];
	uint64_t value;
	unsigned present = 0;
	*total = *available = *free_bytes = 0;
	while (fgets(line, sizeof(line), f)) {
		if (sscanf(line, "%63s %"SCNu64" %7s", key, &value, unit) != 3) continue;
		if (strcmp(key, "MemTotal:") && strcmp(key, "MemAvailable:") && strcmp(key, "MemFree:")) continue;
		if (strcmp(unit, "kB") || value > UINT64_MAX / 1024) return -1;
		value *= 1024;
		if (!strcmp(key, "MemTotal:")) { *total = value; present |= 1; }
		if (!strcmp(key, "MemAvailable:")) { *available = value; present |= 2; }
		if (!strcmp(key, "MemFree:")) { *free_bytes = value; present |= 4; }
	}
	return present != 7 || !*total || *available > *total || *free_bytes > *total ? -1 : 0;
}
#endif
