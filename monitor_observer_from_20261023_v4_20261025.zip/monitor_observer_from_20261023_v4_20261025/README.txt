Monitor v4 记录版：从 monitor_live_tests_v4_20261023 直接升级
日期：2026-10-25

你当前已移植的是 23 日版。本包明确以该版本为基线，不需要先合入 24 日版。
上一份 monitor_observer_v4_20261025 包的 upstream_update.patch 基于 24 日版；
对你当前版本请改用本包，不要混用其中的增量或回退补丁。

一、只需按顺序核对两份补丁
1. from_20261023.patch：15 个上游参考/测试/说明文件，含完整的现有 Guest 测试框架迁移。
2. ccm_from_uploaded.patch：你上传的两个私有 Hypervisor 文件，只在既有失败分支追加记录。
   两份路径均相对 Hypervisor 根目录。私有文件有其他变动时按函数手工合入。

二、交付内容
full_files/upstream：第一份补丁的全部修改后文件。
full_files/private_hypervisor：cpu_hcall.c、vmm_u_ioreq.c 的完整参考文件。
merge_locations.txt：按旧文件函数与行号列出的手工合入位置。
design.md：记录边界、事件解释、测试条件及限制。
validation：基线和补丁校验，以及相同最终源码此前通过的测试报告。
file_manifest.json / SHA256SUMS.txt：文件校验信息。

三、保持现有业务策略
CCM 不新增 serverVM 独占注册、容量限制、重复注册拒绝或通知/返回值变化。
仅清理早期 monitor 在 shmem 中自行引入的额外策略；保留你项目原有的检查及私有函数。
不修改 Linux/Android 内核或 CCM 驱动，无新 ioctl，无 Linux 还原操作。
不重复修改产品 scheduler、Stage-2、monitor_agent 和 23 日版只读观察接口。
继续沿用现有日志接口：能否落盘、何时落盘由原项目日志后端负责。

四、测试入口变化
CONFIG_WBOXTEST_MONITOR、CONFIG_WBOXTEST_MONITOR_LIVE 沿用，objects.mk 不变。
先 monitor start，再 monitor_live target <全局vCPU ID>，选择现有 Guest。
调度测试需要目标忙负载；storm 测试需要外部可控高低负载；内存测试等待真实错误事件。
没有这些触发条件时不能自动完成验收。无需新增专用 Guest，旧 live_guest 流程不再使用。
日志核对改用 tests/monitor/verify_existing_logs.py，详见 design.md。

五、验证说明
23 日版 24 个交付文件、9 个依赖的哈希一致；两份补丁正向应用、结果比对和反向还原通过。
本次只重制基线及说明，最终源码与已验证的记录版一致，复用其 32 次 ARM64 编译、
54 次隔离白盒执行、开关各 212 组行为对照及日志/观察接口回归结果。
尚未完成你的私有整机链接、QEMU/板卡验证、持久化介质验收和 ROM/CPU 指标验收。
