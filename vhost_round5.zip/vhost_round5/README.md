# vhost第五轮：TX退出原因与work提交来源

适配基线：本次上传的 `net.c.txt`（1474行）与 `vhost.c.txt`（2336行）。
本包是诊断补丁，不是性能优化补丁；不改变EVENT_IDX、busyloop、CCM路由、ring大小或处理预算。

## 1. 先纠正第四轮的一处分类错误

本次源文件的 `handle_tx_kick()` 和 `handle_tx_net()` 都传入 `n4_handle_tx(net, 1)`。
后者必须传2。否则旧ORIGIN的kick是两个入口合计，backend_ready=0不能证明后端回调没有执行。
旧的COUNT总量、合并批次及总体耗时不因此自动作废，但入口归因必须撤回。

`0001_fix_n4_origin.patch` 只修改 `handle_tx_net()` 的这一行，不改变报文处理逻辑。

## 2. 两个补丁按顺序应用

在实际ServerVM内核源码根目录执行；先备份/提交当前变更。将P改为本包解压目录。

```sh
P=/实际路径/vhost_round5

git apply --check "$P/0001_fix_n4_origin.patch"
git apply "$P/0001_fix_n4_origin.patch"

git apply --check "$P/0002_vhost_n5_counters.patch"
git apply "$P/0002_vhost_n5_counters.patch"
git diff -- drivers/vhost/net.c drivers/vhost/vhost.c
```

如果已经手工把 `handle_tx_net()` 的origin改成2，跳过0001。0002基于修正后的文件。
如果任一 `--check` 失败，不使用模糊覆盖；先对照本地函数。0002会自行新增两个头文件并添加include，不必重复复制/插入。
上传的net.c片段止于 `vhost_net_set_backend()`，没有后面的完整源文件内容。**不要用该片段整体覆盖真实net.c；本包只按hunk修改已知位置，保留真实源文件的其余内容。**

## 3. 确切的修改位置

行号指原上传文件，函数名和原有语句是实际定位锚点；应用补丁后行号会变化。

| 文件/原行号 | 函数或区域 | 新增或替换位置 |
|---|---|---|
| net.c:33 | include区域 | 原n4头文件之后包含 `vhost_round5.h` |
| net.c:115-130 | `struct vhost_net` | 最后一项之后追加TX局部累计状态，不改公开vhost.h |
| net.c:329 | `vhost_zerocopy_callback()` | 原 `vhost_poll_queue()` 替换为带ZCOPY_COMPLETE标签的等价提交 |
| net.c:392 | `vhost_tx_batch()` | 原XDP批量sendmsg前后累计flush、帧数和负返回值 |
| net.c:432 | `vhost_net_busy_poll_try_queue()` | 保留原判空/enable/disable顺序，为两条重新排队分支标来源 |
| net.c:442 | `vhost_net_busy_poll()` | 对上述辅助函数传BUSY_PEER调用位置标识 |
| net.c:482 | `vhost_net_tx_get_vq_desc()` | 原非零超时条件内部累计busy-poll实际进入次数 |
| net.c:521 | `get_tx_bufs()` | 使用原返回值统计描述符错误、最终为空、格式错误、长度为0；不重新取描述符 |
| net.c:647 | `handle_tx_copy()` | 每个原break前设置退出原因；原sendmsg之后分类返回值；原done及收尾处累计；不改变业务分支 |
| net.c:740 | `handle_tx_zerocopy()` | 同样记录退出、实际zcopy选择、retry以及继续复查，不额外signal |
| net.c:842 | `handle_tx()` | 原TX mutex获取之后begin，原unlock之前end；根据原判断记录copy/zero-copy路径 |
| net.c:868 | `n4_handle_tx()` | 保留原包装函数，但本轮n4_run=0 |
| net.c:1187 | `handle_tx_net()` | 0001修正origin为2，kick回调仍为1 |
| vhost.c:21 | include区域 | 包含 `vhost_round5_impl.h`，统计实体只在此编译一次 |
| vhost.c:125 | `vhost_poll_wakeup()` | 回调转到带来源参数的内部函数，区分真正回调与poll启动时的同步就绪检查 |
| vhost.c:158 | `vhost_poll_start()` | 原mask非零分支使用POLL_START_READY来源，不额外执行vfs_poll |
| vhost.c:201 | `vhost_work_queue()` | 原test_and_set_bit/llist_add/wake_up_process顺序保持且各只执行一次，记录原结果 |
| vhost.c:221 | `vhost_poll_queue()` | 保留原公共API，并新增带来源标签API；一个事件只调用一种API |
| vhost.c:278 | `vhost_worker()` | 原clear_bit后、原work->fn调用前记录具体work开始执行；不修改清位位置 |
| vhost.c:349 | `vhost_exceeds_weight()` | 原判断成立后，原queue语句替换为WEIGHT标签提交 |
| vhost.c:886 | `vhost_iotlb_notify_vq()` | 原queue语句标记IOTLB来源 |
| vhost.c:2324/2328 | `vhost_init()/vhost_exit()` | 创建/移除 `/proc/vhost_n5`；创建失败只警告，不使原vhost初始化失败 |

新增的 `_tagged` / `*_reason` 辅助函数只是携带诊断来源。没有再次调用test_and_set_bit、没有额外wake_up_process、没有通过第二次判空来获取统计。

## 4. 采集口径及并发约束

- 只选择一个当前vhost worker TID。首次选中的TX处理绑定该设备真正的TX kick work和TX backend work对象。
- **按目标work对象过滤，不按调用者TID过滤。** 因此ioeventfd上下文、vhost上下文、完成回调上下文的提交都可以记录。
- 首次绑定前极少量提交/执行记入prebind，不能假装零窗口边界误差。
- TX分支计数在原TX mutex保护的局部状态中累计，结束时一次汇总。异步完成回调不访问这个局部状态。
- 通用提交/执行计数按CPU保存，短raw-spinlock段只操作诊断计数，不包围原队列/发送/signal函数。
- start清零并开启新epoch；stop停止计数并等待短计数临界区退出，不flush真实vhost队列。
- 采集启停时，真实work可能已在排队/运行。`new_queued`不要求与`EXECUTE`逐项严格相等。
- 报告使用proc/seq_file，不受单次module-param报告一页的限制；运行中只返回状态，不遍历打印计数。
- 不逐包打印、不抓调用栈、不读取逐次时钟。不等于完全无开销，应保留无新采集的吞吐基线。
- 采集期间不重启DSM/Guest、不STR、不换backend、不改协商特征、不卸载模块、不在两个采集间复用旧TID。
- 不要在脚本延后导出期间手工start下一轮；脚本会检查epoch，但不能恢复已被清空的数据。

## 5. 部署

本轮修改的是内核 `drivers/vhost/net.c` 与 `drivers/vhost/vhost.c`，不改DSM/CCM业务实现。
新增跨编译单元导出API，所以**核心vhost与vhost-net两个构建产物必须保持一致**。
核心内置时更新kernel；核心/网络后端编为模块时更新实际加载的新模块及构建产生的依赖信息，不能只烧kernel或只换一个模块。
不要在Guest运行期间强制卸载vhost。保留原第四轮头文件，因为原n4包装器仍引用它。

重新启动后检查：

```sh
ls -l /proc/vhost_n5
cat /proc/vhost_n5
```

初始 `run=0`、`bound=0` 正常；有流量且成功采集后应bound=1。

## 6. 保留但关闭旧探针

在启动iperf之前执行：

```sh
[ ! -e /proc/ipi_origin ] || echo stop > /proc/ipi_origin
for p in /sys/module/ccm_proxy/parameters/ioem_run \
         /sys/module/ccm_proxy/parameters/n4_run \
         /sys/module/vhost_net/parameters/n4_run; do
    [ ! -e "$p" ] || echo 0 > "$p"
done
echo stop > /proc/vhost_n5
```

VQMAP、VQCFG、IOEM_CFG初始化日志保留；不要启动旧 `capture_n4.sh`、`collect_notify_chain.sh`、`capture_sched_wait.sh`、eth0逐秒脚本或全量ftrace。

## 7. 测试布局

| 组 | ioeventfd | vhost | eth0 IRQ有效CPU |
|---|---|---|---|
| A1 | 1 | 0 | 0 |
| B | 0 | 0 | 0 |
| A2（回切复核，可后做） | 1 | 0 | 0 |

kworker不强绑；Android发包参数、二进制、发送CPU和源端口策略保持相同；三个优化开关不改。
A/B标签只命名输出目录，不修改任何亲和性。

先查询本次TID和IRQ，不使用旧ID：

```sh
ps -eLo pid,tid,psr,comm | grep -E 'ioeventfd|vhost-'
grep -w eth0 /proc/interrupts
```

下列188、1009和131只是旧结果示例，必须按本次查询替换。

```sh
IO_TID=188
VH_TID=1009
ETH_IRQ=131

taskset -pc 1 "$IO_TID"  # A；B时改0
taskset -pc 0 "$VH_TID"
echo 0 > /proc/irq/$ETH_IRQ/smp_affinity_list
cat /proc/irq/$ETH_IRQ/effective_affinity_list
```

先留一份不运行任何采集的基线。采集轮Android运行：

```sh
./iperf3 -p 5201 -c 192.168.1.1 -b 1000M -t 60 -l 1400 -i 10 -u
```

这是Android→PC UDP上行。出现第一个10秒区间结果后，在ServerVM执行：

```sh
sh capture_vhost_n5.sh "$IO_TID" "$VH_TID" A1 3
```

B组先手工调整布局，再执行同一命令、标签换B。脚本采集约3秒，停止后默认再等60秒才导出；不要以为没有即时输出就是卡死。
脚本不轮询流量、不改变亲和性；前后各读一次网口累计值供辅助核对，网络快照范围稍宽于内核n5窗口，不做严格逐事件等式。
`CAPTURE_SECONDS`是普通变量，不再使用Bash的特殊变量SECONDS。

手动控制（不用脚本时）：

```sh
echo "start $VH_TID" > /proc/vhost_n5
sleep 3
echo stop > /proc/vhost_n5
# 等iperf结束再读取
cat /proc/vhost_n5 > /tmp/vhost_n5.txt
```

## 8. 输出解释

### CHECK / CONFIG

期望bound=1，identity_conflict=0，config_changed=0，bad_units=0，completed>0。
weight/byte_weight直接读实际设备状态。PATH_COPY/PATH_ZCOPY统计最终选择，不只看默认experimental_zcopytx。

### EXIT与EXIT_TAIL

`EXIT`逐条显示循环/前置退出原因、完成调用数、split净推进链头数及0/1/2-4/5-16/17-64/>64分布。
`get_tx_bufs_empty`是**原TX循环内**观察到为空；它发生在最后batch flush和收尾复查之前。

`EXIT_TAIL`把**同一次TX处理**的退出原因和copy收尾结果交叉统计：
- not_run：不是copy收尾路径，例如zerocopy/前置失败。
- pending：原 `vhost_vq_avail_empty()` 返回false，进行原有内部重新排队。
- recheck_changed：原 `vhost_enable_notify()` 返回true，原有disable+重新排队。
- no_self_requeue：原辅助函数没有发起内部重新排队；不保证线程睡眠，也不证明eventfd没有并发提交。
- busy_interrupted：原busyloop_intr分支重新排队。

注意：本地avail判空函数在读取索引错误时也返回false，故使用not_proven_empty命名，不能无条件声称pending必定是新报文。enable_notify的false也可能是原有错误/已开启分支。

### QUEUE / EXECUTE

`QUEUE,work,source,observed_outcomes,new_queued,merged,wake_return_0,wake_return_1`

- tx_kick_work：`vq->poll.work`。
- tx_backend_work：`net->poll[TX].work`，后端socket的EPOLLOUT工作。
- poll_event：等待队列实际回调；对kick对象通常对应注册的kick eventfd，但这不是MMIO写次数。
- poll_start_already_ready：调用vfs_poll注册/恢复监听时立即就绪，不是新到来的异步事件。
- copy_tail_not_proven_empty / copy_tail_notify_changed：copy收尾主动重排，与busyloop超时是否非零无必然关系。
- weight_limit、zcopy_completion、iotlb_update：各对应原有调用位置。
- untagged_poll_api / direct_work_api：其余入口显式保留，不能自动归到Guest kick。

同一行严格应满足：observed_outcomes=new_queued+merged；new_queued=wake_return_0+wake_return_1。
wake_return_1只是原wake_up_process返回非零，不等于物理IPI发送次数。
`EXECUTE`是worker开始执行相应work的次数，不是包数，也不能给每次执行唯一分配一个提交来源，因为提交可能被合并。

### EVENT

- path_copy_calls、path_zerocopy_calls：实际分支。
- copy_sndbuf_unlimited_calls：是否走允许XDP组包的sndbuf条件。
- descriptor_heads_fetched/discarded：取出/退回，不代表已发到线上。
- single_sendmsg_*：普通sendmsg原返回值分类。
- xdp_batch_sendmsg_negative：批量sendmsg负返回值；loop_done不能因此等价于成功发包。
- zero-copy完成只通过QUEUE来源计数，不在异步完成上下文访问TX局部状态。

## 9. 反馈最小集合

每组提供 `vhost_n5.txt`、`context_before.txt`、`context_after.txt`，附上iperf命令和最终sender/receiver/丢包。
`counters_before/after.txt`很小，可附上；不需要trace，不需要几万行日志，也不用重新发前四轮材料。

判断顺序：先看采集有效性，再看实际copy/zero-copy，随后看EXIT+EXIT_TAIL，最后看两个work的提交来源和新入队/合并比例。
不将“旧N4合计比CCM多”直接当成内部重排数量。

## 10. 验证范围

参见VALIDATION.md。宿主测试只是模拟业务调用序列和新增头文件构建检查，**不是**厂商完整ARM64 RT内核编译或上板结果。
