Monitor v4：直接从记录版升级统一测试集 / 2026-10-25

唯一基线：monitor_observer_from_20261023_v4_20261025 已合入后的工程。
无需先合入 unified、hv_tests、one_option 等中间测试包。

合入两份补丁：
1. from_observer.patch：直接基于记录版，包含核心测试支持、测试归组、Hypervisor 内存用例和单一开关。
2. cmd_memory_from_uploaded.patch：基于你上传的原 cmd_memory.c，追加记录及仅测试配置下的适配函数。
私有文件按 merge_locations.txt 的函数和上下文合入，不用完整文件覆盖你的其他修改。
full_files 提供全部新增/修改后的参考文件；删除项见补丁与文件清单。

测试侧唯一选项：CONFIG_WBOXTEST_MONITOR=y。
已有 CONFIG_WBOXTEST、CONFIG_MONITOR_AGENT、CONFIG_CMD_MONITOR 仍需为 y；
CMD_MEMORY、CMD_WBOXTEST 由测试项自动选择，无 HOST/LIVE 子选项。

执行：
monitor start
wboxtest run_groups 1 monitor

共 9 项：原 6 项隔离测试 + 3 项 Hypervisor 内存测试。
Guest 现场源码迁移保留但本阶段不编译，不需 Guest 程序或新 Guest。
Guest 写保护测试仍需已有符合原检查条件的映射；缺少条件明确失败。日志人工检查。
现有 CCM、Linux/Android 驱动、VM 生命周期及访问策略沿用记录版，无新增 ioctl。

验证：已重建并核对发布的记录版基线；两份直接补丁应用、全文件结果及反向还原通过；
有效代码与既有已验证的单开关实现一致，复用相同源码的编译和模型报告。
此次未重跑功能测试；未完成你的私有固件整机链接或板卡/QEMU运行。
细节见 guide.md、validation、file_manifest.json、SHA256SUMS.txt。
