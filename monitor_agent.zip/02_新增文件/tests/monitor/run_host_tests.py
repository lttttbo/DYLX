"""Run unchanged production sources against a small, deterministic host API model.
Usage: python tests/monitor/run_host_tests.py --cc /path/to/zig --build-dir /tmp/mon-test
Use --cc gcc or --cc clang for a conventional host compiler. No target execution.
"""
import argparse
import json
import re
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--cc', required=True)
p.add_argument('--build-dir', required=True)
args = p.parse_args()
root = Path(__file__).resolve().parents[2]
out = Path(args.build_dir).resolve()
out.mkdir(parents=True, exist_ok=True)
shim = out / 'include'
for name in ['vmm_types.h','vmm_manager.h','vmm_timer.h','vmm_mutex.h',
             'vmm_stdio.h','vmm_modules.h','vmm_smp.h','vmm_cmdmgr.h',
             'libs/stringlib.h','libs/mathlib.h','arch_barrier.h','arch_atomic64.h']:
    path = shim / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text('#include "host.h"\n')
# Error-pointer helpers assume LP64; the host model only needs error numbers.
errors=(root/'core/include/vmm_error.h').read_text()
(shim/'vmm_error.h').write_text('\n'.join(line for line in errors.splitlines()
    if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',line))+'\n')
cmd = [args.cc]
if Path(args.cc).stem == 'zig': cmd += ['cc']
cmd += ['-std=gnu11','-O2','-Wall','-Werror',
        '-DCONFIG_MONITOR_AGENT=1','-DCONFIG_MONITOR_EXTERNAL_EXECUTOR=1',
        '-DCONFIG_MAX_VCPU_COUNT=4','-DCONFIG_CPU_COUNT=12','-DCONFIG_MONITOR_IRQ_SLOTS=4',
        '-I'+str(shim),'-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
cmd += [str(root/n) for n in ['tests/monitor/test_monitor.c',
    'core/monitor/monitor_agent.c','core/monitor/monitor_stats.c',
    'core/monitor/monitor_irq.c','commands/cmd_monitor.c']]
exe = out/'test_monitor.exe'
subprocess.run(cmd+['-o',str(exe)],check=True)
r = subprocess.run([str(exe)],capture_output=True,text=True,check=True)
records = [json.loads(line) for line in r.stdout.splitlines() if line.startswith('{')]
assert len(records) >= 10
assert len([e for e in records if 'seq' in e]) == 8
assert any(e.get('instruction_cycles')=='unsupported' for e in records)
(out/'results.txt').write_text(r.stdout)
print(r.stdout.splitlines()[-1])
print(f'PASS: {len(records)} JSON records parsed with the standard JSON parser')
disabled=[args.cc]+(['cc'] if Path(args.cc).stem=='zig' else [])
disabled += ['-std=gnu11','-O2','-Wall','-Werror','-I'+str(shim),
    '-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include'),
    str(root/'tests/monitor/test_disabled.c'),'-o',str(out/'test_disabled.exe')]
subprocess.run(disabled,check=True)
subprocess.run([str(out/'test_disabled.exe')],check=True)
print('PASS: disabled hooks evaluate no arguments')
