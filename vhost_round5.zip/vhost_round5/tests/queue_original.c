
#include <stdio.h>
#include <stdbool.h>
#include "vhost_round5.h"
struct vhost_work { unsigned long flags; int node; };
struct vhost_dev { int *worker; int work_list; };
#define VHOST_WORK_QUEUED 0
static int bit_calls,wake_calls,list_calls;
static bool test_and_set_bit(int bit,unsigned long *flags){bool old=*flags & (1UL<<bit); *flags|=1UL<<bit;bit_calls++;return old;}
static void llist_add(int *node,int *list){(void)node;(*list)++;list_calls++;}
static int wake_up_process(int *p){int r=*p;*p=0;wake_calls++;return r;}
static void n5_note_queue(struct vhost_dev *d,struct vhost_work *w,enum n5_source s,int outcome){(void)d;(void)w;(void)s;(void)outcome;}

void vhost_work_queue(struct vhost_dev *dev, struct vhost_work *work)
{
        if (!dev->worker)
                return;
        if (!test_and_set_bit(VHOST_WORK_QUEUED, &work->flags)) {
                /* We can only add the work to the list after we're
                 * sure it was not in the list.
                 * test_and_set_bit() implies a memory barrier.
                 */
                llist_add(&work->node, &dev->work_list);
                wake_up_process(dev->worker);
        }
}

int main(void){
 int sleeping=1;struct vhost_dev d={&sleeping,0};struct vhost_work w={0,0};int i;
 for(i=0;i<20;i++){
   if(i%3==0)w.flags=0;
   if(i%7==0)sleeping=1;
   vhost_work_queue(&d,&w);
   printf("%d:%lu,%d,%d,%d,%d\n",i,w.flags,d.work_list,bit_calls,wake_calls,list_calls);
 }
 d.worker=NULL;vhost_work_queue(&d,&w);
 printf("no_worker:%d,%d,%d\n",bit_calls,wake_calls,list_calls);
 return 0;
}
