# hos TEE：第二步线程数量查询

版本：step02 / v1，日期：2026-11-02。
依赖：已合入并验证第一步 `hos_tee_step01_caps_v1_20261102`。

## 修改行为

Guest 的 Linux/Android OP-TEE 驱动初始化时会发起 `OPTEE_SMC_GET_THREAD_COUNT`
（`0xB200000F`）。原先 hos 只在自身探测时调用它，Guest 分发器没有对应入口。
本次新增入口，以当前 Guest 的 client_id 向安全侧查询，并返回：

```text
Guest 可用线程总额度 = min(安全侧返回的线程数量, ctx->max_calls)
```

这不是 CPU 核数，也不是“当前剩余线程数”。不能扣除 ctx->call_count，否则 Guest
驱动可能在已有调用执行时低估总容量。查询本身不申请标准调用对象、不改变额度、不增加
call_count，也不分配动态内存。

## 三处代码修改

1. `OPTEE_MEDIATOR_SMC_COUNT` 从 11 改为 12，与新增处理入口一致。
2. 新增 `optee_handle_get_thread_count()`。
3. `optee_handle_call()` 增加对应 case。

仅修改 `arch/arm/cpu/common/optee.c`。不新增 Kconfig、生产头文件或 Guest 测试模块。
完整文件包含第一步能力屏蔽；增量 patch 只包含本步三处变化。

## 函数处理细节

- 复用 optee_smc_call()，由该接口强制使用 ctx->client_id 作为 a7，忽略 Guest 自己填写的 a7。
- 查询不使用其他参数，传向安全侧的 a1～a6 均为 0。
- SMC32 查询只取返回数量的低 32 位。
- 安全侧查询失败时，仅将其错误返回码写入 Guest 的 a0，保留 a1～a7。
- 成功取得数量后，短暂持有 ctx->lock 读取 max_calls；锁不会跨越实际 SMC 调用。
- 对数量取上限后，若结果为 0，返回 UNKNOWN_FUNCTION，使实际 Linux 驱动使用原有回退逻辑，
  不伪造一个可用线程数。此路径同样保留 a1～a7。
- 正常返回只修改 a0=OK、a1=有效总额度，保留 a2～a7，不把固件临时改动的这些寄存器回写 Guest。
- 不修改已有 max_calls、call_count、宿主侧探测、VM 生命周期、缓存处理及 RPC 处理策略。

如果安全侧支持查询，但 hos 因原有探测失败而将 max_calls 设为 1，本步会如实返回 1。
本步不会自动提高这个既有额度。Linux 的系统会话预留能力还受到线程数量和实际客户端条件限制，
不能把“查询成功”理解为所有系统会话场景已经验证通过。

## 如何合入

见 MANUAL_MERGE.txt，包含准确锚点、基线与结果哈希及完整新增函数。
在第一步工程上应用 step02_threads.patch；若已有额外私有修改，按三处锚点手工合入。
不要同时应用 patch 和再整文件覆盖。

## 板端验证

1. 编译部署 hos，重启 serverVM 和 Android，使各自 OP-TEE 驱动重新初始化。
2. 不应再因 0xB200000F 缺少 Guest 入口而产生未处理调用。第一步已消除的
   0x32000012/0x32000013 问题也不应重新出现。
3. 默认不会新增串口输出。要确认实际返回数量，可以在调试器检查新增函数，或者临时启用已有
   OPTEE_FLOW_DBG：将 OPTEE_DEBUG_MASTER 设为 1，并将其 #if 分支中的 OPTEE_DEBUG_FLOW
   设为 1。两者需要同时设置；验证后恢复为 0。这是现有调试开关，并非新增编译选项。
4. 查询成功时可见如下格式：

```text
OPTEE-FLOW: get_thread_count: client_id=1 secure=4 limit=4 exposed=4
```

其中 4 仅为示例。secure 是安全侧查询数量，limit 是现有 hos 标准调用额度，exposed 是
返回 Guest 的值；它应等于前两者较小值。两个 Guest 使用各自的 client_id，例如 Guest ID 0
对应 client_id 1；以实际绑定日志为准。查询失败不会打印这条成功记录。

5. 分别运行第一步已通过的 TA/xtest/KeyMint 业务，再验证两个 Guest 同时调用。
   如已有并发测试，检查重复开启会话、调用和关闭会话没有新增挂起或线程耗尽回归。
6. 如发现 exposed=1，先核对既有 max_calls 和宿主侧探测结果，不要直接提高额度。
   若查询失败，记录安全侧返回的 a0；实际驱动会把查询结果视为线程数未知，仍保留旧调用路径。

板端通过标准：确认两个 Guest 正确取得可用额度，原业务和并发调用无回归。
仅凭“不再打印错误”无法确认实际返回数量，建议至少读取一次成功记录或寄存器。

## 本地验证及其限制

已从交付源码直接提取新增函数和完整分发器，使用用户提供的 SMC 定义进行隔离接口检查：

- 正常返回；已有活动调用时仍返回总额度。
- hos 额度更小、安全侧数量更小、原额度为 1。
- 安全侧不支持、不可用、返回 0、hos 额度为 0。
- SMC32 数量截取及大数量上限处理。
- 每例同时核对 Guest client_id、查询参数、寄存器保留、锁释放和额度未被修改。
- 分发器核对 CALLS_COUNT=12、新协议入口仍未开启及无上下文等路径。

合计 11 个查询场景加 1 组分发器回归检查，均通过。新增函数及分发器的 ARM64 隔离编译
使用 -Wall -Wextra -Werror 通过；补丁正向应用得到完整文件，反向应用恢复第一步基线。

上述检查使用 SMC、寄存器和锁接口的测试替身，没有执行真实 SMC；ARM64 检查也不是
完整私有工程的编译。产品构建、真实固件响应和双 Guest 板端验证仍需在你的环境执行。
测试替身未加入生产交付目录，不要求合入新的测试头文件或修改 wboxtest。

## 下一步

本包完成第二步。第三步将单独处理缓存释放、RPC 失败恢复及相关错误处理，
随后再实现 RPC_ARG / REGD_ARG；异步通知仍需结合平台实际配置。

## 协议依据

- [OP-TEE OS 4.0.0 fastcall 实现](https://raw.githubusercontent.com/OP-TEE/optee_os/4.0.0/core/arch/arm/tee/entry_fast.c)：线程查询返回 CFG_NUM_THREADS。
- [Linux 6.12 SMC 协议](https://raw.githubusercontent.com/torvalds/linux/v6.12/drivers/tee/optee/optee_smc.h)：GET_THREAD_COUNT 的返回值及寄存器保留约定。
- 实际用户提供的 smc_abi.c：optee_msg_get_thread_count() 在返回错误时取线程数量 0，供原有回退路径使用。
