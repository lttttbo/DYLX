﻿monitor_agent v2 手动合入说明（2026-10-21）
参考基线：6e1a1fbd596f3da5ed2d244ec333113b2ec70e2f
本包包含 28 个相对开源基线的新增文件、11 个开源原有文件的修改说明。
这是完整内容及定位说明，不是 patch，也不是可覆盖私有源码的整树文件包。

新增文件目录中包含完整内容；其中上一版已经新增过的 monitor 文件，本次是完整新版。
原开源文件按函数名、基线/新版行号和前后文逐段合入。行号仅用于参考，函数与分支语义优先。
产品 packed-state、GICv3、LPI、auth/mterm 代码不能被上游函数整体替换。
product 的 guest -> vm 命令适配需保留，必要时同时适配 Guest 查找 API。

重要变化：采样使用 HV 定时器 IRQ；日志队列默认 priority=3；schema=2；
ready 结束于 selected，dispatch 单独统计；collect 会进行1秒按需诊断。
平台 sample 覆盖函数必须改成 IRQ-safe；drain/publish 仍在后台。

未关闭：ROM<=5KB 未达标，CPU<0.5% 未板测；精确PMU周期未采集。
Guest 采集桥需用产品内核构建；只在匹配HVC固件上发送。
私有GICv3/DM/CCM需按说明接入，公共API模型通过不代表实际产品覆盖完成。

新增文件：
  commands/cmd_monitor.c
  core/include/vmm_monitor.h
  core/include/vmm_monitor_diag.h
  core/include/vmm_monitor_guest.h
  core/monitor/monitor_agent.c
  core/monitor/monitor_diag.c
  core/monitor/monitor_guest.c
  core/monitor/monitor_irq.c
  core/monitor/monitor_stats.c
  core/monitor/objects.mk
  core/monitor/openconf.cfg
  docs/monitor_agent.txt
  docs/monitor_agent_v2.md
  tests/monitor/arm64_12cpu.config
  tests/monitor/cross_compile.py
  tests/monitor/elf_budget.py
  tests/monitor/host.h
  tests/monitor/run_boundary_tests.py
  tests/monitor/run_host_tests.py
  tests/monitor/test_disabled.c
  tests/monitor/test_guest_parse.c
  tests/monitor/test_monitor.c
  tools/monitor_guest/Makefile
  tools/monitor_guest/monitor_guest.c
  tools/monitor_guest/monitor_parse.h
  tools/monitor_guest/monitor_uapi.h
  tools/monitor_guest/parse_monitor_jsonl.py
  tools/monitor_guest/xvisor_monitor_bridge.c

原开源修改文件：
  arch/arm/cpu/arm64/cpu_interrupts.c
  arch/arm/cpu/arm64/cpu_vcpu_excep.c
  arch/arm/cpu/common/vgic.c
  commands/objects.mk
  commands/openconf.cfg
  core/include/vmm_shmem.h
  core/openconf.cfg
  core/vmm_host_irq.c
  core/vmm_main.c
  core/vmm_scheduler.c
  core/vmm_shmem.c

先阅读需求覆盖与验证结果.txt，再阅读新增文件/docs/monitor_agent_v2.md。
