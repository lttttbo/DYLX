#!/usr/bin/env python3
"""Synthetic source anchors/schema tests; no ARM64 runtime claim."""
import sys,tempfile,subprocess,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import apply_r6 as p
import analyze_r6 as a
SMP='''#include <linux/smp.h>
void __smp_call_single_queue(int cpu, struct llist_node *node) {
 ipio_note_enqueue(cpu, node, (unsigned long)_RET_IP_);
 if (llist_add(node, &per_cpu(call_single_queue, cpu))) send_call_function_single_ipi(cpu);
}
void generic_smp_call_function_single_interrupt(void) {
 ipio_irq_enter();
 flush_smp_call_function_queue(true);
 ipio_irq_exit();
}
static void flush_smp_call_function_queue(bool warn_cpu_offline) {
 struct llist_node *entry;
 entry = llist_del_all(head);
 entry = llist_reverse_order(entry);
 ipio_note_batch(entry);
 original_callbacks(entry);
}
'''
VH='''#include "vhost.h"
static void vhost_work_queue_tagged(struct vhost_dev *dev, struct vhost_work *work, enum n5_source source) {
 int woke;
 if (!dev->worker) return;
 if (!test_and_set_bit(VHOST_WORK_QUEUED, &work->flags)) {
  llist_add(&work->node, &dev->work_list);
  woke = wake_up_process(dev->worker);
  n5_note_queue(dev, work, source, woke ? 1 : 0);
 } else {
  n5_note_queue(dev, work, source, 2);
 }
}
static int vhost_worker(void *data) {
 for (;;) {
  clear_bit(VHOST_WORK_QUEUED, &work->flags);
  __set_current_state(TASK_RUNNING);
  n5_note_execute(dev, work);
  work->fn(work);
 }
 return 0;
}
'''
NET='''#include "vhost.h"
static void handle_tx(struct vhost_net *net) {
 struct vhost_virtqueue *vq;
 mutex_lock_nested(&vq->mutex, VHOST_NET_VQ_TX);
 original_tx();
out:
 vhost_n5_tx_end(&net->n5_tx, vq);
 mutex_unlock(&vq->mutex);
}
static void handle_tx_net(struct vhost_work *work) {
 n4_handle_tx(net, 2);
}
'''
CCM='''#include "ccm_drv.h"
static int ioeventfd_handler(struct ioreq_client *client, struct io_request *req) {
 u64 addr = req->reqs.mmio_request.address;
 mutex_lock(&client->vm->ioeventfds_lock);
 p = ccm_ioeventfd_match(client->vm, addr, val, size, req->type);
 if(p) { eventfd_signal(p->eventfd, 1); }
 mutex_unlock(&client->vm->ioeventfds_lock);
 return 0;
}
'''
TP='TRACE_EVENT(sched_switch, TP_PROTO(bool preempt, struct task_struct *prev, struct task_struct *next), TP_ARGS(preempt,prev,next));'
def synthetic_report():
 rows=['R6,version=1,run=0,epoch=1,start_ns=1000000000,stop_ns=4000000000,shift=8,tx_addr=0x6020003004','IPI_TOTAL,handler_entries=100','TX,bound=1,completed=100,heads=100,identity_error=0,bad_heads=0,config_changes=0']
 for role in ['ioeventfd','vhost']:
  rows+=['TASK,'+role+',services=1,valid_samples=1','CHECK_TASK,'+role+',invalid=0']
  vals={'waking_to_activation':500,'activation_to_switch':400,'waking_to_switch':900,'waking_to_publish':100,'publish_to_rx_batch':300,'rx_batch_to_activation':100}
  for name,v in vals.items():
   rows.append(f'DIST,{role},queued_ipi,{name},1,{v},{v},{v},{v}')
   h=[0]*24;b=0;z=v
   while z>=64 and b<23:z>>=1;b+=1
   h[b]=1;rows.append('HIST,'+role+',queued_ipi,'+name+','+','.join(map(str,h)))
 return '\n'.join(rows)+'\n'
class Tests(unittest.TestCase):
 def test_smp_order(self):
  s=p.smp(SMP);self.assertLess(s.index('r6_ttwu_publish(cpu'),s.index('llist_add'))
  self.assertLess(s.index('llist_reverse_order'),s.index('r6_call_batch'))
 def test_worker_generation(self):
  s=p.vhost(VH);self.assertLess(s.index('r6_work_execute'),s.index('clear_bit'))
  self.assertLess(s.index('r6_work_publish'),s.index('llist_add'));self.assertEqual(s.count('wake_up_process('),1)
 def test_no_double_wake(self):
  with self.assertRaises(p.Refuse):p.vhost(VH.replace('woke = wake_up_process(dev->worker);','wake_up_process(dev->worker); woke = wake_up_process(dev->worker);'))
 def test_unknown_anchor(self):
  with self.assertRaises(p.Refuse):p.smp(SMP.replace('ipio_note_batch(entry);','other(entry);'))
 def test_origin(self):
  with self.assertRaises(p.Refuse):p.net(NET.replace('n4_handle_tx(net, 2)','n4_handle_tx(net, 1)'))
 def test_ccm(self):
  s=p.ccm(CCM);self.assertLess(s.index('r6_io_service'),s.index('mutex_lock'));self.assertEqual(s.count('eventfd_signal('),1)
 def test_abi(self):
  self.assertEqual(p.switch_abi(TP),0);self.assertEqual(p.switch_abi(TP.replace('*next)', '*next, unsigned int prev_state)')),1)
  with self.assertRaises(p.Refuse):p.switch_abi(TP.replace('bool preempt','int unknown'))
 def test_apply_restore(self):
  with tempfile.TemporaryDirectory() as td:
   r=Path(td)/'k';cp=Path(td)/'ccm/ioeventfd.c'
   files={r/'kernel/smp.c':SMP,r/'drivers/vhost/vhost.c':VH,r/'drivers/vhost/net.c':NET,r/'kernel/Makefile':'obj-y += fork.o\n',r/'include/trace/events/sched.h':TP,cp:CCM}
   for f,s in files.items():f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
   cmd=[sys.executable,str(ROOT/'apply_r6.py'),'--kernel',str(r),'--ccm',str(cp),'--out',str(Path(td)/'out')]
   subprocess.run(cmd+['--check'],check=True,stdout=subprocess.PIPE)
   for f,s in files.items():self.assertEqual(f.read_text(),s)
   subprocess.run(cmd+['--apply'],check=True,stdout=subprocess.PIPE)
   subprocess.run([sys.executable,str(ROOT/'apply_r6.py'),'--kernel',str(r),'--restore'],check=True,stdout=subprocess.PIPE)
   for f,s in files.items():self.assertEqual(f.read_text(),s)
 def test_analyzer_good(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);(d/'r6_report.txt').write_text(synthetic_report());o=a.analyze(d)
   self.assertFalse(o['errors']);self.assertEqual(len(o['within_cycle_closure']),4);self.assertTrue((d/'r6_compact.txt').exists())
 def test_analyzer_bad_partition(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);s=synthetic_report().replace('waking_to_switch,1,900,900,900,900','waking_to_switch,1,901,901,901,901');(d/'r6_report.txt').write_text(s)
   self.assertTrue(a.analyze(d)['errors'])
 def test_baseline(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);(d/'r6_report.txt').write_text('R6,version=1,run=0,start_ns=100,stop_ns=1000000100,shift=-2\nIPI_TOTAL,handler_entries=0\nTX,bound=0,completed=0,heads=0\n')
   o=a.analyze(d);self.assertFalse(o['errors']);self.assertIsNone(o['rates']['ipi_handler_entries_per_s'])
 def test_hist(self):
  h=[0]*24;h[3]=1;self.assertEqual(a.quantile(h,.95),{'lower_ns':256,'upper_exclusive_ns':512})
if __name__=='__main__':unittest.main(verbosity=2)
