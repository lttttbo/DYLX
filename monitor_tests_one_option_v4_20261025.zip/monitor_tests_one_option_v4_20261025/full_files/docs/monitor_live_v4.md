# Monitor v4 统一测试集

> 配置更新：当前统一使用 CONFIG_WBOXTEST_MONITOR，一个开关运行 6 个隔离用例和 3 个 Hypervisor 用例。下文 HOST/LIVE 子开关及 12 用例组合属于历史版本；当前执行步骤以 [单开关说明](monitor_one_option_v4.md) 为准。Guest 现场源码保留但本阶段不编译。

所有隔离和现场用例均归属 `monitor` 测试集。现场代码位于 `libs/wboxtest/monitor/live/`。

请阅读 [需求覆盖与验收说明](monitor_test_coverage_v4.md)。原专用测试 Guest/mailbox 操作步骤不再适用。
既有 `monitor_live target` 命令和 `monitor_live_*` 用例名称继续保留，便于兼容日志核对工具；它们不再是独立测试组。
