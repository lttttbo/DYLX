// SPDX-License-Identifier: GPL-2.0-only
/* Diagnostic only. Built-in, with GPL exports for CCM and vhost modules.
 * Existing scheduler tracepoints feed private aggregates, NOT an ftrace ring.
 * IRQ hooks receive a detached list before its callbacks or CSD reuse.
 * The two pinned task identities and per-wakeup generations prevent TID reuse.
 * Work pending generations are detached BEFORE the original queued-bit clear.
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <linux/sched/task.h>
#include <linux/sched/signal.h>
#include <linux/tracepoint.h>
#include <linux/ktime.h>
#include <linux/percpu.h>
#include <linux/spinlock.h>
#include <linux/mutex.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/hash.h>
#include <linux/interrupt.h>
#include <linux/llist.h>
#include <linux/math64.h>
#include <linux/netdevice.h>
#include <net/net_namespace.h>
#include <linux/r6_notify.h>
#include <trace/events/sched.h>
#include "r6_build_config.h"
#include "r6_math.h"
#if !defined(CONFIG_SMP) || !defined(CONFIG_TRACEPOINTS) || !defined(CONFIG_PROC_FS)
#error "R6 needs CONFIG_SMP, CONFIG_TRACEPOINTS and CONFIG_PROC_FS"
#endif
#define NT 2
#define NP 5
#define NS 24
#define NW 2
#define WS 16
/* Report paths: no_queue_same_cpu, queued_ipi, queued_non_ipi,
 * no_queue_remote_cpu (direct remote rq activation), queued_missing_rx. */
enum { LOCAL, QIPI, QOTHER, REMOTE_DIRECT, BAD_RX };
enum { WA, AR, WR, WQ, QD, DA, RH, WH, SRC_RETURN, ND };
static const char *const roles[] = {"ioeventfd", "vhost"};
static const char *const paths[] = {"no_queue_same_cpu", "queued_ipi", "queued_non_ipi", "no_queue_remote_cpu", "queued_missing_rx"};
static const char *const dn[] = {"waking_to_activation", "activation_to_switch", "waking_to_switch", "waking_to_publish", "publish_to_rx_batch", "rx_batch_to_activation", "switch_to_first_service", "waking_to_first_service", "publish_call_elapsed_NOT_ADDITIVE"};
struct cycle {
        u64 seq,w,q,d,a,r;
        bool sampled,queued,rx_ipi,switched,serviced,valid;
        int src_cpu,dst_cpu,act_cpu,path;
};
struct source { int pid,cpu,ctx; char comm[TASK_COMM_LEN]; u64 n; };
struct task_stats {
        raw_spinlock_t lock;
        struct task_struct *task;
        struct llist_node *node;
        int pid; char comm[TASK_COMM_LEN];
        struct cycle c;
        struct r6_dist dist[NP][ND];
        struct source src[NS];
        u64 seq,waking,queued,rx_ipi,rx_other,activated,switches,services;
        u64 overwritten,no_waking,duplicate,invalid,incomplete_rx,no_service;
        u64 source_overflow,migrated,post_switch_out,selected,valid_samples,serviced_samples;
};
struct irq_stats { raw_spinlock_t lock; u64 epoch,count,begin; unsigned int depth; bool sampled; struct r6_dist elapsed; };
static struct task_stats ts[NT];
static DEFINE_PER_CPU(struct irq_stats, irqs);
static DEFINE_MUTEX(control);
static bool running, measuring, probes;
static u64 epoch,start_ns,stop_ns,tx_addr;
static int shift=8;
/* baseline mode, shift=-2, collects only two endpoint snapshots. */
struct net_snapshot { bool valid; u64 begin,end; struct rtnl_link_stats64 s; };
static struct net_snapshot nb[2],na[2];
static const char *const ifname[]={"eth0","tap1"};
static void net_snapshot(struct net_snapshot dst[2])
{
        int i;
        for(i=0;i<2;i++) {
                struct net_device *d;
                const struct rtnl_link_stats64 *s;
                memset(&dst[i],0,sizeof(dst[i])); dst[i].begin=ktime_get_ns();
                d=dev_get_by_name(&init_net,ifname[i]);
                if(d) { s=dev_get_stats(d,&dst[i].s); if(s!=&dst[i].s) dst[i].s=*s; dst[i].valid=true; dev_put(d); }
                dst[i].end=ktime_get_ns();
        }
}
static bool live(u64 *e)
{
        *e=READ_ONCE(epoch);
        return smp_load_acquire(&running) && !in_nmi();
}
static bool same_epoch(u64 e) { return smp_load_acquire(&running) && e==READ_ONCE(epoch); }
static bool select_sample(u64 seq,u64 e)
{
        int s=READ_ONCE(shift);
        if(s<0) return false;
        return !s || hash_64(seq ^ (e*0x9e3779b97f4a7c15ULL),s)==0;
}
static int slot(struct task_struct *p)
{
        if(p==READ_ONCE(ts[0].task)) return 0;
        if(p==READ_ONCE(ts[1].task)) return 1;
        return -1;
}
static int node_slot(struct llist_node *p)
{
        if(p==READ_ONCE(ts[0].node)) return 0;
        if(p==READ_ONCE(ts[1].node)) return 1;
        return -1;
}
static void clean_comm(char *s)
{
        s[TASK_COMM_LEN-1]=0;
        strreplace(s,',','_'); strreplace(s,'\n','_'); strreplace(s,'\r','_');
}
static void record_source(struct task_stats *s)
{
        int i,pid=task_pid_nr(current),cpu=raw_smp_processor_id();
        int ctx=in_irq()?1:(in_serving_softirq()?2:0);
        for(i=0;i<NS;i++) {
                struct source *x=&s->src[i];
                if(!x->n) { x->pid=pid;x->cpu=cpu;x->ctx=ctx;memcpy(x->comm,current->comm,TASK_COMM_LEN);clean_comm(x->comm); }
                if(x->pid==pid && x->cpu==cpu && x->ctx==ctx) { ++x->n;return; }
        }
        ++s->source_overflow;
}
static void on_waking(void *unused,struct task_struct *p)
{
        struct task_stats *s; unsigned long f; u64 e; int k;
        if(!live(&e) || (k=slot(p))<0) return;
        s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
        if(!same_epoch(e) || s->task!=p) goto out;
        ++s->waking;record_source(s);
        if(s->c.sampled && s->c.w) {
                if(!s->c.switched) ++s->overwritten;
                else if(!s->c.serviced) ++s->no_service;
        }
        memset(&s->c,0,sizeof(s->c));s->c.seq=++s->seq;
        s->c.src_cpu=raw_smp_processor_id();s->c.sampled=select_sample(s->seq,e);
        if(s->c.sampled) { ++s->selected;s->c.w=ktime_get_ns(); }
out: raw_spin_unlock_irqrestore(&s->lock,f);
}
struct r6_queue_token r6_ttwu_publish(int cpu,struct llist_node *node)
{
        struct r6_queue_token t={.slot=-1};
        struct task_stats *s;unsigned long f;u64 e;int k;
        if(!live(&e) || (k=node_slot(node))<0) return t;
        s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
        if(!same_epoch(e) || s->node!=node) goto out;
        ++s->queued;s->c.queued=true;s->c.dst_cpu=cpu;
        if(!s->c.sampled) goto out;
        if(!s->c.w || s->c.q || s->c.a || s->c.switched) { ++s->duplicate;goto out; }
        s->c.q=ktime_get_ns();t.epoch=e;t.seq=s->c.seq;t.slot=k;t.begin_ns=s->c.q;
out: raw_spin_unlock_irqrestore(&s->lock,f);return t;
}
void r6_ttwu_publish_return(struct r6_queue_token t)
{
        struct task_stats *s;unsigned long f;u64 now;
        if(t.slot<0 || t.slot>=NT || !t.begin_ns || !same_epoch(t.epoch)) return;
        now=ktime_get_ns();s=&ts[t.slot];raw_spin_lock_irqsave(&s->lock,f);
        if(same_epoch(t.epoch)) {
                if(now>=t.begin_ns) r6_add(&s->dist[QIPI][SRC_RETURN],now-t.begin_ns);else ++s->invalid;
                /* Receiver may already have completed. Never overwrite c. */
        }
        raw_spin_unlock_irqrestore(&s->lock,f);
}
void r6_call_irq_enter(void)
{
        struct irq_stats *s;unsigned long f;u64 e;
        if(!live(&e)) return;
        local_irq_save(f);s=this_cpu_ptr(&irqs);raw_spin_lock(&s->lock);
        if(same_epoch(e)) {
                if(s->epoch!=e) { s->epoch=e;s->depth=0; }
                if(!s->depth++) { ++s->count;s->sampled=select_sample(s->count,e);s->begin=s->sampled?ktime_get_ns():0; }
        }
        raw_spin_unlock(&s->lock);local_irq_restore(f);
}
void r6_call_irq_exit(void)
{
        struct irq_stats *s;unsigned long f;u64 e,now;
        if(!live(&e)) return;
        local_irq_save(f);s=this_cpu_ptr(&irqs);raw_spin_lock(&s->lock);
        if(same_epoch(e) && s->epoch==e && s->depth && !--s->depth && s->sampled) {
                now=ktime_get_ns();if(now>=s->begin) r6_add(&s->elapsed,now-s->begin);
        }
        raw_spin_unlock(&s->lock);local_irq_restore(f);
}
void r6_call_batch(struct llist_node *entry)
{
        struct llist_node *n;struct irq_stats *pc;unsigned long f;u64 e;bool ipi;
        if(!live(&e)) return;
        /* Caller owns the detached list and already has IRQs disabled. */
        pc=this_cpu_ptr(&irqs);ipi=READ_ONCE(pc->epoch)==e && READ_ONCE(pc->depth);
        for(n=entry;n;n=n->next) {
                struct task_stats *s;int k=node_slot(n);
                if(k<0) continue;
                s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
                if(same_epoch(e) && s->node==n) {
                        if(ipi) ++s->rx_ipi;else ++s->rx_other;
                        if(s->c.sampled) {
                                if(!s->c.q || s->c.d || s->c.a) ++s->incomplete_rx;
                                else { s->c.d=ktime_get_ns();s->c.rx_ipi=ipi; }
                        }
                }
                raw_spin_unlock_irqrestore(&s->lock,f);
        }
}
static void on_wakeup(void *unused,struct task_struct *p)
{
        struct task_stats *s;unsigned long f;u64 e;int k;
        if(!live(&e) || (k=slot(p))<0) return;
        s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
        if(!same_epoch(e) || s->task!=p) goto out;
        ++s->activated;
        if(!s->c.sampled) goto out;
        if(!s->c.w || s->c.a) { ++s->no_waking;goto out; }
        s->c.a=ktime_get_ns();s->c.act_cpu=task_cpu(p);
        s->c.path=s->c.queued?(s->c.d?(s->c.rx_ipi?QIPI:QOTHER):BAD_RX)
                :(s->c.src_cpu==task_cpu(p)?LOCAL:REMOTE_DIRECT);
out: raw_spin_unlock_irqrestore(&s->lock,f);
}
#if R6_SWITCH_HAS_PREV_STATE
static void on_switch(void *unused,bool preempt,struct task_struct *prev,
                      struct task_struct *next,unsigned int prev_state)
#else
static void on_switch(void *unused,bool preempt,struct task_struct *prev,
                      struct task_struct *next)
#endif
{
        struct task_stats *s;unsigned long f;u64 e,part[6];int k,j,p;
        if(!live(&e)) return;
        k=slot(prev);
        if(k>=0) {
                s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
                if(same_epoch(e) && s->c.sampled && s->c.switched && !s->c.serviced) ++s->post_switch_out;
                raw_spin_unlock_irqrestore(&s->lock,f);
        }
        if((k=slot(next))<0) return;
        s=&ts[k];raw_spin_lock_irqsave(&s->lock,f);
        if(!same_epoch(e) || s->task!=next) goto out;
        ++s->switches;
        if(!s->c.sampled || s->c.switched) goto out;
        if(!s->c.w || !s->c.a) { ++s->no_waking;goto out; }
        s->c.r=ktime_get_ns();s->c.switched=true;
        if(s->c.act_cpu!=raw_smp_processor_id()) ++s->migrated;
        p=s->c.path;
        if(p==BAD_RX || r6_partition(s->c.w,s->c.q,s->c.d,s->c.a,s->c.r,s->c.queued,part)) { ++s->invalid;goto out; }
        s->c.valid=true;++s->valid_samples;
        for(j=0;j<3;j++) r6_add(&s->dist[p][j],part[j]);
        if(s->c.queued) for(j=3;j<6;j++) r6_add(&s->dist[p][j],part[j]);
out: raw_spin_unlock_irqrestore(&s->lock,f);
}
static void service(int k)
{
        struct task_stats *s=&ts[k];unsigned long f;u64 e,now;
        if(!live(&e) || current!=READ_ONCE(s->task)) return;
        raw_spin_lock_irqsave(&s->lock,f);
        if(!same_epoch(e) || current!=s->task) goto out;
        ++s->services;
        if(s->c.sampled && s->c.valid && s->c.switched && !s->c.serviced) {
                now=ktime_get_ns();s->c.serviced=true;
                if(now>=s->c.r) { r6_add(&s->dist[s->c.path][RH],now-s->c.r);r6_add(&s->dist[s->c.path][WH],now-s->c.w);++s->serviced_samples; }
                else ++s->invalid;
        }
out: raw_spin_unlock_irqrestore(&s->lock,f);
}
void r6_io_service(u64 addr) { if(READ_ONCE(running) && addr==READ_ONCE(tx_addr)) service(0); }
EXPORT_SYMBOL_GPL(r6_io_service);
/* Separate work generations. No diagnostic lock spans an original operation. */
enum { QX,XH,HL,LF,FE,QE,QH,PUBLISH_RETURN,NWD };
static const char *const wn[]={"publish_to_execute","execute_to_tx_entry","tx_mutex_wait","tx_locked_elapsed","tx_leave_to_work_return","publish_to_work_return","publish_to_tx_entry","publish_to_wake_return_NOT_ADDITIVE"};
struct work_sample { u64 gen,q,x,h,l,f; unsigned int source; bool sampled,active; };
struct work_stats {
        struct work_sample pending,executing;
        u64 seq,queued[WS],merged[WS],wake0[WS],wake1[WS];
        u64 executed,complete,sampled,invalid,prewindow,overwritten,missing_tx;
        struct r6_dist dist[WS][NWD];
};
static DEFINE_RAW_SPINLOCK(work_lock);
static struct work_stats ws[NW];
static void *bound_dev,*bound_work[NW];
static u64 bind_count,identity_error,tx_calls,heads,bad_heads,unbound,config_changes;
static bool cfg_set,cfg_packed,cfg_event;
static unsigned int cfg_busy,cfg_size;
static int kind(void *dev,void *work,struct task_struct *worker)
{
        if(worker!=READ_ONCE(ts[1].task) || !dev || dev!=bound_dev) return -1;
        if(work==bound_work[0]) return 0;
        if(work==bound_work[1]) return 1;
        return -1;
}
static unsigned int source_index(unsigned int x) { return x<WS?x:WS-1; }
struct r6_work_token r6_work_publish(void *dev,void *work,struct task_struct *worker,unsigned int src)
{
        struct r6_work_token t={.kind=-1};struct work_stats *s;unsigned long f;u64 e;int k;
        if(!live(&e) || worker!=READ_ONCE(ts[1].task)) return t;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(e)) goto out;
        k=kind(dev,work,worker);
        if(k<0) { if(!bound_dev) ++unbound;goto out; }
        src=source_index(src);s=&ws[k];++s->queued[src];
        if(s->pending.active) ++s->overwritten;
        memset(&s->pending,0,sizeof(s->pending));s->pending.gen=++s->seq;
        s->pending.source=src;s->pending.active=true;s->pending.sampled=select_sample(s->seq,e);
        if(s->pending.sampled) s->pending.q=ktime_get_ns();
        t.kind=k;t.epoch=e;t.seq=s->seq;t.source=src;t.begin_ns=s->pending.q;
out: raw_spin_unlock_irqrestore(&work_lock,f);return t;
}
EXPORT_SYMBOL_GPL(r6_work_publish);
void r6_work_wake_return(struct r6_work_token t,int original_return)
{
        struct work_stats *s;unsigned long f;u64 now;
        if(t.kind<0 || t.kind>=NW || !same_epoch(t.epoch)) return;
        now=t.begin_ns?ktime_get_ns():0;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(t.epoch)) goto out;
        s=&ws[t.kind];
        if(original_return) ++s->wake1[t.source];else ++s->wake0[t.source];
        if(t.begin_ns && now>=t.begin_ns) r6_add(&s->dist[t.source][PUBLISH_RETURN],now-t.begin_ns);
        /* Immutable caller token: never modify a possibly reused work sample. */
out: raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_work_wake_return);
void r6_work_merged(void *dev,void *work,struct task_struct *worker,unsigned int src)
{
        unsigned long f;u64 e;int k;
        if(!live(&e) || worker!=READ_ONCE(ts[1].task)) return;
        raw_spin_lock_irqsave(&work_lock,f);
        if(same_epoch(e) && (k=kind(dev,work,worker))>=0) ++ws[k].merged[source_index(src)];
        raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_work_merged);
void r6_work_execute(void *dev,void *work,struct task_struct *worker)
{
        struct work_stats *s;unsigned long f;u64 e;int k;
        if(!live(&e) || current!=worker) return;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(e) || (k=kind(dev,work,worker))<0) goto out;
        s=&ws[k];++s->executed;
        if(s->executing.active) ++s->overwritten;
        /* BEFORE queued-bit clear: detach the old pending generation first. */
        s->executing=s->pending;memset(&s->pending,0,sizeof(s->pending));
        if(!s->executing.active) { ++s->prewindow;goto out; }
        if(s->executing.sampled) s->executing.x=ktime_get_ns();
out: raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_work_execute);
void r6_work_complete(void *dev,void *work,struct task_struct *worker)
{
        struct work_stats *s;struct work_sample *t;unsigned long f;u64 e,end;int k;
        if(!live(&e) || current!=worker) return;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(e) || (k=kind(dev,work,worker))<0) goto out;
        s=&ws[k];++s->complete;t=&s->executing;
        if(!t->active || !t->sampled) goto clear;
        end=ktime_get_ns();
        if(!t->q || !t->x || t->q>t->x || t->x>end) { ++s->invalid;goto clear; }
        if(!t->h || !t->l || !t->f) { ++s->missing_tx;goto clear; }
        if(t->x>t->h || t->h>t->l || t->l>t->f || t->f>end) { ++s->invalid;goto clear; }
        ++s->sampled;
        r6_add(&s->dist[t->source][QX],t->x-t->q);
        r6_add(&s->dist[t->source][XH],t->h-t->x);
        r6_add(&s->dist[t->source][HL],t->l-t->h);
        r6_add(&s->dist[t->source][LF],t->f-t->l);
        r6_add(&s->dist[t->source][FE],end-t->f);
        r6_add(&s->dist[t->source][QE],end-t->q);
        r6_add(&s->dist[t->source][QH],t->h-t->q);
clear: memset(&s->executing,0,sizeof(s->executing));
out: raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_work_complete);
struct r6_tx_token r6_tx_enter(void *dev,void *kick,void *backend,struct task_struct *worker)
{
        struct r6_tx_token t={.kind=-1};unsigned long f;u64 e;int k;
        if(!live(&e) || current!=worker || worker!=READ_ONCE(ts[1].task)) return t;
        service(1);
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(e)) goto out;
        if(!bound_dev) { bound_dev=dev;bound_work[0]=kick;bound_work[1]=backend;++bind_count; }
        if(bound_dev!=dev || bound_work[0]!=kick || bound_work[1]!=backend) { ++identity_error;goto out; }
        t.active=true;t.epoch=e;
        for(k=0;k<NW;k++) if(ws[k].executing.active) {
                t.kind=k;t.seq=ws[k].executing.gen;
                if(ws[k].executing.sampled) ws[k].executing.h=ktime_get_ns();
                break;
        }
out: raw_spin_unlock_irqrestore(&work_lock,f);return t;
}
EXPORT_SYMBOL_GPL(r6_tx_enter);
void r6_tx_locked(struct r6_tx_token *t,u16 avail,bool packed,bool event_idx,unsigned int busy,unsigned int size)
{
        unsigned long f;
        if(!t->active || !same_epoch(t->epoch)) return;
        t->before=avail;t->packed=packed;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(t->epoch)) goto out;
        if(!cfg_set) { cfg_set=true;cfg_packed=packed;cfg_event=event_idx;cfg_busy=busy;cfg_size=size; }
        else if(cfg_packed!=packed || cfg_event!=event_idx || cfg_busy!=busy || cfg_size!=size) ++config_changes;
        if(t->kind>=0 && ws[t->kind].executing.gen==t->seq && ws[t->kind].executing.sampled) ws[t->kind].executing.l=ktime_get_ns();
out: raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_tx_locked);
void r6_tx_leave(struct r6_tx_token *t,u16 avail)
{
        unsigned long f;u16 n=(u16)(avail-t->before);
        if(!t->active || !same_epoch(t->epoch)) return;
        raw_spin_lock_irqsave(&work_lock,f);
        if(!same_epoch(t->epoch)) goto out;
        ++tx_calls;if(t->packed || n>32768U) ++bad_heads;else heads+=n;
        if(t->kind>=0 && ws[t->kind].executing.gen==t->seq && ws[t->kind].executing.sampled) ws[t->kind].executing.f=ktime_get_ns();
out: raw_spin_unlock_irqrestore(&work_lock,f);
}
EXPORT_SYMBOL_GPL(r6_tx_leave);

/* Control registration is outside the measurement window. */
static int register_probes(void)
{
        int e;
        e=register_trace_sched_waking(on_waking,NULL);if(e) return e;
        e=register_trace_sched_wakeup(on_wakeup,NULL);if(e) goto drop_waking;
        e=register_trace_sched_switch(on_switch,NULL);if(e) goto drop_wakeup;
        probes=true;return 0;
drop_wakeup: unregister_trace_sched_wakeup(on_wakeup,NULL);
drop_waking: unregister_trace_sched_waking(on_waking,NULL);tracepoint_synchronize_unregister();return e;
}
static void stop_capture(void)
{
        unsigned long f;int k,cpu;
        if(measuring) {
                smp_store_release(&running,false);stop_ns=ktime_get_ns();net_snapshot(na);measuring=false;
        }
        if(probes) {
                unregister_trace_sched_switch(on_switch,NULL);
                unregister_trace_sched_wakeup(on_wakeup,NULL);
                unregister_trace_sched_waking(on_waking,NULL);
                tracepoint_synchronize_unregister();probes=false;
        }
        for(k=0;k<NT;k++) { raw_spin_lock_irqsave(&ts[k].lock,f);raw_spin_unlock_irqrestore(&ts[k].lock,f); }
        for_each_possible_cpu(cpu) {
                struct irq_stats *p=&per_cpu(irqs,cpu);
                raw_spin_lock_irqsave(&p->lock,f);raw_spin_unlock_irqrestore(&p->lock,f);
        }
        raw_spin_lock_irqsave(&work_lock,f);raw_spin_unlock_irqrestore(&work_lock,f);
}
static struct task_struct *get_task(int pid)
{
        struct task_struct *p;
        rcu_read_lock();p=find_task_by_vpid(pid);if(p) get_task_struct(p);rcu_read_unlock();return p;
}
static int start_capture(int io,int vh,int sh,u64 addr)
{
        struct task_struct *p[2];unsigned long f;int k,cpu,e;
        if(measuring) return -EBUSY;
        if(io<=0 || vh<=0 || io==vh || sh< -2 || sh>16 || !addr) return -EINVAL;
        p[0]=get_task(io);p[1]=get_task(vh);
        if(!p[0] || !p[1]) { if(p[0]) put_task_struct(p[0]);if(p[1]) put_task_struct(p[1]);return -ESRCH; }
        stop_capture();++epoch;shift=sh;tx_addr=addr;
        for(k=0;k<NT;k++) {
                struct task_stats *s=&ts[k];struct task_struct *old=s->task;
                raw_spin_lock_irqsave(&s->lock,f);
                memset((char *)s+offsetof(struct task_stats,task),0,sizeof(*s)-offsetof(struct task_stats,task));
                s->task=p[k];s->node=&p[k]->wake_entry.llist;s->pid=task_pid_nr(p[k]);
                memcpy(s->comm,p[k]->comm,TASK_COMM_LEN);clean_comm(s->comm);
                raw_spin_unlock_irqrestore(&s->lock,f);
                if(old) put_task_struct(old);
        }
        for_each_possible_cpu(cpu) {
                struct irq_stats *s=&per_cpu(irqs,cpu);
                raw_spin_lock_irqsave(&s->lock,f);
                memset((char *)s+offsetof(struct irq_stats,epoch),0,sizeof(*s)-offsetof(struct irq_stats,epoch));
                raw_spin_unlock_irqrestore(&s->lock,f);
        }
        raw_spin_lock_irqsave(&work_lock,f);
        memset(ws,0,sizeof(ws));bound_dev=NULL;bound_work[0]=bound_work[1]=NULL;
        bind_count=identity_error=tx_calls=heads=bad_heads=unbound=config_changes=0;
        cfg_set=cfg_packed=cfg_event=false;cfg_busy=cfg_size=0;
        raw_spin_unlock_irqrestore(&work_lock,f);
        if(sh>= -1) { e=register_probes();if(e) return e; }
        net_snapshot(nb);memset(na,0,sizeof(na));stop_ns=0;start_ns=ktime_get_ns();measuring=true;
        if(sh>= -1) smp_store_release(&running,true);
        return 0;
}
static void print_dist(struct seq_file *m,const char *type,const char *role,const char *path,const char *name,const struct r6_dist *d)
{
        int i;
        if(!d->n) return;
        seq_printf(m,"%s,%s,%s,%s,%llu,%llu,%llu,%llu,%llu\n",type,role,path,name,d->n,d->sum,div64_u64(d->sum,d->n),d->min,d->max);
        seq_printf(m,"HIST,%s,%s,%s",role,path,name);
        for(i=0;i<R6_HBINS;i++) seq_printf(m,",%llu",d->bins[i]);
        seq_putc(m,'\n');
}
static int show_report(struct seq_file *m,void *unused)
{
        int k,i,j,cpu;u64 total=0;
        mutex_lock(&control);
        if(measuring) { mutex_unlock(&control);return -EBUSY; }
        seq_printf(m,"R6,version=1,run=0,epoch=%llu,start_ns=%llu,stop_ns=%llu,shift=%d,tx_addr=0x%llx\n",epoch,start_ns,stop_ns,shift,tx_addr);
        seq_puts(m,"# DIST/WDIST: role,path_or_source,metric,count,sum_ns,mean_ns,min_ns,max_ns\n");
        seq_puts(m,"# HIST bin0=[0,64)ns; bin1=[64,128)ns; last=[268435456,+inf)ns\n");
        seq_puts(m,"# switch is BEFORE context_switch; service is first selected handler. Wall time != CPU runtime.\n");
        for(k=0;k<NT;k++) {
                struct task_stats *s=&ts[k];
                seq_printf(m,"TASK,%s,pid=%d,comm=%s,waking=%llu,queued=%llu,rx_ipi=%llu,rx_other=%llu,activated=%llu,switches=%llu,services=%llu,selected=%llu,valid_samples=%llu,serviced_samples=%llu\n",roles[k],s->pid,s->comm,s->waking,s->queued,s->rx_ipi,s->rx_other,s->activated,s->switches,s->services,s->selected,s->valid_samples,s->serviced_samples);
                seq_printf(m,"CHECK_TASK,%s,overwritten=%llu,no_waking=%llu,duplicate=%llu,invalid=%llu,incomplete_rx=%llu,no_service=%llu,source_overflow=%llu,migrated=%llu,post_switch_out=%llu,pending_at_stop=%u\n",roles[k],s->overwritten,s->no_waking,s->duplicate,s->invalid,s->incomplete_rx,s->no_service,s->source_overflow,s->migrated,s->post_switch_out,(unsigned int)(s->c.sampled && s->c.w && !s->c.serviced));
                for(i=0;i<NS;i++) if(s->src[i].n) seq_printf(m,"SOURCE,%s,pid=%d,cpu=%d,context=%d,comm=%s,count=%llu\n",roles[k],s->src[i].pid,s->src[i].cpu,s->src[i].ctx,s->src[i].comm,s->src[i].n);
                for(i=0;i<NP;i++) for(j=0;j<ND;j++) print_dist(m,"DIST",roles[k],j==SRC_RETURN?"independent_publish_api":paths[i],dn[j],&s->dist[i][j]);
        }
        for_each_possible_cpu(cpu) {
                struct irq_stats *p=&per_cpu(irqs,cpu);total+=p->count;
                seq_printf(m,"IPI_CPU,cpu=%d,handler_entries=%llu,timed_samples=%llu,elapsed_sum_ns=%llu\n",cpu,p->count,p->elapsed.n,p->elapsed.sum);
        }
        seq_printf(m,"IPI_TOTAL,handler_entries=%llu\n",total);
        for(i=0;i<2;i++) {
                struct net_snapshot *b=&nb[i],*a=&na[i];
                bool ok=b->valid && a->valid && a->s.tx_packets>=b->s.tx_packets && a->s.rx_packets>=b->s.rx_packets && a->s.tx_bytes>=b->s.tx_bytes && a->s.rx_bytes>=b->s.rx_bytes;
                seq_printf(m,"NET,%s,valid=%u,before_begin_ns=%llu,before_end_ns=%llu,after_begin_ns=%llu,after_end_ns=%llu,tx_packets=%llu,rx_packets=%llu,tx_bytes=%llu,rx_bytes=%llu,tx_dropped=%llu,rx_dropped=%llu\n",ifname[i],(unsigned int)ok,b->begin,b->end,a->begin,a->end,ok?a->s.tx_packets-b->s.tx_packets:0,ok?a->s.rx_packets-b->s.rx_packets:0,ok?a->s.tx_bytes-b->s.tx_bytes:0,ok?a->s.rx_bytes-b->s.rx_bytes:0,a->s.tx_dropped>=b->s.tx_dropped?a->s.tx_dropped-b->s.tx_dropped:0,a->s.rx_dropped>=b->s.rx_dropped?a->s.rx_dropped-b->s.rx_dropped:0);
        }
        seq_printf(m,"TX,bound=%u,bind_count=%llu,identity_error=%llu,unbound_hooks=%llu,completed=%llu,heads=%llu,bad_heads=%llu,event_idx=%u,packed=%u,busyloop_us=%u,ring_size=%u,config_changes=%llu\n",(unsigned int)(bound_dev!=NULL),bind_count,identity_error,unbound,tx_calls,heads,bad_heads,(unsigned int)cfg_event,(unsigned int)cfg_packed,cfg_busy,cfg_size,config_changes);
        for(k=0;k<NW;k++) {
                struct work_stats *s=&ws[k];const char *role=k?"tx_backend":"tx_kick";
                seq_printf(m,"WORK,%s,executed=%llu,complete=%llu,sampled=%llu,invalid=%llu,prewindow=%llu,overwritten=%llu,missing_tx=%llu,pending_at_stop=%u,executing_at_stop=%u\n",role,s->executed,s->complete,s->sampled,s->invalid,s->prewindow,s->overwritten,s->missing_tx,(unsigned int)s->pending.active,(unsigned int)s->executing.active);
                for(i=0;i<WS;i++) {
                        char path[24];snprintf(path,sizeof(path),"source_%d",i);
                        if(s->queued[i] || s->merged[i]) seq_printf(m,"QUEUE,%s,source=%d,new=%llu,merged=%llu,wake0=%llu,wake1=%llu\n",role,i,s->queued[i],s->merged[i],s->wake0[i],s->wake1[i]);
                        for(j=0;j<NWD;j++) print_dist(m,"WDIST",role,path,wn[j],&s->dist[i][j]);
                }
        }
        mutex_unlock(&control);return 0;
}
static int report_open(struct inode *inode,struct file *file) { return single_open(file,show_report,NULL); }
static ssize_t control_write(struct file *file,const char __user *u,size_t len,loff_t *pos)
{
        char b[128],op[20],tail;unsigned long long addr;int io,vh,sh,n,e=0;
        if(!len || len>=sizeof(b)) return -EINVAL;
        if(copy_from_user(b,u,len)) return -EFAULT;
        b[len]=0;mutex_lock(&control);
        if(!strcmp(strim(b),"stop")) stop_capture();
        else {
                n=sscanf(b,"%19s %d %d %d %llx %c",op,&io,&vh,&sh,&addr,&tail);
                if(n!=5 || strcmp(op,"start")) e=-EINVAL;else e=start_capture(io,vh,sh,addr);
        }
        mutex_unlock(&control);return e?e:len;
}
static const struct proc_ops ops={.proc_open=report_open,.proc_read=seq_read,.proc_write=control_write,.proc_lseek=seq_lseek,.proc_release=single_release};
static int __init r6_init(void)
{
        int i;
        for(i=0;i<NT;i++) raw_spin_lock_init(&ts[i].lock);
        for_each_possible_cpu(i) raw_spin_lock_init(&per_cpu(irqs,i).lock);
        return proc_create("r6_notify",0600,NULL,&ops)?0:-ENOMEM;
}
late_initcall(r6_init);
MODULE_LICENSE("GPL");
