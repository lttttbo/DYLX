# Monitor v4 统一测试集与需求验收

> 配置更新：当前统一使用 CONFIG_WBOXTEST_MONITOR，一个开关运行 6 个隔离用例和 3 个 Hypervisor 用例。下文 HOST/LIVE 子开关及 12 用例组合属于历史版本；当前执行步骤以 [单开关说明](monitor_one_option_v4.md) 为准。Guest 现场源码保留但本阶段不编译。

> 2026-10-25 补充：新增 HOST 子选项和 3 个 Hypervisor 内存现场用例，见 [Hypervisor 内存测试](monitor_host_memory_v4.md)。下文原 9 个用例的介绍仍适用；HOST 开启时额外加入 3 个。只开 MONITOR+HOST 共 9 个，MONITOR+LIVE+HOST 共 12 个。新增 HOST 用例的日志人工检查，不需要 Guest 用户态刺激。

日期：2026-10-25。适用前提：已完成记录版 Hypervisor/CCM 改动，monitor 只记录原有错误，不改变现有访问策略。

## 1. 结论与测试组织

隔离白盒和现有 Guest 现场用例统一注册到 `monitor` 组，共 9 个用例。它们能验证基本统计、阈值判定、记录及日志调用链路，但不能仅凭一次全部 PASS 宣称所有内存越界/越权、性能和实时性要求均已验收。

原来单列 monitor_live，是为了区分受控模拟与实机事件。合并之后继续保留这一区分作为子开关：

```text
libs/wboxtest/monitor/
    common.h, support.c
    lifecycle.c, scheduler.c, memory.c, storm.c, output.c
    objects.mk, openconf.cfg
    live/
        common.c, common.h
        scheduler.c, memory.c, storm.c
        objects.mk, openconf.cfg
```

- `CONFIG_WBOXTEST_MONITOR=y`：注册 6 个隔离用例。
- 再开启 `CONFIG_WBOXTEST_MONITOR_LIVE=y`：追加 3 个现场用例，仍属于 monitor 组。
- `monitor_live target/timeout` 及 `monitor_live_*` 用例名保留，兼容已有操作和日志工具；不再存在独立 monitor_live 测试组。
- 子开关默认关闭。现场用例会等待外部场景，调度用例会短暂制造竞争，不能作为无前置条件的自动回归。

统一入口为 `wboxtest run_groups 1 monitor`。两个开关都打开时，它会执行全部 9 个用例。未选目标、没有场景或发生超时会失败，不伪装成 PASS。用例顺序取决于注册顺序，不用于安排外部负载。

## 2. 每个用例实际证明什么

| 用例名 | 执行方式与断言 | 证明边界 |
|---|---|---|
| monitor_lifecycle | 独立实例；start/stop、重复 start、epoch、旧槽失效、退出后清理 | 证明控制逻辑，不替代真实初始化和线程调度验证 |
| monitor_config | 参数上下限、非法输入、重复配置、配置序号、简洁回显 | 证明命令解析和参数更新，不证明目标负载能产生指定退出率 |
| monitor_scheduler | 模拟 READY/SELECTED/DISPATCH 时间戳，精确核对 count/sum/max；覆盖 Guest、host、idle、重复及逆序时间 | 证明统计算法，不证明私有调度器每条路径已正确打点 |
| monitor_memory | 调用隔离副本中的真实 shmem 函数；合法访问、原越界拒绝、记录聚合、日志及 stop 后原返回值 | 假后端，不是 Guest CPU 真实越权；回绕对照只是原行为一致性验证，不是安全检查通过 |
| monitor_storm | 模拟退出数和窗口；等于门限不触发、超过门限并持续、断续超限、去重、恢复再告警、配置变化、无效窗口、多个 Guest | 证明风暴判定和去重算法，不证明真实 HVC/IRQ 等退出路径全部接入 |
| monitor_output | JSON 字段、首末时间、聚合、日志只输出一次、查询不消费历史、环满 lost 计数 | 证明缓存和日志调用；不证明日志已经持久化，也不保证每次原始错误有独立记录 |
| monitor_live_schedule | 在目标物理核运行优先级 3 的短时竞争线程，确认目标已 READY，保持约 2ms，核对 ready 增量及下限、dispatch 增量 | 证明该目标的实际 READY 路径和 dispatch 打点有统计；没有独立时钟证据逐条核验 dispatch 精确时长 |
| monitor_live_storm | 连续观察真实采样窗：低负载、持续超限、告警后继续高负载、恢复、再次超限；核对两次事件和日志回执 | 需要可控退出负载；只证明本次实际走到的退出路径和日志接口调用 |
| monitor_live_memory | 等待目标 vCPU 新产生的一条 type=3 事件，核对非空记录和日志回执 | 不主动触发错误，不限制为某一种内存错误，不足以证明全部越界/越权类别 |

这里“隔离”指使用独立 monitor 实例和受控后端，不表示只测试重新实现的算法：用例编译包含实际 monitor/shmem 实现。它仍与真实 EL2 异常和板卡运行不同。

## 3. 需求覆盖和剩余证据

| 需求 | 当前已有证据能力 | 验收还需要什么 | 当前能否仅凭测试集判定全部完成 |
|---|---|---|---|
| vCPU 就绪队列等待时间 | 隔离用例精确时间断言；现场人为增加约 2ms 等待并观察统计 | serverVM 和 Android 分别执行；复核私有 READY/出队打点定义，记录本次目标和前后计数 | 可以验证所测路径，不能推及所有调度分支 |
| vCPU 调度延迟 | 隔离用例校验 dispatch 差值；现场确认真实 dispatch 计数、累计值增加 | 对私有调度器用已有时间戳/独立 trace 核对一次相同调度区间；若要求覆盖 host/idle，也要补真实路径证据 | 部分覆盖，现场精确时长仍需对照 |
| 各域内存边界越界与越权记录 | 原 shmem 拒绝分支；已有 Stage-2 错误打点；上传 CCM 原失败分支记录；现场可观察某次真实事件 | 按下表逐项触发并辨认 code/地址/责任主体，同时做合法访问负例；不能用一条泛化事件代替 | 否，当前现场用例不覆盖全部类别 |
| 异常 exit 风暴触发日志 | 阈值、持续时间、去重、恢复再告警的白盒及现场观察 | 两个 Guest 分别提供实际高低负载；记录真实窗口；独立导出存储日志匹配事件 | 可覆盖基本链路，落盘必须另核对 |
| 代码不超过 5KB ROM | 当前用例不衡量最终固件 ROM；此前 v4 参考对象文件估算为 6553 字节，超过 5120 字节 | 同工具链/优化选项/链接布局，对比生产配置 monitor 开关的链接 map 和镜像节区；明确计入 hook、命令和常量范围，测试代码关闭；超标需优化或调整要求 | 此前参考估算未达标，不能认定已满足 |
| 无动态内存分配 | 固定采集槽和事件环；既有实现启动时创建日志工作队列 | 按已确认“允许启动创建、运行采集不分配”口径，检查热路径并跟踪分配器；测试实例和测试线程不能计入 monitor 运行分配 | 需要产品验证；若要求启动也零分配，当前内部执行器不符合该口径 |
| CPU 占用低于 0.5% | 当前用例不测生产开销 | 在产品 12 核和代表性峰值调度/退出/日志负载下做开关 A/B；计入 hook、IRQ 采样和日志，说明按单核或全机统计 | 尚无达标证明 |
| 高优先级确定性采集 | 调度/退出打点在原 HV 路径；内部采样在 timer IRQ，日志线程优先级 3 | Guest 满载、高优先级 host 活动下测采样间隔、skipped/errors、日志延迟；外部执行器由平台正确调用；约定允许的最大抖动 | 架构支持，不等于已经证明无任何干扰 |
| JSON 查询与异常结构化日志 | status/events 和日志接口；隔离输出校验、现场日志回执 | 从真实持久化存储独立导出，与串口回执按 seq/epoch/主体等匹配；检查异常时间、重复和 lost | 命令查询分支可测，持久化仍需实机 |
| virtio-serial 或共享内存上报 | 本测试集没有这两种 transport 的端到端用例 | 若验收选择“或通过命令查看”，使用现有命令链路；若要求这两种 transport 也必须可选，需另行接入和验证 | 不能声称 transport 全部实现 |
| 编译和运行时启停 | 白盒控制/配置；已有编译关闭宏检查 | 生产配置分别编译开/关，运行 start/stop/start；检查关闭后业务行为保持、没有新采集、量产不编入测试 | 基本逻辑覆盖，产品开关构建仍要验证 |

priority=3 的日志线程不需要高于 ipi=7 才能在调度路径记录 ipi 的相关信息。但高优先级活动、长时间关中断、锁争用仍可能延迟采样或日志。不能把“运行在 Hypervisor”解释成绝对不会受 Guest 所产生的系统负载影响。采样异常会通过无效窗口、skipped/errors 等反映；这些条件也属于验收观测项。

6553 字节来自此前 monitor_all_vcpus_v4_20261023/size_report.json 的 total_rom_estimate，是参考源码对象节区估算，包含打点增量，不是当前私有产品最终链接值。本包将原报告作为 historical_size_report.json 附上，不能用它替代当前版本测量，也不能忽略其超标事实。

## 4. 内存验收必须区分的场景

| 场景 | 应观察的路径 | 当前现场用例的限制 |
|---|---|---|
| 合法域内 RAM/获准的共享访问 | 原业务通过；不产生新的对应内存异常事件 | 当前 memory 用例不单独验证此负例；需限定测试时间与地址核对 |
| 原共享内存 API 判断 off/len 越界 | SHMEM_BOUNDS，code=1；原返回值仍为 0 | 该 API 的 actor 为 NULL，不能被“选定 Guest vCPU”的现场扫描匹配；用 monitor events 和独立日志核对 |
| Guest 真实访问导致 Stage-2 映射失败 | MAP_REJECT，code=2，具体含义依原异常路径 | 映射失败可能有多种原因，不能一概当成越权；须与触发地址、映射状态核对 |
| Guest 真实访问命中 Stage-2 权限拒绝 | PERMISSION，code=4；保留原异常处理 | 当前测试不会改页表或生成这种访问；需要工程允许的独立刺激与恢复流程，并分别验证两个 Guest |
| 原业务明确授权拒绝 | ACCESS_DENIED，code=3，前提是已有检查且已接入记录 | 记录版不增加授权判断；只存在枚举不代表存在可触达的实际检查 |
| CCM 读取描述符失败、注册失败 | code=5/6，调用者 vCPU 和原错误参数 | 属于既有失败结果，不自动证明跨域越权或 CPU 内存越界 |
| sbuf 原 ele_size > max_len 拒绝 | code=7；detail 高低 32 位为长度信息 | actor 为 NULL；当前选定 vCPU 的 memory 用例无法匹配，需查询事件和日志 |
| Guest 自行处理的错误、当前映射允许范围内的对象越界、原代码未检查的异常 | 不保证进入已打点的 HV 错误路径 | 不纳入“已记录所有非法访问”的结论；没有原始错误上报就不会凭空出现 monitor 事件 |

尤其注意：monitor_live_memory 当前接受 code=1..7 中实际匹配目标的一种事件。即使它 PASS，实际可能只是 code=5 的参数读取失败，而非 Stage-2 越权。因此验收报告必须写出实际 code、触发场景及覆盖类别，不能只写“内存用例 PASS”。无归属事件不可为了测试而强行绑定某个 Guest。

原共享内存检查的算术回绕场景只在假后端做行为对照；它并不构成“所有越界都被拦截/记录”的证明。产品如果已有更完整检查，保留原检查并在其失败分支记录。本次测试组织调整不引入新的安全策略。

## 5. 建议的执行顺序

### 5.1 隔离回归

打开 MONITOR，关闭 MONITOR_LIVE 子开关，运行：

```text
wboxtest group_list
wboxtest test_list
wboxtest run_groups 1 monitor
```

预期 monitor 组 6 个用例。若两个开关都打开，而本次只运行隔离部分，可明确指定：

```text
wboxtest run_tests 1 monitor_lifecycle monitor_config monitor_scheduler monitor_memory monitor_storm monitor_output
```

### 5.2 现场回归

打开两个开关，预期 monitor 组 9 个用例。先保持 VM 生命周期和映射不变，再选择全局 vCPU ID。`<id>` 必须替换成项目实际 ID，不是 Guest 内的逻辑 CPU 号：

```text
vcpu list
monitor start
monitor config
monitor_live target <id>
monitor_live timeout 90
wboxtest run_tests 1 monitor_live_schedule
wboxtest run_tests 1 monitor_live_storm
wboxtest run_tests 1 monitor_live_memory
```

逐项执行便于从另一个 Guest 控制台配合场景。准备好所有条件后也可使用统一的 run_groups 命令。

调度测试要求目标单核绑定、物理 CPU 不为 0、优先级不超过 3，Guest 有持续可运行负载。测试会短暂阻止目标核抢占约 2ms。它不改变 Guest 生命周期或产品调度优先级。

风暴测试要求 sustain_s 在 2..10，window_max_ms 不超过 2000，且开始后配置不变；阈值应位于所选负载的低高退出率之间。不是任意降低到 100 就一定满足测试，因为测试需要先建立低负载基线。按输出提示配合：低负载至少两个完整窗口；高负载直到首个事件后再保持至少 sustain_s；低负载直到恢复确认；再次高负载直到第二个事件。Guest CPU 忙循环不必然产生足够的 EL2 exit，必须看实际退出率。没有已验证的可控负载时，这一现场测试尚不能自动完成。

内存测试先启动等待，再用项目现有允许的方式触发一种确定的原错误路径；没有刺激时超时。它不新增 CCM ioctl、Guest 或错误注入。无归属的 shmem/sbuf 事件按第 4 节单独核对。

同一轮串口日志仅包含各现场用例一次成功摘要和对应回执，然后独立导出原日志后端的存储内容：

```sh
python3 tests/monitor/verify_existing_logs.py --console wboxtest.txt --stored-log stored.log
```

该工具核对两条 storm 回执、一条实际内存回执及对应存储记录，不自动核验每一条原始错误，也无法替操作人员证明文件确实来自独立存储。serverVM、Android 分别一轮并分别保存证据。统一组内额外的六条隔离摘要不影响工具匹配。

### 5.3 验收记录格式

每个需求保存：版本/配置、Guest 与 vCPU、刺激方法和时间、原业务返回或异常、对应 JSON、独立存储记录、用例结果与未覆盖项。对 CPU 延迟保存独立时间戳对照；对内存保存实际 code 和地址意义；对资源约束保存生产镜像与开销数据。

只有实际具备刺激、事件、断言和日志证据的场景才记为通过。超时、前置条件不满足、未测试都不能算通过。

## 6. 本次修改与验证边界

本次只调整测试归组、目录和配置入口，保留测试名称、命令、统计断言和现场观察行为；补齐需求覆盖说明。已合入的 Hypervisor/CCM 产品代码无需重复修改。

提供两个互斥入口：测试代码已经是记录版时用 `from_observer_tests.patch`；产品记录版已合入但测试目录还停留在 23 日版时用 `from_20261023_tests.patch`。后者同时带入此前现有 Guest 测试框架和内存隔离测试更新。两者都要求产品已经具备记录版事件定义及 23 日版只读接口。

完整文件与逐项合入位置在包内，旧目录只移除补丁列出的七个文件；不要删除用户自有文件。旧 protocol.h、live_guest 和历史校验器可归档，不参与当前现场测试。

本次本机验证详情见包内 validation：重组后 ARM64 编译、原隔离白盒及日志解析回归、补丁正反向检查。没有在你的私有固件或实际 Guest 上执行这些现场用例，因此不能报告板卡验收通过。
