"""Measure allocated ROM/RAM sections of ELF64 little-endian objects.
Does not count ELF headers, debug info or relocation records as ROM.
Usage: python elf_budget.py --limit 5120 obj1.o obj2.o ...
Exit status 1 means measured objects exceed the budget.
Final linked-image before/after comparison remains the release criterion.
"""
import argparse
import struct
from pathlib import Path

def sections(path):
    data=Path(path).read_bytes()
    if data[:6]!=b'\x7fELF\x02\x01': raise ValueError('Expected ELF64 LE: '+str(path))
    offset=struct.unpack_from('<Q',data,40)[0]
    size,count,names=struct.unpack_from('<HHH',data,58)
    headers=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*size) for i in range(count)]
    shstr=headers[names]
    strings=data[shstr[4]:shstr[4]+shstr[5]]
    for h in headers:
        name=strings[h[0]:].split(b'\0',1)[0].decode()
        if h[2]&2: yield name, h[5], h[1]==8

def totals(path):
    rom=ram=0
    for name,size,bss in sections(path):
        if bss: ram+=size
        else: rom+=size
    return rom,ram

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--limit',type=int,default=5120)
    p.add_argument('objects',nargs='+')
    args=p.parse_args()
    rom=ram=0
    for path in args.objects:
        r,b=totals(path); rom+=r; ram+=b
        print(f'{Path(path).name}: ROM={r}, BSS={b}')
    print(f'TOTAL ROM={rom}, BSS={ram}; budget={args.limit}: '+('PASS' if rom<=args.limit else 'FAIL'))
    raise SystemExit(rom>args.limit)
