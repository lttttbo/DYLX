/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef XVISOR_MONITOR_UAPI_H
#define XVISOR_MONITOR_UAPI_H
#include <linux/types.h>
#define XM_HVC_IMM 0x4d4f
#define XM_HVC_MAGIC 0x584d4f4e00000001ULL
/* Native Linux ABI: five u64 values, 40 bytes; no pointers. */
struct xm_report {
	__u64 cpu_bp, total_bytes, available_bytes, free_bytes, valid;
};
#endif
