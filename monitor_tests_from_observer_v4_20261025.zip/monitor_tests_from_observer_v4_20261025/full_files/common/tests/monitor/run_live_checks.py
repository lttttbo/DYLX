"""Host checks for inspection/evidence helpers. Does NOT execute live tests.

python3 run_live_checks.py --cc /path/to/zig --out build/live-host
"""
import argparse, json, os, re, subprocess, sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cc',required=True); p.add_argument('--out',required=True); a=p.parse_args()
    root=Path(__file__).resolve().parents[2]; out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('ZIG_GLOBAL_CACHE_DIR',str(out/'zig-cache'))
    shim=out/'include'
    for n in ['vmm_types.h','vmm_scheduler.h','vmm_manager.h','vmm_timer.h','vmm_stdio.h',
              'vmm_modules.h','vmm_smp.h','vmm_cmdmgr.h','vmm_threads.h','vmm_workqueue.h',
              'libs/stringlib.h','libs/mathlib.h','arch_barrier.h']:
        path=shim/n; path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text('#include "host.h"\n',encoding='utf-8')
    (shim/'vmm_error.h').write_text('\n'.join(s for s in (root/'core/include/vmm_error.h').read_text(encoding='utf-8').splitlines()
        if re.match(r'#define\s+VMM_\w+\s+-?\d+\s*$',s))+'\n',encoding='utf-8')
    cc=[a.cc]+(['cc'] if Path(a.cc).stem=='zig' else [])
    flags=['-std=gnu11','-O2','-Wall','-Werror','-I'+str(shim),'-I'+str(root/'tests/monitor'),'-I'+str(root/'core/include')]
    flags+=['-D'+s for s in ['CONFIG_MONITOR_AGENT=1','CONFIG_CMD_MONITOR=1','CONFIG_WBOXTEST_MONITOR=1',
        'CONFIG_MAX_VCPU_COUNT=4','CONFIG_CPU_COUNT=12','CONFIG_MONITOR_EXIT_RATE=50000','CONFIG_MONITOR_STORM_SECONDS=5','CONFIG_MONITOR_PRIORITY=3']]
    report={}
    for mode in ['internal','external','boot']:
        extra=['-DCONFIG_MONITOR_EXTERNAL_EXECUTOR=1'] if mode=='external' else ['-DCONFIG_MONITOR_START_ENABLED=1'] if mode=='boot' else []
        exe=out/(mode+'.exe')
        subprocess.run(cc+flags+extra+[str(root/'tests/monitor/test_live_inspection.c'),str(root/'commands/cmd_monitor.c'),'-o',str(exe)],check=True)
        run=subprocess.run([str(exe)],capture_output=True,text=True)
        (out/(mode+'.txt')).write_text(run.stdout+run.stderr,encoding='utf-8')
        if run.returncode: raise RuntimeError(run.stdout+run.stderr)
        report[mode]='passed'; print('PASS observer:',mode,flush=True)
    run=subprocess.run([sys.executable,str(root/'tests/monitor/test_live_log_verifier.py'),'-v'],capture_output=True,text=True)
    (out/'evidence_tests.txt').write_text(run.stdout+run.stderr,encoding='utf-8')
    if run.returncode: raise RuntimeError(run.stdout+run.stderr)
    report.update(evidence_matching_tests=8,real_guest_executed=False)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('PASS evidence matcher: 8 regression cases')

if __name__=='__main__': main()
